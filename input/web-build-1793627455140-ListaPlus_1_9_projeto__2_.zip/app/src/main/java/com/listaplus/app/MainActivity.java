package com.listaplus.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
