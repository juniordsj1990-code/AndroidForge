package com.ladderlab.simulator

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    @Volatile private var ready = false
    private val main = Handler(Looper.getMainLooper())
    private var printView: WebView? = null
    private var pendingSave = ""
    private var pendingOpen: String? = null

    private fun readIntent(i: Intent?): String? {
        val uri = i?.data ?: return null
        if (i.action != Intent.ACTION_VIEW) return null
        return contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) }
    }

    private fun deliver(view: WebView?, txt: String) {
        view?.evaluateJavascript("ldImportText(" + JSONObject.quote(txt) + ")", null)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        readIntent(intent)?.let { deliver(web, it) }
    }

    // Salvar/abrir programas em arquivo (seletor de arquivos do sistema)
    private val saveLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-ladderlab")) { uri ->
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { it.write(pendingSave.toByteArray(Charsets.UTF_8)) }
            web.evaluateJavascript("toast('Programa salvo.')", null)
        }
    }
    private val openLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val txt = contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
            web.evaluateJavascript("ldImportText(" + JSONObject.quote(txt) + ")", null)
        }
    }

    inner class FileBridge {
        @JavascriptInterface
        fun save(name: String, json: String) {
            pendingSave = json
            runOnUiThread { saveLauncher.launch(name) }
        }

        @JavascriptInterface
        fun open() {
            runOnUiThread { openLauncher.launch(arrayOf("*/*")) }
        }
    }

    /** Ponte JS -> Android: abre o diálogo de impressão do sistema (impressora ou "Salvar como PDF"). */
    inner class PrintBridge {
        @JavascriptInterface
        fun print(html: String, name: String) {
            runOnUiThread {
                val w = WebView(this@MainActivity)
                printView = w
                var done = false
                w.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        if (done) return
                        done = true
                        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                        pm.print(name, view.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
                    }
                }
                w.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)

        // A tela de carregamento fica até a página terminar de carregar (limite de 4 s).
        splash.setKeepOnScreenCondition { !ready }
        main.postDelayed({ ready = true }, 4000)

        web = WebView(this).apply {
            setBackgroundColor(0xFF000308.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    main.postDelayed({ ready = true }, 700)
                    pendingOpen?.let { deliver(view, it); pendingOpen = null }
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url ?: return false
                    if (url.toString().startsWith("file:///android_asset")) return false
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url.toString())))
                    return true
                }
            }
        }
        web.addJavascriptInterface(PrintBridge(), "AndroidPrint")
        web.addJavascriptInterface(FileBridge(), "AndroidFiles")
        setContentView(web)

        // Voltar fecha primeiro a janela do Programador/Monitor; depois sai do app.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript(
                    "(function(){var o=document.getElementById('workspaceOverlay');" +
                        "if(o&&o.classList.contains('open')){closeWorkspace();return 1}return 0})()"
                ) { r ->
                    if (r != "1") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        pendingOpen = readIntent(intent)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }
}
