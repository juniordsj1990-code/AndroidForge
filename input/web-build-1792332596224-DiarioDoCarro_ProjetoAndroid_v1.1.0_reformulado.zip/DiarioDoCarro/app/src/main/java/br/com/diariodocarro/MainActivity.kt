package br.com.diariodocarro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF0B0C0E)
private val Panel = Color(0xFF17191D)
private val Orange = Color(0xFFFF7900)
private val Muted = Color(0xFF9A9DA3)
private val categories = listOf("Manutenção preventiva", "Defeito / diagnóstico", "Peça / componente", "Documento / foto", "Modificação", "Lembrete")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent { DiaryApp(CarDatabase(this)) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiaryApp(db: CarDatabase) {
    var tab by remember { mutableStateOf("Início") }
    var vehicles by remember { mutableStateOf(db.vehicles()) }
    var activeVehicleId by remember { mutableLongStateOf(vehicles.firstOrNull()?.id ?: 0L) }
    var records by remember { mutableStateOf(if (activeVehicleId != 0L) db.all(activeVehicleId) else emptyList()) }
    var showNew by remember { mutableStateOf(false) }
    var showVehicleForm by remember { mutableStateOf(false) }
    var editingVehicle by remember { mutableStateOf<Vehicle?>(null) }
    var category by remember { mutableStateOf(categories[0]) }
    var search by remember { mutableStateOf("") }
    val activeVehicle = vehicles.firstOrNull { it.id == activeVehicleId }

    fun refreshVehicles(selectId: Long? = null) {
        vehicles = db.vehicles()
        activeVehicleId = selectId?.takeIf { id -> vehicles.any { it.id == id } } ?: activeVehicleId.takeIf { id -> vehicles.any { it.id == id } } ?: vehicles.firstOrNull()?.id ?: 0L
        records = if (activeVehicleId != 0L) db.all(activeVehicleId) else emptyList()
    }
    fun selectVehicle(id: Long) { activeVehicleId = id; records = db.all(id); search = "" }

    MaterialTheme(colorScheme = darkColorScheme(primary = Orange, onPrimary = Color.Black, background = Bg, surface = Panel, onSurface = Color.White, secondary = Orange)) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = { Column { Text("DIÁRIO DO CARRO", fontWeight = FontWeight.Bold, fontSize = 17.sp); Text(activeVehicle?.displayName ?: "Cadastre seu primeiro veículo", color = Muted, fontSize = 11.sp, maxLines = 1) } },
                    actions = { IconButton(onClick = { if (activeVehicle == null) showVehicleForm = true else showNew = true }) { Icon(Icons.Default.Add, if (activeVehicle == null) "Cadastrar veículo" else "Novo registro", tint = Orange) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg, titleContentColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Início", "Histórico", "Manutenção", "Arquivos", "Veículos").forEach { t ->
                        val ico = when (t) { "Início" -> Icons.Default.Home; "Histórico" -> Icons.Default.History; "Manutenção" -> Icons.Default.Build; "Arquivos" -> Icons.Default.Folder; else -> Icons.Default.DirectionsCar }
                        NavigationBarItem(selected = tab == t, onClick = { tab = t }, icon = { Icon(ico, t) }, label = { Text(t, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Orange, selectedTextColor = Orange, indicatorColor = Color(0xFF3A2415)))
                    }
                }
            },
            floatingActionButton = { if (activeVehicle != null && tab != "Veículos") FloatingActionButton(onClick = { showNew = true }, containerColor = Orange, contentColor = Color.Black) { Icon(Icons.Default.Add, "Registrar") } }
        ) { pad ->
            when (tab) {
                "Início" -> if (activeVehicle == null) EmptyGarage(Modifier.padding(pad), { showVehicleForm = true }) else Home(Modifier.padding(pad), activeVehicle, vehicles, ::selectVehicle, records, { tab = "Histórico" }, { showNew = true }, { tab = "Veículos" })
                "Histórico" -> if (activeVehicle == null) EmptyGarage(Modifier.padding(pad), { tab = "Veículos" }) else RecordList(Modifier.padding(pad), records, search, { search = it }, { id -> db.delete(id); records = db.all(activeVehicleId) })
                "Manutenção" -> if (activeVehicle == null) EmptyGarage(Modifier.padding(pad), { tab = "Veículos" }) else RecordList(Modifier.padding(pad), records.filter { it.category == categories[0] || it.category == categories[2] || it.category == categories[5] }, search, { search = it }, { id -> db.delete(id); records = db.all(activeVehicleId) })
                "Arquivos" -> if (activeVehicle == null) EmptyGarage(Modifier.padding(pad), { tab = "Veículos" }) else RecordList(Modifier.padding(pad), records.filter { it.category == categories[3] }, search, { search = it }, { id -> db.delete(id); records = db.all(activeVehicleId) })
                else -> VehicleManager(Modifier.padding(pad), vehicles, activeVehicleId, { editingVehicle = it; showVehicleForm = true }, { showVehicleForm = true }, { v ->
                    db.deleteVehicle(v.id); refreshVehicles();
                }, { selectVehicle(it); tab = "Início" })
            }
            if (showNew && activeVehicle != null) NewRecord(category, { category = it }, { showNew = false }, { r -> db.add(r.copy(vehicleId = activeVehicle.id)); records = db.all(activeVehicle.id); showNew = false })
            if (showVehicleForm) VehicleForm(editingVehicle, { showVehicleForm = false; editingVehicle = null }, { v ->
                if (editingVehicle == null) {
                    val id = db.addVehicle(v)
                    refreshVehicles(id)
                    tab = "Início"
                } else {
                    db.updateVehicle(v.copy(id = editingVehicle!!.id))
                    refreshVehicles(editingVehicle!!.id)
                }
                showVehicleForm = false; editingVehicle = null
            })
        }
    }
}

@Composable
private fun EmptyGarage(modifier: Modifier, onAdd: () -> Unit) {
    Column(modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(88.dp).background(Color(0xFF332114), RoundedCornerShape(28.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.DirectionsCar, null, tint = Orange, modifier = Modifier.size(46.dp)) }
        Spacer(Modifier.height(22.dp))
        Text("Comece cadastrando seu veículo", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("O nome e a quilometragem não precisam ser preenchidos toda vez que você abre o diário. Cadastre um veículo uma única vez e mantenha nele todo o histórico de manutenções, defeitos, peças e lembretes.", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))
        Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Cadastrar veículo") }
    }
}

@Composable
private fun Home(modifier: Modifier, vehicle: Vehicle, vehicles: List<Vehicle>, onSelect: (Long) -> Unit, records: List<CarRecord>, onHistory: () -> Unit, onNew: () -> Unit, onManage: () -> Unit) {
    var selectorExpanded by remember { mutableStateOf(false) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).background(Color(0xFF332114), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.DirectionsCar, null, tint = Orange, modifier = Modifier.size(30.dp)) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(vehicle.name, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Text(listOf(vehicle.make, vehicle.model, vehicle.year).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "Ficha do veículo" }, color = Muted, fontSize = 13.sp)
                            if (vehicle.plate.isNotBlank()) Text("Placa: ${vehicle.plate}", color = Muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = onManage) { Icon(Icons.Default.Edit, "Editar veículo", tint = Orange) }
                    }
                    HorizontalDivider(color = Color(0xFF303238))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("QUILOMETRAGEM ATUAL", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold); Text(if (vehicle.currentKm.isBlank()) "Não informada" else "${vehicle.currentKm} km", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold) }
                        TextButton(onClick = onManage) { Text("Atualizar", color = Orange) }
                    }
                    if (vehicles.size > 1) {
                        ExposedDropdownMenuBox(expanded = selectorExpanded, onExpandedChange = { selectorExpanded = it }) {
                            OutlinedTextField(vehicle.displayName, {}, readOnly = true, label = { Text("Veículo selecionado") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(selectorExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = selectorExpanded, onDismissRequest = { selectorExpanded = false }) { vehicles.forEach { v -> DropdownMenuItem(text = { Text(v.displayName) }, onClick = { onSelect(v.id); selectorExpanded = false }) } }
                        }
                    }
                    OutlinedButton(onClick = onManage, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.DirectionsCar, null); Spacer(Modifier.width(8.dp)); Text("Gerenciar veículos") }
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Summary("Registros", records.size.toString(), Icons.Default.History, Modifier.weight(1f)); Summary("Lembretes", records.count { it.category == categories[5] }.toString(), Icons.Default.Notifications, Modifier.weight(1f)) } }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Últimos registros", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); TextButton(onClick = onHistory) { Text("Ver todos", color = Orange) } } }
        if (records.isEmpty()) item { Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Book, null, tint = Orange, modifier = Modifier.size(38.dp)); Spacer(Modifier.height(8.dp)); Text("O histórico deste veículo está vazio", fontWeight = FontWeight.SemiBold); Text("Registre a primeira manutenção, defeito ou peça.", color = Muted); Button(onClick = onNew, colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) { Text("Criar registro") } } } }
        else items(records.take(5), key = { it.id }) { RecordCard(it) {} }
    }
}

@Composable
private fun Summary(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(icon, null, tint = Orange); Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 12.sp) } }
}

@Composable
private fun VehicleManager(modifier: Modifier, vehicles: List<Vehicle>, activeId: Long, onEdit: (Vehicle) -> Unit, onAdd: () -> Unit, onDelete: (Vehicle) -> Unit, onSelect: (Long) -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Text("Seus veículos", fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("Cada veículo tem sua própria ficha e histórico.", color = Muted) }
        item { Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Cadastrar veículo") } }
        if (vehicles.isEmpty()) item { Text("Nenhum veículo cadastrado ainda.", color = Muted) }
        items(vehicles, key = { it.id }) { v ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.DirectionsCar, null, tint = Orange, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(v.name, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text(listOf(v.make, v.model, v.year).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "Marca/modelo não informados" }, color = Muted, fontSize = 13.sp) }; if (v.id == activeId) Text("ATIVO", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    Text("${if (v.plate.isBlank()) "Sem placa informada" else "Placa: ${v.plate}"}  •  ${if (v.currentKm.isBlank()) "KM não informada" else "${v.currentKm} km"}", color = Muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { if (v.id != activeId) OutlinedButton(onClick = { onSelect(v.id) }, modifier = Modifier.weight(1f)) { Text("Selecionar") }; OutlinedButton(onClick = { onEdit(v) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(5.dp)); Text("Editar") }; if (vehicles.size > 1) IconButton(onClick = { onDelete(v) }) { Icon(Icons.Default.DeleteOutline, "Excluir veículo", tint = Muted) } }
                }
            }
        }
        item { Text("Atenção: excluir um veículo também apaga os registros associados a ele.", color = Muted, fontSize = 12.sp) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VehicleForm(existing: Vehicle?, onDismiss: () -> Unit, onSave: (Vehicle) -> Unit) {
    var name by remember(existing) { mutableStateOf(existing?.name ?: "") }
    var make by remember(existing) { mutableStateOf(existing?.make ?: "") }
    var model by remember(existing) { mutableStateOf(existing?.model ?: "") }
    var year by remember(existing) { mutableStateOf(existing?.year ?: "") }
    var plate by remember(existing) { mutableStateOf(existing?.plate ?: "") }
    var km by remember(existing) { mutableStateOf(existing?.currentKm ?: "") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Cadastrar veículo" else "Editar veículo") }, text = {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 520.dp)) {
            item { Text("Informe apenas os dados que desejar. Nome do veículo é o único campo obrigatório.", color = Muted, fontSize = 12.sp) }
            item { OutlinedTextField(name, { name = it }, label = { Text("Nome do veículo * (ex.: Doblò) ") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(make, { make = it }, label = { Text("Marca (ex.: Fiat)") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(model, { model = it }, label = { Text("Modelo / versão") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(year, { year = it }, label = { Text("Ano / modelo") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(plate, { plate = it.uppercase(Locale.ROOT) }, label = { Text("Placa (opcional)") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(km, { km = it.filter(Char::isDigit) }, label = { Text("Quilometragem atual (opcional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth()) }
        }
    }, confirmButton = { Button(enabled = name.isNotBlank(), onClick = { onSave(Vehicle(name = name.trim(), make = make.trim(), model = model.trim(), year = year.trim(), plate = plate.trim(), currentKm = km.trim())) }, colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) { Text("Salvar veículo") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }, containerColor = Panel)
}

@Composable
private fun RecordList(modifier: Modifier, records: List<CarRecord>, search: String, onSearch: (String) -> Unit, onDelete: (Long) -> Unit) {
    val filtered = records.filter { it.title.contains(search, true) || it.details.contains(search, true) || it.category.contains(search, true) }
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(search, onSearch, modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), singleLine = true, label = { Text("Buscar no histórico") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        if (filtered.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nenhum registro encontrado", color = Muted) }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) { items(filtered, key = { it.id }) { r -> RecordCard(r) { onDelete(r.id) } } }
    }
}

@Composable
private fun RecordCard(r: CarRecord, onDelete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.size(42.dp).background(Color(0xFF332114), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(when (r.category) { categories[0] -> Icons.Default.Build; categories[1] -> Icons.Default.Warning; categories[2] -> Icons.Default.Settings; categories[3] -> Icons.Default.Description; categories[4] -> Icons.Default.DirectionsCar; else -> Icons.Default.Notifications }, null, tint = Orange) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(r.title, fontWeight = FontWeight.SemiBold); Text(r.category, color = Orange, fontSize = 11.sp)
                Text("${r.date}${if (r.mileage.isNotBlank()) " • ${r.mileage} km" else ""}", color = Muted, fontSize = 12.sp)
                if (r.details.isNotBlank()) Text(r.details, color = Color(0xFFD0D2D5), fontSize = 13.sp, maxLines = 4)
                if (r.reminderDate.isNotBlank() || r.reminderKm.isNotBlank()) Text("Lembrete: ${r.reminderDate.ifBlank { "sem data" }}${if (r.reminderKm.isNotBlank()) " • ${r.reminderKm} km" else ""}", color = Orange, fontSize = 11.sp)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, "Excluir", tint = Muted) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewRecord(category: String, onCategory: (String) -> Unit, onDismiss: () -> Unit, onSave: (CarRecord) -> Unit) {
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date())) }
    var km by remember { mutableStateOf("") }; var details by remember { mutableStateOf("") }
    var reminderDate by remember { mutableStateOf("") }; var reminderKm by remember { mutableStateOf("") }; var expanded by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Novo registro") }, text = {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 500.dp)) {
            item { ExposedDropdownMenuBox(expanded, { expanded = it }) { OutlinedTextField(category, {}, readOnly = true, label = { Text("Categoria") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth()); ExposedDropdownMenu(expanded, { expanded = false }) { categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { onCategory(c); expanded = false }) } } } }
            item { OutlinedTextField(title, { title = it }, label = { Text("Título / serviço") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(date, { date = it }, label = { Text("Data (dd/mm/aaaa)") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(km, { km = it.filter(Char::isDigit) }, label = { Text("Quilometragem no registro (opcional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(details, { details = it }, label = { Text("Detalhes, sintomas, peças, solução...") }, minLines = 3, modifier = Modifier.fillMaxWidth()) }
            item { Text("Lembrete opcional", color = Orange, fontWeight = FontWeight.SemiBold) }
            item { OutlinedTextField(reminderDate, { reminderDate = it }, label = { Text("Data do lembrete") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(reminderKm, { reminderKm = it.filter(Char::isDigit) }, label = { Text("Quilometragem do lembrete") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth()) }
        }
    }, confirmButton = { Button(enabled = title.isNotBlank(), onClick = { onSave(CarRecord(category = category, title = title.trim(), date = date.trim(), mileage = km.trim(), details = details.trim(), reminderDate = reminderDate.trim(), reminderKm = reminderKm.trim())) }, colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) { Text("Salvar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }, containerColor = Panel)
}
