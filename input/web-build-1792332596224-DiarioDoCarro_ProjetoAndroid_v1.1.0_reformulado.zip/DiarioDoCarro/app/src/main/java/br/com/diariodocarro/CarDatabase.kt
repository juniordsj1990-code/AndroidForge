package br.com.diariodocarro

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Vehicle(
    val id: Long = 0,
    val name: String,
    val make: String = "",
    val model: String = "",
    val year: String = "",
    val plate: String = "",
    val currentKm: String = ""
) {
    val displayName: String get() = listOf(name, if (make.isNotBlank() || model.isNotBlank()) "$make $model".trim() else "").filter { it.isNotBlank() }.joinToString(" • ")
}

data class CarRecord(
    val id: Long = 0,
    val category: String,
    val title: String,
    val date: String,
    val mileage: String,
    val details: String,
    val reminderDate: String = "",
    val reminderKm: String = "",
    val vehicleId: Long = 1
)

class CarDatabase(context: Context) : SQLiteOpenHelper(context, "diario_do_carro.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE vehicles (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, make TEXT NOT NULL DEFAULT '', model TEXT NOT NULL DEFAULT '', year TEXT NOT NULL DEFAULT '', plate TEXT NOT NULL DEFAULT '', currentKm TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE records (id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, title TEXT NOT NULL, date TEXT NOT NULL, mileage TEXT NOT NULL DEFAULT '', details TEXT NOT NULL DEFAULT '', reminderDate TEXT NOT NULL DEFAULT '', reminderKm TEXT NOT NULL DEFAULT '', vehicleId INTEGER NOT NULL DEFAULT 1)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS vehicles (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, make TEXT NOT NULL DEFAULT '', model TEXT NOT NULL DEFAULT '', year TEXT NOT NULL DEFAULT '', plate TEXT NOT NULL DEFAULT '', currentKm TEXT NOT NULL DEFAULT '')")
            db.execSQL("INSERT INTO vehicles(name) VALUES ('Meu veículo')")
            db.execSQL("ALTER TABLE records ADD COLUMN vehicleId INTEGER NOT NULL DEFAULT 1")
        }
    }
    fun addVehicle(v: Vehicle): Long {
        val values = ContentValues().apply {
            put("name", v.name); put("make", v.make); put("model", v.model); put("year", v.year); put("plate", v.plate); put("currentKm", v.currentKm)
        }
        return writableDatabase.insert("vehicles", null, values)
    }
    fun updateVehicle(v: Vehicle) {
        val values = ContentValues().apply {
            put("name", v.name); put("make", v.make); put("model", v.model); put("year", v.year); put("plate", v.plate); put("currentKm", v.currentKm)
        }
        writableDatabase.update("vehicles", values, "id=?", arrayOf(v.id.toString()))
    }
    fun vehicles(): List<Vehicle> {
        val out = mutableListOf<Vehicle>()
        readableDatabase.rawQuery("SELECT id,name,make,model,year,plate,currentKm FROM vehicles ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) out += Vehicle(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getString(6))
        }
        return out
    }
    fun deleteVehicle(id: Long) {
        writableDatabase.delete("records", "vehicleId=?", arrayOf(id.toString()))
        writableDatabase.delete("vehicles", "id=?", arrayOf(id.toString()))
    }
    fun add(r: CarRecord) {
        val v = ContentValues().apply {
            put("category", r.category); put("title", r.title); put("date", r.date)
            put("mileage", r.mileage); put("details", r.details)
            put("reminderDate", r.reminderDate); put("reminderKm", r.reminderKm); put("vehicleId", r.vehicleId)
        }
        writableDatabase.insert("records", null, v)
    }
    fun all(vehicleId: Long): List<CarRecord> {
        val out = mutableListOf<CarRecord>()
        readableDatabase.rawQuery("SELECT id,category,title,date,mileage,details,reminderDate,reminderKm,vehicleId FROM records WHERE vehicleId=? ORDER BY id DESC", arrayOf(vehicleId.toString())).use { c ->
            while (c.moveToNext()) out += CarRecord(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getString(6), c.getString(7), c.getLong(8))
        }
        return out
    }
    fun delete(id: Long) { writableDatabase.delete("records", "id=?", arrayOf(id.toString())) }
}
