# Diário do Carro — versão 1.1.0

Projeto Android em Kotlin + Jetpack Compose, com tema escuro e banco de dados local SQLite.

## Reformulação nesta versão
- O aplicativo não pede mais nome e quilometragem diretamente na tela inicial.
- Cadastro de veículos separado, com nome obrigatório e marca, modelo, ano, placa e quilometragem opcionais.
- Lista de veículos cadastrados, seleção do veículo ativo, edição da ficha e exclusão com confirmação textual no app.
- Histórico, manutenção, documentos, lembretes e registros são filtrados por veículo.
- Cada novo registro fica associado ao veículo selecionado.
- Migração do banco de dados: instalações antigas preservam os registros existentes e os associam a um veículo inicial chamado “Meu veículo”.
- Dados continuam armazenados localmente no aparelho.

## Abrir e compilar
Extraia o ZIP e abra a pasta `DiarioDoCarro` no Android Studio ou importe-a no AndroidForge. A configuração usa Android Gradle Plugin 8.7.3, Gradle 8.9, Kotlin 2.1.20 e compileSdk 35. O Android SDK Platform 35 precisa estar instalado no ambiente.

## Observação
A estrutura e as alterações de código foram preparadas, mas a compilação Android não pôde ser executada neste ambiente. Compile com `assembleDebug` no AndroidForge e, se houver erro, envie o log gerado para a próxima correção.
