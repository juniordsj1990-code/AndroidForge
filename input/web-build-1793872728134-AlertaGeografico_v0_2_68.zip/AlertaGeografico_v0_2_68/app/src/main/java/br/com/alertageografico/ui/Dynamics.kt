package br.com.alertageografico.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import br.com.alertageografico.R
import java.util.Locale

/** Brilho que percorre o bloco: indica "carregando/aguardando" sem parecer travado. */
@Composable
fun Modifier.shimmer(shape: Shape = RoundedCornerShape(8.dp)): Modifier {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val x by transition.animateFloat(
        initialValue = -1f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmerX"
    )
    val base = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
    val high = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.20f)
    val brush = Brush.horizontalGradient(
        colors = listOf(base, high, base),
        startX = 400f * x,
        endX = 400f * x + 400f
    )
    return this.background(brush, shape)
}

@Composable
fun ShimmerBlock(width: Dp, height: Dp, modifier: Modifier = Modifier) {
    Box(modifier.size(width, height).shimmer())
}

/**
 * Cartão com gesto de deslizar: direita = ação 1 (ex.: pausar/ativar), esquerda = ação 2 (ex.: excluir).
 * O cartão sempre volta à posição; quem decide o que muda é o chamador (lista/estado).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeActionBox(
    startToEndLabel: String,
    startToEndIcon: Int,
    endToStartLabel: String,
    endToStartIcon: Int,
    onStartToEnd: () -> Unit,
    onEndToStart: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    content: @Composable () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val startAction by rememberUpdatedState(onStartToEnd)
    val endAction by rememberUpdatedState(onEndToStart)
    val state = rememberSwipeToDismissBoxState(
        confirmValueChange = { value ->
            when (value) {
                SwipeToDismissBoxValue.StartToEnd -> {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    startAction()
                }
                SwipeToDismissBoxValue.EndToStart -> {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    endAction()
                }
                else -> Unit
            }
            false
        }
    )
    SwipeToDismissBox(
        state = state,
        modifier = modifier,
        backgroundContent = {
            val direction = state.dismissDirection
            val scheme = MaterialTheme.colorScheme
            val target = when (direction) {
                SwipeToDismissBoxValue.StartToEnd -> scheme.secondaryContainer
                SwipeToDismissBoxValue.EndToStart -> scheme.errorContainer
                else -> Color.Transparent
            }
            val color by animateColorAsState(target, tween(180), label = "swipeBg")
            val toEnd = direction == SwipeToDismissBoxValue.StartToEnd
            Box(
                Modifier.fillMaxSize().clip(shape).background(color).padding(horizontal = 22.dp),
                contentAlignment = if (toEnd) Alignment.CenterStart else Alignment.CenterEnd
            ) {
                if (direction != SwipeToDismissBoxValue.Settled) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (toEnd) {
                            AgIcon(startToEndIcon, size = 22.dp, tint = scheme.onSecondaryContainer)
                            Text(startToEndLabel, style = MaterialTheme.typography.labelLarge, color = scheme.onSecondaryContainer)
                        } else {
                            Text(endToStartLabel, style = MaterialTheme.typography.labelLarge, color = scheme.onErrorContainer)
                            AgIcon(endToStartIcon, size = 22.dp, tint = scheme.onErrorContainer)
                        }
                    }
                }
            }
        }
    ) { content() }
}

/** Ponto que "respira" para marcar a parada atual. */
@Composable
private fun PulsingDot(color: Color, size: Dp) {
    val transition = rememberInfiniteTransition(label = "stopPulse")
    val scale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "stopPulseScale"
    )
    Box(Modifier.size(size).graphicsLayer { scaleX = scale; scaleY = scale }.background(color, CircleShape))
}

@Composable
private fun RouteStopRow(name: String, index: Int, current: Int, last: Int, onClick: () -> Unit) {
    // 0 = concluída, 1 = atual, 2 = futura
    val state = when {
        index < current -> 0
        index == current -> 1
        else -> 2
    }
    val scheme = MaterialTheme.colorScheme
    val dotColor by animateColorAsState(
        when (state) {
            0 -> scheme.primary.copy(alpha = 0.55f)
            1 -> scheme.primary
            else -> scheme.outline
        },
        tween(400), label = "stopDotColor"
    )
    val dotSize by animateDpAsState(if (state == 1) 14.dp else 10.dp, tween(400), label = "stopDotSize")
    val label = when {
        state == 0 -> "Concluída"
        index == last -> "Parada Final"
        state == 1 -> "Próx. Baldeação"
        else -> "Em seguida"
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(18.dp), contentAlignment = Alignment.Center) {
            when (state) {
                0 -> AgIcon(R.drawable.ic_ui_check, size = 16.dp, tint = dotColor)
                1 -> PulsingDot(dotColor, dotSize)
                else -> Box(Modifier.size(dotSize).background(dotColor, CircleShape))
            }
        }
        Column(Modifier.weight(1f)) {
            Text(
                name,
                style = if (state == 1) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge,
                color = if (state == 0) scheme.onSurfaceVariant else scheme.onSurface,
                textDecoration = if (state == 0) TextDecoration.LineThrough else null,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(label, style = MaterialTheme.typography.labelSmall, color = if (state == 1) scheme.primary else scheme.onSurfaceVariant)
        }
    }
}

/** Linha do tempo do roteiro em andamento: paradas concluídas, a atual e as seguintes. */
@Composable
fun RouteStopsCard(
    routeName: String,
    stops: List<String>,
    currentIndex: Int,
    onStopClick: (Int) -> Unit,
    modifier: Modifier = Modifier,
    onClose: (() -> Unit)? = null
) {
    var showAll by rememberSaveable { mutableStateOf(false) }
    val last = stops.lastIndex
    val done = currentIndex.coerceIn(0, stops.size)
    val fraction by animateFloatAsState(
        targetValue = if (stops.isEmpty()) 0f else done.toFloat() / stops.size,
        animationSpec = tween(600, easing = FastOutSlowInEasing),
        label = "routeFraction"
    )
    val collapsible = stops.size > 7
    val visible: List<Int> = if (!collapsible || showAll) stops.indices.toList()
    else listOf(done - 1, done, done + 1, done + 2, last).filter { it in 0..last }.distinct().sorted()
    Card(
        modifier = modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AgIcon(R.drawable.ic_ui_route, size = 20.dp, tint = MaterialTheme.colorScheme.primary)
                Column(Modifier.weight(1f)) {
                    Text(routeName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "$done de ${stops.size} paradas · toque numa parada para pular ou voltar",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50))
            )
            visible.forEachIndexed { pos, index ->
                if (pos > 0) {
                    val hidden = index - visible[pos - 1] - 1
                    if (hidden > 0) {
                        Text(
                            "⋯ $hidden parada(s)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 30.dp)
                        )
                    }
                }
                RouteStopRow(stops[index], index, done, last) { onStopClick(index) }
            }
            if (collapsible) {
                TextButton(onClick = { showAll = !showAll }) {
                    Text(if (showAll) "Mostrar menos" else "Ver todas as ${stops.size} paradas")
                }
            }
            if (onClose != null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onClose) { Text("Fechar") }
                }
            }
        }
    }
}

/** Trilha esquemática da viagem: nós = paradas, preenchida até onde a viagem chegou. */
@Composable
fun TripMiniTrail(reached: Int, total: Int, modifier: Modifier = Modifier) {
    val nodes = total.coerceIn(2, 10)
    val fraction = if (total <= 0) 0f else (reached.toFloat() / total).coerceIn(0f, 1f)
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val animated by animateFloatAsState(
        targetValue = if (go) fraction else 0f,
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "tripTrail"
    )
    val track = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
    val fill = MaterialTheme.colorScheme.primary
    Canvas(modifier.fillMaxWidth().height(18.dp)) {
        val pad = 8.dp.toPx()
        val y = size.height / 2f
        val w = size.width - 2 * pad
        val stroke = 3.dp.toPx()
        drawLine(track, Offset(pad, y), Offset(pad + w, y), strokeWidth = stroke, cap = StrokeCap.Round)
        if (animated > 0f) drawLine(fill, Offset(pad, y), Offset(pad + w * animated, y), strokeWidth = stroke, cap = StrokeCap.Round)
        for (i in 0 until nodes) {
            val f = i / (nodes - 1f)
            val reachedNode = f <= animated + 0.001f && (animated > 0f || i == 0 && reached > 0)
            drawCircle(
                color = if (reachedNode) fill else track,
                radius = if (reachedNode) 5.dp.toPx() else 4.dp.toPx(),
                center = Offset(pad + w * f, y)
            )
        }
    }
}

private fun formatKm(meters: Int): String =
    if (meters >= 1000) String.format(Locale("pt", "BR"), "%.1f km", meters / 1000.0) else "$meters m"

private fun formatDuration(minutes: Int): String =
    if (minutes < 60) "$minutes min" else if (minutes % 60 == 0) "${minutes / 60} h" else "${minutes / 60} h ${minutes % 60} min"

@Composable
private fun SummaryNumber(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Resumo geral do histórico; os números "rolam" até o valor ao abrir a tela. */
@Composable
fun HistorySummaryCard(totalTrips: Int, doneTrips: Int, totalMeters: Int, totalMinutes: Int, modifier: Modifier = Modifier) {
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val trips by animateIntAsState(if (go) totalTrips else 0, tween(800, easing = FastOutSlowInEasing), label = "sumTrips")
    val done by animateIntAsState(if (go) doneTrips else 0, tween(800, easing = FastOutSlowInEasing), label = "sumDone")
    val meters by animateIntAsState(if (go) totalMeters else 0, tween(1000, easing = FastOutSlowInEasing), label = "sumMeters")
    val minutes by animateIntAsState(if (go) totalMinutes else 0, tween(1000, easing = FastOutSlowInEasing), label = "sumMinutes")
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp, horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            SummaryNumber("$trips", if (trips == 1) "viagem" else "viagens", Modifier.weight(1f))
            SummaryNumber("$done", if (done == 1) "concluída" else "concluídas", Modifier.weight(1f))
            SummaryNumber(formatKm(meters), "percorridos", Modifier.weight(1f))
            SummaryNumber(formatDuration(minutes), "em viagem", Modifier.weight(1f))
        }
    }
}
