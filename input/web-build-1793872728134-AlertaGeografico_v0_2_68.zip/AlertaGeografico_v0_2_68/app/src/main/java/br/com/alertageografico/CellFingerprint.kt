package br.com.alertageografico

/**
 * Impressão digital de estação por torres de celular (sem Wi-Fi): em cada chegada confirmada por GPS,
 * guarda quais torres atendiam o aparelho naquela estação. Em túnel (sem GPS), se a torre atual é uma
 * das que costumam atender a estação-alvo (e não a anterior), a chegada é reconhecida.
 * Os dados ficam só neste aparelho e entram no aprendizado a cada viagem.
 */
class CellFingerprint {
    private val stations = LinkedHashMap<String, LinkedHashMap<String, Int>>()
    var dirty = false
        private set

    fun consumeDirty(): Boolean { val d = dirty; dirty = false; return d }

    /** Registra as torres vistas numa chegada confirmada à estação [stationId]. */
    fun observe(stationId: String, cells: Set<String>) {
        if (cells.isEmpty()) return
        val known = stations.getOrPut(stationId) { LinkedHashMap() }
        for (cell in cells) known[cell] = (known[cell] ?: 0) + 1
        // Mantém só as torres mais vistas, para o arquivo e a comparação não crescerem sem limite.
        if (known.size > MAX_CELLS_PER_STATION) {
            val keep = known.entries.sortedByDescending { it.value }.take(MAX_CELLS_PER_STATION)
            known.clear()
            keep.forEach { known[it.key] = it.value }
        }
        while (stations.size > MAX_STATIONS) stations.remove(stations.keys.first())
        dirty = true
    }

    /** Verdadeiro se alguma das torres atuais já atendeu a estação em pelo menos [MIN_SEEN] chegadas. */
    fun matches(stationId: String, cells: Set<String>): Boolean {
        val known = stations[stationId] ?: return false
        return cells.any { (known[it] ?: 0) >= MIN_SEEN }
    }

    fun serialize(): String {
        val sb = StringBuilder()
        for ((id, cells) in stations) {
            sb.append(id).append('|')
            sb.append(cells.entries.joinToString(";") { "${it.key}=${it.value}" }).append('\n')
        }
        return sb.toString()
    }

    fun load(text: String?) {
        stations.clear()
        if (text.isNullOrBlank()) return
        for (line in text.lines()) {
            val parts = line.split('|')
            if (parts.size != 2 || parts[0].isBlank()) continue
            val cells = LinkedHashMap<String, Int>()
            for (item in parts[1].split(';')) {
                val kv = item.split('=')
                val n = kv.getOrNull(1)?.toIntOrNull()
                if (kv.size == 2 && kv[0].isNotBlank() && n != null) cells[kv[0]] = n
            }
            if (cells.isNotEmpty()) stations[parts[0]] = cells
        }
        dirty = false
    }

    companion object {
        const val MIN_SEEN = 2
        private const val MAX_CELLS_PER_STATION = 12
        private const val MAX_STATIONS = 400
    }
}
