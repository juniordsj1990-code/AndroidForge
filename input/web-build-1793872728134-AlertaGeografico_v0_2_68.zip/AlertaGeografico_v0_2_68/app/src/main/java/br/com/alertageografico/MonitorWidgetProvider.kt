package br.com.alertageografico

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import java.util.Locale

/**
 * Widget da tela inicial: próxima parada (ou destino), distância, tempo estimado e progresso do roteiro.
 * Só lê o painel que o serviço de monitoramento já grava; não usa GPS nem altera alertas.
 * O serviço chama [refreshAll] quando o painel muda; sem widget na tela, a chamada não faz nada.
 */
class MonitorWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val views = runCatching { build(context) }.getOrNull() ?: return
        appWidgetManager.updateAppWidget(appWidgetIds, views)
    }

    companion object {
        /** Atualiza todos os widgets colocados na tela (se houver). */
        fun refreshAll(context: Context) {
            runCatching {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, MonitorWidgetProvider::class.java))
                if (ids.isEmpty()) return
                manager.updateAppWidget(ids, build(context))
            }
        }

        private fun formatDistance(meters: Int): String =
            if (meters >= 1000) String.format(Locale("pt", "BR"), "%.1f km", meters / 1000.0) else "$meters m"

        private fun formatMinutes(minutes: Int): String =
            if (minutes < 60) "$minutes min" else if (minutes % 60 == 0) "${minutes / 60} h" else "${minutes / 60} h ${minutes % 60} min"

        private fun build(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_monitor)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            views.setOnClickPendingIntent(
                R.id.widget_root,
                PendingIntent.getActivity(
                    context, 10,
                    Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    flags
                )
            )
            views.setViewVisibility(R.id.widget_skip, View.GONE)

            if (!DestinationStore.monitoringActive(context)) {
                views.setTextViewText(R.id.widget_overline, "Alerta Geográfico")
                views.setTextViewText(R.id.widget_title, "Monitoramento parado")
                views.setTextViewText(R.id.widget_status, "Toque para abrir o app")
                views.setViewVisibility(R.id.widget_metrics, View.GONE)
                views.setViewVisibility(R.id.widget_progress, View.GONE)
                return views
            }

            val prefs = context.getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
            val routeMode = DestinationStore.monitorMode(context) == "route"
            val itinerary = DestinationStore.activeItinerary(context)
            val target = prefs.getString(DestinationStore.KEY_DASH_TARGET, null)?.takeIf { it.isNotBlank() }
            val next = prefs.getString(DestinationStore.KEY_DASH_NEXT, null)?.takeIf { it.isNotBlank() }
            val distance = prefs.getInt(DestinationStore.KEY_DASH_DISTANCE, -1)
            val etaMin = prefs.getInt(DestinationStore.KEY_DASH_ETA_MIN, -1)
            val etaMax = prefs.getInt(DestinationStore.KEY_DASH_ETA_MAX, -1)
            val gapSeconds = prefs.getInt(DestinationStore.KEY_DASH_GAP_SECONDS, 0)
            val progress = prefs.getFloat(DestinationStore.KEY_DASH_ROUTE_PROGRESS, 0f).coerceIn(0f, 1f)

            val stops = if (routeMode) {
                DestinationStore.orderedItineraryStops(context, DestinationStore.load(context), itinerary)
            } else emptyList()
            val index = DestinationStore.itineraryIndex(context)
            val concluded = routeMode && next == "Roteiro concluído"
            val nextIsFinal = routeMode && stops.isNotEmpty() && index == stops.lastIndex

            val overline = when {
                !routeMode -> "Destino"
                concluded -> "Roteiro"
                nextIsFinal -> "Parada Final"
                else -> "Próx. Baldeação"
            } + (if (routeMode && !itinerary.isNullOrBlank()) " · $itinerary" else "")
            val title = when {
                concluded -> "Roteiro concluído"
                routeMode -> next ?: "—"
                else -> target ?: next ?: "—"
            }
            views.setTextViewText(R.id.widget_overline, overline)
            views.setTextViewText(R.id.widget_title, title)

            val hasDistance = distance >= 0 && !concluded
            views.setViewVisibility(R.id.widget_metrics, if (concluded) View.GONE else View.VISIBLE)
            views.setTextViewText(R.id.widget_distance, if (hasDistance) formatDistance(distance) else "—")
            views.setTextViewText(
                R.id.widget_eta,
                when {
                    etaMin == 0 && etaMax == 0 -> "No raio"
                    etaMin > 0 && etaMax > etaMin -> "${formatMinutes(etaMin)}–${formatMinutes(etaMax)}"
                    etaMin > 0 -> formatMinutes(etaMin)
                    else -> ""
                }
            )
            views.setTextViewText(
                R.id.widget_status,
                when {
                    concluded -> "Todas as paradas concluídas"
                    gapSeconds > 0 -> "Sem GPS há ${if (gapSeconds >= 60) "${gapSeconds / 60} min" else "$gapSeconds s"} — tempo estimado"
                    !hasDistance -> "Aguardando sinal do GPS…"
                    else -> "Monitorando"
                }
            )

            if (routeMode && !concluded && stops.size > 1) {
                views.setViewVisibility(R.id.widget_progress, View.VISIBLE)
                views.setProgressBar(R.id.widget_progress, 100, (progress * 100).toInt(), false)
            } else {
                views.setViewVisibility(R.id.widget_progress, View.GONE)
            }

            // Mesma ação da notificação: pula a próxima parada (a final não pode ser pulada).
            if (routeMode && !concluded && stops.isNotEmpty() && index < stops.lastIndex) {
                views.setViewVisibility(R.id.widget_skip, View.VISIBLE)
                views.setOnClickPendingIntent(
                    R.id.widget_skip,
                    PendingIntent.getService(
                        context, 11,
                        Intent(context, LocationMonitorService::class.java).setAction(LocationMonitorService.ACTION_SKIP_STOP),
                        flags
                    )
                )
            }
            return views
        }
    }
}
