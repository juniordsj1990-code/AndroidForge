package br.com.alertageografico

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CellFingerprintTest {
    @Test
    fun matchesOnlyAfterSeenTwice() {
        val fp = CellFingerprint()
        fp.observe("a", setOf("L1:10"))
        assertFalse(fp.matches("a", setOf("L1:10")))
        fp.observe("a", setOf("L1:10"))
        assertTrue(fp.matches("a", setOf("L1:10", "L1:99")))
        assertFalse(fp.matches("b", setOf("L1:10")))
    }

    @Test
    fun serializeRoundTrip() {
        val fp = CellFingerprint()
        repeat(2) { fp.observe("a", setOf("L1:10", "G5:7")) }
        val copy = CellFingerprint()
        copy.load(fp.serialize())
        assertTrue(copy.matches("a", setOf("G5:7")))
    }
}
