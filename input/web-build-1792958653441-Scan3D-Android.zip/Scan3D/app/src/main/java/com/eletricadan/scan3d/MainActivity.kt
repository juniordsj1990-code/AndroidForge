package com.eletricadan.scan3d

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {
    private lateinit var wv: WebView
    private var cb: ValueCallback<Array<Uri>>? = null
    private var camUri: Uri? = null

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        var res: Array<Uri>? = null
        val d = r.data
        if (r.resultCode == RESULT_OK) {
            val clip = d?.clipData
            res = when {
                clip != null -> Array(clip.itemCount) { clip.getItemAt(it).uri }
                d?.data != null -> arrayOf(d.data!!)
                camUri != null -> arrayOf(camUri!!)
                else -> null
            }
        }
        val fromCamera = res?.let { it.size == 1 && it[0] == camUri } == true
        if (!fromCamera) camUri?.let { runCatching { contentResolver.delete(it, null, null) } }
        cb?.onReceiveValue(res)
        cb = null
        camUri = null
    }

    inner class Bridge {
        @JavascriptInterface
        fun saveStl(b64: String, name: String) {
            val ok = try {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(u)!!.use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
                true
            } catch (e: Exception) { false }
            runOnUiThread {
                Toast.makeText(this@MainActivity, if (ok) "Salvo em Downloads: $name" else "Falha ao salvar o STL", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wv = WebView(this)
        setContentView(wv)
        ViewCompat.setOnApplyWindowInsetsListener(wv) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.mediaPlaybackRequiresUserGesture = false
        wv.addJavascriptInterface(Bridge(), "AndroidBridge")
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, callback: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                cb?.onReceiveValue(null)
                cb = callback
                val video = p.acceptTypes.any { it.startsWith("video") }
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "scan_" + System.currentTimeMillis())
                }
                camUri = contentResolver.insert(
                    if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv
                )
                val cam = Intent(if (video) MediaStore.ACTION_VIDEO_CAPTURE else MediaStore.ACTION_IMAGE_CAPTURE)
                    .putExtra(MediaStore.EXTRA_OUTPUT, camUri)
                val chooser = Intent.createChooser(p.createIntent(), "Selecionar")
                    .putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(cam))
                launcher.launch(chooser)
                return true
            }
        }
        wv.loadUrl("https://appassets.androidplatform.net/assets/scan3d.html")
    }
}
