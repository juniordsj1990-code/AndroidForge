/* Adaptações para rodar o QuadroDoc dentro do WebView do Android */
(function () {
  if (!window.AndroidBridge) return;

  /* 1) Persistência nativa (sem limite de cota do localStorage) */
  var isNativeKey = function (k) { return /^quadrodoc_/.test(String(k)); };
  var origGet = Storage.prototype.getItem;
  var origSet = Storage.prototype.setItem;
  var origRemove = Storage.prototype.removeItem;
  Storage.prototype.getItem = function (k) {
    if (this === window.localStorage && isNativeKey(k)) {
      var v = AndroidBridge.getItem(String(k));
      return (v === null || v === undefined) ? null : v;
    }
    return origGet.call(this, k);
  };
  Storage.prototype.setItem = function (k, v) {
    if (this === window.localStorage && isNativeKey(k)) {
      AndroidBridge.setItem(String(k), String(v));
      return;
    }
    return origSet.call(this, k, v);
  };
  Storage.prototype.removeItem = function (k) {
    if (this === window.localStorage && isNativeKey(k)) {
      AndroidBridge.setItem(String(k), '');
      return;
    }
    return origRemove.call(this, k);
  };

  /* 2) Downloads (JSON, PNG, PDF) -> "Salvar como" nativo */
  var blobs = new Map();
  var origCreate = URL.createObjectURL;
  URL.createObjectURL = function (b) {
    var u = origCreate.call(URL, b);
    if (b instanceof Blob) blobs.set(u, b);
    return u;
  };
  function toBase64(blob) {
    return new Promise(function (resolve) {
      var r = new FileReader();
      r.onload = function () { resolve(String(r.result).split(',')[1] || ''); };
      r.readAsDataURL(blob);
    });
  }
  async function handleDownload(a) {
    var share = !!window.__shareNext;
    window.__shareNext = false;
    var href = a.href;
    var name = a.getAttribute('download') || 'arquivo';
    var blob = blobs.get(href);
    if (!blob) blob = await (await fetch(href)).blob();
    var b64 = await toBase64(blob);
    var mime = blob.type || 'application/octet-stream';
    if (share) AndroidBridge.shareFile(name, mime, b64);
    else AndroidBridge.saveFile(name, mime, b64);
  }
  var isDownloadAnchor = function (el) {
    return el instanceof HTMLAnchorElement && el.hasAttribute('download');
  };
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (isDownloadAnchor(this)) { handleDownload(this); return; }
    return origClick.call(this);
  };
  var origDispatch = EventTarget.prototype.dispatchEvent;
  EventTarget.prototype.dispatchEvent = function (ev) {
    if (ev && ev.type === 'click' && isDownloadAnchor(this)) { handleDownload(this); return true; }
    return origDispatch.call(this, ev);
  };

  /* 3) Toque: arrastar marcadores/pontas (o app original usa só eventos de mouse) */
  var style = document.createElement('style');
  style.textContent = '.marker,.tipDot{touch-action:none;-webkit-user-select:none;user-select:none;}' +
    '#canvasArea img{-webkit-touch-callout:none;}';
  document.head.appendChild(style);

  function fire(type, target, t) {
    target.dispatchEvent(new MouseEvent(type, {
      bubbles: true, cancelable: true, view: window,
      clientX: t.clientX, clientY: t.clientY, screenX: t.screenX, screenY: t.screenY, button: 0
    }));
  }
  var active = null;
  document.addEventListener('touchstart', function (e) {
    var el = e.target.closest && e.target.closest('.marker,.tipDot');
    if (!el || e.touches.length !== 1) return;
    var t = e.touches[0];
    active = { el: el, moved: false, x: t.clientX, y: t.clientY };
    e.preventDefault();
    fire('mousedown', el, t);
  }, { passive: false });
  document.addEventListener('touchmove', function (e) {
    if (!active) return;
    var t = e.touches[0];
    if (Math.abs(t.clientX - active.x) + Math.abs(t.clientY - active.y) > 6) active.moved = true;
    e.preventDefault();
    fire('mousemove', document, t);
  }, { passive: false });
  function end(e) {
    if (!active) return;
    var t = (e.changedTouches && e.changedTouches[0]) || { clientX: active.x, clientY: active.y };
    e.preventDefault();
    fire('mouseup', document, t);
    if (!active.moved && e.type === 'touchend') active.el.click(); /* toque simples = editar marcador */
    active = null;
  }
  document.addEventListener('touchend', end, { passive: false });
  document.addEventListener('touchcancel', end, { passive: false });

  /* 4) Zoom por pinça na foto (arrastar com 1 dedo move a foto ampliada) */
  document.addEventListener('DOMContentLoaded', function () {
    var area = document.getElementById('canvasArea');
    if (!area) return;
    var zs = document.createElement('style');
    zs.textContent = '#canvasArea.zoomed img{width:100%;max-width:none;}';
    document.head.appendChild(zs);

    var view = document.createElement('div');
    view.id = 'zoomView';
    view.style.cssText = 'overflow:auto;max-width:100%;touch-action:pan-x pan-y;border-radius:6px;';
    area.parentNode.insertBefore(view, area);
    view.appendChild(area);

    var scale = 1, baseW = 0, pinch = null, lastPinch = 0;

    function setScale(s, fx, fy) {
      s = Math.min(6, Math.max(1, s));
      var oldW = area.offsetWidth, oldH = area.offsetHeight;
      var cx = (view.scrollLeft + fx) / oldW, cy = (view.scrollTop + fy) / oldH;
      if (scale === 1 && s > 1) baseW = oldW;
      scale = s;
      if (scale === 1) {
        area.classList.remove('zoomed');
        area.style.width = '';
        area.style.maxWidth = '';
        view.style.maxHeight = '';
        return;
      }
      area.classList.add('zoomed');
      area.style.maxWidth = 'none';
      area.style.width = (baseW * scale) + 'px';
      view.style.maxHeight = '75vh';
      view.scrollLeft = cx * area.offsetWidth - fx;
      view.scrollTop = cy * area.offsetHeight - fy;
    }
    function dist(t) { return Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY); }
    function focal(t) {
      var r = view.getBoundingClientRect();
      return { x: (t[0].clientX + t[1].clientX) / 2 - r.left, y: (t[0].clientY + t[1].clientY) / 2 - r.top };
    }

    view.addEventListener('touchstart', function (e) {
      if (e.touches.length === 2) {
        pinch = { d: dist(e.touches), s: scale };
        lastPinch = Date.now();
      }
    }, { passive: true });
    view.addEventListener('touchmove', function (e) {
      if (!pinch || e.touches.length !== 2) return;
      e.preventDefault();
      var f = focal(e.touches);
      setScale(pinch.s * dist(e.touches) / pinch.d, f.x, f.y);
      lastPinch = Date.now();
    }, { passive: false });
    function endPinch(e) {
      if (e.touches.length < 2) pinch = null;
      lastPinch = Date.now();
    }
    view.addEventListener('touchend', endPinch, { passive: true });
    view.addEventListener('touchcancel', endPinch, { passive: true });
    /* evita abrir "novo marcador" por engano logo após a pinça */
    view.addEventListener('click', function (e) {
      if (Date.now() - lastPinch < 350) { e.stopPropagation(); e.preventDefault(); }
    }, true);
  });
})();
