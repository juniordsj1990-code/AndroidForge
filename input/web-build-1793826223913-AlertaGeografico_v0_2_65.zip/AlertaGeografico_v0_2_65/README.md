# Alerta Geográfico — versão 0.2.65

## Mais precisão em túnel / sem GPS (0.2.65)

- **Velocidade aprendida do trecho + última velocidade:** em roteiro de trem/metrô, quando o trecho entre duas paradas já foi aprendido, o estimador mistura a velocidade de cruzeiro dele à velocidade ao vivo. O peso cresce com o número de viagens (n ÷ (n + 3)) e nunca passa de 50%. Sem trecho aprendido, nada muda. Como a estimativa sem GPS parte dessa velocidade, a contagem no túnel também usa a mistura.
- **Correção no aprendizado:** o tempo dentro de túnel (lacuna sem GPS de 90 s a 10 min, já em movimento) agora conta como movimento do trecho. Antes ficava de fora e a velocidade aprendida de trechos com túnel saía alta demais.
- **Reconhecimento por torre de celular (sem Wi-Fi):** a cada chegada confirmada por GPS o app guarda as torres que atendiam a estação (`cell_fingerprints.txt`, só no aparelho). Sem GPS, se a torre atual já atendeu a estação-alvo em 2 ou mais chegadas, não atende a parada anterior e a leitura se repete 2 vezes seguidas, a chegada é reconhecida e o alerta dispara, desde que a janela de tempo estimada esteja a até 150 s. Só aprende onde há GPS na estação.
- A projeção ao longo da linha já existia quando a malha ferroviária está importada (distância "rail"); sem a malha ela cai para a trilha aprendida ou a linha reta.
- `versionCode` 63, `versionName` 0.2.65.


## Paradas do roteiro em popup (0.2.64)

O card "Roteiro" deixou de ocupar espaço na tela Início. A lista de paradas agora abre em um popup ao tocar na **barra de progresso** do cartão principal (com o aviso "Ver paradas" ao lado da legenda). O conteúdo é o mesmo: paradas concluídas, atual e seguintes, com toque numa parada para **Ir para esta parada** ou **Voltar para esta**, e botão **Fechar**. A barra só é tocável em roteiro em andamento. `versionCode` 62, `versionName` 0.2.64.


## Dinâmica e interação (0.2.63)

Camada visual e de interação; a lógica de GPS, ETA e disparo de alertas não mudou. Componentes novos em `ui/Dynamics.kt`.

- **Roteiro na tela Início:** card com todas as paradas (concluídas riscadas, atual pulsando como "Próx. Baldeação", última como "Parada Final"). Tocar numa parada oferece **Ir para esta parada** (pular) ou **Voltar para esta**; o pedido vai ao serviço (`ACTION_SET_STOP`), que reposiciona o roteiro e zera o motor de proximidade. Com mais de 7 paradas o card mostra só as próximas, com "Ver todas".
- **Gestos:** destinos individuais — deslizar para a direita pausa/ativa, para a esquerda exclui com **Desfazer**. Paradas de roteiro — segurar e arrastar reordena (as setas ↑ ↓ continuam).
- **Notificação fixa:** barra de progresso do roteiro e ação **Pular parada** (`ACTION_SKIP_STOP`; a parada final não pode ser pulada). O alerta (notificação e pop-up) ganhou a mesma ação: "Pular próxima" na chegada, "Pular esta" no aviso de aproximação.
- **Transição entre seções:** o conteúdo novo entra com fade e leve deslize.
- **Aguardando GPS:** brilho (shimmer) no lugar do "—" de distância e tempo enquanto monitora sem leitura válida.
- **Pop-up de alerta:** entrada animada, anéis pulsando atrás do ícone, distância que "rola" até o valor e relógio "Alerta há m:ss".
- **Histórico:** resumo geral no topo (viagens, concluídas, distância, tempo), trilha esquemática por viagem (paradas alcançadas) e detalhes ao tocar (início/fim, velocidade média). Não grava o trajeto de GPS, então não há mini-mapa real.
- `versionCode` 61, `versionName` 0.2.63.


## Tela Início mais dinâmica (0.2.62)

Só camada visual (`ui/Components.kt` e a tela Início); serviço, GPS, cálculos e alertas não mudaram.

- **Números animados:** a distância "rola" até o novo valor (800 ms) em vez de saltar; o tempo estimado troca com fade e deslize; a barra de progresso do roteiro desliza.
- **Toque no tempo estimado:** alterna entre "daqui a X min" e o **horário previsto de chegada** ("chegada prevista"). Só aparece quando há estimativa; no raio ou sem dados não faz nada.
- **Linha do tempo viva:** os pontos mudam de cor/tamanho com transição, o ponto da estação atual pulsa e o nome da estação desliza ao trocar.
- **Retorno tátil** ao iniciar/parar o monitoramento e ao alternar o horário.
- **Sem monitoramento:** o cartão principal fica enxuto (sem "—" de distância/tempo e sem o texto "Monitoramento parado"); o card de Estações só aparece monitorando e entra animado. Avisos reais de `status` (ex.: "Selecione um roteiro…") continuam aparecendo. O "Mostrar mais/menos" também anima.
- `versionCode` 60, `versionName` 0.2.62.


## "Próx. Baldeação" e "Parada Final" (0.2.61)

Só texto, sem mudança de lógica. Em roteiro, o rótulo "Próxima parada" passa a ser **Próx. Baldeação** enquanto houver mais paradas à frente e **Parada Final** quando a próxima já é a última do sentido. Vale na notificação fixa (antes "Última parada"), no cartão da tela Início (título, legenda da distância) e nos textos de ajuda. Destino único, nomes dos áudios e tela de Estações ficam como estavam. `versionCode` 59, `versionName` 0.2.61.


## "Sem GPS" falso e confiança baixa demais (0.2.58)

- **Bug da 0.2.54:** o limite para declarar "sem GPS" era no máximo 20 s, mas o intervalo pedido ao provedor chega a 30–120 s (economia, parado, longe do alvo). O silêncio normal entre leituras era tratado como perda de sinal (aviso falso e, em tese, alerta estimado antecipado). Agora o limite é 2,5 × o maior entre o intervalo observado e o pedido (mínimo 8 s), ex.: 12,5 s com 5 s de intervalo, 300 s com 120 s.
- **Confiança baixa:** parada de 10 s ou mais (estação, semáforo) virava "baixa confiança"; agora segue "Parado — mantendo a última estimativa" por até 3 min. O corte de precisão do ETA subiu de 50 m para 80 m (erro de 80 m pesa pouco em distâncias de quilômetros).
- Testes novos: limite com intervalo pedido, parada de 60 s continua PAUSED, fix de 70 m ainda dá estimativa NORMAL. `versionCode` 56, `versionName` 0.2.58.


## Final de cada sentido antes de iniciar o roteiro (0.2.57)

Na seleção do roteiro, os botões **Ida** e **Volta** voltam a mostrar só o nome (a 0.2.59 removeu o "até X" dos botões). Abaixo deles, um resumo do sentido selecionado: "começa em A e termina em Z • N paradas" (respeita "Pular parada inicial"). Só exibição: a ordem e o comportamento do roteiro não mudam. `versionCode` 55, `versionName` 0.2.57 (botões simplificados na 0.2.59, `versionCode` 57).


## "Sem caminho ferroviário confiável" (0.2.56)

Diagnóstico feito sobre o `TRAÇADOS.geojson` real (34 linhas, 390 estações, metrô e CPTM de SP), reproduzindo a regra de grafo do app:
- Os dados do OSM trazem **uma via por sentido, sem ligação entre elas**: 366 das 390 estações têm 2 ou mais vias não conectadas a até 40 m; 207 pedaços soltos somam 163 km (18,6%), quase todos a menos de 30 m do trilho principal; as linhas 1 a 6 do metrô são ilhas separadas do bloco CPTM.
- O app encaixava o usuário numa via (desde a 0.2.53, pelo rumo) e o destino na mais próxima, **cada um sozinho**. Com erro lateral de GPS de ~12 m, só **80%** dos pares caíam na mesma via; os outros 20% não tinham caminho e voltavam à linha reta, intermitente.

**Correção:** `loadNetwork` calcula as componentes conectadas do grafo; `snapCandidates` devolve o melhor segmento de cada via a até 60 m da mais próxima (máx. 5), com a mesma pontuação de antes (distância + rumo + continuidade da linha); `SnapPairing.bestConnectedPair` escolhe o par (usuário, alvo) **na mesma componente** de menor custo. Sem par conectado, a distância continua em linha reta, mas agora só quando as vias realmente não se ligam nos dados (ex.: metrô x CPTM). Nenhum dado é alterado e nenhuma ligação artificial é criada. Na simulação com o seu arquivo: 80% → 100% (caminho encontrado quando as vias existem).
Testes: `SnapPairingTest`. `versionCode` 54, `versionName` 0.2.56.


## Estação atual ao sair da plataforma (0.2.55)

- **Causa:** em movimento, a "estação atual" era a última estação deixada para trás e só trocava quando a próxima entrava nos 150 m. Por isso a estação já deixada seguia como atual por todo o trecho.
- **Agora** (`StationSequence`, lógica pura com testes): a estação só é "atual" na plataforma (≤ 150 m em movimento, ≤ 220 m parado, para absorver deriva do GPS) e se não estiver ficando para trás (> 40 m atrás no sentido da viagem, em movimento). Fora disso o app está **em trânsito**: `current` fica nulo, a anterior é a última deixada e a próxima é a primeira à frente. A sequência vale nos dois sentidos da linha e usa o último sentido conhecido quando o rumo some (parado/GPS ruim).
- **Telas:** o card de estações mostra "Em trânsito — Entre as estações" no lugar da atual; a notificação mostra "Entre A e B" (ou "Próxima estação: B"); a tela Estações mostra "EM TRÂNSITO". Sem sentido de viagem conhecido, mantém o comportamento antigo (mais próxima como atual).
- `versionCode` 53, `versionName` 0.2.55.


## Túneis, avisos tardios e faixa do ETA (0.2.54)

Correções a partir do teste real da 0.2.53 (não avisava em túnel, avisava tarde ou já no centro do raio, faixa do ETA larga).

**Causas encontradas e corrigidas**
- **O relógio de "sem GPS" era zerado por leituras inúteis.** Em túnel o provedor continua entregando leituras com erro de centenas de metros (ou reentrega a última posição conhecida). Agora só conta como sinal a leitura com erro ≤ 100 m e idade ≤ 15 s (`DeadReckoning`); o limite de "sem GPS" é ~3 intervalos observados, entre 8 e 20 s (antes: 20 s ou 3× o intervalo configurado, até minutos).
- **A base da estimativa era sobrescrita por leituras ruins.** A última estimativa NORMAL de uma leitura boa agora é a única base; leituras LOW/indisponíveis do túnel não a apagam mais (antes, o dead-reckoning ficava desativado na prática).
- **O alerta estimado agora sai da janela absoluta de chegada** do estimador (já com dwell das estações e variação de velocidade), usando a chegada MAIS CEDO plausível recuada até o raio efetivo: avisa antes, não depois de descer. Estimativas em linha reta (janela até a borda do raio) recuam só a diferença.
- **O fix anterior do motor** (segmento do cruzamento do raio) agora é sempre o último fix utilizável: uma leitura ruim no meio não anula mais a detecção de cruzamento. Lacuna máxima do segmento: 90 s.
- **GPS de alta precisão mais cedo**: em aproximação (≤ max(2 km, 2 min de viagem)) e em movimento, o app já pede alta precisão para o receptor estar "quente" antes de túneis/estações cobertas. (O intervalo continua seguindo as regras anteriores.)
- **Kalman**: ruído de processo contínuo (incerteza ~dt³, não dt⁴), sem explodir em lacunas.

**Faixa min–max do ETA**
- Faixa a priori mais estreita: ±4% perto até ±14% a 20 min (antes ±12% a ±40%), com pouco peso para a variação de velocidade.
- Arredondamento ao minuto mais próximo (antes: mínimo para baixo e máximo para cima, somando até 2 min à faixa). Quando min e máx coincidem, o painel mostra um valor só ("4 min") em vez de "4–4 min".
- Calibração por viagens reais com quantis 20–80% (antes 15–85%), limites 0,70–1,05 e 0,95–1,60, a partir de 6 amostras (antes 8). Total do roteiro: −7%/+12% sobre os trechos seguintes (antes −12%/+20%).

Testes novos: cruzamento com leitura ruim no meio, alerta de túnel antes da chegada (janela do estimador + `DeadReckoning`), faixa de 10 min e arredondamento. `versionCode` 52, `versionName` 0.2.54. Lógica pura compilada e testada em JVM (o serviço/UI/Gradle seguem sem compilação aqui, sem Android SDK).


## Precisão de localização e estimativa de tempo (0.2.53)

Correções da auditoria da 0.2.52.

**Localização e alertas**
- **Cruzamento do raio entre fixes** (`ProximityEngine`): além do ponto atual, testa se o segmento entre o fix anterior e o atual passa dentro do raio (fix com tempo monotônico, lacuna ≤ 90 s, salto fisicamente possível). O aviso por distância do ônibus usa o mesmo teste.
- **Raio efetivo** = `max(raio, velocidade × 25 s)`, teto de 1000 m; com aviso por distância (ônibus) fica abaixo de 60% dele, para os dois alertas continuarem separados. O rearme usa o raio do disparo (histerese), então frear no trânsito não repete o alerta.
- **Filtro de Kalman** (`PositionFilter`): velocidade constante por eixo, ruído vindo do `accuracy`, velocidade/rumo Doppler como segunda medição, trava em parada (velocidade ~0) e descarte de saltos por Mahalanobis (recomeça após 3 descartes ou lacuna > 2 min). Alimenta motor de alertas, ETA e estações; leituras > 150 m não entram no filtro.
- **Tempo do fix** por `elapsedRealtimeNanos` (`FixTime.kt`) em motor, ETA e rumo.
- **Snap nos trilhos com rumo**: `distanceAlongRailMeters` passa a pontuar distância + alinhamento do segmento com o rumo + continuidade da linha anterior (como `locate()`).
- **Intervalo por velocidade**: "perto" = `max(1000 m, v × 60 s)`; o intervalo nunca passa de 1/3 do tempo até a borda do raio efetivo (`recommendedIntervalMs(borda, v)`, em degraus de 3/5/8/12/20/30/45/60 s, com histerese de 15 s).
- **Sem GPS (túnel/subsolo)**: após 20 s (ou 3 intervalos) o painel e a notificação mostram "Sem GPS há X s"; se o último movimento era real (≥ 4 m/s), a distância avança por dead-reckoning (cruzeiro, descontando dwell das estações intermediárias) e o alerta de chegada "estimado — sem GPS" dispara ao atingir o raio (o motor marca o destino como alertado, sem repetir quando o sinal volta).

**Tempo estimado**
- **Lag do suavizador corrigido**: o EMA agora desconta o tempo decorrido entre fixes antes de misturar a nova medida.
- **ETA como janela absoluta de chegada**: em perda de GPS a contagem continua; em parada operacional (estação) a janela é empurrada. Novo estado `no_gps`.
- **Faixa calibrada** (`EtaCalibrator`): registra previsto × real em cada chegada e usa os quantis 15%/85% por tipo e horizonte (≥ 8 amostras, salvo em `eta_calibration.txt`). Sem amostras, faixa a priori de ±12% (perto) a ±40% (20 min), alargada pela variação de velocidade.
- **Dwell por estação**: estações intermediárias entre a posição e o alvo (contadas na linha atual) somam o dwell aprendido ao tempo.
- **Tempo até a parada final do roteiro por trecho** (`TravelModel`): ETA ao vivo da próxima parada + Σ (distância do trecho ÷ cruzeiro aprendido + dwell aprendido); sem histórico do trecho, usa o cruzeiro ao vivo e o dwell médio do tipo (padrão 30 s trem, 15 s ônibus). Aprende a cada chegada de parada (`travel_model.txt`; viagens simuladas não entram).
- **Ônibus**: velocidade média ponderada pelo tempo em 4 min, incluindo paradas, sem piso de cruzeiro.
- **Trilha das viagens concluídas** (`LearnedTrack`/`TrackStore`): grava a trilha ao concluir (não simulada; ≥ 300 m) e, sem malha ferroviária, mede a distância ao longo dela (painel: "pela trilha da viagem anterior"). Descarta se o usuário está a > 60 m da trilha, o alvo ficou para trás ou o resultado destoa da linha reta.

**Limpeza**: removidos `confirmFixes`/`streak` (código morto) do motor. Testes novos: `PositionFilterTest`, `OfflineEtaEstimatorTest`, `LearnedModelsTest` e casos novos em `ProximityEngineTest`.
`versionCode` 51, `versionName` 0.2.53. A lógica pura foi compilada e testada em JVM; o serviço, a UI e o Gradle não foram compilados aqui (sem Android SDK).


## Cadastro em passos, viagem rápida, histórico e simulador (0.2.52)

- **Adicionar destino em 3 passos** (Local, Tipo e raio, Alertas) com indicador de progresso e validação a cada passo. Coordenadas manuais ficam recolhidas no passo 1.
- **Busca com sugestões**: enquanto digita (≥3 letras, 0,7 s sem digitar) aparecem até 5 locais do Geocoder; tocar numa sugestão preenche local, coordenadas e nome.
- **Favoritos e recentes** na viagem rápida (Destino único): estrela nos destinos; tocar num favorito/recente reativa o destino e inicia o monitoramento na hora. `Destination` ganhou `favorite` e `lastUsedAt` (compatível com dados antigos).
- **Atalhos**: atalho estático no ícone do app (`res/xml/shortcuts.xml`) e bloco nas configurações rápidas (`QuickTripTileService`), ambos abrem o Destino único (`MainActivity.ACTION_QUICK_TRIP`). O bloco mostra "Monitorando" e abre a confirmação de parada quando já há monitoramento.
- **Histórico de viagens** (`TripHistory`, `Trip`): registrado pelo serviço (início, paradas alcançadas, distância, concluída/interrompida, simulada); tela "Histórico" no menu, limpar com confirmação; últimas 60 viagens, entram no backup.
- **Preferências → Avançado** (recolhido): modo alarme, canal de áudio, música tocando, onde tocar e **simulador de trajeto** (`TripSimulator`): sem GPS, o serviço gera posições a partir de 1,5 km antes do destino (ou da primeira parada restante do roteiro), velocidade ajustável (10 a 300 km/h). Aviso no Início e "simulação" na notificação.
- **Snackbar** para todas as mensagens de status.
- **Ícones padronizados**: emojis substituídos por vetores (`ic_pick_*` para destinos/roteiros, `ic_ui_*` para a interface), com biblioteca `ui/AppIcons` que converte os emojis salvos antes (destinos, roteiros, backups).
- **Pop-up de alerta** redesenhado: ícone grande, cor por tipo (azul trem/metrô, laranja ônibus), distância que falta e selo de parada final.
- Testes novos: `TripSimulatorTest`. `versionCode` 50, `versionName` 0.2.52. Não compilado aqui.

# Versão 0.2.51

## Início guiado, destino único e sons padrão (0.2.51)

- Ao abrir o app sem monitoramento ativo (e depois da tela de abertura) aparece **"O que deseja fazer?"**: **Destino único**, **Roteiro** ou **Continuar para o app**. Aparece uma vez por abertura.
- **Destino único** (antes "Destino individual", renomeado em toda a interface; o valor interno `individual` continua o mesmo para não quebrar dados e backups): abre o cadastro em modo viagem rápida, sem seletor de roteiro/CSV, nome opcional, e o botão **Salvar e iniciar monitoramento** já inicia o monitoramento (pede permissões se faltarem). O destino é salvo com "alertar só uma vez".
- **Roteiro**: lista os roteiros cadastrados; ao escolher, seleciona o roteiro no Início para iniciar. Sem roteiros, abre o cadastro de paradas.
- **Sons padrão incluídos** (`res/raw`): `desembarque_proxima_parada.mp3` (trem/metrô e ônibus no raio) e `atencao_alerta_geografico.mp3` (ônibus, aviso por distância). Valem enquanto o usuário não escolher outro; Preferências → Sons → "Restaurar sons padrão do app" volta a eles. Quem já tinha escolhido o som geral antigo mantém essa escolha.
- `versionCode` 49, `versionName` 0.2.51. Não compilado aqui.

# Versão 0.2.50

## Preferências, Ajuda e Sobre (0.2.50)

- **Preferências** redesenhadas no estilo das configurações do Android: grupos (Alertas, Sons, Saída de áudio, Monitoramento e bateria, Mapa, Dados e permissões) com linhas de título + valor atual, interruptores e escolhas em diálogo. Novos componentes em `ui/Components.kt` (`SettingsGroup`, `SettingsSwitchRow`, `SettingsValueRow`, `SettingsSliderRow`, `SettingsChoiceDialog`). O alerta antecipado passou a ser uma lista de minutos (0 = desativado).
- **Ajuda** reescrita em tópicos recolhíveis, com as novidades e todos os recursos até a 0.2.50.
- **Sobre** atualizado (recursos atuais, permissões do pop-up, crédito da voz do áudio final).
- `versionCode` 48, `versionName` 0.2.50. Não compilado aqui.

# Versão 0.2.49

## Fim de percurso, pop-up e comentários (0.2.49)

- **Áudio de percurso concluído** (`res/raw/percurso_concluido.mp3`): toca ao terminar o alerta sonoro da parada final (esse alerta toca uma vez, sem repetir). Preferências → "Áudio de percurso concluído" desliga. Tocar em OK/Soneca antes do fim cancela o áudio.
- **Parada automática**: ao chegar na parada final (último ponto do roteiro, ou destino individual) o GPS é desligado na hora, o painel marca monitoramento parado e a notificação fixa some em 5 s. O serviço só fica vivo além disso enquanto o áudio final ainda toca (limite de 30 s).
- **Forma de exibir o alerta**: Preferências → Notificação (como antes) ou Pop-up na tela, com OK, Soneca 5 min e Abrir app. Para abrir sobre outros apps pede "Exibir sobre outros apps"; sem a permissão, só abre sobre a tela bloqueada (e a notificação continua como apoio).
- **Última parada**: quando a próxima parada já é a final, a notificação fixa mostra "Última parada: X" uma vez só, sem a linha repetida de parada final.
- **Comentário curto por parada** (até 80 caracteres): cadastro, edição e CSV (coluna opcional `comentario`). Aparece só em Roteiros e Destinos cadastrados, nunca no painel.
- `versionCode` 47, `versionName` 0.2.49. Não compilado aqui.

# Versão 0.2.48

## Tipo de transporte e sons por tipo (0.2.48)

- Cada destino agora é **Trem/Metrô** ou **Ônibus** (cadastro e edição). Destinos antigos contam como Trem/Metrô.
- Ao escolher o tipo, o raio é preenchido automaticamente: **300 m** para trem/metrô e **60 m** para ônibus (continua editável).
- Preferências → "Som por tipo de transporte": um som para trem/metrô e dois para ônibus (**aviso por distância** e **chegada no raio**), cada um com botão Testar. Enquanto um tipo não tiver som próprio, vale o som geral antigo.
- Ônibus tem o campo "Aviso por distância (m)" (padrão 300 m, sempre maior que o raio): toca uma vez ao cruzar essa distância e de novo ao entrar no raio.
- O alerta por tempo estimado (ETA) usa o som de trem/metrô para trem e o som de distância para ônibus, e não consome mais o "alertar só uma vez".
- A importação CSV aceita a coluna opcional `tipo` (`onibus`/`trem`); sem ela, importa como trem/metrô.
- `versionCode` 46, `versionName` 0.2.48. Ainda não compilado/testado em aparelho real.

# Alerta Geográfico — versão 0.2.43

## Correção de áudio (0.2.43)

- O modo de saída por fones deixa de forçar `setPreferredDevice` para um dispositivo Bluetooth/cabeado específico; o Android seleciona a rota ativa. Isso evita uma rota preferida incompatível que pode iniciar o player sem som audível.
- O modo AudioTrack verifica inicialização, escrita de amostras e estado de reprodução; falhas são registradas e acionam o tom de emergência.
- Atualizados `versionCode` para 41 e `versionName` para 0.2.43.
- A correção ainda precisa ser validada em aparelho real, principalmente com fone Bluetooth.

# Alerta Geográfico — versão 0.2.18

## Alterações da versão 0.2.18

- A Ajuda foi ampliada com instruções sobre importação dos dados do Overpass Turbo, identificação estimada das estações, camadas do mapa e limitações do cálculo ferroviário.
- A tela Sobre agora explica a origem dos dados ferroviários, a atribuição ao OpenStreetMap/ODbL, o uso do mapa base OpenFreeMap e o armazenamento local dos arquivos GeoJSON.
- Preferências ganhou o atalho “Gerenciar permissões”, que abre a página de informações do aplicativo nas configurações do Android para revisar permissões.
- Preferências ganhou controles para escolher se linhas ferroviárias e estações aparecem por padrão no mapa.
- As escolhas de visibilidade são persistidas e sincronizadas entre os controles da tela Preferências e os controles dentro do mapa.


Aplicativo Android nativo em Kotlin + Jetpack Compose para cadastrar destinos e emitir alertas locais quando o aparelho entra no raio configurado.

## Alterações da versão 0.2.17

- Distância até um destino passa a usar o caminho mais curto conectado na malha ferroviária importada do OpenStreetMap quando tanto a posição GPS quanto o destino podem ser associados aos trilhos.
- O cálculo considera os segmentos e as curvas dos trilhos, conectando os pontos do GeoJSON por suas coordenadas. Os traçados sem nome também são usados para o cálculo, mesmo que não possam identificar nominalmente uma linha.
- A Central de Monitoramento identifica quando a distância exibida foi calculada pela malha ferroviária. Se não houver trilhos próximos ou não existir caminho conectado, usa distância em linha reta como alternativa.
- O painel de estações também pode exibir a distância estimada pelos trilhos até a próxima estação.
- A lógica de alertas por proximidade continua usando a distância geográfica até o raio configurado, para não alterar o momento em que o alerta de entrada deve disparar.
- A distância ferroviária é uma estimativa: não restringe o cálculo por linha/operadora ou sentido operacional, e pode escolher uma conexão errada em malhas paralelas/ramificadas se os dados OSM não distinguirem esses caminhos. O tempo de chegada também permanece estimado.

## Alterações da versão 0.2.16

- Painel de monitoramento distingue o destino final do roteiro da próxima parada pendente.
- Distância e tempo estimado identificam explicitamente a próxima parada no modo de roteiro.
- Após concluir todas as paradas, o destino final continua visível e o painel informa que o roteiro foi concluído.

## Alterações da versão 0.2.15
- O mapa agora desenha as linhas/trechos ferroviários importados por GeoJSON e atribui cores por nome/referência quando os dados permitem.
- Estações são exibidas como marcadores clicáveis; tocar em um marcador mostra o nome e, quando disponíveis, a operadora e a referência da linha.
- O painel “Camadas ferroviárias” permite ocultar ou exibir as linhas e as estações independentemente.
- Os dados são lidos do armazenamento local do aparelho; não é feita uma nova consulta ao Overpass para desenhar o mapa.
- O importador aceita geometrias de estação em área e trechos ferroviários sem nome para exibição no mapa. A navegação/ordenação offline continua dependendo de dados de estações e linhas que possam ser interpretados pelo algoritmo.

## Alterações da versão 0.2.14
- A Central de Monitoramento usa um único botão dinâmico: “Iniciar monitoramento” quando parado e “Parar monitoramento” quando ativo.
- A Central mostra estação anterior, atual estimada e próxima estação quando os arquivos GeoJSON de estações e linhas estão importados.
- Durante o monitoramento, o serviço recalcula a sequência ferroviária com cada posição GPS válida. Ao iniciar no meio do percurso, a posição atual é usada para se localizar na sequência, sem contar as estações desde o início do monitoramento.
- A navegação por estações mantém os dados GeoJSON analisados em memória, reduzindo leituras repetidas dos arquivos durante o monitoramento.
- A identificação permanece estimada: qualidade/cobertura dos dados, linhas paralelas, ramificações, baixa precisão do GPS e túneis podem afetar o resultado.

## Incluído nesta versão
- Cadastro manual de destinos por latitude/longitude.
- Ícone personalizável por roteiro, salvo independentemente dos ícones das paradas e preservado ao renomear o roteiro.
- Busca de local por nome ou endereço, preenchendo as coordenadas encontradas automaticamente.
- Cada destino pode ter um nome legível para o local/endereço, armazenado junto às coordenadas.
- Ícone selecionável por destino, com opções visuais para casa, trabalho, posto, compras, saúde, escola, alimentação, estacionamento e outros locais.
- Na edição, endereço/local fica em destaque; coordenadas ficam em uma área avançada e podem ser atualizadas pela busca de endereço.
- Tela de mapa integrada com marcadores e círculos que mostram o raio de alerta de cada destino.
- Botão “Ver no mapa” em cada destino cadastrado, além de “Ver todos no mapa”.
- Cadastro de destino único ou criação de roteiro: informe o mesmo nome de roteiro ao adicionar cada parada; o mapa conecta os pontos na ordem cadastrada.
- Ícone do aplicativo personalizado com o ícone fornecido.
- Importação em lote por arquivo CSV, usando o seletor de arquivos Android.
- Validação de latitude, longitude, raio e campos obrigatórios.
- Opção de ignorar destinos duplicados por nome + coordenadas aproximadas.
- Monitoramento iniciado/interrompido manualmente por serviço em primeiro plano (com ação "Parar" na notificação).
- Notificação e vibração configuráveis.
- Seleção de ponto por toque no mapa, com retorno automático das coordenadas ao formulário.
- Escolha de saída de áudio (fone ou alto-falante), volume próprio e **modo alarme** (toca como alarme, repetindo até confirmar).
- Persistência local dos destinos em SharedPreferences (JSON).
- Lógica de alerta ao entrar no raio; rearma após sair do raio acrescido de margem.
- Destinos de **alerta único**: são desativados automaticamente após o primeiro alerta.

## Ainda não incluído
- Roteiro sequencial (armar só a próxima parada), soneca e alerta por tempo estimado de chegada.
- Tela de edição de destinos e de reordenação/renomeação de roteiros.
- Integração com Home Assistant.
- Histórico de trajetos.
- Rotas de transporte público e previsão de desembarque.
- Testes automatizados e validação em aparelhos reais.
- Banco Room; a primeira versão usa SharedPreferences para simplificar o protótipo.

## Requisitos
- Android Studio recente.
- JDK 17.
- Android SDK 35.
- Gradle wrapper pode ser gerado pelo Android Studio ao abrir o projeto.

## CSV
Cabeçalho recomendado:
`nome,latitude,longitude,raio_metros,mensagem`

Exemplo:
```csv
nome,latitude,longitude,raio_metros,mensagem
Estação A,-23.3210,-46.1230,500,Você está chegando
Estação B,-23.3300,-46.1400,300,Prepare-se para descer
Trabalho,-23.3500,-46.1600,200,Você chegou ao trabalho
```
Use UTF-8. O importador tenta reconhecer vírgula ou ponto e vírgula como separador. Valores com separador dentro do texto entre aspas são suportados de forma básica.

## Mapa e roteiros
A tela de mapa usa MapLibre GL JS e os tiles do OpenFreeMap, carregados pela internet. As camadas ferroviárias são lidas dos GeoJSON importados localmente; o mapa base ainda precisa de conexão com a internet. Os círculos representam o raio configurado de cada destino; os pontos de um roteiro são ligados por uma linha na ordem em que foram cadastrados. O traçado é visual e não representa uma rota viária navegável.

## Observações importantes
- Este é um projeto inicial de código-fonte, não um APK testado. Compile no Android Studio e teste em seu aparelho antes de depender dos alertas.
- Android pode limitar localização em segundo plano por economia de bateria. O serviço mantém notificação persistente enquanto o monitoramento estiver ativo.
- GPS pode ser impreciso em estações subterrâneas, trens, prédios e áreas com sinal ruim.
- Com “Tocar no fone” e nenhum fone conectado, o alerta toca no alto-falante (perder o alerta é pior). O roteamento final depende do Android e do fabricante.
- O estado “ativo” é gravado pelo serviço; se o sistema encerrar o processo, o serviço é reiniciado (START_STICKY), mas alguns fabricantes impedem esse reinício. Revise as restrições de bateria do aparelho.

### Mapas (atualização)
A tela de mapa usa MapLibre GL JS com o estilo Liberty do OpenFreeMap, baseado em dados OpenStreetMap. Ela não solicita tiles ao `tile.openstreetmap.org`, inclui atribuição a OpenStreetMap/OpenFreeMap e desenha os raios como polígonos geográficos, além dos marcadores e da linha visual do roteiro. É necessária conexão com a internet para carregar o estilo e os dados do mapa. A disponibilidade e os termos do provedor OpenFreeMap devem ser verificados antes de distribuir o aplicativo em larga escala.

## Mudanças da versão 0.2.0
- **ProximityEngine** (lógica pura, sem Android): descarta leituras imprecisas, exige 2 leituras consecutivas dentro do raio (1 se a precisão for ≤ 25 m) e calcula a distância até a borda do raio mais próximo.
- **GPS adaptativo**: o intervalo vai de 3 s a 60 s conforme a distância (1/3 do tempo para alcançar a borda a 108 km/h); prioridade de alta precisão só quando o destino está próximo. Todas as leituras do lote são processadas.
- **Estado real do serviço** em SharedPreferences, refletido na tela mesmo após rotação ou recriação da Activity.
- **Áudio**: instância única, foco de áudio transitório (a música abaixa), modo alarme, e o som para ao tocar em OK ou deslizar a notificação.
- **Navegação**: botão Voltar retorna ao Início; formulário e seção sobrevivem à rotação; geocodificação fora da thread principal; mapa recebe ids (não JSON) e respeita as barras do sistema; links externos abrem no navegador.
- **CSV**: raio não numérico agora é erro; nova coluna opcional `roteiro`.
- `allowBackup` desativado (destinos são dados sensíveis); dependência não usada removida.

## Testes
`./gradlew testDebugUnitTest` executa `ProximityEngineTest` (8 casos: entrada, rearme, precisão ruim, confirmação, intervalo adaptativo). Validação em aparelho real continua necessária, inclusive com localização simulada.

## Recursos adicionados nesta revisão

- **Editar destino:** na lista de destinos, use `Editar` para alterar nome, latitude, longitude, raio, mensagem e nome do roteiro. As coordenadas e o raio são validados antes de salvar.
- **Roteiro sequencial:** na tela `Roteiros`, use `Iniciar sequência`. Apenas a próxima parada habilitada do roteiro escolhido será monitorada, além de destinos individuais. Ao chegar à parada, o índice avança para a próxima. `Parar sequência` encerra o modo sequencial.
- **Soneca:** os alertas incluem a ação `Soneca 5 min`. Novos alertas ficam suspensos durante cinco minutos; o monitoramento de localização continua.
- **Alerta antecipado estimado:** em `Preferências`, configure antecedência entre 0 e 30 minutos. A estimativa usa distância em linha reta e velocidade GPS instantânea, portanto é aproximada e **não considera ruas, trânsito, curvas ou modo de transporte**. Zero desativa a função.

Observação: a sequência respeita a ordem em que as paradas estão armazenadas/cadastradas. Teste em ambiente real antes de depender dos alertas durante uma viagem; o comportamento do GPS depende de permissões, cobertura e restrições de bateria do Android.


## Ajuda e sobre
O aplicativo inclui as seções **Ajuda** e **Sobre** no menu lateral. A Ajuda explica como cadastrar destinos, montar roteiros, configurar alertas e resolver problemas comuns. A seção Sobre apresenta o propósito do aplicativo e identifica Daniel Jr como criador.

A versão exibida no rodapé e na tela Sobre é obtida automaticamente de `versionName` no Gradle (`BuildConfig.VERSION_NAME`), para acompanhar a versão definida no projeto.


## Interface mais organizada (v0.2.4)

- Os cards de roteiros e destinos individuais começam recolhidos e mostram apenas ícone, nome e resumo.
- Toque em um card para expandir e acessar coordenadas, endereço, controles de ativação, edição, exclusão e visualização no mapa.
- Roteiros usam um ícone de mapa 🗺️ e destinos individuais usam um marcador 📍.
- A versão do aplicativo foi atualizada para 0.2.4 (versionCode 4).


## Versão 0.2.6 — estimativa offline de tempo

- Filtragem robusta de velocidade GPS usando leituras recentes e validação de consistência.
- Estimativa exibida como faixa de tempo, em vez de um único valor.
- Preservação temporária da última estimativa durante pausas e degradação do GPS.
- Indicação visual de pausa, baixa confiança e estimativa indisponível.
- Expiração da previsão congelada após 60 segundos sem uma nova estimativa válida.
- O cálculo de tempo permanece separado da lógica de proximidade e dos alertas de chegada.
- A estimativa continua baseada na distância geográfica em linha reta; não calcula rotas viárias nem trânsito.


## Versão 0.2.7 — edição do nome do roteiro

- Adicionada a ação **Renomear roteiro** nas telas de Roteiros e Destinos cadastrados.
- A alteração atualiza o nome em todas as paradas do roteiro, preservando destinos, coordenadas, ordem, configurações e demais dados.
- Se o roteiro renomeado estiver selecionado para monitoramento sequencial, a seleção ativa também é atualizada.
- Não permite nome vazio nem duplicar o nome de outro roteiro (a comparação ignora maiúsculas/minúsculas).


## Versão 0.2.9

- Configuração do intervalo de atualização da localização entre 5 segundos e 5 minutos, com padrão de 5 segundos.
- Alterações no intervalo passam a valer mesmo durante o monitoramento ativo.
- Botão para abrir o mapa do destino ou roteiro monitorado na tela inicial.
- Atalho em Preferências para abrir as informações do aplicativo no Android e consultar o uso de bateria disponível no aparelho.

## Versão 0.2.10

- Adicionados os perfis **Precisão**, **Equilibrado** e **Economia** em Preferências.
- Precisão mantém o intervalo configurado e solicita localização de alta precisão.
- Equilibrado reduz atualizações longe dos destinos e aumenta a frequência/precisão quando o destino está a até 1 km.
- Economia reduz a frequência quando o usuário parece parado, usa localização de menor consumo quando está longe do destino e aumenta temporariamente a frequência ao se aproximar de uma parada.
- A mudança de perfil é aplicada durante o monitoramento ativo; a lógica de proximidade e os alertas existentes não foram alterados intencionalmente.
- O modo selecionado é salvo entre sessões. O perfil padrão é **Equilibrado**.
- O Android e o fabricante podem limitar a frequência real das atualizações; Economia pode atrasar a detecção de aproximação.


## Versão 0.2.11 — áudio dos alertas

- Adiciona seleção entre canal de mídia e canal de notificação.
- Adiciona comportamento para diminuir temporariamente a música ou tentar tocar o alerta sobre ela sem solicitar foco de áudio.
- As preferências são salvas no dispositivo.
- O Android e os outros players controlam o comportamento final; não há garantia de ignorar silencioso ou Não Perturbe.


## Navegação por estações (v0.2.13)

A seção **Estações** inclui um tutorial dentro do aplicativo, link para abrir o Overpass Turbo, as duas consultas prontas e botões para copiar cada código. O usuário pode exportar os resultados como GeoJSON e importar os arquivos diretamente pela tela. Ela estima a estação atual, anterior e próxima sem consultar uma API durante o uso. Os arquivos são salvos no armazenamento privado do app.

Importe dois `FeatureCollection` GeoJSON: (1) pontos das estações com propriedade `name`; (2) geometrias `LineString`/`MultiLineString` das relações/rotas ferroviárias, com `name` ou `ref`. Os arquivos precisam cobrir a área em que o recurso será usado. A estação atual é estimada pela projeção do GPS na geometria mais próxima e pela estação mais próxima ao longo dessa geometria; linhas paralelas, ramificações, geometrias fragmentadas e GPS em túneis podem causar ambiguidades. Os dados não vêm embutidos nesta versão: devem ser importados pelo usuário.

Atribuição: © OpenStreetMap contributors. Dados sob licença Open Database License (ODbL).


### Exportando os arquivos pelo Overpass Turbo

Abra https://overpass-turbo.eu/, ajuste o mapa para uma área pequena (por exemplo, parte da Grande São Paulo) e execute uma consulta por vez. Depois use **Exportar → Dados → GeoJSON**. Repita em áreas vizinhas quando necessário; o app combina os arquivos importados do mesmo tipo.

**1. Estações**

```overpass
[out:json][timeout:60];
(
  nwr["railway"~"^(station|halt)$"]({{bbox}});
  nwr["public_transport"="station"]({{bbox}});
);
out center;
```

**2. Linhas/rotas ferroviárias**

```overpass
[out:json][timeout:90];
(
  relation["route"~"^(subway|train|light_rail)$"]({{bbox}});
);
out geom;
```

Exporte as estações e as linhas separadamente. Importe todos os arquivos de estações primeiro e, depois, todos os arquivos de linhas/rotas. A área do mapa precisa cobrir as regiões desejadas. Se a consulta de rotas der timeout, reduza ainda mais a área.


## Versão 0.2.20 — página inicial

A página inicial ganhou um cabeçalho de boas-vindas, acesso direto ao mapa e atalhos para Estações, Destinos e Roteiros. A Central de Monitoramento e suas funções existentes foram mantidas.


## Versão 0.2.20 — navegação ferroviária mais responsiva

- Com dados de estações e trilhos importados, o perfil Equilibrado solicita GPS de alta precisão em intervalos menores durante deslocamento (até 8 s; até 5 s perto de um destino).
- O perfil Economia também acelera a atualização ferroviária enquanto há movimento (5–10 s), mantendo economia quando o aparelho está parado ou sem dados ferroviários.
- O rumo passa a ser estimado por uma sequência curta de posições GPS quando o bearing nativo não é confiável.
- A seleção de traçado considera a continuidade da linha e a compatibilidade com a direção do movimento para reduzir trocas por ruído GPS.
- Os intervalos do Android são pedidos, não garantias: a frequência real depende do aparelho, permissões, cobertura GPS e políticas de bateria.


## v0.2.22 — alerta ao entrar no raio

- O alerta de proximidade é disparado na primeira leitura GPS válida dentro do raio, sem aguardar uma segunda leitura.
- A notificação mostra o texto expandido e usa prioridade máxima para favorecer o aviso visual (o Android ainda pode limitar notificações heads-up pelas configurações do sistema).
- Mantém a margem de rearme para evitar notificações repetidas enquanto a pessoa permanece perto do destino.


## Backup e restauração (v0.2.25)

Em **Preferências → Backup e restauração**, use **Criar backup** para exportar um arquivo JSON com destinos, roteiros, preferências e os dados ferroviários offline importados. Guarde esse arquivo em outro local (por exemplo, nuvem ou computador). Para recuperar os dados, use **Restaurar backup** e selecione o JSON. A restauração substitui os dados atuais e mantém o monitoramento parado por segurança.

## v0.2.47 — Redesenho visual

- Identidade única (ui/Theme.kt): grafite-azulado, turquesa (ação), âmbar (próxima parada), verde (monitorando), vermelho só para alerta/parar.
- Componentes novos (ui/Components.kt): cartão principal de monitoramento, linha do tempo de estações, métricas, atalho do mapa, cabeçalho do menu, abertura animada.
- Ícones vetoriais próprios (res/drawable/ic_ui_*) no lugar de emojis e símbolos de texto.
- Ícone adaptativo (fundo + primeiro plano + monocromático) e ícones de notificação próprios (ic_stat_*).
- Splash nativa (androidx.core:core-splashscreen) com fundo escuro; tema do app escuro; edge-to-edge.
- Mapa: estilo escuro (alternável para claro), controles reestilizados e MapLibre empacotado em assets/ (sem CDN).
- Seletores de modo viraram SegmentedButton; textos de ajuda longos ficam recolhidos ("Mostrar mais").
- Removidos os PNGs antigos do ícone (mipmap-*) e drawable-nodpi/ic_alerta_geografico.png (não usado).
