# InverterLab — Android Studio

Projeto Android nativo (Java) que empacota o simulador de inversor e lógica Ladder em uma WebView.

## Abrir
1. Extraia o ZIP.
2. Abra a pasta `InverterLab_Android` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute em um dispositivo/emulador Android (minSdk 23).

## Identidade
- Nome do aplicativo: **InverterLab**.
- Subtítulo: **Virtual Inverter · Ladder Simulator**.
- O identificador Android foi preservado para facilitar a atualização da instalação anterior.

## Recursos incluídos
- Simulador CFW100 e lógica Ladder em `app/src/main/assets/index.html`.
- Ícone personalizado e tela de carregamento nativa com a marca InverterLab.
- Seleção de arquivos `.ladlab` e `.invsim` pelo seletor Android.
- Salvamento `.invsim` pelo seletor de documentos do Android.
- Saída com dois toques em Voltar dentro de 2 segundos.
- Ajuste de parâmetros pela navegação e teclas ▲/▼ da HMI simulada.
- Comandos RUN/STOP e reset P204 conforme a implementação atual do simulador.

## Observações técnicas
- O simulador é didático; não estabelece conexão física com um inversor e não substitui o manual do equipamento.
- A lista de parâmetros continua sendo a seleção cadastrada no simulador, não o conjunto completo de parâmetros do CFW100.
- Para compilar, o Android Studio precisará baixar o Android Gradle Plugin e o SDK Platform 35.

## Biblioteca Ladder ampliada

Consulte `LADDER_INSTRUCTIONS.md` para a lista de contatos, bobinas, temporizadores, contadores, comparadores e operações aritméticas reconhecidas pelo motor de execução. Esta versão interpreta essas instruções em programas carregados; não inclui ainda um editor visual para inserir e parametrizar cada instrução diretamente na tela.
