# InverterLab — biblioteca de instruções Ladder

Esta versão amplia o **motor de execução** para interpretar as instruções abaixo em arquivos `.ladlab` e projetos `.invsim`. O aplicativo continua sendo um simulador/visualizador de programas carregados; não foi criado um editor gráfico de montagem de degraus nesta atualização.

## Contatos

| `type` | Função | Campos |
|---|---|---|
| `NA` | Normalmente aberto | `name` |
| `NF` | Normalmente fechado | `name` |
| `P` | Detecção de borda de subida | `name` |
| `N` | Detecção de borda de descida | `name` |
| `EQ` | Igual | `a`, `b` (ou `left`, `right`) |
| `NE` | Diferente | `a`, `b` |
| `GT` | Maior que | `a`, `b` |
| `GE` | Maior ou igual | `a`, `b` |
| `LT` | Menor que | `a`, `b` |
| `LE` | Menor ou igual | `a`, `b` |

## Bobinas e controle

| `type` | Função | Comportamento |
|---|---|---|
| `OUT` | Bobina normal | Atualiza a saída conforme a continuidade do degrau. |
| `S` | SET | Memoriza a saída ligada quando o degrau fica verdadeiro. |
| `R` | RESET | Desliga a saída memorizada quando o degrau fica verdadeiro. |

## Temporizadores

`TON`, `TOF` e `TP` usam `name`, `preset` e `unit` (`s` ou `ms`). O ciclo de simulação é de 50 ms.

- `TON`: saída liga após o tempo programado com entrada continuamente ativa; zera ao desativar.
- `TOF`: saída liga imediatamente e desliga após o atraso contado a partir da desativação.
- `TP`: gera um pulso de duração programada na borda de subida.

## Contadores

`CTU`, `CTD` e `CTUD` usam `name` e `preset` (ou `PV`). Campo opcional `reset` recebe o nome de um bit de reset.

- `CTU`: incrementa na borda de subida do degrau; `Q` liga quando `CV >= PV`.
- `CTD`: inicia em `PV`, decrementa na borda de subida e ativa `Q` quando chega a zero.
- `CTUD`: conta para cima/baixo; pode usar `direction: "UP"` ou `"DOWN"`. Para contagem independente, informe `up` e `down` com nomes de bits/entradas; bordas simultâneas se anulam.

O valor atual fica em `state.counters[name].CV` e o estado de conclusão é o bit `name`.

## Operações com registradores

`MOV`, `ADD`, `SUB`, `MUL` e `DIV` são instruções de saída de degrau. Use `a`, `b` e `dest` (ou `source`/`register` como alternativas). `MOV` copia `a`; as demais executam a operação aritmética com `a` e `b`. O resultado é armazenado no registrador `dest`. Os operandos aceitam constantes numéricas, bits (`I`, `Q`, `M`, `T`, `C`) e nomes de registradores já definidos.

Exemplo de estrutura de degrau:

```json
{
  "slots": [
    {"type":"NA", "name":"I1"},
    {"type":"ADD", "a":"REG_A", "b":5, "dest":"REG_B"}
  ],
  "br": []
}
```

## Escopo e compatibilidade

A biblioteca implementa um subconjunto didático inspirado em recursos comuns de CLPs. Não é uma certificação de compatibilidade integral com o WEG CLIC02 nem com todos os modelos/firmwares. Instruções desconhecidas não devem ser consideradas equivalentes às instruções de um equipamento físico. A resolução temporal é limitada ao ciclo de 50 ms do simulador.
