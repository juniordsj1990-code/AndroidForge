// Permissões de câmera e localização via plugins do Capacitor (sem bundler)
window.pedirPermissoes = async () => {
  try {
    const P = (window.Capacitor && window.Capacitor.Plugins) || {};
    if (P.Camera) await P.Camera.requestPermissions();
    if (P.Geolocation) await P.Geolocation.requestPermissions();
    alert('Permissões concedidas ✅');
  } catch (erro) {
    alert('Permissões negadas ❌');
    console.error(erro);
  }
};
