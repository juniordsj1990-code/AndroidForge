package br.com.radaralerta

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object RadarStore {
    private const val PREFS = "radar_alerta"
    private const val KEY_DATA = "radars_json"
    private const val KEY_UPDATED = "updated_at"

    fun all(context: Context): List<Radar> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_DATA, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).mapNotNull { i ->
            runCatching {
                val o = arr.getJSONObject(i)
                Radar(o.getDouble("latitude"), o.getDouble("longitude"), o.optString("type", "Radar fixo"),
                    if (o.isNull("speedLimit")) null else o.optInt("speedLimit"), o.optString("direction").takeIf { it.isNotBlank() }, o.optString("source", "Importado"))
            }.getOrNull()
        }
    }

    fun save(context: Context, radars: List<Radar>) {
        val arr = JSONArray()
        radars.forEach { r -> arr.put(JSONObject().put("latitude", r.latitude).put("longitude", r.longitude).put("type", r.type)
            .put("speedLimit", r.speedLimit ?: JSONObject.NULL).put("direction", r.direction ?: "").put("source", r.source)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_DATA, arr.toString())
            .putString(KEY_UPDATED, SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())).apply()
    }

    fun updatedAt(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_UPDATED, "Nunca") ?: "Nunca"

    fun import(context: Context, input: java.io.InputStream, filename: String): ImportResult {
        val text = BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { it.readText() }.removePrefix("\uFEFF")
        val parsed = if (filename.lowercase().endsWith(".json")) parseJson(text) else parseCsv(text)
        val existing = all(context).toMutableList()
        var added = 0
        var duplicates = 0
        parsed.forEach { r ->
            if (existing.any { distanceMeters(it, r) < 25.0 }) duplicates++
            else { existing.add(r); added++ }
        }
        save(context, existing)
        return ImportResult(parsed.size, added, duplicates, parsed.size - added - duplicates)
    }

    private fun parseJson(text: String): List<Radar> {
        val arr = JSONArray(text)
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val lat = o.optDouble("latitude", o.optDouble("lat", Double.NaN))
            val lon = o.optDouble("longitude", o.optDouble("lon", o.optDouble("lng", Double.NaN)))
            makeRadar(lat, lon, o.optString("type", o.optString("tipo", "Radar fixo")), o.optInt("speedLimit", o.optInt("velocidade", -1)), o.optString("direction", o.optString("direcao", "")))
        }
    }

    private fun parseCsv(text: String): List<Radar> {
        val lines = text.lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        val delimiter = if (lines.first().count { it == ';' } > lines.first().count { it == ',' }) ';' else ','
        val headers = lines.first().split(delimiter).map { normalize(it) }
        val latIndex = headers.indexOfFirst { it in listOf("latitude", "lat", "y") }
        val lonIndex = headers.indexOfFirst { it in listOf("longitude", "lon", "lng", "long", "x") }
        if (latIndex < 0 || lonIndex < 0) throw IllegalArgumentException("Não encontrei colunas de latitude e longitude no CSV.")
        return lines.drop(1).mapNotNull { line ->
            val cols = line.split(delimiter).map { it.trim().trim('"') }
            val lat = cols.getOrNull(latIndex)?.replace(',', '.')?.toDoubleOrNull() ?: return@mapNotNull null
            val lon = cols.getOrNull(lonIndex)?.replace(',', '.')?.toDoubleOrNull() ?: return@mapNotNull null
            val typeIndex = headers.indexOfFirst { it in listOf("tipo", "type", "equipamento") }
            val speedIndex = headers.indexOfFirst { it in listOf("velocidade", "speed", "limite", "speedlimit") }
            val dirIndex = headers.indexOfFirst { it in listOf("direcao", "direction", "sentido") }
            makeRadar(lat, lon, cols.getOrNull(typeIndex) ?: "Radar fixo", cols.getOrNull(speedIndex)?.toIntOrNull() ?: -1, cols.getOrNull(dirIndex) ?: "")
        }
    }

    private fun makeRadar(lat: Double, lon: Double, type: String, speed: Int, direction: String): Radar? {
        if (!lat.isFinite() || !lon.isFinite() || lat !in -90.0..90.0 || lon !in -180.0..180.0) return null
        return Radar(lat, lon, type.ifBlank { "Radar fixo" }, speed.takeIf { it > 0 }, direction.takeIf { it.isNotBlank() })
    }
    private fun normalize(s: String) = java.text.Normalizer.normalize(s.lowercase().trim().replace("\"", ""), java.text.Normalizer.Form.NFD).replace("\\p{Mn}+".toRegex(), "")
    private fun distanceMeters(a: Radar, b: Radar): Double {
        val r = 6371000.0; val dLat = Math.toRadians(b.latitude-a.latitude); val dLon = Math.toRadians(b.longitude-a.longitude)
        val x = kotlin.math.sin(dLat/2).let { it*it } + kotlin.math.cos(Math.toRadians(a.latitude))*kotlin.math.cos(Math.toRadians(b.latitude))*kotlin.math.sin(dLon/2).let { it*it }
        return 2*r*kotlin.math.asin(kotlin.math.sqrt(x.coerceIn(0.0, 1.0)))
    }
}
data class ImportResult(val read: Int, val added: Int, val duplicates: Int, val invalid: Int)
