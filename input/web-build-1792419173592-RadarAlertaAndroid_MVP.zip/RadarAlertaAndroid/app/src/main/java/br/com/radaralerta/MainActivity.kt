package br.com.radaralerta

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("radar_alerta", MODE_PRIVATE) }
    private val importPicker = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderHome()
        requestBasicPermissions()
    }

    private fun base(title: String): LinearLayout {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 28); setBackgroundColor(0xFFF4F6F8.toInt()) }
        scroll.addView(root)
        setContentView(scroll)
        root.addView(TextView(this).apply { text = title; textSize = 27f; setTextColor(0xFF132238.toInt()); setPadding(0,0,0,18); setTypeface(null, 1) })
        return root
    }

    private fun cardTitle(text: String) = TextView(this).apply { this.text = text; textSize = 18f; setTextColor(0xFF132238.toInt()); setTypeface(null, 1); setPadding(0, 14, 0, 8) }
    private fun label(text: String) = TextView(this).apply { this.text = text; textSize = 15f; setTextColor(0xFF354052.toInt()); setPadding(0, 5, 0, 8) }
    private fun action(text: String, click: () -> Unit) = Button(this).apply { this.text = text; isAllCaps = false; setOnClickListener { click() }; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 } }
    private fun renderHome() {
        base("Radar Alerta")
        root.addView(label("Alertas independentes do Google Maps, Waze ou outro navegador."))
        root.addView(cardTitle("Monitoramento"))
        val count = RadarStore.all(this).size
        root.addView(label("Radares na base: $count\nÚltima atualização: ${RadarStore.updatedAt(this)}"))
        root.addView(action("▶  Iniciar monitoramento") { startMonitoring() })
        root.addView(action("■  Parar monitoramento") { stopService(Intent(this, RadarMonitorService::class.java)); toast("Monitoramento solicitado para parar") })
        root.addView(action("⚙  Configurações de alertas") { renderSettings() })
        root.addView(action("🗂  Gerenciar / importar radares") { renderDatabase() })
        root.addView(action("⌖  Radares próximos (lista local)") { renderNearby() })
        root.addView(action("Permissões e diagnóstico") { renderDiagnostics() })
        root.addView(label("Aviso: base vazia ou incompleta não gera alertas confiáveis. Importe dados verificados antes de usar na via."))
    }

    private fun renderSettings() {
        base("Configurações")
        root.addView(label("Personalize o comportamento dos alertas."))
        addSwitch("Aviso por voz", "voice", true)
        addSwitch("Notificação sonora", "sound", true)
        addSwitch("Vibração", "vibrate", false)
        addSwitch("Janela flutuante", "overlay", true)
        addSwitch("Avisar somente no sentido informado (quando disponível)", "direction", false)
        root.addView(cardTitle("Distância de aviso"))
        val spinner = Spinner(this)
        val options = listOf("100 m", "200 m", "300 m", "500 m", "800 m", "1.000 m")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        spinner.setSelection(prefs.getInt("distance", 2).coerceIn(0, options.lastIndex))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { prefs.edit().putInt("distance", position).apply() }
        }
        root.addView(spinner)
        root.addView(cardTitle("Aviso de velocidade"))
        val speed = EditText(this).apply { hint = "Limite adicional (km/h), opcional"; inputType = 2; setText(prefs.getInt("speed_extra", 0).takeIf { it > 0 }?.toString() ?: "") }
        root.addView(speed)
        root.addView(action("Salvar configurações") { prefs.edit().putInt("speed_extra", speed.text.toString().toIntOrNull() ?: 0).apply(); toast("Configurações salvas") })
        root.addView(action("Voltar") { renderHome() })
    }

    private fun addSwitch(text: String, key: String, default: Boolean) {
        root.addView(Switch(this).apply { this.text = text; isChecked = prefs.getBoolean(key, default); setTextColor(0xFF354052.toInt()); setPadding(0, 6, 0, 6); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply(); if (key == "overlay" && checked && !Settings.canDrawOverlays(this@MainActivity)) requestOverlayPermission() } })
    }

    private fun renderDatabase() {
        base("Base de radares")
        val list = RadarStore.all(this)
        root.addView(label("Registros cadastrados: ${list.size}\nÚltima importação/atualização: ${RadarStore.updatedAt(this)}"))
        root.addView(action("Importar arquivo CSV ou JSON") { openImportPicker() })
        root.addView(action("Exportar base JSON") { exportJson() })
        root.addView(action("Apagar toda a base") { AlertDialog.Builder(this).setTitle("Apagar radares?").setMessage("Essa ação remove os dados locais.").setNegativeButton("Cancelar", null).setPositiveButton("Apagar") { _, _ -> RadarStore.save(this, emptyList()); renderDatabase() }.show() })
        root.addView(cardTitle("Formatos aceitos"))
        root.addView(label("CSV: cabeçalhos latitude/longitude (ou lat/lon), opcionalmente tipo, velocidade e direção. Separador vírgula ou ponto e vírgula.\nJSON: lista de objetos com latitude/longitude (ou lat/lon), type/tipo, speedLimit/velocidade e direction/direcao."))
        root.addView(action("Voltar") { renderHome() })
    }

    private fun openImportPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/comma-separated-values", "application/json", "text/plain", "application/octet-stream")) }
        startActivityForResult(intent, importPicker)
    }

    @Deprecated("Legacy activity result API used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7002 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val contents = prefs.getString("pending_export", "[]") ?: "[]"
                contentResolver.openOutputStream(uri)?.use { it.write(contents.toByteArray(Charsets.UTF_8)) }
                toast("Base exportada")
            } catch (e: Exception) { toast("Falha ao exportar: ${e.message}") }
        }
        if (requestCode == importPicker && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val name = queryName(uri) ?: "radares.csv"
                val result = contentResolver.openInputStream(uri)?.use { RadarStore.import(this, it, name) } ?: throw IllegalStateException("Não foi possível abrir o arquivo")
                AlertDialog.Builder(this).setTitle("Importação concluída").setMessage("Linhas lidas: ${result.read}\nNovos radares: ${result.added}\nDuplicados ignorados: ${result.duplicates}\nRegistros inválidos: ${result.invalid}").setPositiveButton("OK") { _, _ -> renderDatabase() }.show()
            } catch (e: Exception) { AlertDialog.Builder(this).setTitle("Falha na importação").setMessage(e.message ?: "Arquivo inválido").setPositiveButton("OK", null).show() }
        }
    }

    private fun queryName(uri: Uri): String? = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    private fun exportJson() {
        val arr = org.json.JSONArray()
        RadarStore.all(this).forEach { r -> arr.put(org.json.JSONObject().put("latitude", r.latitude).put("longitude", r.longitude).put("type", r.type).put("speedLimit", r.speedLimit ?: org.json.JSONObject.NULL).put("direction", r.direction ?: "").put("source", r.source)) }
        val filename = "radares-export.json"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, filename) }
        // Persist export text for the result callback.
        prefs.edit().putString("pending_export", arr.toString(2)).apply()
        startActivityForResult(intent, 7002)
    }

    private fun renderNearby() {
        base("Radares cadastrados")
        val list = RadarStore.all(this)
        if (list.isEmpty()) root.addView(label("A base está vazia. Importe um arquivo na seção Gerenciar radares."))
        list.take(100).forEachIndexed { i, r -> root.addView(label("${i+1}. ${r.type}\n${r.latitude}, ${r.longitude}\nLimite: ${r.speedLimit?.let { "$it km/h" } ?: "não informado"} • ${r.direction ?: "sentido não informado"}")) }
        root.addView(action("Voltar") { renderHome() })
    }

    private fun renderDiagnostics() {
        base("Permissões e diagnóstico")
        root.addView(label("Localização: ${if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) "concedida" else "não concedida"}\nSobreposição: ${if (Settings.canDrawOverlays(this)) "concedida" else "não concedida"}\nRadares locais: ${RadarStore.all(this).size}"))
        root.addView(action("Conceder permissão de janela flutuante") { requestOverlayPermission() })
        root.addView(action("Abrir configurações do aplicativo") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) })
        root.addView(action("Voltar") { renderHome() })
    }

    private fun startMonitoring() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 12); return
        }
        if (prefs.getBoolean("overlay", true) && !Settings.canDrawOverlays(this)) requestOverlayPermission()
        val intent = Intent(this, RadarMonitorService::class.java)
        ContextCompat.startForegroundService(this, intent)
        toast("Monitoramento iniciado. Confira a notificação permanente.")
    }

    private fun stopService(intent: Intent) { super.stopService(intent) }
    private fun requestOverlayPermission() { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
    private fun requestBasicPermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 11)
    }
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
}
