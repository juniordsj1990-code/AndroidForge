package br.com.alertageografico

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object DestinationStore {
    const val PREFS = "alerta_geografico"
    const val KEY = "destinations"
    const val KEY_ITINERARY_ICONS = "itinerary_icons"
    const val KEY_MONITORING = "monitoring_active"
    const val KEY_LOCATION_INTERVAL_SECONDS = "location_interval_seconds"
    const val KEY_BATTERY_PROFILE = "battery_profile"
    const val KEY_ALARM_MODE = "alert_alarm_mode"
    const val KEY_ALERT_AUDIO_MODE = "alert_audio_mode"
    const val KEY_ALERT_MIX_MODE = "alert_mix_mode"
    const val KEY_ACTIVE_ITINERARY = "active_itinerary"
    const val KEY_ITINERARY_INDEX = "itinerary_index"
    const val KEY_ROUTE_DIRECTION = "route_direction"
    const val KEY_AUTO_SKIP_TO_LATER_STOP = "auto_skip_to_later_stop"
    const val KEY_SKIP_INITIAL_STOP = "skip_initial_stop"
    const val KEY_SNOOZE_UNTIL = "alert_snooze_until"
    const val KEY_ETA_MINUTES = "eta_alert_minutes"
    const val KEY_MONITOR_MODE = "monitor_mode"
    const val KEY_SELECTED_DESTINATION = "selected_destination_id"
    const val KEY_DASH_TARGET = "dashboard_target"
    const val KEY_DASH_NEXT = "dashboard_next"
    const val KEY_DASH_DISTANCE = "dashboard_distance_m"
    const val KEY_DASH_ETA = "dashboard_eta_min"
    const val KEY_DASH_ETA_MIN = "dashboard_eta_min_range"
    const val KEY_DASH_ETA_MAX = "dashboard_eta_max_range"
    const val KEY_DASH_ETA_CONFIDENCE = "dashboard_eta_confidence"
    const val KEY_DASH_DISTANCE_MODE = "dashboard_distance_mode"
    const val KEY_DASH_UPDATED = "dashboard_updated"
    const val KEY_LAST_LATITUDE = "last_location_latitude"
    const val KEY_LAST_LONGITUDE = "last_location_longitude"
    const val KEY_LAST_LOCATION_UPDATED = "last_location_updated"
    const val KEY_STATION_ROUTE = "station_route_name"
    const val KEY_STATION_OPERATOR = "station_operator"
    const val KEY_STATION_PREVIOUS = "station_previous_name"
    const val KEY_STATION_CURRENT = "station_current_name"
    const val KEY_STATION_NEXT = "station_next_name"
    const val KEY_STATION_LINE_DISTANCE = "station_distance_to_line_m"
    const val KEY_STATION_CURRENT_DISTANCE = "station_distance_to_current_m"
    const val KEY_STATION_NEXT_DISTANCE = "station_distance_to_next_m"
    const val KEY_STATION_UPDATED = "station_navigation_updated"

    /** Intervalo configurado pelo usuário: 5 segundos a 5 minutos. */
    fun locationIntervalSeconds(context: Context): Int = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getInt(KEY_LOCATION_INTERVAL_SECONDS, 5).coerceIn(5, 300)

    fun setLocationIntervalSeconds(context: Context, seconds: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_LOCATION_INTERVAL_SECONDS, seconds.coerceIn(5, 300)).apply()
    }

    /** Perfis de consumo: precision, balanced ou economy. */
    fun batteryProfile(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_BATTERY_PROFILE, "balanced")?.takeIf { it in setOf("precision", "balanced", "economy") } ?: "balanced"

    fun setBatteryProfile(context: Context, profile: String) {
        val safeProfile = profile.takeIf { it in setOf("precision", "balanced", "economy") } ?: "balanced"
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_BATTERY_PROFILE, safeProfile).apply()
    }

    fun saveLastLocation(context: Context, latitude: Double, longitude: Double) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_LAST_LATITUDE, latitude.toString())
            .putString(KEY_LAST_LONGITUDE, longitude.toString())
            .putLong(KEY_LAST_LOCATION_UPDATED, System.currentTimeMillis())
            .apply()
    }

    /** Estado real do serviço: gravado pelo próprio serviço, sobrevive à recriação da Activity. */
    fun monitoringActive(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_MONITORING, false)

    fun setMonitoringActive(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_MONITORING, value).apply()
    }

    /** Modo alarme: toca em volume de alarme, repetindo até o usuário confirmar (ou 60 s). */
    fun alarmMode(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ALARM_MODE, false)

    fun setAlarmMode(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ALARM_MODE, value).apply()
    }

    /** Canal de áudio: mídia (volume de mídia) ou notificação (volume de notificações). */
    fun alertAudioMode(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_ALERT_AUDIO_MODE, "media")?.takeIf { it == "media" || it == "notification" } ?: "media"

    fun setAlertAudioMode(context: Context, value: String) {
        val safeValue = if (value == "notification") "notification" else "media"
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ALERT_AUDIO_MODE, safeValue).apply()
    }

    /** duck reduz temporariamente a música; overlap tenta tocar sem solicitar foco de áudio. */
    fun alertMixMode(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_ALERT_MIX_MODE, "duck")?.takeIf { it == "duck" || it == "overlap" } ?: "duck"

    fun setAlertMixMode(context: Context, value: String) {
        val safeValue = if (value == "overlap") "overlap" else "duck"
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ALERT_MIX_MODE, safeValue).apply()
    }

    fun load(context: Context): List<Destination> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { Destination.fromJson(array.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    /** Ícones dos roteiros são guardados separadamente para não alterar os dados de cada parada. */
    fun loadItineraryIcons(context: Context): Map<String, String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ITINERARY_ICONS, "{}") ?: "{}"
        return runCatching {
            val json = JSONObject(raw)
            buildMap {
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val value = json.optString(key, "🗺️").ifBlank { "🗺️" }
                    put(key, value)
                }
            }
        }.getOrDefault(emptyMap())
    }

    fun saveItineraryIcons(context: Context, icons: Map<String, String>) {
        val json = JSONObject()
        icons.forEach { (name, icon) -> json.put(name, icon) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_ITINERARY_ICONS, json.toString()).apply()
    }

    fun save(context: Context, destinations: List<Destination>) {
        val array = JSONArray()
        destinations.forEach { array.put(it.toJson()) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }

    fun monitorMode(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_MONITOR_MODE, "individual") ?: "individual"
    fun setMonitorSelection(context: Context, mode: String, destinationId: String? = null, itinerary: String? = null) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_MONITOR_MODE, mode).putString(KEY_SELECTED_DESTINATION, destinationId)
            .putString(KEY_ACTIVE_ITINERARY, itinerary).putInt(KEY_ITINERARY_INDEX, 0).apply()
    }
    fun selectedDestinationId(context: Context): String? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SELECTED_DESTINATION, null)
    fun saveDashboard(
        context: Context,
        target: String,
        next: String,
        distanceMeters: Int,
        etaMinutes: Int,
        etaMinMinutes: Int = etaMinutes,
        etaMaxMinutes: Int = etaMinutes,
        etaConfidence: String = "normal",
        distanceMode: String = "straight"
    ) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_DASH_TARGET, target).putString(KEY_DASH_NEXT, next)
            .putInt(KEY_DASH_DISTANCE, distanceMeters).putInt(KEY_DASH_ETA, etaMinutes)
            .putInt(KEY_DASH_ETA_MIN, etaMinMinutes).putInt(KEY_DASH_ETA_MAX, etaMaxMinutes)
            .putString(KEY_DASH_ETA_CONFIDENCE, etaConfidence)
            .putString(KEY_DASH_DISTANCE_MODE, distanceMode)
            .putLong(KEY_DASH_UPDATED, System.currentTimeMillis()).apply()
    }
    fun dashboard(context: Context): android.content.SharedPreferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Salva a estimativa local de navegação ferroviária para a Central de Monitoramento. */
    fun saveStationNavigation(context: Context, result: StationNavigationResult?) {
        val edit = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (result == null) {
            edit.remove(KEY_STATION_ROUTE)
                .remove(KEY_STATION_OPERATOR)
                .remove(KEY_STATION_PREVIOUS)
                .remove(KEY_STATION_CURRENT)
                .remove(KEY_STATION_NEXT)
                .remove(KEY_STATION_LINE_DISTANCE)
                .remove(KEY_STATION_CURRENT_DISTANCE)
                .remove(KEY_STATION_NEXT_DISTANCE)
        } else {
            edit.putString(KEY_STATION_ROUTE, result.routeName)
                .putString(KEY_STATION_OPERATOR, result.operator)
                .putString(KEY_STATION_PREVIOUS, result.previous?.name)
                .putString(KEY_STATION_CURRENT, result.current.name)
                .putString(KEY_STATION_NEXT, result.next?.name)
                .putInt(KEY_STATION_LINE_DISTANCE, result.distanceToLineMeters.toInt().coerceAtLeast(0))
                .putInt(KEY_STATION_CURRENT_DISTANCE, result.distanceToCurrentMeters.toInt().coerceAtLeast(0))
            if (result.distanceToNextMeters != null) edit.putInt(KEY_STATION_NEXT_DISTANCE, result.distanceToNextMeters) else edit.remove(KEY_STATION_NEXT_DISTANCE)
        }
        edit.putLong(KEY_STATION_UPDATED, System.currentTimeMillis()).apply()
    }

    fun routeDirection(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ROUTE_DIRECTION, "ida") ?: "ida"
    fun setRouteDirection(context: Context, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_ROUTE_DIRECTION, if (value == "volta") "volta" else "ida")
            .putInt(KEY_ITINERARY_INDEX, 0).apply()
    }
    /** Retorna as paradas ativas na ordem escolhida sem alterar a lista original salva. */
    fun orderedItineraryStops(context: Context, destinations: List<Destination>, itinerary: String?): List<Destination> {
        val stops = destinations.filter { it.itineraryName == itinerary && it.enabled }
        return if (routeDirection(context) == "volta") stops.asReversed() else stops
    }

    fun activeItinerary(context: Context): String? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ACTIVE_ITINERARY, null)
    fun setActiveItinerary(context: Context, value: String?) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ACTIVE_ITINERARY, value).putInt(KEY_ITINERARY_INDEX, 0).apply() }
    fun autoSkipToLaterStopEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_AUTO_SKIP_TO_LATER_STOP, true)
    fun setAutoSkipToLaterStopEnabled(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_AUTO_SKIP_TO_LATER_STOP, value).apply()
    }
    fun skipInitialStop(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SKIP_INITIAL_STOP, false)
    fun setSkipInitialStop(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_SKIP_INITIAL_STOP, value).apply()
    }
    fun itineraryIndex(context: Context): Int = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_ITINERARY_INDEX, 0)
    fun setItineraryIndex(context: Context, value: Int) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_ITINERARY_INDEX, value.coerceAtLeast(0)).apply() }
    fun etaAlertMinutes(context: Context): Int = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_ETA_MINUTES, 0).coerceIn(0, 30)
    fun setEtaAlertMinutes(context: Context, value: Int) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_ETA_MINUTES, value.coerceIn(0, 30)).apply() }
    fun snoozed(context: Context): Boolean = System.currentTimeMillis() < context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_SNOOZE_UNTIL, 0L)

    fun soundEnabled(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("sound", true)

    fun alertSoundUri(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("alert_sound_uri", null)

    fun setAlertSoundUri(context: Context, value: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("alert_sound_uri", value).apply()
    }


    fun alertVolume(context: Context): Float =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat("alert_volume", 1.0f).coerceIn(0f, 1f)

    fun setAlertVolume(context: Context, value: Float) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat("alert_volume", value.coerceIn(0f, 1f)).apply()
    }

    fun alertAudioOutput(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("alert_audio_output", "headphones") ?: "headphones"

    fun setAlertAudioOutput(context: Context, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("alert_audio_output", value).apply()
    }

    fun vibrationEnabled(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("vibration", true)

    fun setSoundEnabled(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("sound", value).apply()
    }

    fun setVibrationEnabled(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("vibration", value).apply()
    }
}
