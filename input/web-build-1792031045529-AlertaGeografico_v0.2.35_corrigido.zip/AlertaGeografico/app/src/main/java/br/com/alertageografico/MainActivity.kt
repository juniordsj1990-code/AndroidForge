package br.com.alertageografico

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.content.pm.PackageManager
import android.app.NotificationChannel
import android.app.PendingIntent
import android.app.NotificationManager
import android.media.RingtoneManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import android.location.Geocoder
import android.location.Location
import java.util.Locale
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource

private fun formatEtaMinutes(totalMinutes: Int): String {
    if (totalMinutes < 60) return "$totalMinutes min"
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return if (minutes == 0) "$hours h" else "$hours h $minutes min"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppScreen() }
    }

    private fun dismissPendingIntent(context: Context, notificationId: Int): PendingIntent {
        val intent = Intent(context, AlertDismissReceiver::class.java).putExtra("notification_id", notificationId)
        return PendingIntent.getBroadcast(context, notificationId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun recreateAlertChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel("geo_alerts_routed", "Alertas de proximidade", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Alertas de proximidade do Alerta Geográfico"
            channel.setSound(null, null)
            manager.createNotificationChannel(channel)
        }
    }

    private fun showTestNotification(onAudioStatus: ((String) -> Unit)? = null) {
        recreateAlertChannel()
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(this, "geo_alerts_routed")
            .setSmallIcon(android.R.drawable.ic_dialog_map)
            .setContentTitle("Alerta Geográfico — teste")
            .setContentText("Teste de som na saída selecionada nas preferências.")
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "OK", dismissPendingIntent(this, 987654))
            .build()
        manager.notify(987654, notification)
        RoutedAlertSound.play(this, onAudioStatus)
        if (DestinationStore.vibrationEnabled(this)) {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
            else { @Suppress("DEPRECATION") vibrator.vibrate(350) }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun AppScreen() {
        val appVersionName = packageManager.getPackageInfo(packageName, 0).versionName ?: "desconhecida"
        var destinations by remember { mutableStateOf(DestinationStore.load(this)) }
        var name by rememberSaveable { mutableStateOf("") }
        var place by rememberSaveable { mutableStateOf("") }
        var selectedDestinationIcon by rememberSaveable { mutableStateOf("📍") }
        var latitude by rememberSaveable { mutableStateOf("") }
        var longitude by rememberSaveable { mutableStateOf("") }
        var radius by rememberSaveable { mutableStateOf("300") }
        var message by rememberSaveable { mutableStateOf("Você está chegando ao destino") }
        var oneShot by rememberSaveable { mutableStateOf(false) }
        var entryMode by rememberSaveable { mutableStateOf("Único") }
        var itineraryName by rememberSaveable { mutableStateOf("") }
        var sound by remember { mutableStateOf(DestinationStore.soundEnabled(this)) }
        var selectedSoundUri by remember { mutableStateOf(DestinationStore.alertSoundUri(this)) }
        var alertAudioOutput by remember { mutableStateOf(DestinationStore.alertAudioOutput(this)) }
        var alertVolume by remember { mutableFloatStateOf(DestinationStore.alertVolume(this)) }
        var alarmMode by remember { mutableStateOf(DestinationStore.alarmMode(this)) }
        var alertAudioMode by remember { mutableStateOf(DestinationStore.alertAudioMode(this)) }
        var alertAudioModeMenuExpanded by remember { mutableStateOf(false) }
        var alertMixMode by remember { mutableStateOf(DestinationStore.alertMixMode(this)) }
        var alertMixModeMenuExpanded by remember { mutableStateOf(false) }
        var monitoring by remember { mutableStateOf(DestinationStore.monitoringActive(this)) }
        var vibration by remember { mutableStateOf(DestinationStore.vibrationEnabled(this)) }
        var etaLead by remember { mutableStateOf(DestinationStore.etaAlertMinutes(this).toString()) }
        var locationIntervalSeconds by remember { mutableIntStateOf(DestinationStore.locationIntervalSeconds(this)) }
        var locationIntervalMenuExpanded by remember { mutableStateOf(false) }
        var batteryProfile by remember { mutableStateOf(DestinationStore.batteryProfile(this)) }
        var showRailLinesOnMap by remember { mutableStateOf(getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE).getBoolean(MapActivity.PREF_SHOW_RAIL_LINES, true)) }
        var showRailStationsOnMap by remember { mutableStateOf(getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE).getBoolean(MapActivity.PREF_SHOW_RAIL_STATIONS, true)) }
        var batteryProfileMenuExpanded by remember { mutableStateOf(false) }
        var activeItinerary by remember { mutableStateOf(DestinationStore.activeItinerary(this)) }
        var routeDirection by rememberSaveable { mutableStateOf(DestinationStore.routeDirection(this)) }
        var monitorMode by rememberSaveable { mutableStateOf(DestinationStore.monitorMode(this)) }
        var selectedDestinationId by rememberSaveable { mutableStateOf(DestinationStore.selectedDestinationId(this) ?: "") }
        var destinationMenuExpanded by remember { mutableStateOf(false) }
        var routeMenuExpanded by remember { mutableStateOf(false) }
        var dashboardRefresh by remember { mutableIntStateOf(0) }
        var status by remember { mutableStateOf("Monitoramento parado") }
        var stationImportMessage by rememberSaveable { mutableStateOf("") }
        var stationResult by remember { mutableStateOf<StationNavigationResult?>(null) }
        var stationLocationStatus by rememberSaveable { mutableStateOf("Toque em Atualizar posição para consultar o GPS.") }
        var stationLoading by remember { mutableStateOf(false) }
        var confirmClearRailData by remember { mutableStateOf(false) }
        val overpassStationsQuery = """[out:json][timeout:60];
(
  nwr["railway"~"^(station|halt)$"]({{bbox}});
  nwr["public_transport"="station"]({{bbox}});
);
out center;"""
        val overpassRoutesQuery = """[out:json][timeout:90];
(
  relation["route"~"^(subway|train|light_rail)$"]({{bbox}});
);
out geom;"""
        var pendingImport by remember { mutableStateOf<List<Destination>?>(null) }
        var importReport by remember { mutableStateOf("") }
        var decodedAddresses by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
        var attemptedAddressIds by remember { mutableStateOf<Set<String>>(emptySet()) }
        var pendingDelete by remember { mutableStateOf<Destination?>(null) }
        var pendingBackup by remember { mutableStateOf<org.json.JSONObject?>(null) }
        var pendingEdit by remember { mutableStateOf<Destination?>(null) }
        var pendingRenameRoute by remember { mutableStateOf<String?>(null) }
        var renameRouteName by rememberSaveable { mutableStateOf("") }
        var routeIcons by remember { mutableStateOf(DestinationStore.loadItineraryIcons(this)) }
        var pendingRouteIcon by remember { mutableStateOf<String?>(null) }
        val routeIconChoices = listOf("🗺️", "🚗", "🚙", "🚕", "🚌", "🚐", "🚚", "🏍️", "🚲", "🚶", "✈️", "🚆", "🚢", "🏖️", "🏕️", "🏨", "🏠", "💼", "🛒", "📦", "⭐", "❤️", "📍", "🎯")

        fun setRouteIcon(routeName: String, icon: String) {
            val updated = routeIcons.toMutableMap().apply { put(routeName, icon) }
            routeIcons = updated
            DestinationStore.saveItineraryIcons(this, updated)
        }
        var selectedSection by rememberSaveable { mutableStateOf("Início") }
        var expandedRouteCards by rememberSaveable { mutableStateOf(setOf<String>()) }
        var expandedDestinationCards by rememberSaveable { mutableStateOf(setOf<String>()) }
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        LaunchedEffect(selectedSection) {
            if (selectedSection == "Preferências") {
                val mapPrefs = getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE)
                showRailLinesOnMap = mapPrefs.getBoolean(MapActivity.PREF_SHOW_RAIL_LINES, true)
                showRailStationsOnMap = mapPrefs.getBoolean(MapActivity.PREF_SHOW_RAIL_STATIONS, true)
            }
        }

        fun save(list: List<Destination>) {
            destinations = list
            DestinationStore.save(this, list)
        }

        fun moveItineraryStop(itineraryName: String, destinationId: String, direction: Int) {
            val routeStops = destinations.filter { it.itineraryName == itineraryName }
            val currentIndex = routeStops.indexOfFirst { it.id == destinationId }
            val targetIndex = currentIndex + direction
            if (currentIndex !in routeStops.indices || targetIndex !in routeStops.indices) return

            // Reorder only the selected route's stops, preserving the positions of all other destinations.
            val reorderedStops = routeStops.toMutableList()
            val moved = reorderedStops.removeAt(currentIndex)
            reorderedStops.add(targetIndex, moved)
            var routeIndex = 0
            val reorderedAll = destinations.map { destination ->
                if (destination.itineraryName == itineraryName) reorderedStops[routeIndex++] else destination
            }
            save(reorderedAll)
            status = "Ordem das paradas de $itineraryName atualizada"
        }

        // "Voltar" volta ao Início (ou fecha o menu) em vez de sair do app.
        BackHandler(enabled = drawerState.isOpen || selectedSection != "Início") {
            if (drawerState.isOpen) scope.launch { drawerState.close() } else selectedSection = "Início"
        }

        // Mantém a tela sincronizada com o estado real do serviço e com alterações feitas por ele
        // (ex.: destino de alerta único desativado após disparar).
        DisposableEffect(Unit) {
            val prefs = getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE)
            val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
                when (key) {
                    DestinationStore.KEY_MONITORING -> monitoring = DestinationStore.monitoringActive(this@MainActivity)
                    DestinationStore.KEY -> destinations = DestinationStore.load(this@MainActivity)
                    DestinationStore.KEY_DASH_TARGET, DestinationStore.KEY_DASH_NEXT, DestinationStore.KEY_DASH_DISTANCE,
                    DestinationStore.KEY_DASH_ETA, DestinationStore.KEY_DASH_ETA_MIN, DestinationStore.KEY_DASH_ETA_MAX,
                    DestinationStore.KEY_DASH_ETA_CONFIDENCE, DestinationStore.KEY_DASH_DISTANCE_MODE, DestinationStore.KEY_LOCATION_INTERVAL_SECONDS,
                    DestinationStore.KEY_STATION_ROUTE, DestinationStore.KEY_STATION_OPERATOR,
                    DestinationStore.KEY_STATION_PREVIOUS, DestinationStore.KEY_STATION_CURRENT,
                    DestinationStore.KEY_STATION_NEXT, DestinationStore.KEY_STATION_NEXT_DISTANCE, DestinationStore.KEY_STATION_UPDATED -> dashboardRefresh++
                }
            }
            prefs.registerOnSharedPreferenceChangeListener(listener)
            monitoring = DestinationStore.monitoringActive(this@MainActivity)
            destinations = DestinationStore.load(this@MainActivity)
            onDispose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
        }

        fun showOnMap(items: List<Destination>) {
            if (items.isEmpty()) {
                status = "Não há destinos para mostrar no mapa"
                return
            }
            // Só os ids vão na Intent (limite ~1 MB); o mapa lê os dados do DestinationStore.
            startActivity(
                Intent(this@MainActivity, MapActivity::class.java)
                    .putStringArrayListExtra(MapActivity.EXTRA_DESTINATION_IDS, ArrayList(items.map { it.id }))
            )
        }

        fun startMonitoring() {
            val chosen = if (monitorMode == "individual") destinations.firstOrNull { it.id == selectedDestinationId && it.enabled } else null
            val routeStops = DestinationStore.orderedItineraryStops(this@MainActivity, destinations, activeItinerary)
            if (monitorMode == "individual" && chosen == null) {
                status = "Selecione um destino individual habilitado antes de iniciar"
                return
            }
            if (monitorMode == "route" && (activeItinerary.isNullOrBlank() || routeStops.isEmpty())) {
                status = "Selecione um roteiro com paradas habilitadas antes de iniciar"
                return
            }
            DestinationStore.setMonitorSelection(this@MainActivity, monitorMode, chosen?.id, if (monitorMode == "route") activeItinerary else null)
            // Evita exibir a sequência ferroviária da sessão anterior enquanto aguardamos o primeiro GPS.
            DestinationStore.saveStationNavigation(this@MainActivity, null)
            ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, LocationMonitorService::class.java))
            monitoring = true
            val warnings = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                    this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                warnings += "as notificações estão bloqueadas (o aviso visual não aparecerá)"
            }
            if (ContextCompat.checkSelfPermission(
                    this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                warnings += "só há localização aproximada (raios pequenos podem falhar)"
            }
            status = if (warnings.isEmpty()) "Monitoramento iniciado"
                     else "Monitoramento iniciado, mas " + warnings.joinToString("; ")
        }

        val mapPointPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                latitude = result.data!!.getDoubleExtra(MapActivity.EXTRA_SELECTED_LAT, 0.0).toString()
                longitude = result.data!!.getDoubleExtra(MapActivity.EXTRA_SELECTED_LON, 0.0).toString()
                if (name.isBlank()) name = "Ponto selecionado no mapa"
                place = "Ponto selecionado no mapa"
                status = "Ponto selecionado. Informe um nome e salve o destino."
            }
        }

        val soundPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val uri = result.data!!.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                selectedSoundUri = uri?.toString()
                DestinationStore.setAlertSoundUri(this@MainActivity, selectedSoundUri)
                status = if (uri == null) "Som de alerta: silencioso" else "Som de alerta atualizado para todos os destinos"
                recreateAlertChannel()
            }
        }

        val backupExportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
            if (uri != null) {
                runCatching {
                    contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(AppBackup.create(this@MainActivity)) }
                        ?: error("Não foi possível gravar o arquivo escolhido.")
                }.onSuccess { status = "Backup criado com sucesso." }
                    .onFailure { status = "Falha ao criar backup: ${it.message ?: "erro desconhecido"}" }
            }
        }

        val backupImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                runCatching {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("Não foi possível ler o arquivo escolhido.")
                    AppBackup.validate(raw)
                }.onSuccess { pendingBackup = it }
                    .onFailure { status = "Backup inválido: ${it.message ?: "arquivo não reconhecido"}" }
            }
        }

        val csvPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    contentResolver.openInputStream(uri)?.use { stream ->
                        val result = CsvImporter.parse(stream, destinations)
                        pendingImport = result.imported
                        importReport = buildString {
                            append("Prontos para importar: ${result.imported.size}\n")
                            append("Duplicados ignorados: ${result.duplicates}\n")
                            append("Erros: ${result.errors.size}")
                            if (result.errors.isNotEmpty()) append("\n\n" + result.errors.take(15).joinToString("\n"))
                        }
                        if (result.imported.isEmpty()) pendingImport = null
                    } ?: run { importReport = "Não foi possível abrir o arquivo." }
                } catch (e: Exception) {
                    importReport = "Falha ao ler CSV: ${e.message ?: "erro desconhecido"}"
                    pendingImport = null
                }
            }
        }

        val stationGeoJsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("Não foi possível abrir o arquivo selecionado.")
                    val count = StationNavigationStore.importGeoJson(this@MainActivity, raw, true)
                    stationImportMessage = "$count estações importadas. Agora importe o arquivo das linhas/rotas."
                    stationResult = null
                } catch (e: Exception) {
                    stationImportMessage = "Falha ao importar estações: ${e.message ?: "arquivo inválido"}"
                }
            }
        }

        val railRoutesGeoJsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("Não foi possível abrir o arquivo selecionado.")
                    val count = StationNavigationStore.importGeoJson(this@MainActivity, raw, false)
                    stationImportMessage = "$count linhas/rotas importadas. Os dados ficam salvos no aparelho para uso offline."
                    stationResult = null
                } catch (e: Exception) {
                    stationImportMessage = "Falha ao importar linhas/rotas: ${e.message ?: "arquivo inválido"}"
                }
            }
        }

        fun refreshStationPosition() {
            if (!StationNavigationStore.hasStations(this@MainActivity) || !StationNavigationStore.hasRoutes(this@MainActivity)) {
                stationLocationStatus = "Importe primeiro os GeoJSON de estações e de linhas/rotas."
                stationResult = null
                return
            }
            val fine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (!fine && !coarse) {
                stationLocationStatus = "Permissão de localização necessária. Autorize o acesso e tente novamente."
                return
            }
            stationLoading = true
            stationLocationStatus = "Obtendo posição GPS…"
            val token = CancellationTokenSource()
            try {
                LocationServices.getFusedLocationProviderClient(this@MainActivity)
                    .getCurrentLocation(if (fine) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY, token.token)
                    .addOnSuccessListener { loc: Location? ->
                        stationLoading = false
                        if (loc == null) {
                            stationLocationStatus = "Posição indisponível. Verifique se a localização está ligada e tente novamente."
                            stationResult = null
                        } else {
                            val result = StationNavigationStore.locate(this@MainActivity, loc)
                            stationResult = result
                            stationLocationStatus = if (result == null) {
                                "Não foi possível associar sua posição a uma linha/estação com confiança. Isso pode ocorrer fora da ferrovia, em túneis ou com dados incompletos."
                            } else {
                                "GPS atualizado • precisão aproximada de ${loc.accuracy.toInt()} m"
                            }
                        }
                    }
                    .addOnFailureListener { e ->
                        stationLoading = false
                        stationLocationStatus = "Falha ao obter GPS: ${e.message ?: "erro desconhecido"}"
                    }
            } catch (e: SecurityException) {
                stationLoading = false
                stationLocationStatus = "Permissão de localização não concedida."
            }
        }

        val testNotificationPermissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                showTestNotification()
                status = "Notificação de teste enviada"
            } else status = "Permissão de notificações negada pelo Android"
        }

        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { grants ->
            val fine = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true
            val coarse = grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
            if (fine || coarse) startMonitoring()
            else status = "Permissão de localização negada"
        }

        // Identifica endereços automaticamente quando a lista de destinos é aberta.
        // A consulta ocorre fora da thread principal para não congelar a interface.
        LaunchedEffect(destinations, selectedSection) {
            if (selectedSection == "Destinos cadastrados") {
                val pending = destinations.filter {
                    !decodedAddresses.containsKey(it.id) && !attemptedAddressIds.contains(it.id)
                }
                for (destination in pending) {
                    val address = withContext(Dispatchers.IO) {
                        try {
                            val geocoder = Geocoder(this@MainActivity, Locale("pt", "BR"))
                            @Suppress("DEPRECATION")
                            geocoder.getFromLocation(destination.latitude, destination.longitude, 1)
                                ?.firstOrNull()?.getAddressLine(0)
                        } catch (_: Exception) { null }
                    }
                    attemptedAddressIds = attemptedAddressIds + destination.id
                    if (!address.isNullOrBlank()) {
                        decodedAddresses = decodedAddresses + (destination.id to address)
                    }
                }
            }
        }

        // Tema escuro de baixo brilho para reduzir o desconforto visual em ambientes pouco iluminados.
        val brandNavy = Color(0xFFE0E8ED)
        val brandTeal = Color(0xFF78C7C8)
        val appColors = darkColorScheme(
            primary = brandTeal,
            onPrimary = Color(0xFF08292D),
            primaryContainer = Color(0xFF203B43),
            onPrimaryContainer = Color(0xFFD7E9EA),
            secondary = Color(0xFFA9BEC7),
            background = Color(0xFF101518),
            surface = Color(0xFF171E22),
            surfaceVariant = Color(0xFF252F35),
            onSurface = Color(0xFFE0E7EA),
            onSurfaceVariant = Color(0xFFB0BEC5),
            outline = Color(0xFF3B494F),
            surfaceContainer = Color(0xFF1D262B),
            surfaceContainerHigh = Color(0xFF253137),
            surfaceContainerHighest = Color(0xFF2C393F)
        )

        MaterialTheme(colorScheme = appColors) {
            pendingBackup?.let { backup ->
                AlertDialog(
                    onDismissRequest = { pendingBackup = null },
                    title = { Text("Restaurar backup?") },
                    text = { Text("Isso substituirá os destinos, roteiros, preferências e dados ferroviários deste aparelho pelos dados do backup. O monitoramento ficará parado após a restauração.") },
                    confirmButton = {
                        TextButton(onClick = {
                            runCatching {
                                DestinationStore.setMonitoringActive(this@MainActivity, false)
                                stopService(Intent(this@MainActivity, LocationMonitorService::class.java))
                                AppBackup.restore(this@MainActivity, backup)
                            }.onSuccess {
                                pendingBackup = null
                                recreate()
                            }.onFailure {
                                pendingBackup = null
                                status = "Falha ao restaurar backup: ${it.message ?: "erro desconhecido"}"
                            }
                        }) { Text("Restaurar e substituir") }
                    },
                    dismissButton = { TextButton(onClick = { pendingBackup = null }) { Text("Cancelar") } }
                )
            }
            if (confirmClearRailData) {
                AlertDialog(
                    onDismissRequest = { confirmClearRailData = false },
                    title = { Text("Apagar todos os dados ferroviários?") },
                    text = { Text("Isso excluirá todas as estações e linhas/trilhos importados deste aparelho e limpará a estação atual estimada. Seus destinos e roteiros de alerta não serão apagados.") },
                    confirmButton = {
                        TextButton(onClick = {
                            StationNavigationStore.clearAll(this@MainActivity)
                            stationResult = null
                            stationImportMessage = "Todos os dados de estações e linhas/trilhos foram apagados."
                            stationLocationStatus = "Importe novamente os arquivos GeoJSON para usar a navegação ferroviária."
                            confirmClearRailData = false
                            dashboardRefresh++
                        }) { Text("Apagar tudo") }
                    },
                    dismissButton = { TextButton(onClick = { confirmClearRailData = false }) { Text("Cancelar") } }
                )
            }
            pendingEdit?.let { destination ->
                var editName by remember(destination.id) { mutableStateOf(destination.name) }
                var editLat by remember(destination.id) { mutableStateOf(destination.latitude.toString()) }
                var editLon by remember(destination.id) { mutableStateOf(destination.longitude.toString()) }
                var editLocation by remember(destination.id) { mutableStateOf(destination.locationLabel ?: decodedAddresses[destination.id].orEmpty()) }
                var editRadius by remember(destination.id) { mutableStateOf(destination.radiusMeters.toString()) }
                var editMessage by remember(destination.id) { mutableStateOf(destination.message) }
                var editRoute by remember(destination.id) { mutableStateOf(destination.itineraryName.orEmpty()) }
                var editIcon by remember(destination.id) { mutableStateOf(destination.icon) }
                var editCoordinatesExpanded by remember(destination.id) { mutableStateOf(false) }
                AlertDialog(
                    onDismissRequest = { pendingEdit = null },
                    title = { Text("Editar destino") },
                    text = {
                        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(editName, { editName = it }, label = { Text("Nome do destino") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(editLocation, { editLocation = it }, label = { Text("Endereço ou identificação do local") }, placeholder = { Text("Ex.: Entrada principal, Rua das Flores...") }, modifier = Modifier.fillMaxWidth())
                            Text("Ícone do destino", style = MaterialTheme.typography.labelLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                                listOf("📍", "🏠", "💼", "⛽", "🛒", "🏥", "🏫", "🍽️", "🅿️", "🚉", "🏖️", "⭐").forEach { iconChoice ->
                                    FilterChip(selected = editIcon == iconChoice, onClick = { editIcon = iconChoice }, label = { Text(iconChoice) })
                                }
                            }
                            OutlinedButton(onClick = {
                                if (editLocation.isBlank()) status = "Informe um endereço ou local para pesquisar"
                                else {
                                    val query = editLocation.trim()
                                    status = "Procurando endereço…"
                                    scope.launch {
                                        val outcome = withContext(Dispatchers.IO) {
                                            runCatching {
                                                @Suppress("DEPRECATION")
                                                Geocoder(this@MainActivity, Locale("pt", "BR")).getFromLocationName(query, 1)?.firstOrNull()
                                            }
                                        }
                                        val found = outcome.getOrNull()
                                        if (found != null) {
                                            editLat = found.latitude.toString()
                                            editLon = found.longitude.toString()
                                            status = "Endereço localizado; salve para aplicar as coordenadas"
                                        } else status = "Endereço não encontrado. Confira o texto e tente novamente."
                                    }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Buscar endereço e atualizar local") }
                            OutlinedButton(onClick = { editCoordinatesExpanded = !editCoordinatesExpanded }, modifier = Modifier.fillMaxWidth()) { Text(if (editCoordinatesExpanded) "Ocultar coordenadas avançadas" else "Alterar coordenadas manualmente") }
                            if (editCoordinatesExpanded) {
                                OutlinedTextField(editLat, { editLat = it }, label = { Text("Latitude") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(editLon, { editLon = it }, label = { Text("Longitude") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                            OutlinedTextField(editRadius, { editRadius = it }, label = { Text("Raio de alerta (m)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(editMessage, { editMessage = it }, label = { Text("Mensagem do alerta") })
                            OutlinedTextField(editRoute, { editRoute = it }, label = { Text("Nome do roteiro (opcional)") }, singleLine = true)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val lat = editLat.replace(',', '.').toDoubleOrNull()
                            val lon = editLon.replace(',', '.').toDoubleOrNull()
                            val rad = editRadius.toIntOrNull()
                            if (editName.isNotBlank() && lat != null && lat in -90.0..90.0 && lon != null && lon in -180.0..180.0 && rad != null && rad > 0) {
                                save(destinations.map { d -> if (d.id == destination.id) d.copy(name = editName.trim(), latitude = lat, longitude = lon, locationLabel = editLocation.trim().takeIf { it.isNotEmpty() }, icon = editIcon, radiusMeters = rad, message = editMessage, itineraryName = editRoute.trim().takeIf { it.isNotEmpty() }) else d })
                                pendingEdit = null
                                status = "Destino atualizado"
                            } else status = "Confira nome, coordenadas e raio antes de salvar"
                        }) { Text("Salvar") }
                    },
                    dismissButton = { TextButton(onClick = { pendingEdit = null }) { Text("Cancelar") } }
                )
            }
            pendingRouteIcon?.let { routeName ->
                AlertDialog(
                    onDismissRequest = { pendingRouteIcon = null },
                    title = { Text("Ícone do roteiro") },
                    text = {
                        Column(
                            modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Escolha um ícone para identificar ‘$routeName’.")
                            routeIconChoices.chunked(4).forEach { choices ->
                                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
                                    choices.forEach { choice ->
                                        FilterChip(
                                            selected = (routeIcons[routeName] ?: "🗺️") == choice,
                                            onClick = { setRouteIcon(routeName, choice) },
                                            label = { Text(choice) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { pendingRouteIcon = null }) { Text("Concluir") } },
                    dismissButton = { TextButton(onClick = { setRouteIcon(routeName, "🗺️"); pendingRouteIcon = null }) { Text("Restaurar padrão") } }
                )
            }
            pendingRenameRoute?.let { oldRouteName ->
                AlertDialog(
                    onDismissRequest = { pendingRenameRoute = null },
                    title = { Text("Renomear roteiro") },
                    text = {
                        OutlinedTextField(
                            value = renameRouteName,
                            onValueChange = { renameRouteName = it },
                            label = { Text("Nome do roteiro") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val newRouteName = renameRouteName.trim()
                            val nameAlreadyUsed = destinations.any {
                                !it.itineraryName.isNullOrBlank() &&
                                    it.itineraryName.equals(newRouteName, ignoreCase = true) &&
                                    it.itineraryName != oldRouteName
                            }
                            when {
                                newRouteName.isBlank() -> status = "Informe um nome para o roteiro"
                                newRouteName == oldRouteName -> pendingRenameRoute = null
                                nameAlreadyUsed -> status = "Já existe um roteiro com esse nome"
                                else -> {
                                    save(destinations.map { destination ->
                                        if (destination.itineraryName == oldRouteName) destination.copy(itineraryName = newRouteName)
                                        else destination
                                    })
                                    if (activeItinerary == oldRouteName) {
                                        DestinationStore.setActiveItinerary(this@MainActivity, newRouteName)
                                        activeItinerary = newRouteName
                                    }
                                    expandedRouteCards = expandedRouteCards - "main:$oldRouteName" + "main:$newRouteName"
                                    expandedDestinationCards = expandedDestinationCards - "dest-route:$oldRouteName" + "dest-route:$newRouteName"
                                    routeIcons[oldRouteName]?.let { oldIcon ->
                                        val updatedIcons = routeIcons.toMutableMap().apply {
                                            remove(oldRouteName)
                                            put(newRouteName, oldIcon)
                                        }
                                        routeIcons = updatedIcons
                                        DestinationStore.saveItineraryIcons(this@MainActivity, updatedIcons)
                                    }
                                    status = "Roteiro renomeado para: $newRouteName"
                                    pendingRenameRoute = null
                                }
                            }
                        }) { Text("Salvar") }
                    },
                    dismissButton = {
                        TextButton(onClick = { pendingRenameRoute = null }) { Text("Cancelar") }
                    }
                )
            }
            pendingDelete?.let { destination ->
                AlertDialog(
                    onDismissRequest = { pendingDelete = null },
                    title = { Text("Confirmar exclusão") },
                    text = { Text("Tem certeza de que deseja excluir \"${destination.name}\"${destination.itineraryName?.let { " do roteiro $it" } ?: ""}? Esta ação não pode ser desfeita.") },
                    confirmButton = {
                        TextButton(onClick = {
                            save(destinations.filterNot { it.id == destination.id })
                            pendingDelete = null
                            status = "Destino excluído"
                        }) { Text("Excluir") }
                    },
                    dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancelar") } }
                )
            }
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = MaterialTheme.colorScheme.surface,
                        drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp)
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 28.dp, bottom = 22.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Surface(color = brandNavy, shape = RoundedCornerShape(14.dp), modifier = Modifier.size(48.dp)) {
                                    Box(contentAlignment = androidx.compose.ui.Alignment.Center) {
                                        Text("AG", color = Color.White, style = MaterialTheme.typography.titleMedium)
                                    }
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("Alerta Geográfico", style = MaterialTheme.typography.titleMedium, color = brandNavy)
                                    Text("PROXIMIDADE • ROTAS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("MENU PRINCIPAL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.65f))
                        listOf("Início", "Adicionar destino", "Destinos cadastrados", "Roteiros", "Estações", "Preferências", "Ajuda", "Sobre").forEach { section ->
                            val glyph = when (section) {
                                "Início" -> "⌂"
                                "Adicionar destino" -> "+"
                                "Destinos cadastrados" -> "◎"
                                "Roteiros" -> "↗"
                                "Estações" -> "🚆"
                                "Preferências" -> "⚙"
                                "Ajuda" -> "?"
                                else -> "ⓘ"
                            }
                            NavigationDrawerItem(
                                icon = { Text(glyph, style = MaterialTheme.typography.titleLarge) },
                                label = { Text(section, style = MaterialTheme.typography.labelLarge) },
                                selected = selectedSection == section,
                                onClick = {
                                    selectedSection = section
                                    scope.launch { drawerState.close() }
                                },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        Text("ALERTA GEOGRÁFICO  •  VERSÃO ${appVersionName}", modifier = Modifier.padding(20.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            ) {
            Scaffold(topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = brandNavy,
                        navigationIconContentColor = brandNavy
                    ),
                    title = {
                        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                            Text(selectedSection, style = MaterialTheme.typography.titleLarge)
                            Text("ALERTA GEOGRÁFICO", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Abrir menu")
                        }
                    }
                )
            }) { padding ->
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (selectedSection == "Início") item {
                        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            // Cabeçalho da página inicial, inspirado no conceito visual aprovado.
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(24.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                                            Text("🚆", modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.headlineMedium)
                                        }
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            Text("Alerta Geográfico", style = MaterialTheme.typography.titleLarge)
                                            Text("Nunca perca sua parada.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("CENTRAL DE MONITORAMENTO", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f))
                                    Text("Seu monitoramento", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Surface(
                                            color = if (monitoring) Color(0xFF2E7D65) else MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.10f),
                                            shape = RoundedCornerShape(50)
                                        ) {
                                            Text(
                                                if (monitoring) "● ATIVO" else "● EM ESPERA",
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (monitoring) Color.White else MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                        Text(status, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    }
                                    Text("O que deseja monitorar?", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                        RadioButton(selected = monitorMode == "individual", onClick = { monitorMode = "individual" })
                                        Text("Destino individual", modifier = Modifier.weight(1f))
                                        RadioButton(selected = monitorMode == "route", onClick = { monitorMode = "route" })
                                        Text("Roteiro")
                                    }
                                    if (monitorMode == "individual") {
                                        Box {
                                            OutlinedButton(onClick = { destinationMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                                Text(destinations.firstOrNull { it.id == selectedDestinationId }?.let { it.name + if (it.enabled) "" else " (pausado)" } ?: "Selecionar destino")
                                            }
                                            DropdownMenu(expanded = destinationMenuExpanded, onDismissRequest = { destinationMenuExpanded = false }) {
                                                destinations.filter { it.itineraryName.isNullOrBlank() }.forEach { destination ->
                                                    DropdownMenuItem(text = { Text(destination.name + if (destination.enabled) "" else " (pausado)") }, enabled = destination.enabled, onClick = {
                                                        selectedDestinationId = destination.id
                                                        destinationMenuExpanded = false
                                                    })
                                                }
                                            }
                                        }
                                    } else {
                                        val routeNames = destinations.mapNotNull { it.itineraryName?.takeIf { name -> name.isNotBlank() } }.distinct()
                                        Box {
                                            OutlinedButton(onClick = { routeMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                                Text(activeItinerary ?: "Selecionar roteiro")
                                            }
                                            DropdownMenu(expanded = routeMenuExpanded, onDismissRequest = { routeMenuExpanded = false }) {
                                                routeNames.forEach { routeName ->
                                                    DropdownMenuItem(text = { Text(routeName) }, onClick = {
                                                        activeItinerary = routeName
                                                        DestinationStore.setActiveItinerary(this@MainActivity, routeName)
                                                        routeMenuExpanded = false
                                                    })
                                                }
                                            }
                                        }
                                        Text("Sentido do roteiro", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            FilterChip(
                                                selected = routeDirection == "ida",
                                                enabled = !monitoring,
                                                onClick = {
                                                    routeDirection = "ida"
                                                    DestinationStore.setRouteDirection(this@MainActivity, "ida")
                                                    status = "Sentido definido: ida"
                                                },
                                                label = { Text("→ Ida") },
                                                modifier = Modifier.weight(1f)
                                            )
                                            FilterChip(
                                                selected = routeDirection == "volta",
                                                enabled = !monitoring,
                                                onClick = {
                                                    routeDirection = "volta"
                                                    DestinationStore.setRouteDirection(this@MainActivity, "volta")
                                                    status = "Sentido definido: volta (ordem invertida)"
                                                },
                                                label = { Text("← Volta") },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                        Text(
                                            if (monitoring) "Pare o monitoramento para trocar o sentido do roteiro."
                                            else if (routeDirection == "volta") "As paradas serão percorridas na ordem inversa, sem alterar o roteiro cadastrado."
                                            else "As paradas serão percorridas na ordem cadastrada.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    val dashUpdateTick = dashboardRefresh
                                    val dashPrefs = DestinationStore.dashboard(this@MainActivity)
                                    val dashTarget = dashPrefs.getString(DestinationStore.KEY_DASH_TARGET, null)
                                    val dashNext = dashPrefs.getString(DestinationStore.KEY_DASH_NEXT, "—") ?: "—"
                                    val dashDistance = dashPrefs.getInt(DestinationStore.KEY_DASH_DISTANCE, -1)
                                    val dashEta = dashPrefs.getInt(DestinationStore.KEY_DASH_ETA, -1)
                                    val dashEtaMin = dashPrefs.getInt(DestinationStore.KEY_DASH_ETA_MIN, dashEta)
                                    val dashEtaMax = dashPrefs.getInt(DestinationStore.KEY_DASH_ETA_MAX, dashEta)
                                    val dashEtaConfidence = dashPrefs.getString(DestinationStore.KEY_DASH_ETA_CONFIDENCE, "normal") ?: "normal"
                                    val dashDistanceMode = dashPrefs.getString(DestinationStore.KEY_DASH_DISTANCE_MODE, "straight") ?: "straight"
                                    val etaText = when {
                                        !monitoring -> "—"
                                        monitorMode == "route" && dashNext == "Roteiro concluído" -> "roteiro concluído"
                                        dashEtaMin == 0 && dashEtaMax == 0 -> "dentro do raio da próxima parada"
                                        dashEtaMin > 0 && dashEtaMax >= dashEtaMin -> "${formatEtaMinutes(dashEtaMin)}–${formatEtaMinutes(dashEtaMax)}"
                                        else -> "aguardando dados GPS válidos"
                                    }
                                    val etaStatusText = when {
                                        monitorMode == "route" && dashNext == "Roteiro concluído" -> "Todas as paradas do roteiro foram concluídas."
                                        dashEtaConfidence == "paused" -> "Pausa breve — mantendo a última estimativa"
                                        dashEtaConfidence == "low_confidence" -> "Baixa confiança — localização imprecisa ou desatualizada"
                                        dashEtaConfidence == "unavailable" -> "Estimativa indisponível — aguardando GPS confiável"
                                        dashDistanceMode == "rail" -> "Distância calculada pela malha ferroviária importada do OpenStreetMap; o tempo continua sendo uma estimativa."
                                        else -> "Sem caminho ferroviário confiável entre os pontos; distância em linha reta."
                                    }
                                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                            Text("Destino ativo", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(if (monitoring) dashTarget ?: "Aguardando localização" else "Nenhum — monitoramento parado", style = MaterialTheme.typography.bodyLarge)
                                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                            Text("Próxima parada", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(if (monitoring) dashNext else "—", style = MaterialTheme.typography.titleMedium)
                                            if (monitoring && monitorMode == "route" && dashNext != "Roteiro concluído") {
                                                LinearProgressIndicator(
                                                    modifier = Modifier.fillMaxWidth().height(3.dp),
                                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
                                                    trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                                                )
                                            }
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                    Text("Distância", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    Text(if (monitoring && dashDistance >= 0) if (dashDistance >= 1000) String.format(Locale.getDefault(), "%.1f km", dashDistance / 1000.0) else "$dashDistance m" else "—", style = MaterialTheme.typography.titleSmall)
                                                    Text(if (dashDistanceMode == "rail") "Pela malha ferroviária" else if (monitorMode == "route") "Até a próxima parada" else "Restante", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                    Text("Tempo", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    Text(etaText, style = MaterialTheme.typography.titleSmall)
                                                    Text(if (dashUpdateTick >= 0) "Estimativa por GPS" else "Aguardando atualização", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                            }
                                            Text(etaStatusText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Button(
                                        onClick = {
                                            if (monitoring || DestinationStore.monitoringActive(this@MainActivity)) {
                                                stopService(Intent(this@MainActivity, LocationMonitorService::class.java))
                                                DestinationStore.setMonitoringActive(this@MainActivity, false)
                                                monitoring = false
                                                status = "Monitoramento parado"
                                            } else {
                                                val permissions = mutableListOf(
                                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                                )
                                                if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
                                                val missing = permissions.filter {
                                                    ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
                                                }
                                                if (missing.isEmpty()) startMonitoring()
                                                else permissionLauncher.launch(missing.toTypedArray())
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (monitoring) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                        )
                                    ) { Text(if (monitoring) "■  Parar monitoramento" else "▶  Iniciar monitoramento") }
                                        }
                                    }
                                    // A sequência de estações é calculada continuamente pelo serviço usando o GPS,
                                    // independentemente de onde o usuário começou a monitorar.
                                    val stationPrefs = DestinationStore.dashboard(this@MainActivity)
                                    val stationRouteName = stationPrefs.getString(DestinationStore.KEY_STATION_ROUTE, null)
                                    val stationOperator = stationPrefs.getString(DestinationStore.KEY_STATION_OPERATOR, null)
                                    val stationPrevious = stationPrefs.getString(DestinationStore.KEY_STATION_PREVIOUS, null)
                                    val stationCurrent = stationPrefs.getString(DestinationStore.KEY_STATION_CURRENT, null)
                                    val stationNext = stationPrefs.getString(DestinationStore.KEY_STATION_NEXT, null)
                                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text("Estações ferroviárias", style = MaterialTheme.typography.titleMedium)
                                            if (!monitoring) {
                                                Text("Inicie o monitoramento para estimar as estações pela posição GPS.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            } else if (stationCurrent.isNullOrBlank()) {
                                                Text(
                                                    if (!StationNavigationStore.hasStations(this@MainActivity) || !StationNavigationStore.hasRoutes(this@MainActivity))
                                                        "Importe os GeoJSON de estações e linhas na seção Estações para ativar esta identificação."
                                                    else "Identificando a linha e as estações pela posição GPS…",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            } else {
                                                Text(listOfNotNull(stationRouteName, stationOperator?.takeIf { it.isNotBlank() }).joinToString(" • "), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text("Anterior: ${stationPrevious ?: "Não identificada"}")
                                                Text("Atual estimada: $stationCurrent", style = MaterialTheme.typography.titleSmall)
                                                Text("Próxima: ${stationNext ?: "Não identificada"}")
                                                Text("Estimativa por GPS; pode variar em linhas paralelas, ramificações ou túneis.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            }
                            // Ações secundárias aparecem depois do painel e das informações ferroviárias.
                            Card(
                                onClick = { startActivity(Intent(this@MainActivity, MapActivity::class.java)) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                            ) {
                                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("Mapa e malha ferroviária", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        Text("Veja destinos, estações e linhas importadas", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.82f))
                                        Text("Abrir mapa  →", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Text("🗺️", style = MaterialTheme.typography.headlineLarge)
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Card(Modifier.weight(1f)) {
                                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("${destinations.size}", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                                        Text("Destinos", style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                                Card(Modifier.weight(1f)) {
                                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("${destinations.count { it.enabled }}", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                                        Text("Ativos", style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                                Card(Modifier.weight(1f)) {
                                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("${destinations.mapNotNull { it.itineraryName }.distinct().size}", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                                        Text("Roteiros", style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                            Text("Dica: mantenha a localização permitida e confira as restrições de bateria para melhorar a confiabilidade dos alertas.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (selectedSection == "Adicionar destino") item {
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Novo local", style = MaterialTheme.typography.titleLarge)
                                Text("Escolha um destino individual ou adicione paradas a um roteiro.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (selectedSection == "Adicionar destino") item {
                        Text("Tipo de cadastro", style = MaterialTheme.typography.bodyMedium)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (entryMode == "Único") Button(onClick = { entryMode = "Único" }, modifier = Modifier.weight(1f)) { Text("Destino único") }
                            else OutlinedButton(onClick = { entryMode = "Único" }, modifier = Modifier.weight(1f)) { Text("Destino único") }
                            if (entryMode == "Roteiro") Button(onClick = { entryMode = "Roteiro" }, modifier = Modifier.weight(1f)) { Text("Roteiro de viagem") }
                            else OutlinedButton(onClick = { entryMode = "Roteiro" }, modifier = Modifier.weight(1f)) { Text("Roteiro de viagem") }
                        }
                    }
                    if (selectedSection == "Adicionar destino" && entryMode == "Roteiro") {
                        item {
                            OutlinedTextField(
                                itineraryName, { itineraryName = it },
                                label = { Text("Nome do roteiro") },
                                placeholder = { Text("Ex.: Viagem para o litoral") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text("Adicione os pontos um por vez usando o mesmo nome de roteiro. Eles aparecerão conectados no mapa na ordem cadastrada.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (selectedSection == "Adicionar destino") item { OutlinedTextField(name, { name = it }, label = { Text("Nome") }, modifier = Modifier.fillMaxWidth()) }
                    if (selectedSection == "Adicionar destino") item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Escolha um ícone para o destino", style = MaterialTheme.typography.labelLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                                listOf("📍", "🏠", "💼", "⛽", "🛒", "🏥", "🏫", "🍽️", "🅿️", "🚉", "🏖️", "⭐").forEach { iconChoice ->
                                    FilterChip(selected = selectedDestinationIcon == iconChoice, onClick = { selectedDestinationIcon = iconChoice }, label = { Text(iconChoice) })
                                }
                            }
                        }
                    }
                    if (selectedSection == "Adicionar destino") item {
                        OutlinedTextField(
                            place,
                            { place = it },
                            label = { Text("Local ou endereço") },
                            placeholder = { Text("Ex.: Praça da Sé, São Paulo") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (selectedSection == "Adicionar destino") item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    if (place.isBlank()) {
                                        status = "Informe o nome do local ou endereço primeiro"
                                    } else {
                                        val query = place.trim()
                                        status = "Procurando local…"
                                        scope.launch {
                                            // Rede fora da thread principal para não travar a interface.
                                            val outcome = withContext(Dispatchers.IO) {
                                                runCatching {
                                                    check(Geocoder.isPresent()) { "sem serviço de geocodificação" }
                                                    @Suppress("DEPRECATION")
                                                    val found = Geocoder(this@MainActivity, Locale("pt", "BR"))
                                                        .getFromLocationName(query, 1)?.firstOrNull()
                                                    found
                                                }
                                            }
                                            val result = outcome.getOrNull()
                                            status = when {
                                                outcome.isFailure ->
                                                    "Não foi possível localizar o endereço. Verifique a internet e tente novamente."
                                                result == null ->
                                                    "Local não encontrado. Tente informar endereço e cidade."
                                                else -> {
                                                    latitude = result.latitude.toString()
                                                    longitude = result.longitude.toString()
                                                    if (name.isBlank()) name = query
                                                    "Local encontrado: ${result.latitude}, ${result.longitude}"
                                                }
                                            }
                                        }
                                    }
                                }, modifier = Modifier.weight(1f)
                            ) { Text("Selecionar local") }
                            OutlinedButton(
                                onClick = {
                                    val lat = latitude.trim().replace(',', '.').toDoubleOrNull()
                                    val lon = longitude.trim().replace(',', '.').toDoubleOrNull()
                                    val rad = radius.trim().toIntOrNull()
                                    if (lat == null || lat !in -90.0..90.0 || lon == null || lon !in -180.0..180.0) {
                                        status = "Informe ou selecione um local para visualizar o raio no mapa"
                                    } else if (rad == null || rad !in 50..10000) {
                                        status = "Informe um raio válido entre 50 e 10000 metros"
                                    } else {
                                        val preview = Destination(
                                            name = name.ifBlank { place.ifBlank { "Prévia do destino" } },
                                            latitude = lat,
                                            longitude = lon,
                                            radiusMeters = rad,
                                            message = message.ifBlank { "Você está chegando ao destino" },
                                            enabled = true,
                                            itineraryName = if (entryMode == "Roteiro") itineraryName.ifBlank { null } else null,
                                            oneShot = oneShot
                                        )
                                        val payload = org.json.JSONArray().put(preview.toJson()).toString()
                                        startActivity(Intent(this@MainActivity, MapActivity::class.java).putExtra(MapActivity.EXTRA_DESTINATIONS, payload))
                                    }
                                }, modifier = Modifier.weight(1f)
                            ) { Text("Pré-visualizar raio") }
                        }
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(this@MainActivity, MapActivity::class.java)
                                    .putExtra(MapActivity.EXTRA_DESTINATIONS, "[]")
                                    .putExtra(MapActivity.EXTRA_SELECT_POINT, true)
                                mapPointPicker.launch(intent)
                            }, modifier = Modifier.fillMaxWidth()
                        ) { Text("Adicionar a partir de um ponto no mapa") }
                        Text("Você pode pesquisar um endereço ou tocar diretamente no mapa. O ponto escolhido preencherá as coordenadas automaticamente.",
                            style = MaterialTheme.typography.bodySmall)
                    }
                    if (selectedSection == "Adicionar destino") item {
                        OutlinedTextField(radius, { radius = it }, label = { Text("Raio em metros (50–10000)") }, modifier = Modifier.fillMaxWidth())
                        Text("Pré-visualize a área circular onde o alerta será disparado antes de salvar o destino.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (selectedSection == "Adicionar destino") item { OutlinedTextField(message, { message = it }, label = { Text("Mensagem do alerta") }, modifier = Modifier.fillMaxWidth()) }
                    if (selectedSection == "Adicionar destino") item {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Alertar só uma vez")
                                Text("O destino é desativado depois do primeiro alerta.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = oneShot, onCheckedChange = { oneShot = it })
                        }
                    }
                    if (selectedSection == "Adicionar destino") item {
                        Button(onClick = {
                            val lat = latitude.trim().replace(',', '.').toDoubleOrNull()
                            val lon = longitude.trim().replace(',', '.').toDoubleOrNull()
                            val rad = radius.toIntOrNull()
                            if (name.isBlank() || lat == null || lat !in -90.0..90.0 ||
                                lon == null || lon !in -180.0..180.0 || rad == null || rad !in 50..10000) {
                                status = "Confira nome, coordenadas e raio (50 a 10000 m)"
                            } else {
                                if (entryMode == "Roteiro" && itineraryName.isBlank()) {
                                    status = "Informe um nome para o roteiro"
                                } else {
                                    save(destinations + Destination(name = name.trim(), latitude = lat, longitude = lon,
                                        radiusMeters = rad, message = message.ifBlank { "Você está chegando ao destino" },
                                        itineraryName = if (entryMode == "Roteiro") itineraryName.trim() else null,
                                        oneShot = oneShot,
                                        locationLabel = place.trim().takeIf { it.isNotEmpty() },
                                        icon = selectedDestinationIcon))
                                    name = ""; place = ""; latitude = ""; longitude = ""; radius = "300"; oneShot = false; selectedDestinationIcon = "📍"
                                    message = "Você está chegando ao destino"
                                    status = if (entryMode == "Roteiro") "Ponto adicionado ao roteiro: ${itineraryName.trim()}" else "Destino adicionado"
                                }
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Adicionar destino") }
                    }
                    if (selectedSection == "Adicionar destino") item {
                        Button(onClick = { csvPicker.launch(arrayOf("text/*", "application/*", "application/octet-stream")) },
                            modifier = Modifier.fillMaxWidth()) { Text("Importar destinos CSV") }
                    }
                    if (selectedSection == "Adicionar destino" && importReport.isNotBlank()) {
                        item {
                            Card {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Resultado da importação", style = MaterialTheme.typography.titleMedium)
                                    Text(importReport)
                                    pendingImport?.let { batch ->
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(onClick = {
                                                save(destinations + batch)
                                                pendingImport = null
                                                importReport = "Importação concluída: ${batch.size} destino(s) adicionado(s)."
                                            }) { Text("Confirmar") }
                                            OutlinedButton(onClick = {
                                                pendingImport = null
                                                importReport = "Importação cancelada."
                                            }) { Text("Cancelar") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (selectedSection == "Preferências") item {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Controle os avisos", style = MaterialTheme.typography.headlineSmall, color = brandNavy)
                            Text("As configurações abaixo valem para todos os destinos e roteiros.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (selectedSection == "Preferências") item {
                        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Atualização da localização", style = MaterialTheme.typography.titleMedium)
                                Text("Define a frequência solicitada ao Android para atualizar posição, distância e estimativa. O GPS pode variar conforme sinal e sistema.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Box {
                                    OutlinedButton(onClick = { locationIntervalMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (locationIntervalSeconds < 60) "$locationIntervalSeconds segundos" else if (locationIntervalSeconds % 60 == 0) "${locationIntervalSeconds / 60} minuto(s)" else "${locationIntervalSeconds / 60} min ${locationIntervalSeconds % 60} s")
                                    }
                                    DropdownMenu(expanded = locationIntervalMenuExpanded, onDismissRequest = { locationIntervalMenuExpanded = false }) {
                                        listOf(5, 10, 15, 30, 60, 120, 180, 240, 300).forEach { seconds ->
                                            DropdownMenuItem(
                                                text = { Text(if (seconds < 60) "$seconds segundos" else "${seconds / 60} minuto(s)") },
                                                onClick = {
                                                    locationIntervalSeconds = seconds
                                                    DestinationStore.setLocationIntervalSeconds(this@MainActivity, seconds)
                                                    locationIntervalMenuExpanded = false
                                                },
                                                leadingIcon = { if (locationIntervalSeconds == seconds) Text("✓") }
                                            )
                                        }
                                    }
                                }
                                Text("A alteração também se aplica se o monitoramento já estiver ativo.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                HorizontalDivider()
                                Text("Modo de monitoramento e bateria", style = MaterialTheme.typography.titleMedium)
                                Text("Escolha entre priorizar a precisão ou reduzir o consumo. O perfil pode ajustar a frequência efetiva, especialmente perto de um destino.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Box {
                                    OutlinedButton(onClick = { batteryProfileMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                        Text(when (batteryProfile) {
                                            "precision" -> "Precisão"
                                            "economy" -> "Economia"
                                            else -> "Equilibrado"
                                        })
                                    }
                                    DropdownMenu(expanded = batteryProfileMenuExpanded, onDismissRequest = { batteryProfileMenuExpanded = false }) {
                                        listOf(
                                            "precision" to "Precisão",
                                            "balanced" to "Equilibrado",
                                            "economy" to "Economia"
                                        ).forEach { (profile, label) ->
                                            DropdownMenuItem(
                                                text = { Text(label) },
                                                onClick = {
                                                    batteryProfile = profile
                                                    DestinationStore.setBatteryProfile(this@MainActivity, profile)
                                                    batteryProfileMenuExpanded = false
                                                },
                                                leadingIcon = { if (batteryProfile == profile) Text("✓") }
                                            )
                                        }
                                    }
                                }
                                Text(when (batteryProfile) {
                                    "precision" -> "Usa o intervalo escolhido e localização de alta precisão. Consome mais bateria."
                                    "economy" -> "Reduz atualizações quando estiver longe dos destinos ou parado; aumenta a frequência ao se aproximar de uma parada. Os alertas podem atrasar mais."
                                    else -> "Equilibra precisão e consumo, usando atualizações menos frequentes longe dos destinos e maior precisão perto deles."
                                }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                HorizontalDivider()
                                Text("Bateria", style = MaterialTheme.typography.titleMedium)
                                Text("Abra as informações do aplicativo no Android para consultar o uso de bateria disponível no aparelho.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                OutlinedButton(
                                    onClick = {
                                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                                        runCatching { startActivity(intent) }.onFailure {
                                            status = "Não foi possível abrir as informações do aplicativo nas configurações do Android"
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Ver uso de bateria") }
                            }
                        }
                    }
                    if (selectedSection == "Preferências") item {
                        Card(shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Permissões do aplicativo", style = MaterialTheme.typography.titleMedium)
                                Text("Abra as configurações do Android para revisar localização, notificações e outras permissões do Alerta Geográfico.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                OutlinedButton(onClick = {
                                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                                    runCatching { startActivity(intent) }.onFailure { status = "Não foi possível abrir as permissões do aplicativo" }
                                }, modifier = Modifier.fillMaxWidth()) { Text("Gerenciar permissões") }
                            }
                        }
                    }
                    if (selectedSection == "Preferências") item {
                        Card(shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Preferência das camadas do mapa", style = MaterialTheme.typography.titleMedium)
                                Text("Escolha quais camadas ferroviárias devem aparecer por padrão quando o mapa for aberto. Você também pode alterar isso diretamente no mapa; a preferência será lembrada.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                    Text("Linhas ferroviárias", modifier = Modifier.weight(1f))
                                    Switch(checked = showRailLinesOnMap, onCheckedChange = { checked ->
                                        showRailLinesOnMap = checked
                                        getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE).edit().putBoolean(MapActivity.PREF_SHOW_RAIL_LINES, checked).apply()
                                    })
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                    Text("Estações", modifier = Modifier.weight(1f))
                                    Switch(checked = showRailStationsOnMap, onCheckedChange = { checked ->
                                        showRailStationsOnMap = checked
                                        getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE).edit().putBoolean(MapActivity.PREF_SHOW_RAIL_STATIONS, checked).apply()
                                    })
                                }
                            }
                        }
                    }
                    if (selectedSection == "Preferências") item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Som de alerta (todos os destinos)")
                                Text(if (!sound) "Silencioso" else selectedSoundUri?.let { uri -> RingtoneManager.getRingtone(this@MainActivity, Uri.parse(uri))?.getTitle(this@MainActivity) ?: "Som personalizado" } ?: "Som padrão de notificação", style = MaterialTheme.typography.bodySmall)
                            }
                            Button(onClick = {
                                val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_ALARM)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Escolher som dos alertas")
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, selectedSoundUri?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                                }
                                soundPicker.launch(intent)
                            }) { Text("Escolher") }
                        }
                        HorizontalDivider()
                        Text("Canal de áudio", style = MaterialTheme.typography.titleMedium)
                        Text("Escolha se o alerta usa o volume de mídia (como YouTube e Spotify) ou o volume de notificações do Android.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Box {
                            OutlinedButton(onClick = { alertAudioModeMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (alertAudioMode == "media") "Som de mídia" else "Som de notificação")
                            }
                            DropdownMenu(expanded = alertAudioModeMenuExpanded, onDismissRequest = { alertAudioModeMenuExpanded = false }) {
                                listOf("media" to "Som de mídia", "notification" to "Som de notificação").forEach { (mode, label) ->
                                    DropdownMenuItem(
                                        text = { Text(label) },
                                        onClick = {
                                            alertAudioMode = mode
                                            DestinationStore.setAlertAudioMode(this@MainActivity, mode)
                                            alertAudioModeMenuExpanded = false
                                        },
                                        leadingIcon = { if (alertAudioMode == mode) Text("✓") }
                                    )
                                }
                            }
                        }
                        Text("Comportamento da música", style = MaterialTheme.typography.titleMedium)
                        Text("Se o Modo alarme estiver ativado abaixo, ele terá prioridade sobre o canal escolhido.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Box {
                            OutlinedButton(onClick = { alertMixModeMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (alertMixMode == "duck") "Diminuir música temporariamente" else "Tocar alerta sobre a música")
                            }
                            DropdownMenu(expanded = alertMixModeMenuExpanded, onDismissRequest = { alertMixModeMenuExpanded = false }) {
                                listOf("duck" to "Diminuir música temporariamente", "overlap" to "Tocar alerta sobre a música").forEach { (mode, label) ->
                                    DropdownMenuItem(
                                        text = { Text(label) },
                                        onClick = {
                                            alertMixMode = mode
                                            DestinationStore.setAlertMixMode(this@MainActivity, mode)
                                            alertMixModeMenuExpanded = false
                                        },
                                        leadingIcon = { if (alertMixMode == mode) Text("✓") }
                                    )
                                }
                            }
                        }
                        Text(
                            if (alertMixMode == "duck") "O aplicativo solicita foco de áudio temporário para reduzir a música enquanto o alerta toca. O resultado depende do outro player e do Android."
                            else "O aplicativo não solicita foco de áudio; tenta tocar junto com a música. Alguns players ou dispositivos ainda podem interromper ou reduzir o áudio.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text("Onde tocar o alerta", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "O Android pode limitar o roteamento em alguns modelos. Se nenhum fone estiver conectado, o alerta toca no alto-falante para você não perdê-lo.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            RadioButton(
                                selected = alertAudioOutput == "headphones",
                                onClick = {
                                    alertAudioOutput = "headphones"
                                    DestinationStore.setAlertAudioOutput(this@MainActivity, alertAudioOutput)
                                }
                            )
                            Column(Modifier.weight(1f)) {
                                Text("Tocar no fone")
                                Text("Bluetooth, USB ou fone com fio", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            RadioButton(
                                selected = alertAudioOutput == "speaker",
                                onClick = {
                                    alertAudioOutput = "speaker"
                                    DestinationStore.setAlertAudioOutput(this@MainActivity, alertAudioOutput)
                                }
                            )
                            Column(Modifier.weight(1f)) {
                                Text("Tocar no alto-falante")
                                Text("Usar o alto-falante do celular", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Text("Volume do alerta: ${(alertVolume * 100).toInt()}%", style = MaterialTheme.typography.titleSmall)
                        Slider(
                            value = alertVolume,
                            onValueChange = { alertVolume = it },
                            onValueChangeFinished = { DestinationStore.setAlertVolume(this@MainActivity, alertVolume) },
                            valueRange = 0f..1f,
                            enabled = sound
                        )
                        Text("Este controle ajusta o volume do player do aplicativo. O volume geral de mídia do Android também pode afetar o resultado.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Ativar som")
                            Switch(checked = sound, onCheckedChange = {
                                sound = it; DestinationStore.setSoundEnabled(this@MainActivity, it); recreateAlertChannel()
                            })
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Modo alarme")
                                Text("Toca como alarme (mesmo com a mídia no mudo), repetindo até você tocar em OK ou por 60 s.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = alarmMode, onCheckedChange = {
                                alarmMode = it; DestinationStore.setAlarmMode(this@MainActivity, it)
                            })
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Vibração")
                            Switch(checked = vibration, onCheckedChange = {
                                vibration = it; DestinationStore.setVibrationEnabled(this@MainActivity, it)
                            })
                        }
                    }
                    if (selectedSection == "Destinos cadastrados") item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Seus locais", style = MaterialTheme.typography.titleLarge)
                                Text("${destinations.count { it.enabled }} ativos de ${destinations.size} cadastrados", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Destinos cadastrados (${destinations.size})", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            TextButton(onClick = { showOnMap(destinations) }, enabled = destinations.isNotEmpty()) { Text("Ver todos no mapa") }
                        }
                    }
                    val itineraryGroups = destinations.filter { !it.itineraryName.isNullOrBlank() }.groupBy { it.itineraryName!! }
                    if (selectedSection == "Roteiros" && itineraryGroups.isEmpty()) item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Nenhum roteiro ainda", style = MaterialTheme.typography.titleMedium)
                                Text("Ao adicionar um destino, escolha ‘Roteiro de viagem’ e informe o nome do roteiro.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Button(onClick = { selectedSection = "Adicionar destino"; entryMode = "Roteiro" }) { Text("Criar roteiro") }
                            }
                        }
                    }
                    if (selectedSection == "Destinos cadastrados" && destinations.isEmpty()) item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Nenhum destino cadastrado", style = MaterialTheme.typography.titleMedium)
                                Text("Adicione seu primeiro local para começar a receber alertas de proximidade.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Button(onClick = { selectedSection = "Adicionar destino" }) { Text("Adicionar destino") }
                            }
                        }
                    }
                    if (selectedSection == "Roteiros" && itineraryGroups.isNotEmpty()) {
                        item { Text("Roteiros de viagem", style = MaterialTheme.typography.titleMedium) }
                        items(itineraryGroups.entries.toList(), key = { "route-${it.key}" }) { route ->
                            val expanded = expandedRouteCards.contains("main:${route.key}")
                            Card(onClick = {
                                expandedRouteCards = if (expanded) expandedRouteCards - "main:${route.key}" else expandedRouteCards + "main:${route.key}"
                            }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                        Text(routeIcons[route.key] ?: "🗺️", style = MaterialTheme.typography.headlineSmall)
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Text(route.key, style = MaterialTheme.typography.titleMedium)
                                            Text("${route.value.size} parada(s) · ${route.value.count { it.enabled }} ativa(s)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Text(if (expanded) "⌃" else "⌄", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                                    }
                                    if (expanded) {
                                        Text(route.value.mapIndexed { index, d -> "${index + 1}. ${d.name}" }.joinToString("  →  "), style = MaterialTheme.typography.bodyMedium)
                                        Text("Raio de alerta definido individualmente para cada parada.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(onClick = { showOnMap(route.value) }) { Text("Ver roteiro no mapa") }
                                            TextButton(onClick = { pendingRouteIcon = route.key }) { Text("Ícone") }
                                            TextButton(onClick = {
                                                renameRouteName = route.key
                                                pendingRenameRoute = route.key
                                            }) { Text("Renomear") }
                                            TextButton(onClick = {
                                                val next = if (activeItinerary == route.key) null else route.key
                                                DestinationStore.setActiveItinerary(this@MainActivity, next)
                                                activeItinerary = next
                                                if (next != null) monitorMode = "route"
                                                status = if (next == null) "Roteiro sequencial encerrado" else "Roteiro selecionado: ${route.key}. Volte ao Início e toque em Iniciar monitoramento."
                                            }) { Text(if (activeItinerary == route.key) "Parar sequência" else "Iniciar sequência") }
                                            TextButton(onClick = { selectedSection = "Adicionar destino"; entryMode = "Roteiro"; itineraryName = route.key }) { Text("Adicionar parada") }
                                        }
                                        if (activeItinerary == route.key) Text("Roteiro sequencial ativo: somente a próxima parada deste roteiro dispara o alerta. Parada ${DestinationStore.itineraryIndex(this@MainActivity) + 1} de ${route.value.size}.", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                    if (selectedSection == "Destinos cadastrados") {
                        val routeDestinations = destinations.filter { !it.itineraryName.isNullOrBlank() }
                        val individualDestinations = destinations.filter { it.itineraryName.isNullOrBlank() }

                        if (routeDestinations.isNotEmpty()) {
                            item { Text("Destinos agrupados por roteiro", style = MaterialTheme.typography.titleMedium) }
                            items(itineraryGroups.entries.toList(), key = { "dest-route-${it.key}" }) { route ->
                                val cardKey = "dest-route:${route.key}"
                                val expanded = expandedDestinationCards.contains(cardKey)
                                Card(onClick = {
                                    expandedDestinationCards = if (expanded) expandedDestinationCards - cardKey else expandedDestinationCards + cardKey
                                }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                            Text(routeIcons[route.key] ?: "🗺️", style = MaterialTheme.typography.headlineSmall)
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Text(route.key, style = MaterialTheme.typography.titleMedium)
                                                Text("${route.value.size} parada(s) · ${route.value.count { it.enabled }} ativa(s)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            Text(if (expanded) "⌃" else "⌄", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                                        }
                                        if (expanded) {
                                            HorizontalDivider()
                                            Text("Use as setas ↑ e ↓ para reorganizar a ordem das paradas.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            route.value.forEachIndexed { index, destination ->
                                                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                                        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(10.dp)) {
                                                            Text("${index + 1}", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge)
                                                        }
                                                        Spacer(Modifier.width(9.dp))
                                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                            Text("${destination.icon}  ${destination.name}", style = MaterialTheme.typography.titleSmall)
                                                            Text("Raio: ${destination.radiusMeters} m · ${if (destination.enabled) "Ativo" else "Pausado"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                        }
                                                        Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                                                            IconButton(
                                                                onClick = { moveItineraryStop(route.key, destination.id, -1) },
                                                                enabled = index > 0,
                                                                modifier = Modifier.size(36.dp)
                                                            ) { Text("↑", style = MaterialTheme.typography.titleMedium) }
                                                            IconButton(
                                                                onClick = { moveItineraryStop(route.key, destination.id, 1) },
                                                                enabled = index < route.value.lastIndex,
                                                                modifier = Modifier.size(36.dp)
                                                            ) { Text("↓", style = MaterialTheme.typography.titleMedium) }
                                                        }
                                                        Switch(checked = destination.enabled, onCheckedChange = { enabled ->
                                                            save(destinations.map { if (it.id == destination.id) it.copy(enabled = enabled) else it })
                                                        })
                                                    }
                                                    val stopPlace = destination.locationLabel?.takeIf { it.isNotBlank() } ?: decodedAddresses[destination.id]
                                                    if (!stopPlace.isNullOrBlank()) Text("Local: $stopPlace", style = MaterialTheme.typography.bodySmall)
                                                    else Text("Localização registrada no mapa", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    Row {
                                                        TextButton(onClick = { pendingEdit = destination }) { Text("Editar") }
                                                        TextButton(onClick = { pendingDelete = destination }) { Text("Excluir parada") }
                                                    }
                                                }
                                                if (index < route.value.lastIndex) HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                                            }
                                            OutlinedButton(onClick = { selectedSection = "Adicionar destino"; entryMode = "Roteiro"; itineraryName = route.key }, modifier = Modifier.fillMaxWidth()) { Text("Adicionar parada a este roteiro") }
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                TextButton(onClick = { pendingRouteIcon = route.key }) { Text("Ícone do roteiro") }
                                                TextButton(onClick = {
                                                    renameRouteName = route.key
                                                    pendingRenameRoute = route.key
                                                }) { Text("Renomear roteiro") }
                                                TextButton(onClick = { showOnMap(route.value) }) { Text("Ver roteiro no mapa") }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (individualDestinations.isNotEmpty()) {
                            item { Text("Destinos individuais", style = MaterialTheme.typography.titleMedium) }
                            items(individualDestinations, key = { "individual-${it.id}" }) { destination ->
                                val cardKey = "individual:${destination.id}"
                                val expanded = expandedDestinationCards.contains(cardKey)
                                Card(onClick = {
                                    expandedDestinationCards = if (expanded) expandedDestinationCards - cardKey else expandedDestinationCards + cardKey
                                }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                            Text(destination.icon, style = MaterialTheme.typography.headlineSmall)
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Text(destination.name, style = MaterialTheme.typography.titleMedium)
                                                Text("${destination.radiusMeters} m · ${if (destination.enabled) "Ativo" else "Pausado"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            Text(if (expanded) "⌃" else "⌄", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                                        }
                                        if (expanded) {
                                            val savedPlace = destination.locationLabel?.takeIf { it.isNotBlank() }
                                            val decodedAddress = decodedAddresses[destination.id]
                                            when {
                                                !savedPlace.isNullOrBlank() -> Text("Local: $savedPlace")
                                                !decodedAddress.isNullOrBlank() -> Text("Endereço: $decodedAddress")
                                                attemptedAddressIds.contains(destination.id) -> Text("Endereço não disponível para estas coordenadas", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                                else -> Text("Identificando endereço automaticamente…", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                            }
                                            Text("Raio: ${destination.radiusMeters} m${if (destination.oneShot) " · alerta único" else ""}")
                                            Text(destination.message)
                                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                                Text(if (destination.enabled) "Ativo" else "Desativado", modifier = Modifier.weight(1f))
                                                Switch(checked = destination.enabled, onCheckedChange = { enabled ->
                                                    save(destinations.map { if (it.id == destination.id) it.copy(enabled = enabled) else it })
                                                })
                                            }
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                OutlinedButton(onClick = { showOnMap(listOf(destination)) }) { Text("Ver no mapa") }
                                                TextButton(onClick = { pendingEdit = destination }) { Text("Editar") }
                                                TextButton(onClick = { pendingDelete = destination }) { Text("Excluir") }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (selectedSection == "Estações") item {
                        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Navegação por estações", style = MaterialTheme.typography.titleMedium)
                                    Text("Importe os arquivos GeoJSON do OpenStreetMap/Overpass Turbo: primeiro os pontos das estações e depois as geometrias das linhas/rotas. Se precisar dividir a Região Metropolitana em áreas menores por causa do timeout, importe vários arquivos do mesmo tipo: o app combina os dados. Depois, o GPS e os dados locais estimam a estação atual, a anterior e a próxima.", style = MaterialTheme.typography.bodyMedium)
                                    Text("Estações salvas: ${StationNavigationStore.stationCount(this@MainActivity)} • Linhas/rotas salvas: ${StationNavigationStore.routeCount(this@MainActivity)}", style = MaterialTheme.typography.labelLarge)
                                    HorizontalDivider()
                                    Text("Como obter os dados", style = MaterialTheme.typography.titleSmall)
                                    Text("1. Toque em Abrir Overpass Turbo. 2. No mapa, aproxime e enquadre uma área pequena da região que deseja baixar. 3. Copie a consulta abaixo, cole no editor do Overpass Turbo e toque em Executar. 4. Use Exportar → Dados → GeoJSON e salve o arquivo. Repita para estações e linhas/rotas. Se ocorrer timeout, reduza a área visível e tente novamente. Você pode importar vários arquivos de áreas diferentes.", style = MaterialTheme.typography.bodySmall)
                                    OutlinedButton(onClick = {
                                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://overpass-turbo.eu/")))
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Abrir Overpass Turbo") }
                                    Text("Consulta 1 — estações", style = MaterialTheme.typography.labelLarge)
                                    Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                                        Text(overpassStationsQuery, modifier = Modifier.fillMaxWidth().padding(10.dp), style = MaterialTheme.typography.bodySmall)
                                    }
                                    OutlinedButton(onClick = {
                                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Consulta Overpass - estações", overpassStationsQuery))
                                        stationImportMessage = "Consulta de estações copiada. Cole no editor do Overpass Turbo."
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Copiar código das estações") }
                                    Text("Consulta 2 — linhas/rotas ferroviárias", style = MaterialTheme.typography.labelLarge)
                                    Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                                        Text(overpassRoutesQuery, modifier = Modifier.fillMaxWidth().padding(10.dp), style = MaterialTheme.typography.bodySmall)
                                    }
                                    OutlinedButton(onClick = {
                                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Consulta Overpass - linhas e rotas", overpassRoutesQuery))
                                        stationImportMessage = "Consulta de linhas/rotas copiada. Cole no editor do Overpass Turbo."
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Copiar código das linhas/rotas") }
                                    Text("Depois de exportar cada resultado como GeoJSON, importe os dois tipos de arquivo nos botões abaixo. Os arquivos devem cobrir a área desejada. Atribuição: © OpenStreetMap contributors (ODbL).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    OutlinedButton(onClick = { stationGeoJsonLauncher.launch(arrayOf("application/geo+json", "application/json", "application/octet-stream", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Importar GeoJSON de estações") }
                                    OutlinedButton(onClick = { railRoutesGeoJsonLauncher.launch(arrayOf("application/geo+json", "application/json", "application/octet-stream", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Importar GeoJSON de linhas/rotas") }
                                    OutlinedButton(onClick = { confirmClearRailData = true }, modifier = Modifier.fillMaxWidth(), enabled = StationNavigationStore.hasStations(this@MainActivity) || StationNavigationStore.hasRoutes(this@MainActivity), colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Apagar todos os dados de estações e trilhos") }
                                    if (stationImportMessage.isNotBlank()) Text(stationImportMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                    HorizontalDivider()
                                    Button(onClick = { refreshStationPosition() }, enabled = !stationLoading, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (stationLoading) "Atualizando posição…" else "Atualizar posição pelo GPS")
                                    }
                                    Text(stationLocationStatus, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            stationResult?.let { result ->
                                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("${result.routeName}${result.operator.takeIf { it.isNotBlank() }?.let { " • $it" } ?: ""}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        Text("ESTAÇÃO ANTERIOR", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f))
                                        Text(result.previous?.name ?: "Não identificada", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.18f))
                                        Text("ESTAÇÃO ATUAL (estimada)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f))
                                        Text(result.current.name, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        Text("Aproximadamente ${result.distanceToCurrentMeters.toInt()} m da estação • ${result.distanceToLineMeters.toInt()} m da linha", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.18f))
                                        Text("PRÓXIMA ESTAÇÃO", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f))
                                        Text(result.next?.name ?: "Não identificada", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        result.distanceToNextMeters?.let { distance ->
                                            Text("Distância estimada pelos trilhos até a próxima: ${if (distance >= 1000) String.format(Locale.getDefault(), "%.1f km", distance / 1000.0) else "$distance m"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        }
                                    }
                                }
                            }
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Importante", style = MaterialTheme.typography.titleSmall)
                                    Text("A estação atual é uma estimativa por proximidade e posição ao longo da geometria ferroviária; não é uma confirmação de que você está dentro de um trem. A precisão depende da qualidade e da cobertura dos arquivos OSM. Em linhas paralelas, ramificações ou túneis, confira o resultado. Os arquivos importados ficam no armazenamento privado do app e podem ser usados sem internet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("Dados © OpenStreetMap contributors • ODbL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    if (selectedSection == "Preferências") item {
                        Card(shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Alerta antecipado por tempo estimado", style = MaterialTheme.typography.titleSmall)
                                Text("Define quantos minutos antes do destino tentar avisar. Usa distância em linha reta e velocidade GPS atual; não é uma previsão de rota viária. Use 0 para desativar.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                OutlinedTextField(value = etaLead, onValueChange = { etaLead = it.filter(Char::isDigit).take(2) }, label = { Text("Antecedência em minutos (0–30)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Button(onClick = {
                                    val minutes = etaLead.toIntOrNull()?.coerceIn(0, 30) ?: 0
                                    DestinationStore.setEtaAlertMinutes(this@MainActivity, minutes)
                                    etaLead = minutes.toString()
                                    status = if (minutes == 0) "Alerta antecipado desativado" else "Alerta antecipado configurado para aproximadamente $minutes min"
                                }, modifier = Modifier.fillMaxWidth()) { Text("Salvar antecedência") }
                                Text("Soneca: cada notificação de alerta tem a ação ‘Soneca 5 min’, que silencia novos alertas durante esse período.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    if (selectedSection == "Ajuda") item {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Como começar", style = MaterialTheme.typography.titleMedium)
                                    Text("1. Abra “Adicionar destino”. Informe um nome e escolha o local pela busca, pelo mapa ou pelas coordenadas.", style = MaterialTheme.typography.bodyMedium)
                                    Text("2. Ajuste o raio de alerta em metros e, se quiser, personalize a mensagem.", style = MaterialTheme.typography.bodyMedium)
                                    Text("3. Salve o destino e volte à tela Início para selecionar o modo de monitoramento.", style = MaterialTheme.typography.bodyMedium)
                                    Text("4. Toque em iniciar e mantenha a localização e as notificações permitidas pelo Android.", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Destinos e roteiros", style = MaterialTheme.typography.titleMedium)
                                    Text("Use “Destinos cadastrados” para consultar, ativar, editar, visualizar no mapa ou excluir locais. A exclusão pede confirmação.", style = MaterialTheme.typography.bodyMedium)
                                    Text("Para montar um roteiro, cadastre várias paradas com o mesmo nome de roteiro. A importação em lote aceita arquivos CSV; confira o relatório antes de importar.", style = MaterialTheme.typography.bodyMedium)
                                    Text("O monitoramento de roteiro considera as paradas habilitadas do roteiro selecionado. Confira os nomes e a ordem das paradas antes de iniciar.", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Alertas e precisão", style = MaterialTheme.typography.titleMedium)
                                    Text("O alerta é disparado quando a localização detectada entra no raio configurado. A precisão do GPS, prédios, túneis, economia de bateria e permissões podem atrasar ou impedir o aviso.", style = MaterialTheme.typography.bodyMedium)
                                    Text("Raios pequenos exigem uma localização mais precisa. Se os alertas não aparecerem, confira as permissões de localização e notificações, desative restrições agressivas de bateria para o app e teste o som em Preferências.", style = MaterialTheme.typography.bodyMedium)
                                    Text("O alerta antecipado é uma estimativa baseada em distância em linha reta e velocidade GPS, não uma previsão de rota. O app não substitui a atenção ao trajeto.", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Estações e navegação ferroviária", style = MaterialTheme.typography.titleMedium)
                                    Text("Na seção Estações, abra o Overpass Turbo, enquadre uma área pequena, copie a consulta de estações ou de linhas/rotas, execute-a e exporte o resultado em GeoJSON. Importe os arquivos correspondentes no aplicativo. Se ocorrer timeout, diminua a área do mapa e repita a consulta; você pode importar várias áreas do mesmo tipo.", style = MaterialTheme.typography.bodyMedium)
                                    Text("Com os dois tipos de dados importados, o app tenta estimar a estação anterior, atual e próxima pela posição GPS e pela malha ferroviária. O mapa pode mostrar as linhas e os marcadores, que podem ser tocados para consultar o nome. Use as camadas do mapa para exibir ou ocultar linhas e estações.", style = MaterialTheme.typography.bodyMedium)
                                    Text("A distância pela malha depende de geometrias conectadas e corretas. Em ramificações, linhas paralelas, dados incompletos ou túneis, a identificação pode ser imprecisa e o aplicativo pode recorrer à distância em linha reta. A estimativa não confirma que você está dentro de um trem.", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Solução de problemas", style = MaterialTheme.typography.titleMedium)
                                    Text("• Sem som: confira volume, saída de áudio, modo silencioso e as opções em Preferências.\n• Sem notificação: permita notificações nas configurações do Android. Use Preferências → Gerenciar permissões para abrir as configurações do app.\n• Localização imprecisa: permita localização precisa e verifique se o GPS está ativo.\n• Destino não encontrado na busca: tente um endereço mais completo ou selecione o ponto no mapa.", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                    if (selectedSection == "Sobre") item {
                        Card(shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Alerta Geográfico", style = MaterialTheme.typography.headlineSmall, color = brandNavy)
                                Text("Versão ${appVersionName}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Criado por Daniel Jr", style = MaterialTheme.typography.titleMedium)
                                HorizontalDivider()
                                Text("Propósito do aplicativo", style = MaterialTheme.typography.titleMedium)
                                Text("O Alerta Geográfico ajuda o usuário a lembrar de locais importantes durante um deslocamento. Você cadastra destinos ou organiza paradas em roteiros e define uma área de proximidade para receber um aviso quando o aparelho detectar que está chegando ao local.", style = MaterialTheme.typography.bodyMedium)
                                Text("A proposta é tornar viagens e deslocamentos mais tranquilos, especialmente quando a pessoa não quer depender de lembrar sozinha o momento de se aproximar de um destino.", style = MaterialTheme.typography.bodyMedium)
                                HorizontalDivider()
                                Text("Mapas e dados ferroviários", style = MaterialTheme.typography.titleMedium)
                                Text("Os dados de estações e linhas ferroviárias podem ser importados pelo usuário a partir do OpenStreetMap. A atribuição dos dados é © OpenStreetMap contributors, licenciados sob ODbL. O mapa base usa OpenFreeMap e precisa de conexão com a internet.", style = MaterialTheme.typography.bodyMedium)
                                Text("Os arquivos GeoJSON importados são guardados no armazenamento privado do aplicativo e podem ser usados localmente. A busca de locais e o carregamento do mapa base podem envolver serviços externos e conexão à internet.", style = MaterialTheme.typography.bodyMedium)
                                HorizontalDivider()
                                Text("Permissões e limitações", style = MaterialTheme.typography.titleMedium)
                                Text("Os alertas dependem das permissões do Android, da disponibilidade e precisão da localização e das configurações de notificação e bateria do aparelho. A navegação ferroviária é uma estimativa e pode ser afetada por dados incompletos, linhas paralelas ou sinal GPS fraco.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (selectedSection == "Preferências") item {
                        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Backup e restauração", style = MaterialTheme.typography.titleMedium)
                                Text("Salve destinos, roteiros, preferências e dados ferroviários offline em um arquivo JSON. Guarde o arquivo fora do celular para poder recuperar seus dados depois.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Button(onClick = { backupExportLauncher.launch("AlertaGeografico_backup.json") }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Criar backup")
                                }
                                OutlinedButton(onClick = { backupImportLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Restaurar backup")
                                }
                                Text("A restauração substitui os dados atuais. O monitoramento será interrompido para evitar alertas inesperados.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    if (selectedSection == "Preferências") item {
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                                        this@MainActivity, Manifest.permission.POST_NOTIFICATIONS
                                    ) != PackageManager.PERMISSION_GRANTED
                                ) {
                                    testNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    status = "Notificação de teste enviada; verificando saída de áudio…"
                                    showTestNotification { audioStatus -> status = audioStatus }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Testar notificação") }
                    }
                }
            }
            }
        }
    }
}
