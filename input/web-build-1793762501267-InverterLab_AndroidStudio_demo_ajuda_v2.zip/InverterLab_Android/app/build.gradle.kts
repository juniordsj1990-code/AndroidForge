plugins { id("com.android.application") }

android {
    namespace = "br.com.csautomacoes.cfw100ladderlab"
    compileSdk = 35

    defaultConfig {
        applicationId = "br.com.csautomacoes.cfw100ladderlab"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
