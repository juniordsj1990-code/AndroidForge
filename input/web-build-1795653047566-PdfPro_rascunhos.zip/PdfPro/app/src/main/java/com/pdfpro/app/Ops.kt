package com.pdfpro.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.RectF
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.multipdf.Splitter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionGoTo
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDNamedDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineNode
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDCheckBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDComboBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDListBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDRadioButton
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTextField
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import com.tom_roush.pdfbox.util.Matrix
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Operações de edição de PDF (PdfBox-Android) e utilitários de arquivo. Todas bloqueantes: chame em Dispatchers.IO. */
object Ops {
    private const val MEM = 24L * 1024 * 1024

    fun init(ctx: Context) {
        PDFBoxResourceLoader.init(ctx.applicationContext)
    }

    private fun open(f: File, pw: String = ""): PDDocument =
        PDDocument.load(f, pw, MemoryUsageSetting.setupMixed(MEM))

    // ---------- senha ----------

    fun unlock(src: File, pw: String, out: File) {
        open(src, pw).use { doc ->
            doc.setAllSecurityToBeRemoved(true)
            doc.save(out)
        }
    }

    fun protect(src: File, out: File, pw: String) {
        open(src).use { doc ->
            val policy = StandardProtectionPolicy(pw, pw, AccessPermission())
            policy.setEncryptionKeyLength(128)
            doc.protect(policy)
            doc.save(out)
        }
    }

    // ---------- páginas ----------

    fun merge(files: List<File>, out: File) {
        val m = PDFMergerUtility()
        files.forEach { m.addSource(it) }
        m.setDestinationFileName(out.absolutePath)
        m.mergeDocuments(MemoryUsageSetting.setupMixed(MEM))
    }

    /** Reconstrói o PDF com as páginas [order] (índices da origem), aplicando rotação extra por página de origem. */
    fun rebuild(src: File, out: File, order: List<Int>, rot: Map<Int, Int>) {
        open(src).use { doc ->
            val pages = order.map { doc.getPage(it) }
            order.forEachIndexed { i, srcIdx ->
                val d = rot[srcIdx] ?: 0
                if (d != 0) pages[i].rotation = (((pages[i].rotation + d) % 360) + 360) % 360
            }
            while (doc.numberOfPages > 0) doc.removePage(0)
            pages.forEach { doc.addPage(it) }
            doc.save(out)
        }
    }

    fun splitEvery(src: File, n: Int, dir: File): List<File> {
        dir.mkdirs()
        val files = mutableListOf<File>()
        open(src).use { doc ->
            val sp = Splitter()
            sp.setSplitAtPage(n)
            val parts = sp.split(doc)
            parts.forEachIndexed { i, d ->
                val f = File(dir, "part_${i + 1}.pdf")
                d.save(f)
                d.close()
                files.add(f)
            }
        }
        return files
    }

    /** "1-3,5,8-9" -> índices base 0 */
    fun parseRanges(s: String, max: Int): List<Int> {
        val out = linkedSetOf<Int>()
        for (part in s.split(',', ';', ' ')) {
            val p = part.trim()
            if (p.isEmpty()) continue
            val seg = p.split('-')
            val a = seg[0].toIntOrNull() ?: continue
            val b = if (seg.size > 1) (seg[1].toIntOrNull() ?: a) else a
            for (i in minOf(a, b)..maxOf(a, b)) if (i in 1..max) out.add(i - 1)
        }
        return out.toList()
    }

    // ---------- compressão (rasteriza as páginas em JPEG) ----------

    fun compress(src: File, out: File, quality: Int, maxDim: Int) {
        val pfd = ParcelFileDescriptor.open(src, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        try {
            PDDocument().use { doc ->
                for (i in 0 until r.pageCount) {
                    val pg = r.openPage(i)
                    val wPt = pg.width.toFloat()
                    val hPt = pg.height.toFloat()
                    val scale = maxDim / max(wPt, hPt)
                    val bw = (wPt * scale).toInt().coerceAtLeast(1)
                    val bh = (hPt * scale).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    pg.close()
                    val page = PDPage(PDRectangle(wPt, hPt))
                    doc.addPage(page)
                    val img = JPEGFactory.createFromImage(doc, bmp, quality / 100f)
                    PDPageContentStream(doc, page).use { it.drawImage(img, 0f, 0f, wPt, hPt) }
                    bmp.recycle()
                }
                doc.save(out)
            }
        } finally {
            r.close()
            pfd.close()
        }
    }

    // ---------- imagens -> PDF ----------

    fun decode(ctx: Context, uri: Uri, maxDim: Int, keepAlpha: Boolean): Bitmap? = try {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        var bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val s = max(info.size.width, info.size.height) / maxDim
            if (s > 1) dec.setTargetSampleSize(s)
        }
        if (!keepAlpha && bmp.hasAlpha()) {
            val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
            val c = Canvas(flat)
            c.drawColor(Color.WHITE)
            c.drawBitmap(bmp, 0f, 0f, null)
            bmp.recycle()
            bmp = flat
        }
        bmp
    } catch (e: Exception) {
        null
    }

    fun imagesToPdf(ctx: Context, uris: List<Uri>, out: File) {
        PDDocument().use { doc ->
            for (u in uris) {
                val bmp = decode(ctx, u, 2400, false) ?: continue
                val landscape = bmp.width > bmp.height
                val pw = if (landscape) 842f else 595f
                val ph = if (landscape) 595f else 842f
                val page = PDPage(PDRectangle(pw, ph))
                doc.addPage(page)
                val img = JPEGFactory.createFromImage(doc, bmp, 0.9f)
                val scale = minOf(pw / bmp.width, ph / bmp.height)
                val w = bmp.width * scale
                val h = bmp.height * scale
                PDPageContentStream(doc, page).use { it.drawImage(img, (pw - w) / 2f, (ph - h) / 2f, w, h) }
                bmp.recycle()
            }
            if (doc.numberOfPages == 0) throw IllegalStateException("Nenhuma imagem válida")
            doc.save(out)
        }
    }

    // ---------- busca / índice ----------

    fun search(src: File, q: String, limit: Int = 1000): List<SearchMatch> {
        val out = mutableListOf<SearchMatch>()
        val query = q.trim().replace(Regex("\\s+"), " ")
        if (query.isEmpty()) return out
        open(src).use { doc ->
            val st = MatchStripper(doc, query, out, limit)
            st.setSortByPosition(true)
            st.getText(doc)
        }
        return out
    }

    fun outline(src: File): List<OutlineItem> {
        val out = mutableListOf<OutlineItem>()
        open(src).use { doc ->
            val root = doc.documentCatalog.documentOutline ?: return emptyList()
            fun walk(node: PDOutlineNode, level: Int) {
                var c: PDOutlineItem? = node.firstChild
                while (c != null) {
                    val page = try {
                        pageOf(doc, c)
                    } catch (e: Exception) {
                        -1
                    }
                    out.add(OutlineItem(c.title ?: "", page, level))
                    walk(c, level + 1)
                    c = c.nextSibling
                }
            }
            walk(root, 0)
        }
        return out
    }

    private fun pageOf(doc: PDDocument, item: PDOutlineItem): Int {
        var dest = item.destination
        if (dest == null) {
            val act = item.action
            if (act is PDActionGoTo) dest = act.destination
        }
        if (dest is PDNamedDestination) dest = doc.documentCatalog.findNamedDestinationPage(dest)
        return if (dest is PDPageDestination) dest.retrievePageNumber() else -1
    }

    // ---------- formulários ----------

    fun formFields(src: File): List<FormField> = open(src).use { doc ->
        val form = doc.documentCatalog.acroForm ?: return@use emptyList<FormField>()
        form.fieldTree.mapNotNull { f ->
            when (f) {
                is PDTextField -> FormField(f.fullyQualifiedName, "text", f.value ?: "", emptyList())
                is PDCheckBox -> FormField(f.fullyQualifiedName, "check", if (f.isChecked) "true" else "false", emptyList())
                is PDComboBox -> FormField(f.fullyQualifiedName, "choice", f.value.firstOrNull() ?: "", f.options)
                is PDListBox -> FormField(f.fullyQualifiedName, "choice", f.value.firstOrNull() ?: "", f.options)
                is PDRadioButton -> FormField(f.fullyQualifiedName, "choice", f.value ?: "", f.onValues.toList())
                else -> null
            }
        }
    }

    fun fillForm(src: File, out: File, values: Map<String, String>) {
        open(src).use { doc ->
            val form = doc.documentCatalog.acroForm
            if (form != null) {
                for ((name, v) in values) {
                    val f = form.getField(name) ?: continue
                    try {
                        if (f is PDCheckBox) {
                            if (v == "true") f.check() else f.unCheck()
                        } else {
                            f.setValue(v)
                        }
                    } catch (_: Exception) {
                    }
                }
            }
            doc.save(out)
        }
    }

    // ---------- gravar anotações no PDF ----------

    fun flatten(src: File, out: File, annots: List<Annot>) {
        open(src).use { doc ->
            val font = PDType1Font.HELVETICA
            for ((pi, list) in annots.groupBy { it.page }) {
                if (pi !in 0 until doc.numberOfPages) continue
                val page = doc.getPage(pi)
                val box = page.cropBox
                val w = box.width
                val h = box.height
                val rot = ((page.rotation % 360) + 360) % 360
                val wd = if (rot == 90 || rot == 270) h else w
                val hd = if (rot == 90 || rot == 270) w else h
                // matriz: espaço "como exibido" (y para cima) -> espaço não rotacionado da página
                val m = when (rot) {
                    90 -> floatArrayOf(0f, 1f, -1f, 0f, w, 0f)
                    180 -> floatArrayOf(-1f, 0f, 0f, -1f, w, h)
                    270 -> floatArrayOf(0f, -1f, 1f, 0f, 0f, h)
                    else -> floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
                }
                fun fx(n: Float) = n * wd
                fun fy(n: Float) = hd - n * hd

                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.transform(Matrix(m[0], m[1], m[2], m[3], m[4] + box.lowerLeftX, m[5] + box.lowerLeftY))
                    for (a in list) {
                        when (a) {
                            is Annot.Highlight -> {
                                cs.saveGraphicsState()
                                val gs = PDExtendedGraphicsState()
                                gs.setNonStrokingAlphaConstant(0.4f)
                                gs.setStrokingAlphaConstant(0.4f)
                                cs.setGraphicsStateParameters(gs)
                                cs.setNonStrokingColor(Color.red(a.color), Color.green(a.color), Color.blue(a.color))
                                cs.addRect(fx(a.l), fy(a.b), (a.r - a.l) * wd, (a.b - a.t) * hd)
                                cs.fill()
                                cs.restoreGraphicsState()
                            }
                            is Annot.Underline -> {
                                cs.setStrokingColor(Color.red(a.color), Color.green(a.color), Color.blue(a.color))
                                cs.setLineWidth(max(1f, 0.0025f * wd))
                                cs.moveTo(fx(a.l), fy(a.b))
                                cs.lineTo(fx(a.r), fy(a.b))
                                cs.stroke()
                            }
                            is Annot.Ink -> {
                                cs.setStrokingColor(Color.red(a.color), Color.green(a.color), Color.blue(a.color))
                                cs.setLineWidth(a.width * wd)
                                cs.setLineCapStyle(1)
                                cs.setLineJoinStyle(1)
                                val p = a.pts
                                cs.moveTo(fx(p[0].first), fy(p[0].second))
                                if (p.size == 1) {
                                    cs.lineTo(fx(p[0].first) + 0.1f, fy(p[0].second))
                                } else {
                                    for (i in 1 until p.size) cs.lineTo(fx(p[i].first), fy(p[i].second))
                                }
                                cs.stroke()
                            }
                            is Annot.Text -> {
                                val size = a.size * wd
                                val clean = a.text.replace("\r", "").map { ch ->
                                    if (ch == '\n') {
                                        ch
                                    } else {
                                        try {
                                            font.encode(ch.toString())
                                            ch
                                        } catch (e: Exception) {
                                            '?'
                                        }
                                    }
                                }.joinToString("")
                                cs.beginText()
                                cs.setFont(font, size)
                                cs.setNonStrokingColor(Color.red(a.color), Color.green(a.color), Color.blue(a.color))
                                cs.newLineAtOffset(fx(a.x), fy(a.y) - size)
                                clean.split("\n").forEachIndexed { i, line ->
                                    if (i > 0) cs.newLineAtOffset(0f, -size * 1.2f)
                                    if (line.isNotEmpty()) cs.showText(line)
                                }
                                cs.endText()
                            }
                            is Annot.Picture -> {
                                val img = LosslessFactory.createFromImage(doc, a.bitmap)
                                cs.drawImage(img, fx(a.l), fy(a.b), (a.r - a.l) * wd, (a.b - a.t) * hd)
                            }
                        }
                    }
                }
            }
            doc.save(out)
        }
    }

    // ---------- salvar em Downloads/PdfPro ----------

    fun saveToDownloads(ctx: Context, src: File, name: String): Uri? {
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PdfPro")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { o -> src.inputStream().use { it.copyTo(o) } }
        return uri
    }
}

/**
 * Junta o texto de cada página (palavra por palavra, com a posição de cada caractere)
 * e procura a consulta no texto inteiro, devolvendo um retângulo por linha de cada ocorrência.
 */
private class MatchStripper(
    private val doc: PDDocument,
    private val q: String,
    private val out: MutableList<SearchMatch>,
    private val limit: Int
) : PDFTextStripper() {
    private val chars = StringBuilder()
    private val pos = ArrayList<TextPosition?>()

    override fun startPage(page: PDPage) {
        chars.setLength(0)
        pos.clear()
        super.startPage(page)
    }

    override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
        if (textPositions.isEmpty()) return
        for (i in text.indices) {
            chars.append(text[i])
            pos.add(textPositions.getOrNull(i) ?: textPositions.last())
        }
        chars.append(' ')
        pos.add(null)
    }

    override fun endPage(page: PDPage) {
        flush()
        super.endPage(page)
    }

    private fun flush() {
        if (out.size >= limit || chars.isEmpty()) return
        val pageIdx = currentPageNo - 1
        val page = doc.getPage(pageIdx)
        val box = page.cropBox
        val rot = ((page.rotation % 360) + 360) % 360
        val w = if (rot == 90 || rot == 270) box.height else box.width
        val h = if (rot == 90 || rot == 270) box.width else box.height
        val text = chars.toString()
        var idx = text.indexOf(q, ignoreCase = true)
        while (idx >= 0 && out.size < limit) {
            val ps = (idx until idx + q.length).mapNotNull { pos.getOrNull(it) }
            if (ps.isNotEmpty()) {
                val rects = mutableListOf<RectF>()
                var cur = mutableListOf<TextPosition>()
                for (p in ps) {
                    if (cur.isNotEmpty() &&
                        abs(p.yDirAdj - cur.last().yDirAdj) > max(1f, cur.last().heightDir * 0.6f)
                    ) {
                        rects.add(rectOf(cur, w, h))
                        cur = mutableListOf()
                    }
                    cur.add(p)
                }
                if (cur.isNotEmpty()) rects.add(rectOf(cur, w, h))
                val from = max(0, idx - 25)
                val to = min(text.length, idx + q.length + 40)
                out.add(SearchMatch(pageIdx, rects, text.substring(from, to).trim()))
            }
            idx = text.indexOf(q, idx + q.length, ignoreCase = true)
        }
    }

    private fun rectOf(ps: List<TextPosition>, w: Float, h: Float): RectF {
        val l = ps.minOf { it.xDirAdj }
        val r = ps.maxOf { it.xDirAdj + it.widthDirAdj }
        val bottom = ps.maxOf { it.yDirAdj } + ps.maxOf { it.heightDir } * 0.2f
        val top = ps.minOf { it.yDirAdj - it.heightDir }
        return RectF(
            (l / w).coerceIn(0f, 1f), (top / h).coerceIn(0f, 1f),
            (r / w).coerceIn(0f, 1f), (bottom / h).coerceIn(0f, 1f)
        )
    }
}
