@file:OptIn(ExperimentalMaterial3Api::class)

package com.pdfpro.app

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Só visualizar a página (com zoom); a edição fica no botão "Editar". */
@Composable
fun ScanViewScreen(vm: MainViewModel) {
    val s = vm.scan
    val page = s?.page(vm.editId)
    if (s == null || page == null) {
        LaunchedEffect(Unit) { vm.screen = if (s != null) Screen.SCAN_REVIEW else Screen.HOME }
        return
    }
    BackHandler { vm.closeEdit() }
    val idx = s.pages.indexOfFirst { it.id == page.id }

    var scale by remember(page.id) { mutableFloatStateOf(1f) }
    var offset by remember(page.id) { mutableStateOf(Offset.Zero) }

    val key = page.cacheKey() + "|v"
    val bmp by produceState<Bitmap?>(ScanCache.get(key), key) {
        if (value == null) {
            value = withContext(Dispatchers.Default) { ImageProc.render(page, 1800) }?.also { ScanCache.put(key, it) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Página ${idx + 1} de ${s.pages.size}", style = MaterialTheme.typography.titleMedium) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                navigationIcon = {
                    IconButton(onClick = { vm.closeEdit() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                },
                actions = {
                    IconButton(enabled = idx > 0, onClick = { vm.editId = s.pages[idx - 1].id }) {
                        Icon(Icons.Default.KeyboardArrowLeft, "Página anterior")
                    }
                    IconButton(enabled = idx < s.pages.size - 1, onClick = { vm.editId = s.pages[idx + 1].id }) {
                        Icon(Icons.Default.KeyboardArrowRight, "Próxima página")
                    }
                    FilledTonalButton(onClick = { vm.openEdit(page.id) }, modifier = Modifier.padding(end = 8.dp)) {
                        Icon(Icons.Default.Edit, null, Modifier.size(18.dp))
                        Text("  Editar")
                    }
                }
            )
        }
    ) { pad ->
        Box(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .background(Color(0xFF1B1D22))
                .pointerInput(page.id) {
                    detectTapGestures(onDoubleTap = {
                        if (scale > 1f) {
                            scale = 1f
                            offset = Offset.Zero
                        } else {
                            scale = 2.5f
                        }
                    })
                }
                .pointerInput(page.id) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val ns = (scale * zoom).coerceIn(1f, 5f)
                        val maxX = size.width * (ns - 1f) / 2f
                        val maxY = size.height * (ns - 1f) / 2f
                        scale = ns
                        offset = Offset(
                            (offset.x + pan.x).coerceIn(-maxX, maxX),
                            (offset.y + pan.y).coerceIn(-maxY, maxY)
                        )
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            val b = bmp
            if (b == null) {
                CircularProgressIndicator()
            } else {
                val ib = remember(b) { b.asImageBitmap() }
                Image(
                    ib, null,
                    Modifier.fillMaxSize().padding(8.dp).graphicsLayer(
                        scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y
                    ),
                    contentScale = ContentScale.Fit
                )
            }
        }
    }
}
