package com.pdfpro.app

import android.graphics.Bitmap
import android.graphics.RectF
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

enum class Tool { NONE, HIGHLIGHT, UNDERLINE, PEN, TEXT, IMAGE }

/**
 * Anotações ficam numa camada separada até serem gravadas no PDF.
 * Coordenadas normalizadas (0..1) sobre a página como exibida, origem no canto superior esquerdo.
 */
sealed class Annot {
    abstract val page: Int

    data class Highlight(override val page: Int, val l: Float, val t: Float, val r: Float, val b: Float, val color: Int) : Annot()
    data class Underline(override val page: Int, val l: Float, val t: Float, val r: Float, val b: Float, val color: Int) : Annot()
    data class Ink(override val page: Int, val pts: List<Pair<Float, Float>>, val color: Int, val width: Float) : Annot()
    data class Text(override val page: Int, val x: Float, val y: Float, val text: String, val size: Float, val color: Int) : Annot()
    class Picture(override val page: Int, val l: Float, val t: Float, val r: Float, val b: Float, val bitmap: Bitmap) : Annot() {
        val image: ImageBitmap = bitmap.asImageBitmap()
    }
}

data class FormField(val name: String, val kind: String, val value: String, val options: List<String>)
data class OutlineItem(val title: String, val page: Int, val level: Int)
/** Uma ocorrência da busca: página, retângulos normalizados (0..1, um por linha) e trecho de texto. */
data class SearchMatch(val page: Int, val rects: List<RectF>, val snippet: String)
data class Recent(val uri: String, val name: String, val page: Int, val time: Long)
