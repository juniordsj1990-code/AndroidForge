package com.pdfpro.app

import android.util.LruCache
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

enum class ScanFilter(val label: String) {
    ORIGINAL("Original"),
    MAGIC("Mágico"),
    BW("P&B"),
    GRAY("Cinza"),
    LIGHT("Clarear")
}

enum class PageSize(val label: String) {
    A4("A4"),
    LETTER("Carta"),
    FIT("Ajustar à imagem")
}

enum class MarginSize(val label: String, val pt: Float) {
    NONE("Sem margem", 0f),
    SMALL("Pequena", 18f),
    MEDIUM("Média", 36f)
}

enum class PdfQuality(val label: String, val jpeg: Float, val maxDim: Int) {
    HIGH("Alta", 0.9f, 2400),
    MEDIUM("Média", 0.75f, 1800),
    LOW("Baixa (menor arquivo)", 0.55f, 1200)
}

enum class NumberStyle(val label: String) {
    NONE("Sem numeração"),
    PLAIN("1, 2, 3…"),
    FULL("Página 1 de N")
}

enum class CamMode(val label: String) {
    DOC("Documento"),
    CARD("RG/Cartão"),
    BOOK("Livro")
}

/** Uma página do PDF em construção. Todas as edições são não destrutivas: o arquivo original nunca muda. */
data class ScanPage(
    val id: Long,
    val src: File,
    /** 8 valores normalizados (0..1) sobre a imagem original: TL, TR, BR, BL (x, y). null = imagem inteira. */
    val corners: List<Float>? = null,
    /** Giro aplicado ao resultado, em graus (0, 90, 180, 270). */
    val rotation: Int = 0,
    val filter: ScanFilter = ScanFilter.ORIGINAL,
    val brightness: Int = 0,
    val contrast: Int = 0,
    val shadow: Boolean = false,
    val denoise: Boolean = false
) {
    fun cacheKey(): String {
        val c = corners?.joinToString(",") { (it * 1000f).toInt().toString() } ?: "-"
        return "$id|${src.name}|$c|$rotation|${filter.name}|$brightness|$contrast|$shadow|$denoise"
    }
}

data class PdfOptions(
    val size: PageSize = PageSize.A4,
    val margin: MarginSize = MarginSize.SMALL,
    val quality: PdfQuality = PdfQuality.HIGH,
    val ocr: Boolean = false,
    val watermark: String = "",
    val numbering: NumberStyle = NumberStyle.NONE
)

class ScanSession {
    val pages = mutableStateListOf<ScanPage>()
    val selected = mutableStateListOf<Long>()
    var options by mutableStateOf(PdfOptions())
    private var seq = 1L

    fun newId(): Long = seq++

    /** Próximo id que será usado; gravado no rascunho para não repetir ids ao retomar. */
    val nextSeq: Long get() = seq

    /** Repõe a sessão a partir de um rascunho salvo. */
    fun restore(list: List<ScanPage>, opt: PdfOptions, next: Long) {
        pages.clear()
        pages.addAll(list)
        selected.clear()
        options = opt
        seq = maxOf(next, (list.maxOfOrNull { it.id } ?: 0L) + 1L)
    }

    fun page(id: Long): ScanPage? = pages.firstOrNull { it.id == id }

    fun update(id: Long, f: (ScanPage) -> ScanPage) {
        val i = pages.indexOfFirst { it.id == id }
        if (i >= 0) pages[i] = f(pages[i])
    }

    fun toggle(id: Long) {
        if (!selected.remove(id)) selected.add(id)
    }

    fun selectAllOrNone() {
        if (selected.size == pages.size) selected.clear()
        else {
            selected.clear()
            selected.addAll(pages.map { it.id })
        }
    }

    fun rotateSelected(d: Int) {
        for (i in pages.indices) {
            val p = pages[i]
            if (p.id in selected) pages[i] = p.copy(rotation = (p.rotation + d + 360) % 360)
        }
    }

    fun moveEarlier() {
        for (i in 1 until pages.size) {
            if (pages[i].id in selected && pages[i - 1].id !in selected) {
                val x = pages.removeAt(i)
                pages.add(i - 1, x)
            }
        }
    }

    fun moveLater() {
        for (i in pages.size - 2 downTo 0) {
            if (pages[i].id in selected && pages[i + 1].id !in selected) {
                val x = pages.removeAt(i)
                pages.add(i + 1, x)
            }
        }
    }

    fun deleteSelected() {
        pages.removeAll { it.id in selected }
        selected.clear()
    }
}

/** Cache de miniaturas/prévias já processadas. */
object ScanCache {
    private val cache = object : LruCache<String, Bitmap>(28 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(key: String): Bitmap? = cache.get(key)
    fun put(key: String, b: Bitmap) {
        cache.put(key, b)
    }

    fun clear() = cache.evictAll()
}
