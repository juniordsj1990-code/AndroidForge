package com.pdfpro.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private inline fun <reified T : Enum<T>> enumOr(name: String?, def: T): T =
    try {
        if (name == null) def else enumValueOf<T>(name)
    } catch (e: Exception) {
        def
    }

private fun writeAtomic(file: File, text: String) {
    val tmp = File(file.parentFile, file.name + ".tmp")
    tmp.writeText(text)
    if (!tmp.renameTo(file)) {
        file.writeText(text)
        tmp.delete()
    }
}

/**
 * Rascunho da digitalização (Foto/Imagens → PDF).
 * Só guarda a lista de páginas e as opções em JSON; as fotos ficam na pasta de imagens do scan.
 */
object ScanDraft {
    class Data(val pages: List<ScanPage>, val options: PdfOptions, val nextSeq: Long)

    @Synchronized
    fun write(file: File, pages: List<ScanPage>, opt: PdfOptions, nextSeq: Long) {
        val arr = JSONArray()
        pages.forEach { p ->
            val o = JSONObject()
                .put("id", p.id)
                .put("src", p.src.name)
                .put("rot", p.rotation)
                .put("filter", p.filter.name)
                .put("br", p.brightness)
                .put("ct", p.contrast)
                .put("shadow", p.shadow)
                .put("denoise", p.denoise)
            p.corners?.let { c ->
                val a = JSONArray()
                c.forEach { v -> a.put(v.toDouble()) }
                o.put("corners", a)
            }
            arr.put(o)
        }
        val opts = JSONObject()
            .put("size", opt.size.name)
            .put("margin", opt.margin.name)
            .put("quality", opt.quality.name)
            .put("ocr", opt.ocr)
            .put("watermark", opt.watermark)
            .put("numbering", opt.numbering.name)
        val root = JSONObject().put("v", 1).put("next", nextSeq).put("pages", arr).put("options", opts)
        writeAtomic(file, root.toString())
    }

    /** Devolve null se não houver rascunho válido (arquivo ausente, corrompido ou sem nenhuma foto restante). */
    @Synchronized
    fun read(file: File, imgDir: File): Data? = try {
        if (!file.exists()) {
            null
        } else {
            val root = JSONObject(file.readText())
            val arr = root.getJSONArray("pages")
            val pages = ArrayList<ScanPage>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val src = File(imgDir, File(o.getString("src")).name)
                if (!src.exists()) continue
                val ca = o.optJSONArray("corners")
                val corners: List<Float>? = if (ca != null && ca.length() == 8) List(8) { k -> ca.getDouble(k).toFloat() } else null
                pages.add(
                    ScanPage(
                        id = o.getLong("id"),
                        src = src,
                        corners = corners,
                        rotation = o.optInt("rot", 0),
                        filter = enumOr(o.optString("filter"), ScanFilter.ORIGINAL),
                        brightness = o.optInt("br", 0),
                        contrast = o.optInt("ct", 0),
                        shadow = o.optBoolean("shadow", false),
                        denoise = o.optBoolean("denoise", false)
                    )
                )
            }
            if (pages.isEmpty()) {
                null
            } else {
                val oo = root.optJSONObject("options")
                val def = PdfOptions()
                val opt = if (oo == null) def else PdfOptions(
                    size = enumOr(oo.optString("size"), def.size),
                    margin = enumOr(oo.optString("margin"), def.margin),
                    quality = enumOr(oo.optString("quality"), def.quality),
                    ocr = oo.optBoolean("ocr", def.ocr),
                    watermark = oo.optString("watermark", def.watermark),
                    numbering = enumOr(oo.optString("numbering"), def.numbering)
                )
                Data(pages, opt, root.optLong("next", 1L))
            }
        }
    } catch (e: Exception) {
        null
    }
}

/**
 * Rascunho da edição de um PDF: cópia do arquivo de trabalho (work.pdf) + anotações ainda não gravadas (state.json).
 */
object DocDraft {
    class Data(val title: String, val uri: String?, val annots: List<Annot>)

    private const val STATE = "state.json"
    const val WORK = "work.pdf"

    /** Título do rascunho, se houver um completo (state.json + work.pdf). */
    fun title(dir: File): String? = try {
        if (File(dir, STATE).exists() && File(dir, WORK).exists()) JSONObject(File(dir, STATE).readText()).optString("title", "Documento") else null
    } catch (e: Exception) {
        null
    }

    @Synchronized
    fun writeState(dir: File, title: String, uri: String?, annots: List<Annot>) {
        val arr = JSONArray()
        val keep = HashSet<String>()
        var img = 0
        annots.forEach { a ->
            val o = JSONObject().put("page", a.page)
            when (a) {
                is Annot.Highlight -> o.put("k", "hl").put("l", a.l.toDouble()).put("t", a.t.toDouble())
                    .put("r", a.r.toDouble()).put("b", a.b.toDouble()).put("c", a.color)
                is Annot.Underline -> o.put("k", "ul").put("l", a.l.toDouble()).put("t", a.t.toDouble())
                    .put("r", a.r.toDouble()).put("b", a.b.toDouble()).put("c", a.color)
                is Annot.Ink -> {
                    val pts = JSONArray()
                    a.pts.forEach { p ->
                        pts.put(p.first.toDouble())
                        pts.put(p.second.toDouble())
                    }
                    o.put("k", "ink").put("pts", pts).put("c", a.color).put("w", a.width.toDouble())
                }
                is Annot.Text -> o.put("k", "txt").put("x", a.x.toDouble()).put("y", a.y.toDouble())
                    .put("text", a.text).put("s", a.size.toDouble()).put("c", a.color)
                is Annot.Picture -> {
                    val name = "img_${img++}.png"
                    keep.add(name)
                    File(dir, name).outputStream().use { a.bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    o.put("k", "pic").put("l", a.l.toDouble()).put("t", a.t.toDouble())
                        .put("r", a.r.toDouble()).put("b", a.b.toDouble()).put("img", name)
                }
            }
            arr.put(o)
        }
        dir.listFiles()?.forEach { f -> if (f.name.startsWith("img_") && f.name !in keep) f.delete() }
        val root = JSONObject().put("v", 1).put("title", title).put("annots", arr)
        if (uri != null) root.put("uri", uri)
        writeAtomic(File(dir, STATE), root.toString())
    }

    @Synchronized
    fun read(dir: File): Data? = try {
        val sf = File(dir, STATE)
        if (!sf.exists() || !File(dir, WORK).exists()) {
            null
        } else {
            val root = JSONObject(sf.readText())
            val arr = root.optJSONArray("annots") ?: JSONArray()
            val list = ArrayList<Annot>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val pg = o.getInt("page")
                fun f(k: String) = o.getDouble(k).toFloat()
                when (o.getString("k")) {
                    "hl" -> list.add(Annot.Highlight(pg, f("l"), f("t"), f("r"), f("b"), o.getInt("c")))
                    "ul" -> list.add(Annot.Underline(pg, f("l"), f("t"), f("r"), f("b"), o.getInt("c")))
                    "ink" -> {
                        val a = o.getJSONArray("pts")
                        val pts = ArrayList<Pair<Float, Float>>()
                        var j = 0
                        while (j + 1 < a.length()) {
                            pts.add(Pair(a.getDouble(j).toFloat(), a.getDouble(j + 1).toFloat()))
                            j += 2
                        }
                        list.add(Annot.Ink(pg, pts, o.getInt("c"), f("w")))
                    }
                    "txt" -> list.add(Annot.Text(pg, f("x"), f("y"), o.getString("text"), f("s"), o.getInt("c")))
                    "pic" -> {
                        val bmp = BitmapFactory.decodeFile(File(dir, File(o.getString("img")).name).absolutePath)
                        if (bmp != null) list.add(Annot.Picture(pg, f("l"), f("t"), f("r"), f("b"), bmp))
                    }
                }
            }
            Data(root.optString("title", "Documento"), if (root.has("uri")) root.getString("uri") else null, list)
        }
    } catch (e: Exception) {
        null
    }
}
