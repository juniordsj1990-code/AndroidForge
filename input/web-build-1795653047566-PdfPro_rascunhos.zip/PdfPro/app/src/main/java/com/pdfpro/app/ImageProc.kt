package com.pdfpro.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/** Imagem em tons de cinza reduzida, usada só para detectar o documento. */
class Gray(val w: Int, val h: Int, val px: IntArray)

/** Resultado da detecção: 8 valores normalizados (TL, TR, BR, BL) e fração da imagem ocupada. */
class Detection(val q: List<Float>, val area: Float)

/**
 * Processamento de imagem 100% offline (sem OpenCV): detecção de bordas, perspectiva,
 * filtros, brilho/contraste, remoção de sombra e ruído.
 */
object ImageProc {

    val FULL: List<Float> = listOf(0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f)

    // ---------------------------------------------------------------- decodificação

    /** Decodifica respeitando a orientação EXIF, com lado maior em torno de [maxSide]. */
    fun decode(file: File, maxSide: Int): Bitmap? = try {
        val src = ImageDecoder.createSource(file)
        val bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            dec.setTargetSampleSize(max(1, m / maxSide))
        }
        scaleDown(bmp, maxSide)
    } catch (e: Throwable) {
        null
    }

    fun scaleDown(b: Bitmap, maxSide: Int): Bitmap {
        val m = max(b.width, b.height)
        if (m <= maxSide) return b
        val s = maxSide.toFloat() / m
        val out = Bitmap.createScaledBitmap(
            b, max(1, (b.width * s).roundToInt()), max(1, (b.height * s).roundToInt()), true
        )
        if (out !== b) b.recycle()
        return out
    }

    // ---------------------------------------------------------------- detecção de bordas

    fun grayFromBitmap(b: Bitmap, target: Int = 160): Gray {
        val s = target.toFloat() / max(b.width, b.height)
        val w = max(8, (b.width * s).roundToInt())
        val h = max(8, (b.height * s).roundToInt())
        val sm = Bitmap.createScaledBitmap(b, w, h, true)
        val p = IntArray(w * h)
        sm.getPixels(p, 0, w, 0, 0, w, h)
        if (sm !== b) sm.recycle()
        for (i in p.indices) {
            val c = p[i]
            p[i] = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
        }
        return Gray(w, h, p)
    }

    /** Monta a imagem cinza (já em pé) a partir do plano Y de um quadro da câmera. */
    fun grayFromY(buf: ByteBuffer, rowStride: Int, srcW: Int, srcH: Int, rot: Int, target: Int = 160): Gray {
        val uw = if (rot == 90 || rot == 270) srcH else srcW
        val uh = if (rot == 90 || rot == 270) srcW else srcH
        val s = target.toFloat() / max(uw, uh)
        val gw = max(8, (uw * s).toInt())
        val gh = max(8, (uh * s).toInt())
        val out = IntArray(gw * gh)
        for (gy in 0 until gh) {
            val uy = min(uh - 1, ((gy + 0.5f) / s).toInt())
            for (gx in 0 until gw) {
                val ux = min(uw - 1, ((gx + 0.5f) / s).toInt())
                val sx: Int
                val sy: Int
                when (rot) {
                    90 -> { sx = uy; sy = srcH - 1 - ux }
                    180 -> { sx = srcW - 1 - ux; sy = srcH - 1 - uy }
                    270 -> { sx = srcW - 1 - uy; sy = ux }
                    else -> { sx = ux; sy = uy }
                }
                out[gy * gw + gx] = buf.get(sy * rowStride + sx).toInt() and 255
            }
        }
        return Gray(gw, gh, out)
    }

    private class Cand(val score: Float, val q: FloatArray, val frac: Float)

    fun detectQuad(g: Gray): Detection? {
        val w = g.w
        val h = g.h
        val b = blur3(blur3(g.px, w, h), w, h)
        val cands = ArrayList<Cand>(3)

        // 1) região clara e 2) região escura (limiar de Otsu)
        val t = otsu(b)
        cands.addIfNotNull(candidate(BooleanArray(w * h) { b[it] > t }, w, h))
        cands.addIfNotNull(candidate(BooleanArray(w * h) { b[it] <= t }, w, h))

        // 3) bordas: preenche o fundo a partir das margens; o que sobra é o documento
        val mag = IntArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val gx = -b[i - w - 1] + b[i - w + 1] - 2 * b[i - 1] + 2 * b[i + 1] - b[i + w - 1] + b[i + w + 1]
                val gy = -b[i - w - 1] - 2 * b[i - w] - b[i - w + 1] + b[i + w - 1] + 2 * b[i + w] + b[i + w + 1]
                mag[i] = abs(gx) + abs(gy)
            }
        }
        val sorted = mag.copyOf()
        sorted.sort()
        val p98 = sorted[(sorted.size * 0.98f).toInt().coerceIn(0, sorted.size - 1)]
        val thr = max(30f, min(0.25f * p98, 60f))
        val dil = BooleanArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (mag[y * w + x] > thr) {
                    for (dy in -1..1) {
                        val yy = y + dy
                        if (yy < 0 || yy >= h) continue
                        for (dx in -1..1) {
                            val xx = x + dx
                            if (xx in 0 until w) dil[yy * w + xx] = true
                        }
                    }
                }
            }
        }
        val bg = BooleanArray(w * h)
        val stack = IntArray(w * h)
        var sp = 0
        fun seed(i: Int) {
            if (!dil[i] && !bg[i]) {
                bg[i] = true
                stack[sp++] = i
            }
        }
        for (x in 0 until w) {
            seed(x)
            seed((h - 1) * w + x)
        }
        for (y in 0 until h) {
            seed(y * w)
            seed(y * w + w - 1)
        }
        while (sp > 0) {
            val p = stack[--sp]
            val x = p % w
            val y = p / w
            if (x > 0) seed(p - 1)
            if (x < w - 1) seed(p + 1)
            if (y > 0) seed(p - w)
            if (y < h - 1) seed(p + w)
        }
        cands.addIfNotNull(candidate(BooleanArray(w * h) { !bg[it] }, w, h))

        val best = cands.maxByOrNull { it.score } ?: return null
        val q = best.q
        return Detection(
            listOf(
                (q[0] + 0.5f) / w, (q[1] + 0.5f) / h,
                (q[2] + 0.5f) / w, (q[3] + 0.5f) / h,
                (q[4] + 0.5f) / w, (q[5] + 0.5f) / h,
                (q[6] + 0.5f) / w, (q[7] + 0.5f) / h
            ),
            best.frac
        )
    }

    private fun <T> ArrayList<T>.addIfNotNull(x: T?) {
        if (x != null) add(x)
    }

    private fun blur3(src: IntArray, w: Int, h: Int): IntArray {
        val tmp = IntArray(w * h)
        val out = IntArray(w * h)
        for (y in 0 until h) {
            val r = y * w
            for (x in 0 until w) {
                var s = src[r + x]
                var n = 1
                if (x > 0) { s += src[r + x - 1]; n++ }
                if (x < w - 1) { s += src[r + x + 1]; n++ }
                tmp[r + x] = s / n
            }
        }
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = tmp[y * w + x]
                var n = 1
                if (y > 0) { s += tmp[(y - 1) * w + x]; n++ }
                if (y < h - 1) { s += tmp[(y + 1) * w + x]; n++ }
                out[y * w + x] = s / n
            }
        }
        return out
    }

    private fun otsu(g: IntArray): Int {
        val hist = IntArray(256)
        for (v in g) hist[v.coerceIn(0, 255)]++
        val total = g.size
        var sumAll = 0L
        for (i in 0 until 256) sumAll += i.toLong() * hist[i]
        var wb = 0
        var sb = 0L
        var best = -1.0
        var t = 128
        for (i in 0 until 256) {
            wb += hist[i]
            if (wb == 0) continue
            val wf = total - wb
            if (wf == 0) break
            sb += i.toLong() * hist[i]
            val mb = sb.toDouble() / wb
            val mf = (sumAll - sb).toDouble() / wf
            val v = wb.toDouble() * wf * (mb - mf) * (mb - mf)
            if (v > best) {
                best = v
                t = i
            }
        }
        return t
    }

    /** Maior componente conexo (vizinhança 4) da máscara. */
    private fun largest(mask: BooleanArray, w: Int, h: Int): IntArray? {
        val n = w * h
        val seen = BooleanArray(n)
        val stack = IntArray(n)
        val tmp = IntArray(n)
        var best: IntArray? = null
        var bestN = 0
        for (s in 0 until n) {
            if (!mask[s] || seen[s]) continue
            var sp = 0
            var cnt = 0
            stack[sp++] = s
            seen[s] = true
            while (sp > 0) {
                val p = stack[--sp]
                tmp[cnt++] = p
                val x = p % w
                val y = p / w
                if (x > 0 && mask[p - 1] && !seen[p - 1]) { seen[p - 1] = true; stack[sp++] = p - 1 }
                if (x < w - 1 && mask[p + 1] && !seen[p + 1]) { seen[p + 1] = true; stack[sp++] = p + 1 }
                if (y > 0 && mask[p - w] && !seen[p - w]) { seen[p - w] = true; stack[sp++] = p - w }
                if (y < h - 1 && mask[p + w] && !seen[p + w]) { seen[p + w] = true; stack[sp++] = p + w }
            }
            if (cnt > bestN) {
                bestN = cnt
                best = tmp.copyOf(cnt)
            }
        }
        return best
    }

    private fun candidate(mask: BooleanArray, w: Int, h: Int): Cand? {
        val pts = largest(mask, w, h) ?: return null
        if (pts.size < 0.04f * w * h) return null
        var tl = 0; var tr = 0; var br = 0; var bl = 0
        var aTl = Int.MAX_VALUE; var aTr = Int.MIN_VALUE; var aBr = Int.MIN_VALUE; var aBl = Int.MAX_VALUE
        for (p in pts) {
            val x = p % w
            val y = p / w
            if (x + y < aTl) { aTl = x + y; tl = p }
            if (x - y > aTr) { aTr = x - y; tr = p }
            if (x + y > aBr) { aBr = x + y; br = p }
            if (x - y < aBl) { aBl = x - y; bl = p }
        }
        val q = floatArrayOf(
            (tl % w).toFloat(), (tl / w).toFloat(),
            (tr % w).toFloat(), (tr / w).toFloat(),
            (br % w).toFloat(), (br / w).toFloat(),
            (bl % w).toFloat(), (bl / w).toFloat()
        )
        var area = 0f
        for (i in 0 until 4) {
            val j = (i + 1) % 4
            area += q[2 * i] * q[2 * j + 1] - q[2 * j] * q[2 * i + 1]
        }
        area = abs(area) / 2f
        if (area <= 0f) return null
        val fill = min(1f, pts.size / area)
        val frac = area / (w * h)
        var minSide = Float.MAX_VALUE
        for (i in 0 until 4) {
            val j = (i + 1) % 4
            minSide = min(minSide, hypot(q[2 * i] - q[2 * j], q[2 * i + 1] - q[2 * j + 1]))
        }
        if (frac < 0.06f || frac > 0.985f || fill < 0.7f || minSide < 0.08f * min(w, h)) return null
        // recua ~1 px em direção ao centro (o desfoque infla a região um pouco)
        val cx = (q[0] + q[2] + q[4] + q[6]) / 4f
        val cy = (q[1] + q[3] + q[5] + q[7]) / 4f
        for (i in 0 until 4) {
            val dx = cx - q[2 * i]
            val dy = cy - q[2 * i + 1]
            val d = hypot(dx, dy)
            if (d > 2f) {
                q[2 * i] += dx / d * 0.8f
                q[2 * i + 1] += dy / d * 0.8f
            }
        }
        return Cand(frac * fill.pow(6), q, frac)
    }

    /** Divide uma foto de livro aberto em duas páginas (esquerda e direita), com perspectiva. */
    fun splitSpread(c: List<Float>?): Pair<List<Float>, List<Float>> {
        val q = c ?: FULL
        val mtx = (q[0] + q[2]) / 2f
        val mty = (q[1] + q[3]) / 2f
        val mbx = (q[6] + q[4]) / 2f
        val mby = (q[7] + q[5]) / 2f
        val left = listOf(q[0], q[1], mtx, mty, mbx, mby, q[6], q[7])
        val right = listOf(mtx, mty, q[2], q[3], q[4], q[5], mbx, mby)
        return left to right
    }

    // ---------------------------------------------------------------- geometria

    private fun isFull(c: List<Float>): Boolean {
        for (i in 0 until 8) if (abs(c[i] - FULL[i]) > 0.004f) return false
        return true
    }

    /** Recorta o quadrilátero [c] e corrige a perspectiva, devolvendo um retângulo. */
    fun warp(src: Bitmap, c: List<Float>?, maxSide: Int): Bitmap {
        if (c == null || c.size < 8 || isFull(c)) return scaleDown(src, maxSide)
        val w = src.width.toFloat()
        val h = src.height.toFloat()
        val p = FloatArray(8) { if (it % 2 == 0) c[it] * w else c[it] * h }
        fun d(i: Int, j: Int) = hypot(p[2 * i] - p[2 * j], p[2 * i + 1] - p[2 * j + 1])
        var dw = max(d(0, 1), d(3, 2))
        var dh = max(d(0, 3), d(1, 2))
        if (dw < 8f || dh < 8f) return scaleDown(src, maxSide)
        val s = min(1f, maxSide / max(dw, dh))
        dw *= s
        dh *= s
        val ow = max(1, dw.roundToInt())
        val oh = max(1, dh.roundToInt())
        val dst = floatArrayOf(0f, 0f, ow.toFloat(), 0f, ow.toFloat(), oh.toFloat(), 0f, oh.toFloat())
        val m = Matrix()
        if (!m.setPolyToPoly(p, 0, dst, 0, 4)) return scaleDown(src, maxSide)
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(Color.WHITE)
        cv.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        return out
    }

    fun rotate(b: Bitmap, deg: Int): Bitmap {
        val d = ((deg % 360) + 360) % 360
        if (d == 0) return b
        val m = Matrix()
        m.postRotate(d.toFloat())
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    // ---------------------------------------------------------------- filtros

    private class Bg(val gw: Int, val gh: Int, val cell: Float, val v: FloatArray) {
        fun at(x: Int, y: Int): Float {
            val fx = ((x + 0.5f) / cell - 0.5f).coerceIn(0f, (gw - 1).toFloat())
            val fy = ((y + 0.5f) / cell - 0.5f).coerceIn(0f, (gh - 1).toFloat())
            val x0 = fx.toInt()
            val y0 = fy.toInt()
            val x1 = min(x0 + 1, gw - 1)
            val y1 = min(y0 + 1, gh - 1)
            val tx = fx - x0
            val ty = fy - y0
            val a = v[y0 * gw + x0] * (1 - tx) + v[y0 * gw + x1] * tx
            val b = v[y1 * gw + x0] * (1 - tx) + v[y1 * gw + x1] * tx
            return a * (1 - ty) + b * ty
        }
    }

    /** Estima o brilho do papel em cada região (percentil 90 por célula), ignorando o texto. */
    private fun background(px: IntArray, w: Int, h: Int): Bg {
        val cell = max(8, max(w, h) / 72)
        val gw = (w + cell - 1) / cell
        val gh = (h + cell - 1) / cell
        val hist = IntArray(gw * gh * 64)
        val cnt = IntArray(gw * gh)
        var y = 0
        while (y < h) {
            val cy = y / cell
            var x = 0
            while (x < w) {
                val c = px[y * w + x]
                val l = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
                val ci = cy * gw + x / cell
                hist[ci * 64 + (l shr 2)]++
                cnt[ci]++
                x += 2
            }
            y += 2
        }
        var cur = FloatArray(gw * gh)
        for (i in 0 until gw * gh) {
            val target = cnt[i] * 0.9f
            var acc = 0
            var bin = 63
            for (k in 0 until 64) {
                acc += hist[i * 64 + k]
                if (acc >= target) {
                    bin = k
                    break
                }
            }
            cur[i] = bin * 4f + 2f
        }
        repeat(2) {
            val nx = FloatArray(gw * gh)
            for (gy in 0 until gh) {
                for (gx in 0 until gw) {
                    var s = 0f
                    var n = 0
                    for (dy in -1..1) {
                        for (dx in -1..1) {
                            val xx = gx + dx
                            val yy = gy + dy
                            if (xx in 0 until gw && yy in 0 until gh) {
                                s += cur[yy * gw + xx]
                                n++
                            }
                        }
                    }
                    nx[gy * gw + gx] = s / n
                }
            }
            cur = nx
        }
        return Bg(gw, gh, cell.toFloat(), cur)
    }

    /** Filtro de média seletiva 3x3: suaviza ruído sem borrar as bordas do texto. */
    private fun denoise(px: IntArray, w: Int, h: Int) {
        val lum = IntArray(w * h)
        for (i in lum.indices) {
            val c = px[i]
            lum[i] = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
        }
        val out = px.copyOf()
        val tol = 24
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val lc = lum[i]
                var sr = 0
                var sg = 0
                var sb = 0
                var n = 0
                for (dy in -1..1) {
                    val r = (y + dy) * w + x
                    for (dx in -1..1) {
                        val j = r + dx
                        if (abs(lum[j] - lc) <= tol) {
                            val c = px[j]
                            sr += (c shr 16) and 255
                            sg += (c shr 8) and 255
                            sb += c and 255
                            n++
                        }
                    }
                }
                out[i] = (0xFF shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
            }
        }
        System.arraycopy(out, 0, px, 0, px.size)
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private val magicLut = IntArray(256) {
        val v = ((it / 255f - 0.10f) / 0.78f).coerceIn(0f, 1f)
        (v * 255f).roundToInt()
    }

    private val lightLut = IntArray(256) { (255f * (it / 255f).pow(0.65f)).roundToInt().coerceIn(0, 255) }

    private fun bcLut(brightness: Int, contrast: Int): IntArray? {
        if (brightness == 0 && contrast == 0) return null
        val cf = 1f + contrast / 100f
        val bo = brightness * 1.28f
        return IntArray(256) { (((it - 128) * cf) + 128f + bo).roundToInt().coerceIn(0, 255) }
    }

    fun applyFilter(src: Bitmap, p: ScanPage): Bitmap {
        val f = p.filter
        if (f == ScanFilter.ORIGINAL && !p.shadow && !p.denoise && p.brightness == 0 && p.contrast == 0) return src
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        if (p.denoise) denoise(px, w, h)
        val useBg = p.shadow || f == ScanFilter.MAGIC || f == ScanFilter.BW
        val bg = if (useBg) background(px, w, h) else null
        val lut = bcLut(p.brightness, p.contrast)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val c = px[row + x]
                var r = (c shr 16) and 255
                var g = (c shr 8) and 255
                var b = c and 255
                var bgv = 255f
                if (bg != null) {
                    bgv = bg.at(x, y)
                    if (f != ScanFilter.BW) {
                        val gain = min(4f, 255f / max(bgv, 60f))
                        r = min(255, (r * gain).toInt())
                        g = min(255, (g * gain).toInt())
                        b = min(255, (b * gain).toInt())
                    }
                }
                when (f) {
                    ScanFilter.ORIGINAL -> {}
                    ScanFilter.MAGIC -> {
                        val lum = (r * 299 + g * 587 + b * 114) / 1000f
                        r = magicLut[(lum + (r - lum) * 1.2f).toInt().coerceIn(0, 255)]
                        g = magicLut[(lum + (g - lum) * 1.2f).toInt().coerceIn(0, 255)]
                        b = magicLut[(lum + (b - lum) * 1.2f).toInt().coerceIn(0, 255)]
                    }
                    ScanFilter.BW -> {
                        val lum = (r * 299 + g * 587 + b * 114) / 1000f
                        val t = smooth(0.60f, 0.86f, lum / max(bgv, 60f))
                        val v = (t * 255f).toInt()
                        r = v; g = v; b = v
                    }
                    ScanFilter.GRAY -> {
                        val v = (r * 299 + g * 587 + b * 114) / 1000
                        r = v; g = v; b = v
                    }
                    ScanFilter.LIGHT -> {
                        r = lightLut[r]; g = lightLut[g]; b = lightLut[b]
                    }
                }
                if (lut != null) {
                    r = lut[r]; g = lut[g]; b = lut[b]
                }
                px[row + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Pipeline completo de uma página: decodifica → recorta/perspectiva → gira → filtros. */
    fun render(p: ScanPage, maxSide: Int): Bitmap? {
        val srcMax = (maxSide * 1.5f).toInt().coerceIn(600, 3200)
        val src = decode(p.src, srcMax) ?: return null
        val wp = warp(src, p.corners, maxSide)
        if (wp !== src) src.recycle()
        val rt = rotate(wp, p.rotation)
        if (rt !== wp) wp.recycle()
        val fl = applyFilter(rt, p)
        if (fl !== rt) rt.recycle()
        return fl
    }
}
