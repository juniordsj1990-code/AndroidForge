package com.pdfpro.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Cores fixas da marca / leitura (usadas fora do ColorScheme). */
object PdfColors {
    val Brand = Color(0xFFD62839)
    val BrandDeep = Color(0xFF9E1B2A)
    val ReaderBgLight = Color(0xFFC9CCD3)
    val ReaderBgDark = Color(0xFF14161A)
    val ReaderBgInverted = Color(0xFF0B0C0E)
}

private val LightScheme = lightColorScheme(
    primary = Color(0xFFC4202F),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFDAD9),
    onPrimaryContainer = Color(0xFF410006),
    secondary = Color(0xFF5B5F6B),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE6E8EF),
    onSecondaryContainer = Color(0xFF1A1C22),
    tertiary = Color(0xFF2F5FA8),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFF5F6F9),
    onBackground = Color(0xFF16181D),
    surface = Color(0xFFF5F6F9),
    onSurface = Color(0xFF16181D),
    surfaceVariant = Color(0xFFE9EBF1),
    onSurfaceVariant = Color(0xFF4B4F5A),
    surfaceTint = Color(0xFFC4202F),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFFFFFF),
    surfaceContainer = Color(0xFFEFF1F6),
    surfaceContainerHigh = Color(0xFFE9EBF1),
    surfaceContainerHighest = Color(0xFFE2E5EC),
    outline = Color(0xFF8B8F9B),
    outlineVariant = Color(0xFFD3D6DF),
    error = Color(0xFFB3261E)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFFF6B77),
    onPrimary = Color(0xFF5E0010),
    primaryContainer = Color(0xFF7A1421),
    onPrimaryContainer = Color(0xFFFFDAD9),
    secondary = Color(0xFFB4B8C5),
    onSecondary = Color(0xFF2A2D36),
    secondaryContainer = Color(0xFF2B2E37),
    onSecondaryContainer = Color(0xFFE2E4EC),
    tertiary = Color(0xFF8FB4F0),
    onTertiary = Color(0xFF0B2A56),
    background = Color(0xFF101216),
    onBackground = Color(0xFFE6E8EE),
    surface = Color(0xFF101216),
    onSurface = Color(0xFFE6E8EE),
    surfaceVariant = Color(0xFF23262E),
    onSurfaceVariant = Color(0xFFB0B4C0),
    surfaceTint = Color(0xFFFF6B77),
    surfaceContainerLowest = Color(0xFF0B0C0F),
    surfaceContainerLow = Color(0xFF16181D),
    surfaceContainer = Color(0xFF1A1D23),
    surfaceContainerHigh = Color(0xFF21242B),
    surfaceContainerHighest = Color(0xFF292D35),
    outline = Color(0xFF7B7F8B),
    outlineVariant = Color(0xFF30343D),
    error = Color(0xFFFFB4AB)
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

private val base = FontFamily.Default

private val AppTypography = Typography(
    displaySmall = TextStyle(fontFamily = base, fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 38.sp, letterSpacing = (-1).sp),
    headlineMedium = TextStyle(fontFamily = base, fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 30.sp, letterSpacing = (-0.6).sp),
    headlineSmall = TextStyle(fontFamily = base, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 26.sp, letterSpacing = (-0.4).sp),
    titleLarge = TextStyle(fontFamily = base, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 24.sp, letterSpacing = (-0.3).sp),
    titleMedium = TextStyle(fontFamily = base, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp, letterSpacing = (-0.1).sp),
    titleSmall = TextStyle(fontFamily = base, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = base, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = base, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = base, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = base, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.sp),
    labelMedium = TextStyle(fontFamily = base, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.1.sp),
    labelSmall = TextStyle(fontFamily = base, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 0.1.sp)
)

@Composable
fun PdfProTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
