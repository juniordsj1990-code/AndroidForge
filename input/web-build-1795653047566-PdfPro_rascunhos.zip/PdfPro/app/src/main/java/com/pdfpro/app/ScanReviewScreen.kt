@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.pdfpro.app

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ScanReviewScreen(vm: MainViewModel) {
    val s = vm.scan
    if (s == null) {
        LaunchedEffect(Unit) { vm.screen = Screen.HOME }
        return
    }
    var confirmExit by remember { mutableStateOf(false) }
    var showOptions by remember { mutableStateOf(false) }
    val selCount = s.selected.size

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { l ->
        if (l.isNotEmpty()) vm.importImages(l)
    }

    fun exit() {
        if (s.pages.isEmpty()) vm.exitScan() else confirmExit = true
    }
    BackHandler { if (selCount > 0) s.selected.clear() else exit() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (selCount > 0) "$selCount selecionada(s)" else "${s.pages.size} página(s)",
                        style = MaterialTheme.typography.titleMedium
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
                ),
                navigationIcon = {
                    IconButton(onClick = { exit() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                },
                actions = {
                    FilledTonalButton(
                        onClick = { vm.createScanPdf() },
                        enabled = s.pages.isNotEmpty(),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(Icons.Default.Check, null, Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text("Criar PDF")
                    }
                }
            )
        },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surfaceContainerLowest, shadowElevation = 8.dp) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 6.dp)) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AssistChip(
                            onClick = { vm.openCamera() },
                            label = { Text("Câmera") },
                            leadingIcon = { Icon(Icons.Default.PhotoCamera, null, Modifier.size(18.dp)) }
                        )
                        AssistChip(
                            onClick = { gallery.launch("image/*") },
                            label = { Text("Galeria") },
                            leadingIcon = { Icon(Icons.Default.Image, null, Modifier.size(18.dp)) }
                        )
                        AssistChip(
                            onClick = { showOptions = true },
                            label = { Text("Opções do PDF") },
                            leadingIcon = { Icon(Icons.Default.Tune, null, Modifier.size(18.dp)) }
                        )
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        IconButton(onClick = { s.selectAllOrNone() }) { Icon(Icons.Default.SelectAll, "Selecionar tudo") }
                        IconButton(enabled = selCount > 0, onClick = { s.rotateSelected(-90) }) {
                            Icon(Icons.Default.RotateLeft, "Girar à esquerda")
                        }
                        IconButton(enabled = selCount > 0, onClick = { s.rotateSelected(90) }) {
                            Icon(Icons.Default.RotateRight, "Girar à direita")
                        }
                        IconButton(enabled = selCount > 0, onClick = { s.moveEarlier() }) {
                            Icon(Icons.Default.KeyboardArrowLeft, "Mover antes")
                        }
                        IconButton(enabled = selCount > 0, onClick = { s.moveLater() }) {
                            Icon(Icons.Default.KeyboardArrowRight, "Mover depois")
                        }
                        IconButton(enabled = selCount > 0, onClick = { s.deleteSelected() }) {
                            Icon(Icons.Default.Delete, "Excluir")
                        }
                    }
                }
            }
        }
    ) { pad ->
        if (s.pages.isEmpty()) {
            Box(
                Modifier.padding(pad).fillMaxSize().background(MaterialTheme.colorScheme.surfaceContainer),
                contentAlignment = Alignment.Center
            ) {
                Text("Nenhuma página. Use Câmera ou Galeria para adicionar.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(104.dp),
                modifier = Modifier.padding(pad).fillMaxSize().background(MaterialTheme.colorScheme.surfaceContainer),
                contentPadding = PaddingValues(14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                itemsIndexed(s.pages.toList(), key = { _, p -> p.id }) { idx, p ->
                    PageCard(
                        page = p,
                        index = idx + 1,
                        selected = p.id in s.selected,
                        onClick = { if (s.selected.isNotEmpty()) s.toggle(p.id) else vm.openView(p.id) },
                        onLongClick = { s.toggle(p.id) }
                    )
                }
            }
        }
    }

    if (showOptions) PdfOptionsDialog(s) { showOptions = false }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Sair da digitalização?") },
            text = { Text("As ${s.pages.size} página(s) ainda não viraram PDF. Você pode guardar um rascunho e continuar depois pela tela inicial.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmExit = false
                    vm.leaveScanKeepingDraft()
                }) { Text("Salvar rascunho") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        confirmExit = false
                        vm.exitScan()
                    }) { Text("Descartar") }
                    TextButton(onClick = { confirmExit = false }) { Text("Continuar") }
                }
            }
        )
    }
}

@Composable
private fun PageCard(page: ScanPage, index: Int, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val key = page.cacheKey() + "|t"
    val bmp by produceState<Bitmap?>(ScanCache.get(key), key) {
        if (value == null) {
            value = withContext(Dispatchers.Default) { ImageProc.render(page, 360) }?.also { ScanCache.put(key, it) }
        }
    }
    val shape = RoundedCornerShape(10.dp)
    val primary = MaterialTheme.colorScheme.primary
    Box(
        Modifier
            .aspectRatio(0.72f)
            .clip(shape)
            .background(Color.White)
            .border(if (selected) 3.dp else 1.dp, if (selected) primary else MaterialTheme.colorScheme.outlineVariant, shape)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        bmp?.let {
            Image(it.asImageBitmap(), null, Modifier.fillMaxSize().padding(4.dp), contentScale = ContentScale.Fit)
        }
        Box(
            Modifier.align(Alignment.BottomStart).padding(6.dp).clip(RoundedCornerShape(50))
                .background(Color.Black.copy(alpha = 0.6f)).padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text("$index", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        if (selected) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).clip(CircleShape).background(primary),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Check, null, Modifier.size(15.dp), tint = Color.White) }
        }
    }
}

@Composable
private fun <T> ChipRow(items: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { it ->
            FilterChip(selected = it == selected, onClick = { onSelect(it) }, label = { Text(label(it)) })
        }
    }
}

@Composable
private fun PdfOptionsDialog(s: ScanSession, onDismiss: () -> Unit) {
    val o = s.options
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Opções do PDF") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Tamanho da página", style = MaterialTheme.typography.labelLarge)
                ChipRow(PageSize.values().toList(), o.size, { it.label }) { s.options = o.copy(size = it) }
                Text("Margens", style = MaterialTheme.typography.labelLarge)
                ChipRow(MarginSize.values().toList(), o.margin, { it.label }) { s.options = o.copy(margin = it) }
                Text("Qualidade / compressão", style = MaterialTheme.typography.labelLarge)
                ChipRow(PdfQuality.values().toList(), o.quality, { it.label }) { s.options = o.copy(quality = it) }
                Text("Numeração de páginas", style = MaterialTheme.typography.labelLarge)
                ChipRow(NumberStyle.values().toList(), o.numbering, { it.label }) { s.options = o.copy(numbering = it) }
                OutlinedTextField(
                    value = o.watermark,
                    onValueChange = { s.options = o.copy(watermark = it.take(40)) },
                    label = { Text("Marca d'água (texto)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("OCR (PDF pesquisável)", style = MaterialTheme.typography.labelLarge)
                        Text(
                            "Reconhece o texto e o deixa selecionável e pesquisável. Mais lento. Alfabeto latino (português, inglês…).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = o.ocr, onCheckedChange = { s.options = o.copy(ocr = it) })
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
    )
}
