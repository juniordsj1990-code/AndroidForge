@file:OptIn(ExperimentalMaterial3Api::class)

package com.pdfpro.app

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun ScanEditScreen(vm: MainViewModel) {
    val s = vm.scan
    val page = s?.page(vm.editId)
    if (s == null || page == null) {
        LaunchedEffect(Unit) { vm.screen = if (s != null) Screen.SCAN_REVIEW else Screen.HOME }
        return
    }
    BackHandler { vm.closeEdit() }
    var tab by remember { mutableIntStateOf(0) }
    val idx = s.pages.indexOfFirst { it.id == page.id }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Página ${idx + 1} de ${s.pages.size}", style = MaterialTheme.typography.titleMedium) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                navigationIcon = {
                    IconButton(onClick = { vm.closeEdit() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                },
                actions = {
                    IconButton(enabled = idx > 0, onClick = { vm.editId = s.pages[idx - 1].id }) {
                        Icon(Icons.Default.KeyboardArrowLeft, "Página anterior")
                    }
                    IconButton(enabled = idx < s.pages.size - 1, onClick = { vm.editId = s.pages[idx + 1].id }) {
                        Icon(Icons.Default.KeyboardArrowRight, "Próxima página")
                    }
                    TextButton(onClick = { vm.closeEdit() }) { Text("Concluído") }
                }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Crop, null) }, label = { Text("Cortar") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.AutoFixHigh, null) }, label = { Text("Filtros") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Ajustes") })
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF1B1D22))) {
                if (tab == 0) CropPane(s, page) else ResultPane(page)
            }
            when (tab) {
                0 -> CropControls(vm, s, page)
                1 -> FilterControls(s, page)
                else -> AdjustControls(s, page)
            }
        }
    }
}

// ------------------------------------------------------------------ recorte

private class Fit(val ox: Float, val oy: Float, val dw: Float, val dh: Float)

private fun fit(w: Float, h: Float, iw: Int, ih: Int, pad: Float): Fit {
    val sc = min((w - 2 * pad) / iw, (h - 2 * pad) / ih)
    val dw = iw * sc
    val dh = ih * sc
    return Fit((w - dw) / 2f, (h - dh) / 2f, dw, dh)
}

/** Coordenada da imagem original (normalizada) → coordenada na imagem girada exibida. */
private fun toDisplay(c: List<Float>, rot: Int): List<Float> {
    val out = ArrayList<Float>(8)
    for (i in 0 until 4) {
        val x = c[2 * i]
        val y = c[2 * i + 1]
        when (rot) {
            90 -> { out.add(1f - y); out.add(x) }
            180 -> { out.add(1f - x); out.add(1f - y) }
            270 -> { out.add(y); out.add(1f - x) }
            else -> { out.add(x); out.add(y) }
        }
    }
    return out
}

private fun toSource(c: List<Float>, rot: Int): List<Float> {
    val out = ArrayList<Float>(8)
    for (i in 0 until 4) {
        val u = c[2 * i]
        val v = c[2 * i + 1]
        when (rot) {
            90 -> { out.add(v); out.add(1f - u) }
            180 -> { out.add(1f - u); out.add(1f - v) }
            270 -> { out.add(1f - v); out.add(u) }
            else -> { out.add(u); out.add(v) }
        }
    }
    return out
}

@Composable
private fun CropPane(s: ScanSession, page: ScanPage) {
    val src by produceState<Bitmap?>(null, page.src) {
        value = withContext(Dispatchers.Default) { ImageProc.decode(page.src, 1600) }
    }
    val base = src
    if (base == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    val shown = remember(base, page.rotation) { ImageProc.rotate(base, page.rotation) }
    val img = remember(shown) { shown.asImageBitmap() }
    var pts by remember(page.id, page.rotation, page.corners) {
        mutableStateOf(toDisplay(page.corners ?: ImageProc.FULL, page.rotation))
    }
    val rot = page.rotation
    val id = page.id

    Canvas(
        Modifier
            .fillMaxSize()
            .pointerInput(shown, id, page.corners) {
                var active = -1
                detectDragGestures(
                    onDragStart = { o ->
                        val f = fit(size.width.toFloat(), size.height.toFloat(), shown.width, shown.height, 28.dp.toPx())
                        var best = -1
                        var bd = Float.MAX_VALUE
                        for (i in 0 until 4) {
                            val px = f.ox + pts[2 * i] * f.dw
                            val py = f.oy + pts[2 * i + 1] * f.dh
                            val d = hypot(px - o.x, py - o.y)
                            if (d < bd) {
                                bd = d
                                best = i
                            }
                        }
                        active = if (bd <= 60.dp.toPx()) best else -1
                    },
                    onDrag = { change, drag ->
                        if (active >= 0) {
                            change.consume()
                            val f = fit(size.width.toFloat(), size.height.toFloat(), shown.width, shown.height, 28.dp.toPx())
                            val np = pts.toMutableList()
                            np[2 * active] = (np[2 * active] + drag.x / f.dw).coerceIn(0f, 1f)
                            np[2 * active + 1] = (np[2 * active + 1] + drag.y / f.dh).coerceIn(0f, 1f)
                            pts = np
                        }
                    },
                    onDragEnd = {
                        if (active >= 0) {
                            val c = toSource(pts, rot)
                            s.update(id) { it.copy(corners = c) }
                        }
                        active = -1
                    },
                    onDragCancel = { active = -1 }
                )
            }
    ) {
        val f = fit(size.width, size.height, shown.width, shown.height, 28.dp.toPx())
        drawImage(
            img,
            dstOffset = IntOffset(f.ox.roundToInt(), f.oy.roundToInt()),
            dstSize = IntSize(f.dw.roundToInt(), f.dh.roundToInt())
        )
        val p = pts
        val path = Path().apply {
            moveTo(f.ox + p[0] * f.dw, f.oy + p[1] * f.dh)
            lineTo(f.ox + p[2] * f.dw, f.oy + p[3] * f.dh)
            lineTo(f.ox + p[4] * f.dw, f.oy + p[5] * f.dh)
            lineTo(f.ox + p[6] * f.dw, f.oy + p[7] * f.dh)
            close()
        }
        drawPath(path, Color(0xFF42A5F5).copy(alpha = 0.18f))
        drawPath(path, Color(0xFF42A5F5), style = Stroke(width = 2.5.dp.toPx()))
        for (i in 0 until 4) {
            val c = Offset(f.ox + p[2 * i] * f.dw, f.oy + p[2 * i + 1] * f.dh)
            drawCircle(Color.White, 13.dp.toPx(), c)
            drawCircle(Color(0xFF42A5F5), 10.dp.toPx(), c)
        }
    }
}

@Composable
private fun CropControls(vm: MainViewModel, s: ScanSession, page: ScanPage) {
    val scope = rememberCoroutineScope()
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedButton(onClick = {
            scope.launch {
                val c = withContext(Dispatchers.Default) {
                    val b = ImageProc.decode(page.src, 900)
                    val d = b?.let { ImageProc.detectQuad(ImageProc.grayFromBitmap(it)) }
                    b?.recycle()
                    d?.q
                }
                if (c != null) s.update(page.id) { it.copy(corners = c) }
                else vm.message = "Não encontrei as bordas do documento"
            }
        }) { Text("Detectar") }
        OutlinedButton(onClick = { s.update(page.id) { it.copy(corners = null) } }) { Text("Imagem inteira") }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = { s.update(page.id) { it.copy(rotation = (it.rotation + 270) % 360) } }) {
            Icon(Icons.Default.RotateLeft, "Girar à esquerda")
        }
        IconButton(onClick = { s.update(page.id) { it.copy(rotation = (it.rotation + 90) % 360) } }) {
            Icon(Icons.Default.RotateRight, "Girar à direita")
        }
    }
}

// ------------------------------------------------------------------ resultado (filtros e ajustes)

@Composable
private fun ResultPane(page: ScanPage) {
    val key = page.cacheKey() + "|p"
    var shown by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(false) }
    LaunchedEffect(key) {
        loading = true
        val cached = ScanCache.get(key)
        val b = if (cached != null) cached else {
            delay(120)
            withContext(Dispatchers.Default) { ImageProc.render(page, 1100) }?.also { ScanCache.put(key, it) }
        }
        if (b != null) shown = b
        loading = false
    }
    Box(Modifier.fillMaxSize()) {
        shown?.let { b ->
            val ib = remember(b) { b.asImageBitmap() }
            Image(ib, null, Modifier.fillMaxSize().padding(12.dp), contentScale = ContentScale.Fit)
        }
        if (loading) {
            CircularProgressIndicator(Modifier.align(Alignment.TopEnd).padding(12.dp).size(22.dp), strokeWidth = 2.dp)
        }
    }
}

@Composable
private fun FilterControls(s: ScanSession, page: ScanPage) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ScanFilter.values().forEach { f ->
                FilterChip(
                    selected = page.filter == f,
                    onClick = { s.update(page.id) { it.copy(filter = f) } },
                    label = { Text(f.label) }
                )
            }
        }
        OutlinedButton(onClick = {
            for (i in s.pages.indices) {
                s.pages[i] = s.pages[i].copy(
                    filter = page.filter, brightness = page.brightness, contrast = page.contrast,
                    shadow = page.shadow, denoise = page.denoise
                )
            }
        }) { Text("Aplicar filtro e ajustes a todas as páginas") }
    }
}

@Composable
private fun AdjustControls(s: ScanSession, page: ScanPage) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text("Brilho: ${page.brightness}", style = MaterialTheme.typography.labelLarge)
        Slider(
            value = page.brightness.toFloat(),
            onValueChange = { v -> s.update(page.id) { it.copy(brightness = v.roundToInt()) } },
            valueRange = -100f..100f
        )
        Text("Contraste: ${page.contrast}", style = MaterialTheme.typography.labelLarge)
        Slider(
            value = page.contrast.toFloat(),
            onValueChange = { v -> s.update(page.id) { it.copy(contrast = v.roundToInt()) } },
            valueRange = -100f..100f
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Remover sombra", Modifier.weight(1f))
            Switch(checked = page.shadow, onCheckedChange = { c -> s.update(page.id) { it.copy(shadow = c) } })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Remover ruído", Modifier.weight(1f))
            Switch(checked = page.denoise, onCheckedChange = { c -> s.update(page.id) { it.copy(denoise = c) } })
        }
        TextButton(onClick = {
            s.update(page.id) { it.copy(brightness = 0, contrast = 0, shadow = false, denoise = false) }
        }) { Text("Redefinir ajustes") }
    }
}
