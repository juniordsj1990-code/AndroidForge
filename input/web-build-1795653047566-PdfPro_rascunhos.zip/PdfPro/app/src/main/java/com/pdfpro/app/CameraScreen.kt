@file:OptIn(ExperimentalMaterial3Api::class)

package com.pdfpro.app

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import android.view.Surface
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

/** Estado do disparo automático (só mexido na thread principal). */
private class AutoState {
    var stable = 0
    var missing = 0
    var lastShot: List<Float>? = null
    var lastShotAt = 0L
    var lastAnalysis = 0L
}

private fun maxDiff(a: List<Float>, b: List<Float>): Float {
    var m = 0f
    for (i in 0 until 8) m = max(m, abs(a[i] - b[i]))
    return m
}

private fun blend(a: List<Float>, b: List<Float>, t: Float): List<Float> =
    List(8) { a[it] + (b[it] - a[it]) * t }

@Composable
fun CameraScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }
    BackHandler { vm.leaveCamera() }

    if (!granted) {
        Column(
            Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Para fotografar documentos o app precisa de acesso à câmera.",
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Permitir câmera") }
            TextButton(onClick = { vm.leaveCamera() }) { Text("Voltar") }
        }
        return
    }
    CameraContent(vm)
}

@Composable
private fun CameraContent(vm: MainViewModel) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val orientation = LocalConfiguration.current.orientation
    val portrait = orientation != Configuration.ORIENTATION_LANDSCAPE
    val ratio = if (portrait) 3f / 4f else 4f / 3f
    val main = remember { Handler(Looper.getMainLooper()) }
    val auto = remember { AutoState() }

    var quad by remember { mutableStateOf<List<Float>?>(null) }
    var stableShown by remember { mutableIntStateOf(0) }
    var capturing by remember { mutableStateOf(false) }
    var flash by remember { mutableStateOf(false) }

    val previewView = remember {
        PreviewView(ctx).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
    }
    val preview = remember {
        Preview.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .build()
            ).build()
    }
    // ~8 MP: bem mais rápido de salvar que a resolução máxima do sensor, e suficiente para OCR
    val capture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .setResolutionStrategy(
                        ResolutionStrategy(Size(3264, 2448), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
                    )
                    .build()
            ).build()
    }
    val analysis = remember {
        ImageAnalysis.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .setResolutionStrategy(
                        ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                    )
                    .build()
            )
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
    }

    fun applyRotation() {
        val r = previewView.display?.rotation ?: Surface.ROTATION_0
        preview.targetRotation = r
        capture.targetRotation = r
        analysis.targetRotation = r
    }

    fun shoot(q: List<Float>?) {
        if (capturing) return
        capturing = true
        auto.lastShot = q ?: quad
        auto.lastShotAt = SystemClock.elapsedRealtime()
        auto.stable = 0
        stableShown = 0
        flash = true
        val f = vm.scanFile()
        capture.takePicture(
            ImageCapture.OutputFileOptions.Builder(f).build(),
            ContextCompat.getMainExecutor(ctx),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    capturing = false
                    vm.onShot(f)
                }

                override fun onError(exception: ImageCaptureException) {
                    capturing = false
                    vm.message = "Falha ao capturar a foto"
                }
            }
        )
    }

    fun onDetect(d: Detection?) {
        val minShow = 0.06f
        if (d == null || d.area < minShow) {
            auto.missing++
            if (auto.missing >= 3) {
                quad = null
                auto.stable = 0
                stableShown = 0
                auto.lastShot = null
            }
            return
        }
        auto.missing = 0
        val prev = quad
        if (prev == null) {
            quad = d.q
            auto.stable = 0
        } else {
            val diff = maxDiff(prev, d.q)
            quad = blend(prev, d.q, 0.6f)
            auto.stable = if (diff < 0.025f) auto.stable + 1 else 0
        }
        stableShown = auto.stable
        val minArea = if (vm.camMode == CamMode.CARD) 0.07f else 0.22f
        val now = SystemClock.elapsedRealtime()
        if (vm.camAuto && !capturing && auto.stable >= 7 && d.area >= minArea && now - auto.lastShotAt > 1500) {
            val ls = auto.lastShot
            if (ls == null || maxDiff(ls, d.q) > 0.08f) shoot(d.q)
        }
    }

    DisposableEffect(lifecycleOwner) {
        val future = ProcessCameraProvider.getInstance(ctx)
        var provider: ProcessCameraProvider? = null
        val exec = Executors.newSingleThreadExecutor()
        analysis.setAnalyzer(exec, ImageAnalysis.Analyzer { proxy ->
            try {
                val now = SystemClock.elapsedRealtime()
                if (now - auto.lastAnalysis >= 90) {
                    auto.lastAnalysis = now
                    val plane = proxy.planes[0]
                    val g = ImageProc.grayFromY(
                        plane.buffer, plane.rowStride, proxy.width, proxy.height, proxy.imageInfo.rotationDegrees
                    )
                    val d = ImageProc.detectQuad(g)
                    main.post { onDetect(d) }
                }
            } catch (e: Throwable) {
                // quadro ignorado
            } finally {
                proxy.close()
            }
        })
        future.addListener({
            try {
                val p = future.get()
                provider = p
                preview.setSurfaceProvider(previewView.surfaceProvider)
                applyRotation()
                p.unbindAll()
                p.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture, analysis)
            } catch (e: Exception) {
                vm.message = "Não foi possível iniciar a câmera"
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            analysis.clearAnalyzer()
            provider?.unbindAll()
            exec.shutdown()
        }
    }

    LaunchedEffect(orientation) { applyRotation() }
    LaunchedEffect(flash) {
        if (flash) {
            delay(90)
            flash = false
        }
    }

    val session = vm.scan
    val pages = session?.pages
    val count = (pages?.size ?: 0) + (if (vm.cardFront != null) 1 else 0)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // ---- barra superior
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.leaveCamera() }) { Icon(Icons.Default.Close, "Fechar", tint = Color.White) }
                Spacer(Modifier.weight(1f))
                FilterChip(
                    selected = vm.camAuto,
                    onClick = { vm.camAuto = !vm.camAuto },
                    label = { Text("Auto") },
                    leadingIcon = { Icon(Icons.Default.AutoAwesome, null, Modifier.size(18.dp)) },
                    colors = FilterChipDefaults.filterChipColors(
                        labelColor = Color.White,
                        iconColor = Color.White,
                        selectedContainerColor = Color(0xFF2E7D32),
                        selectedLabelColor = Color.White,
                        selectedLeadingIconColor = Color.White
                    )
                )
                IconButton(onClick = { vm.camGrid = !vm.camGrid }) {
                    Icon(
                        Icons.Default.GridOn, "Grade",
                        tint = if (vm.camGrid) Color(0xFFFFD54F) else Color.White
                    )
                }
            }

            // ---- visor
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val bw = if (maxWidth < maxHeight * ratio) maxWidth else maxHeight * ratio
                val bh = bw / ratio
                Box(Modifier.size(bw, bh)) {
                    AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                    Canvas(Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        if (vm.camGrid) {
                            val gc = Color.White.copy(alpha = 0.4f)
                            for (i in 1..2) {
                                drawLine(gc, Offset(w * i / 3f, 0f), Offset(w * i / 3f, h), 1.5f)
                                drawLine(gc, Offset(0f, h * i / 3f), Offset(w, h * i / 3f), 1.5f)
                            }
                        }
                        val q = quad
                        if (q != null) {
                            val path = Path().apply {
                                moveTo(q[0] * w, q[1] * h)
                                lineTo(q[2] * w, q[3] * h)
                                lineTo(q[4] * w, q[5] * h)
                                lineTo(q[6] * w, q[7] * h)
                                close()
                            }
                            val ready = vm.camAuto && stableShown >= 3
                            val col = if (ready) Color(0xFF66BB6A) else Color.White
                            drawPath(path, col.copy(alpha = 0.18f))
                            drawPath(path, col, style = Stroke(width = 3.dp.toPx()))
                            for (i in 0 until 4) drawCircle(col, 5.dp.toPx(), Offset(q[2 * i] * w, q[2 * i + 1] * h))
                            if (vm.camMode == CamMode.BOOK) {
                                drawLine(
                                    Color.White.copy(alpha = 0.9f),
                                    Offset((q[0] + q[2]) / 2f * w, (q[1] + q[3]) / 2f * h),
                                    Offset((q[6] + q[4]) / 2f * w, (q[7] + q[5]) / 2f * h),
                                    strokeWidth = 2.dp.toPx(),
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f))
                                )
                            }
                        } else if (vm.camMode == CamMode.CARD) {
                            val gw = w * 0.84f
                            val gh = gw / 1.586f
                            drawRoundRect(
                                Color.White.copy(alpha = 0.85f),
                                topLeft = Offset((w - gw) / 2f, (h - gh) / 2f),
                                size = androidx.compose.ui.geometry.Size(gw, gh),
                                cornerRadius = CornerRadius(16f, 16f),
                                style = Stroke(width = 3.dp.toPx())
                            )
                        }
                    }
                    // dica no rodapé do visor
                    val hint = when (vm.camMode) {
                        CamMode.DOC -> "Enquadre o documento"
                        CamMode.BOOK -> "Abra o livro e fotografe as duas páginas de uma vez"
                        CamMode.CARD -> if (vm.cardFront != null) "Agora fotografe o VERSO" else "Fotografe a FRENTE do documento"
                    }
                    Row(
                        Modifier.align(Alignment.BottomCenter).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(color = Color.Black.copy(alpha = 0.55f), shape = RoundedCornerShape(50)) {
                            Text(hint, color = Color.White, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                        }
                        if (vm.camMode == CamMode.CARD && vm.cardFront != null) {
                            TextButton(onClick = { vm.skipCardBack() }) { Text("Só frente", color = Color.White) }
                        }
                    }
                    if (flash) Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.55f)))
                }
            }

            // ---- modos
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
            ) {
                CamMode.values().forEach { m ->
                    FilterChip(
                        selected = vm.camMode == m,
                        onClick = { vm.changeCamMode(m) },
                        label = { Text(m.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            labelColor = Color.White,
                            selectedContainerColor = Color.White,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }

            // ---- miniaturas
            if (pages != null && pages.isNotEmpty()) {
                LazyRow(
                    Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(pages.toList(), key = { _, p -> p.id }) { i, p ->
                        RawThumb(p.src, i + 1)
                    }
                }
            } else {
                Spacer(Modifier.height(60.dp))
            }

            // ---- obturador
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.weight(1f)) {
                    if (count > 0) Text("$count pág.", color = Color.White)
                }
                Box(
                    Modifier
                        .size(74.dp)
                        .border(4.dp, Color.White, CircleShape)
                        .padding(7.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable { shoot(null) }
                )
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                    FilledTonalButton(onClick = { vm.finishCamera() }, enabled = count > 0) {
                        Text("Concluir")
                    }
                }
            }
        }
    }
}

@Composable
private fun RawThumb(file: File, n: Int) {
    val key = "raw|${file.name}"
    val bmp by produceState<Bitmap?>(ScanCache.get(key), key) {
        if (value == null) {
            value = withContext(Dispatchers.Default) { ImageProc.decode(file, 160) }?.also { ScanCache.put(key, it) }
        }
    }
    Box(
        Modifier.size(width = 46.dp, height = 60.dp).clip(RoundedCornerShape(6.dp)).background(Color.DarkGray),
        contentAlignment = Alignment.BottomEnd
    ) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        Text(
            "$n", color = Color.White,
            modifier = Modifier.background(Color.Black.copy(alpha = 0.6f)).padding(horizontal = 4.dp)
        )
    }
}
