@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pdfpro.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.ui.graphics.Path as ComposePath
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.IntSize

@Composable
fun PasswordDialog(vm: MainViewModel) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { vm.needPassword = false },
        title = { Text("PDF protegido") },
        text = {
            Column {
                OutlinedTextField(
                    value = pw,
                    onValueChange = { pw = it },
                    label = { Text("Senha") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                if (vm.passwordError) Text("Senha incorreta", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { TextButton(onClick = { vm.unlock(pw) }) { Text("Abrir") } },
        dismissButton = { TextButton(onClick = { vm.needPassword = false }) { Text("Cancelar") } }
    )
}

@Composable
fun GotoDialog(count: Int, onGo: (Int) -> Unit, onDismiss: () -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ir para página (1–$count)") },
        text = {
            OutlinedTextField(
                value = t,
                onValueChange = { t = it.filter(Char::isDigit) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        },
        confirmButton = {
            TextButton(onClick = {
                t.toIntOrNull()?.let { onGo(it.coerceIn(1, count)) }
                onDismiss()
            }) { Text("Ir") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun SearchDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Buscar no PDF") },
        text = {
            Column {
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.search(q) })
                )
                if (vm.searching) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
                if (vm.matches.isNotEmpty()) {
                    Text(
                        "${vm.matches.size} resultado(s)" + if (vm.matches.size >= 1000) " (mostrando os primeiros 1000)" else "",
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    itemsIndexed(vm.matches) { i, m ->
                        Column(
                            Modifier.fillMaxWidth().clickable { vm.selectMatch(i); onDismiss() }.padding(vertical = 10.dp, horizontal = 4.dp)
                        ) {
                            Text("Página ${m.page + 1}", style = MaterialTheme.typography.labelLarge)
                            Text(m.snippet, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (vm.matches.isNotEmpty()) {
                TextButton(onClick = { vm.selectMatch(0); onDismiss() }) { Text("Ver no PDF") }
            } else {
                TextButton(onClick = { vm.search(q) }) { Text("Buscar") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

@Composable
fun OutlineDialog(vm: MainViewModel, onJump: (Int) -> Unit, onDismiss: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Índice e marcadores") },
        text = {
            Column {
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Índice") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Marcadores") })
                }
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    if (tab == 0) {
                        if (vm.outline.isEmpty()) item { Text("Este PDF não tem índice.", Modifier.padding(12.dp)) }
                        items(vm.outline) { o ->
                            Text(
                                o.title.ifBlank { "(sem título)" },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = o.page >= 0) { onJump(o.page); onDismiss() }
                                    .padding(start = (12 + o.level * 16).dp, top = 10.dp, bottom = 10.dp, end = 12.dp)
                            )
                        }
                    } else {
                        if (vm.bookmarks.isEmpty()) item { Text("Nenhum marcador. Use a estrela no topo.", Modifier.padding(12.dp)) }
                        items(vm.bookmarks) { p ->
                            Row(
                                Modifier.fillMaxWidth().clickable { onJump(p); onDismiss() }.padding(start = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Página ${p + 1}", Modifier.weight(1f))
                                IconButton(onClick = { vm.removeBookmark(p) }) { Icon(Icons.Default.Delete, "Remover") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

@Composable
fun FormsDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    val values = remember(vm.fields) { mutableStateMapOf<String, String>().apply { vm.fields.forEach { put(it.name, it.value) } } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Formulário") },
        text = {
            if (vm.fields.isEmpty()) {
                Text("Este PDF não possui campos de formulário preenchíveis.")
            } else {
                LazyColumn(Modifier.heightIn(max = 400.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vm.fields) { f ->
                        when (f.kind) {
                            "check" -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = values[f.name] == "true", onCheckedChange = { values[f.name] = it.toString() })
                                Text(f.name)
                            }
                            "choice" -> {
                                var open by remember { mutableStateOf(false) }
                                Column {
                                    Text(f.name, style = MaterialTheme.typography.labelMedium)
                                    Box {
                                        OutlinedButton(onClick = { open = true }) {
                                            Text(values[f.name].orEmpty().ifBlank { "Selecionar…" })
                                        }
                                        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                                            f.options.forEach { o ->
                                                DropdownMenuItem(text = { Text(o) }, onClick = { values[f.name] = o; open = false })
                                            }
                                        }
                                    }
                                }
                            }
                            else -> OutlinedTextField(
                                value = values[f.name].orEmpty(),
                                onValueChange = { values[f.name] = it },
                                label = { Text(f.name) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (vm.fields.isNotEmpty()) {
                TextButton(onClick = { vm.fillForm(values.toMap()); onDismiss() }) { Text("Aplicar") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

@Composable
fun SplitDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var range by remember { mutableStateOf("") }
    var n by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Extrair / dividir") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Extrair páginas para um novo PDF (ex.: 1-3,5):")
                OutlinedTextField(range, { range = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
                FilledTonalButton(onClick = { vm.extractRange(range); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("Extrair") }
                Text("Ou dividir em arquivos a cada N páginas:")
                OutlinedTextField(
                    n, { n = it.filter(Char::isDigit) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                FilledTonalButton(onClick = { vm.splitEvery(n.toIntOrNull() ?: 0); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("Dividir") }
                Text("Os arquivos vão para Downloads/PdfPro.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

@Composable
fun CompressDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var level by remember { mutableIntStateOf(1) }
    val labels = listOf("Alta qualidade", "Média", "Menor tamanho")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Comprimir PDF") },
        text = {
            Column {
                Text("Atenção: as páginas viram imagens, então o texto deixa de ser selecionável/pesquisável.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                labels.forEachIndexed { i, l ->
                    val sel = level == i
                    val shape = RoundedCornerShape(14.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(shape)
                            .background(if (sel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                            .border(1.dp, if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, shape)
                            .clickable { level = i }
                            .padding(end = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = sel, onClick = { level = i })
                        Text(l, style = MaterialTheme.typography.titleSmall)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.compress(level); onDismiss() }) { Text("Comprimir") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun ProtectDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Proteger com senha") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(a, { a = it }, label = { Text("Senha") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(b, { b = it }, label = { Text("Repita a senha") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                Text("Será salvo um novo arquivo em Downloads/PdfPro.", style = MaterialTheme.typography.labelSmall)
            }
        },
        confirmButton = {
            TextButton(
                enabled = a.isNotEmpty() && a == b,
                onClick = { vm.protect(a); onDismiss() }
            ) { Text("Proteger") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun TextInputDialog(onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Texto") },
        text = { OutlinedTextField(t, { t = it }, modifier = Modifier.fillMaxWidth(), minLines = 2) },
        confirmButton = { TextButton(onClick = { onOk(t) }) { Text("Inserir") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun DiscardDialog(onSave: () -> Unit, onDiscard: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Alterações não salvas") },
        text = { Text("Deseja salvar uma cópia antes de sair?") },
        confirmButton = { TextButton(onClick = onSave) { Text("Salvar cópia") } },
        dismissButton = {
            Row {
                TextButton(onClick = onDiscard) { Text("Descartar") }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        }
    )
}

@Composable
fun MergeDialog(vm: MainViewModel, uris: List<Uri>, onDismiss: () -> Unit) {
    val items = remember { mutableStateListOf<Uri>().apply { addAll(uris) } }
    val names = remember { uris.associateWith { vm.nameOf(it) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mesclar ${items.size} PDFs") },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                itemsIndexed(items) { i, u ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}. ${names[u]}", Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        IconButton(enabled = i > 0, onClick = { val x = items.removeAt(i); items.add(i - 1, x) }) {
                            Icon(Icons.Default.KeyboardArrowUp, "Subir")
                        }
                        IconButton(enabled = i < items.lastIndex, onClick = { val x = items.removeAt(i); items.add(i + 1, x) }) {
                            Icon(Icons.Default.KeyboardArrowDown, "Descer")
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.mergeUris(items.toList()); onDismiss() }) { Text("Mesclar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun SignatureDialog(onSave: (Bitmap) -> Unit, onDismiss: () -> Unit) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var cur by remember { mutableStateOf<List<Offset>>(emptyList()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Desenhe sua assinatura") },
        text = {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { cur = listOf(it) },
                            onDrag = { change, _ ->
                                change.consume()
                                cur = cur + change.position
                            },
                            onDragEnd = {
                                if (cur.isNotEmpty()) strokes.add(cur)
                                cur = emptyList()
                            }
                        )
                    }
            ) {
                ComposeCanvas(Modifier.fillMaxWidth().height(200.dp)) {
                    drawLine(
                        Color(0xFFD0D3DA),
                        Offset(size.width * 0.06f, size.height * 0.72f),
                        Offset(size.width * 0.94f, size.height * 0.72f),
                        strokeWidth = 2f
                    )
                    (strokes.toList() + listOf(cur)).forEach { s ->
                        if (s.size > 1) {
                            val p = ComposePath()
                            s.forEachIndexed { i, o -> if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }
                            drawPath(p, Color(0xFF0D2B8A), style = Stroke(width = 6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                renderSignature(strokes.toList())?.let(onSave)
                onDismiss()
            }) { Text("Usar") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { strokes.clear(); cur = emptyList() }) { Text("Limpar") }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        }
    )
}

private fun renderSignature(strokes: List<List<Offset>>): Bitmap? {
    val pts = strokes.flatten()
    if (pts.size < 2) return null
    val pad = 12f
    val minX = pts.minOf { it.x } - pad
    val minY = pts.minOf { it.y } - pad
    val maxX = pts.maxOf { it.x } + pad
    val maxY = pts.maxOf { it.y } + pad
    val bmp = Bitmap.createBitmap(
        (maxX - minX).toInt().coerceAtLeast(1),
        (maxY - minY).toInt().coerceAtLeast(1),
        Bitmap.Config.ARGB_8888
    )
    val c = Canvas(bmp)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        color = 0xFF0D2B8A.toInt()
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    strokes.forEach { s ->
        val path = android.graphics.Path()
        s.forEachIndexed { i, o ->
            if (i == 0) path.moveTo(o.x - minX, o.y - minY) else path.lineTo(o.x - minX, o.y - minY)
        }
        c.drawPath(path, paint)
    }
    return bmp
}
