# PDF Pro (Android)

Leitor e editor de PDF em Kotlin + Jetpack Compose. 100% offline (sem permissão de internet).

## Como abrir
1. Android Studio (Ladybug ou mais novo) > File > Open > pasta `PdfPro`.
2. Aguarde o Gradle sincronizar (baixa dependências; precisa de internet na 1ª vez).
3. Run (▶) no celular, ou Build > Build APK(s).

Requisitos: Android 10+ (minSdk 29), JDK 17 (o Android Studio já traz).
Para usar `./gradlew` no terminal: rode `gradle wrapper` uma vez (o jar do wrapper não vem no zip).

## Estrutura
- `Ops.kt` – operações PdfBox-Android (mesclar, dividir, páginas, proteger, formulário, gravar anotações...)
- `PdfHolder.kt` – renderização com PdfRenderer nativo
- `MainViewModel.kt` – estado e fluxo (versões/desfazer, salvar, compartilhar)
- `ViewerScreen.kt` / `PagesScreen.kt` / `HomeScreen.kt` / `Dialogs.kt` – telas

## Scanner (Foto/Imagens → PDF)

Fluxo: câmera própria (CameraX) ou galeria → revisão das páginas → edição por página → PDF.

- **Câmera**: aberta uma vez, disparo contínuo com miniaturas, detecção automática de bordas ao vivo,
  captura automática (chip "Auto"), grade, modos Documento / RG-Cartão (frente e verso numa página A4) / Livro
  (uma foto vira duas páginas). Foto salva em ~8 MP para ser rápida.
- **Edição**: recorte com cantos ajustáveis e correção de perspectiva, giro, filtros (Original, Mágico, P&B, Cinza,
  Clarear), brilho/contraste, remover sombra e ruído, "aplicar a todas".
- **Revisão**: reordenar, girar e excluir páginas antes de gerar o PDF (toque longo seleciona).
- **Opções do PDF**: A4 / Carta / ajustar à imagem, margens, qualidade (Alta/Média/Baixa), numeração,
  marca d'água de texto e OCR (PDF pesquisável, ML Kit com modelo embutido, funciona offline).

Arquivos novos: `CameraScreen`, `ScanReviewScreen`, `ScanEditScreen`, `ScanModels`, `ImageProc`, `ScanOps`.
A detecção de bordas é própria (sem OpenCV): Otsu claro/escuro + preenchimento de fundo por bordas.

## Rascunhos (retomar depois)

- **Digitalização**: as fotos ficam em `filesDir/scan` e a lista de páginas/opções em `scan_draft.json`,
  gravada automaticamente a cada mudança e ao sair do app. Se o Android encerrar o app, a tela inicial mostra
  "Digitalização em andamento" com Continuar/Descartar. Ao sair da revisão há a opção **Salvar rascunho**.
  Começar uma nova digitalização com uma em andamento pergunta antes (nunca sobrescreve em silêncio).
- **Edição de PDF**: ao sair de primeiro plano com alterações não salvas, o app grava uma cópia do arquivo de
  trabalho + anotações em `filesDir/doc_draft` (um único rascunho). A tela inicial mostra "Edição não salva".
  O rascunho é apagado ao salvar uma cópia, descartar ou fechar o documento.
- Abrir outro PDF por fora do app (intent VIEW) com alterações não salvas abre o diálogo Salvar cópia / Descartar / Cancelar.
- Lista de **Recentes**: limite de 30 (`Store.touch`).
