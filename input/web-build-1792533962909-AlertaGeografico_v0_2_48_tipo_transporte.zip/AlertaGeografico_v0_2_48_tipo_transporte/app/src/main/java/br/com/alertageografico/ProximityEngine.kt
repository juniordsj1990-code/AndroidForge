package br.com.alertageografico

import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Leitura de posição independente de Android, para permitir testes de unidade. */
data class Fix(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    val timeMillis: Long = 0L
)

data class ProximityResult(
    /** Destinos cujo alerta deve ser disparado agora. */
    val triggered: List<Destination>,
    /** Menor distância até a borda de um raio ativo (0 se estiver dentro de algum). Null sem destinos ativos. */
    val nearestEdgeMeters: Double?,
    /** Verdadeiro se a leitura foi descartada por baixa precisão (para qualquer destino). */
    val lowAccuracy: Boolean,
    /** Ônibus que acabaram de entrar na distância do aviso antecipado (ainda fora do raio). */
    val distanceTriggered: List<Destination> = emptyList()
)

/**
 * Decide quando alertar. Regras:
 *  - leituras com precisão pior que min(maxAccuracy, max(raio, 50 m)) não podem disparar nem rearmar;
 *  - dispara na primeira leitura válida dentro do raio, sem aguardar uma segunda atualização;
 *  - rearma após sair do raio × [rearmFactor] + [rearmExtraMeters];
 *  - ônibus com distância de aviso maior que o raio também disparam um aviso por distância, uma vez por aproximação;
 *  - estado de destinos removidos é descartado.
 */
class ProximityEngine(
    private val maxAccuracyMeters: Float = 150f,
    private val confirmFixes: Int = 2,
    private val strongAccuracyMeters: Float = 25f,
    private val rearmFactor: Double = 1.15,
    private val rearmExtraMeters: Double = 15.0
) {
    private val inside = mutableMapOf<String, Boolean>()
    private val streak = mutableMapOf<String, Int>()
    private val distanceInside = mutableMapOf<String, Boolean>()

    fun process(fix: Fix, destinations: List<Destination>): ProximityResult {
        val active = destinations.filter { it.enabled }
        val activeIds = active.mapTo(HashSet()) { it.id }
        inside.keys.retainAll(activeIds)
        streak.keys.retainAll(activeIds)
        distanceInside.keys.retainAll(activeIds)

        val triggered = mutableListOf<Destination>()
        val distanceTriggered = mutableListOf<Destination>()
        var nearestEdge: Double? = null
        var anyLowAccuracy = false

        for (d in active) {
            val distance = distanceMeters(fix.latitude, fix.longitude, d.latitude, d.longitude)
            val edge = max(0.0, distance - d.radiusMeters)
            nearestEdge = nearestEdge?.let { min(it, edge) } ?: edge

            // Aviso antecipado por distância (só ônibus): dispara uma vez ao cruzar a distância,
            // sem esperar o raio. Se a primeira leitura já cair dentro do raio, só o alerta do
            // raio importa, então o aviso por distância é marcado como já consumido.
            if (d.hasDistanceAlert) {
                val distanceGate = min(maxAccuracyMeters, max(d.distanceAlertMeters.toFloat(), 50f))
                if (fix.accuracyMeters <= distanceGate) {
                    val wasInsideDistance = distanceInside[d.id] ?: false
                    if (distance <= d.distanceAlertMeters) {
                        if (!wasInsideDistance) {
                            distanceInside[d.id] = true
                            if (distance > d.radiusMeters) distanceTriggered += d
                        }
                    } else if (wasInsideDistance && distance > d.distanceAlertMeters * rearmFactor + rearmExtraMeters) {
                        distanceInside[d.id] = false
                    }
                }
            }

            val gate = min(maxAccuracyMeters, max(d.radiusMeters.toFloat(), 50f))
            if (fix.accuracyMeters > gate) {
                anyLowAccuracy = true
                continue // leitura pouco confiável: não altera estado
            }

            val wasInside = inside[d.id] ?: false
            if (distance <= d.radiusMeters) {
                // O requisito do produto é alertar ao entrar no raio. Uma única posição
                // válida já dispara; exigir duas leituras podia perder a chegada quando
                // o usuário passava rapidamente pelo raio entre atualizações do GPS.
                streak[d.id] = 0
                if (!wasInside) {
                    inside[d.id] = true
                    triggered += d
                }
            } else {
                streak[d.id] = 0
                if (wasInside && distance > d.radiusMeters * rearmFactor + rearmExtraMeters) {
                    inside[d.id] = false
                }
            }
        }
        return ProximityResult(triggered, nearestEdge, anyLowAccuracy, distanceTriggered)
    }

    fun reset() { inside.clear(); streak.clear(); distanceInside.clear() }

    companion object {
        private const val EARTH_RADIUS_M = 6_371_000.0
        private const val ASSUMED_MAX_SPEED_MPS = 30.0 // ~108 km/h
        const val MIN_INTERVAL_MS = 3_000L
        const val MAX_INTERVAL_MS = 60_000L

        fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
            val p1 = Math.toRadians(lat1)
            val p2 = Math.toRadians(lat2)
            val dp = p2 - p1
            val dl = Math.toRadians(lon2 - lon1)
            val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
            return 2 * EARTH_RADIUS_M * asin(min(1.0, sqrt(a)))
        }

        /**
         * Intervalo de atualização seguro: no máximo 1/3 do tempo que levaria para alcançar a borda
         * do raio na velocidade assumida, limitado a 3–60 s. Sem destinos ativos, usa o máximo.
         */
        fun recommendedIntervalMs(nearestEdgeMeters: Double?): Long {
            if (nearestEdgeMeters == null) return MAX_INTERVAL_MS
            val ms = nearestEdgeMeters / ASSUMED_MAX_SPEED_MPS * 1000.0 / 3.0
            return ms.toLong().coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)
        }
    }
}
