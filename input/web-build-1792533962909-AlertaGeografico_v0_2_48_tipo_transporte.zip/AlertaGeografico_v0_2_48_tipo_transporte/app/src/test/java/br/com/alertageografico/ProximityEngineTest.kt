package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProximityEngineTest {
    private val dest = Destination(id = "a", name = "A", latitude = -23.0, longitude = -46.0, radiusMeters = 200)

    // ~1 grau de latitude = 111,2 km → 0,001° ≈ 111 m
    private fun fixAt(dLat: Double, accuracy: Float = 10f) = Fix(dest.latitude + dLat, dest.longitude, accuracy)

    @Test fun triggersOnceWhenEntering() {
        val e = ProximityEngine()
        assertTrue(e.process(fixAt(0.01), listOf(dest)).triggered.isEmpty())
        assertEquals(1, e.process(fixAt(0.0005), listOf(dest)).triggered.size)
        assertTrue(e.process(fixAt(0.0004), listOf(dest)).triggered.isEmpty())
    }

    @Test fun rearmsOnlyAfterLeavingWithMargin() {
        val e = ProximityEngine()
        e.process(fixAt(0.0), listOf(dest))
        assertTrue(e.process(fixAt(0.0020), listOf(dest)).triggered.isEmpty()) // ~222 m: ainda na margem
        assertTrue(e.process(fixAt(0.0), listOf(dest)).triggered.isEmpty())    // não rearmou
        e.process(fixAt(0.01), listOf(dest))                                    // saiu de vez
        assertEquals(1, e.process(fixAt(0.0), listOf(dest)).triggered.size)
    }

    @Test fun poorAccuracyNeverTriggers() {
        val e = ProximityEngine()
        assertTrue(e.process(fixAt(0.0, accuracy = 400f), listOf(dest)).triggered.isEmpty())
        assertTrue(e.process(fixAt(0.0, accuracy = 400f), listOf(dest)).lowAccuracy)
    }

    @Test fun validFixInsideRadiusTriggersImmediatelyEvenWithMediocreAccuracy() {
        val e = ProximityEngine()
        assertEquals(1, e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.size)
        assertTrue(e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.isEmpty())
    }

    @Test fun reentryTriggersOnlyAfterLeavingRearmMargin() {
        val e = ProximityEngine()
        assertEquals(1, e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.size)
        assertTrue(e.process(fixAt(0.01, accuracy = 60f), listOf(dest)).triggered.isEmpty())
        assertEquals(1, e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.size)
    }

    @Test fun disabledDestinationsAreIgnored() {
        val e = ProximityEngine()
        val r = e.process(fixAt(0.0), listOf(dest.copy(enabled = false)))
        assertTrue(r.triggered.isEmpty())
        assertNull(r.nearestEdgeMeters)
    }

    @Test fun nearestEdgeIsZeroInsideAndPositiveOutside() {
        val e = ProximityEngine()
        assertEquals(0.0, e.process(fixAt(0.0), listOf(dest)).nearestEdgeMeters!!, 0.001)
        val far = e.process(fixAt(0.01), listOf(dest)).nearestEdgeMeters
        assertNotNull(far)
        assertTrue(far!! in 880.0..920.0) // ~1112 m − 200 m
    }

    @Test fun intervalScalesWithDistance() {
        assertEquals(60_000L, ProximityEngine.recommendedIntervalMs(null))
        assertEquals(60_000L, ProximityEngine.recommendedIntervalMs(50_000.0))
        assertEquals(3_000L, ProximityEngine.recommendedIntervalMs(0.0))
        assertEquals(3_000L, ProximityEngine.recommendedIntervalMs(200.0))
        assertEquals(11_111L, ProximityEngine.recommendedIntervalMs(1_000.0))
    }

    // --- Ônibus: aviso por distância + alerta do raio ---
    private val bus = Destination(
        id = "b", name = "B", latitude = -23.0, longitude = -46.0, radiusMeters = 60,
        transportType = TransportType.BUS, distanceAlertMeters = 300
    )
    private fun busFix(dLat: Double) = Fix(bus.latitude + dLat, bus.longitude, 10f)

    @Test fun busFiresDistanceAlertThenRadiusAlert() {
        val e = ProximityEngine()
        assertTrue(e.process(busFix(0.01), listOf(bus)).distanceTriggered.isEmpty())
        val atDistance = e.process(busFix(0.002), listOf(bus)) // ~222 m
        assertEquals(1, atDistance.distanceTriggered.size)
        assertTrue(atDistance.triggered.isEmpty())
        assertTrue(e.process(busFix(0.0018), listOf(bus)).distanceTriggered.isEmpty()) // não repete
        val atRadius = e.process(busFix(0.0003), listOf(bus)) // ~33 m
        assertEquals(1, atRadius.triggered.size)
        assertTrue(atRadius.distanceTriggered.isEmpty())
    }

    @Test fun busEnteringRadiusDirectlySkipsDistanceAlert() {
        val e = ProximityEngine()
        val r = e.process(busFix(0.0003), listOf(bus))
        assertEquals(1, r.triggered.size)
        assertTrue(r.distanceTriggered.isEmpty())
    }

    @Test fun trainNeverFiresDistanceAlert() {
        val e = ProximityEngine()
        val train = bus.copy(transportType = TransportType.TRAIN)
        assertTrue(e.process(busFix(0.002), listOf(train)).distanceTriggered.isEmpty())
    }

    @Test fun destinationJsonKeepsTransportAndDefaultsOldDataToTrain() {
        val restored = Destination.fromJson(bus.toJson())
        assertEquals(TransportType.BUS, restored.transportType)
        assertEquals(300, restored.distanceAlertMeters)
        val old = org.json.JSONObject().put("name", "X").put("latitude", 1.0).put("longitude", 2.0)
        assertEquals(TransportType.TRAIN, Destination.fromJson(old).transportType)
    }
}
