package br.com.alertageografico

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.content.pm.PackageManager
import android.app.NotificationChannel
import android.app.PendingIntent
import android.app.NotificationManager
import android.media.RingtoneManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import android.location.Geocoder
import android.location.Location
import java.util.Locale
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.ui.Alignment
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.ui.res.painterResource
import br.com.alertageografico.ui.AgColors
import br.com.alertageografico.ui.AgIcon
import br.com.alertageografico.ui.AgTheme
import br.com.alertageografico.ui.CollapsibleCard
import br.com.alertageografico.ui.SettingsChoiceDialog
import br.com.alertageografico.ui.SettingsGroup
import br.com.alertageografico.ui.SettingsSliderRow
import br.com.alertageografico.ui.SettingsSwitchRow
import br.com.alertageografico.ui.SettingsValueRow
import br.com.alertageografico.ui.DrawerHeader
import br.com.alertageografico.ui.ExpandableHelp
import br.com.alertageografico.ui.IntroScreen
import br.com.alertageografico.ui.MapShortcutCard
import br.com.alertageografico.ui.MonitoringHero
import br.com.alertageografico.ui.SectionLabel
import br.com.alertageografico.ui.StatTile
import br.com.alertageografico.ui.StationTimelineCard
import br.com.alertageografico.ui.StatusPill

private fun formatEtaMinutes(totalMinutes: Int): String {
    if (totalMinutes < 60) return "$totalMinutes min"
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return if (minutes == 0) "$hours h" else "$hours h $minutes min"
}

class MainActivity : ComponentActivity() {
    /** Pedido vindo do botão "Parar" da notificação: a UI mostra a confirmação antes de parar. */
    private var stopConfirmRequested by mutableStateOf(false)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(LocationMonitorService.EXTRA_CONFIRM_STOP, false)) stopConfirmRequested = true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Tela de abertura nativa (tema Theme.AlertaGeografico.Starting) precisa ser instalada antes do super.
        installSplashScreen()
        super.onCreate(savedInstanceState)
        if (intent?.getBooleanExtra(LocationMonitorService.EXTRA_CONFIRM_STOP, false) == true) stopConfirmRequested = true
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            var showIntro by remember { mutableStateOf(savedInstanceState == null) }
            LaunchedEffect(showIntro) {
                if (showIntro) {
                    kotlinx.coroutines.delay(1500)
                    showIntro = false
                }
            }
            AgTheme {
                Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                    AppScreen()
                    AnimatedVisibility(
                        visible = showIntro,
                        enter = fadeIn(animationSpec = tween(150)),
                        exit = fadeOut(animationSpec = tween(350))
                    ) {
                        IntroScreen()
                    }
                }
            }
        }
    }

    private fun dismissPendingIntent(context: Context, notificationId: Int): PendingIntent {
        val intent = Intent(context, AlertDismissReceiver::class.java).putExtra("notification_id", notificationId)
        return PendingIntent.getBroadcast(context, notificationId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun recreateAlertChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel("geo_alerts_routed", "Alertas de proximidade", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Alertas de proximidade do Alerta Geográfico"
            channel.setSound(null, null)
            manager.createNotificationChannel(channel)
        }
    }

    private fun showTestNotification(onAudioStatus: ((String) -> Unit)? = null) {
        recreateAlertChannel()
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(this, "geo_alerts_routed")
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setColor(androidx.core.content.ContextCompat.getColor(this, R.color.ag_notification))
            .setContentTitle("Alerta Geográfico — teste")
            .setContentText("Teste de som na saída selecionada nas preferências.")
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "OK", dismissPendingIntent(this, 987654))
            .build()
        manager.notify(987654, notification)
        RoutedAlertSound.play(this, onAudioStatus, AlertKind.TRAIN)
        if (DestinationStore.vibrationEnabled(this)) {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
            else { @Suppress("DEPRECATION") vibrator.vibrate(350) }
        }
    }

    @Composable
    private fun HelpText(text: String) {
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }

    /** Nome do som escolhido, para mostrar na linha de preferência. */
    private fun soundLabel(current: String?, soundEnabled: Boolean): String = when {
        !soundEnabled -> "Silencioso (som desativado)"
        current == DestinationStore.SOUND_SILENT -> "Silencioso"
        current != null && current.endsWith("/${R.raw.desembarque_proxima_parada}") -> "Desembarque na próxima parada (padrão)"
        current != null && current.endsWith("/${R.raw.atencao_alerta_geografico}") -> "Atenção – Alerta Geográfico (padrão)"
        current != null -> RingtoneManager.getRingtone(this, Uri.parse(current))?.getTitle(this) ?: "Som personalizado"
        else -> "Som padrão de notificação"
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun AppScreen() {
        val appVersionName = packageManager.getPackageInfo(packageName, 0).versionName ?: "desconhecida"
        var destinations by remember { mutableStateOf(DestinationStore.load(this)) }
        var name by rememberSaveable { mutableStateOf("") }
        var place by rememberSaveable { mutableStateOf("") }
        var selectedDestinationIcon by rememberSaveable { mutableStateOf("📍") }
        var latitude by rememberSaveable { mutableStateOf("") }
        var longitude by rememberSaveable { mutableStateOf("") }
        var radius by rememberSaveable { mutableStateOf("300") }
        var transportType by rememberSaveable { mutableStateOf(TransportType.TRAIN) }
        var stopComment by rememberSaveable { mutableStateOf("") }
        var prefDialog by remember { mutableStateOf<String?>(null) }
        // Pop-up "O que deseja fazer?" ao abrir o app sem monitoramento ativo, e viagem rápida (destino único).
        var showStartChooser by rememberSaveable { mutableStateOf(false) }
        var startChooserHandled by rememberSaveable { mutableStateOf(false) }
        var showRoutePicker by remember { mutableStateOf(false) }
        var quickTrip by rememberSaveable { mutableStateOf(false) }
        var distanceAlert by rememberSaveable { mutableStateOf(TransportType.DEFAULT_BUS_DISTANCE_ALERT.toString()) }
        var message by rememberSaveable { mutableStateOf("Você está chegando ao destino") }
        var oneShot by rememberSaveable { mutableStateOf(false) }
        var entryMode by rememberSaveable { mutableStateOf("Único") }
        var itineraryName by rememberSaveable { mutableStateOf("") }
        var sound by remember { mutableStateOf(DestinationStore.soundEnabled(this)) }
        var trainSoundUri by remember { mutableStateOf(DestinationStore.alertSoundUri(this, AlertKind.TRAIN)) }
        var busRadiusSoundUri by remember { mutableStateOf(DestinationStore.alertSoundUri(this, AlertKind.BUS_RADIUS)) }
        var busDistanceSoundUri by remember { mutableStateOf(DestinationStore.alertSoundUri(this, AlertKind.BUS_DISTANCE)) }
        var soundPickerKind by remember { mutableStateOf(AlertKind.TRAIN) }
        var alertAudioOutput by remember { mutableStateOf(DestinationStore.alertAudioOutput(this)) }
        var alertVolume by remember { mutableFloatStateOf(DestinationStore.alertVolume(this)) }
        var alarmMode by remember { mutableStateOf(DestinationStore.alarmMode(this)) }
        var alertAudioMode by remember { mutableStateOf(DestinationStore.alertAudioMode(this)) }
        var alertAudioModeMenuExpanded by remember { mutableStateOf(false) }
        var alertMixMode by remember { mutableStateOf(DestinationStore.alertMixMode(this)) }
        var alertMixModeMenuExpanded by remember { mutableStateOf(false) }
        var monitoring by remember { mutableStateOf(DestinationStore.monitoringActive(this)) }
        var autoSkipToLaterStop by remember { mutableStateOf(DestinationStore.autoSkipToLaterStopEnabled(this)) }
        var skipInitialStop by remember { mutableStateOf(DestinationStore.skipInitialStop(this)) }
        var vibration by remember { mutableStateOf(DestinationStore.vibrationEnabled(this)) }
        var completionAudio by remember { mutableStateOf(DestinationStore.completionAudioEnabled(this)) }
        var displayMode by remember { mutableStateOf(DestinationStore.alertDisplayMode(this)) }
        var etaLead by remember { mutableStateOf(DestinationStore.etaAlertMinutes(this).toString()) }
        var locationIntervalSeconds by remember { mutableIntStateOf(DestinationStore.locationIntervalSeconds(this)) }
        var locationIntervalMenuExpanded by remember { mutableStateOf(false) }
        var batteryProfile by remember { mutableStateOf(DestinationStore.batteryProfile(this)) }
        var showRailLinesOnMap by remember { mutableStateOf(getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE).getBoolean(MapActivity.PREF_SHOW_RAIL_LINES, true)) }
        var showRailStationsOnMap by remember { mutableStateOf(getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE).getBoolean(MapActivity.PREF_SHOW_RAIL_STATIONS, true)) }
        var batteryProfileMenuExpanded by remember { mutableStateOf(false) }
        var activeItinerary by remember { mutableStateOf(DestinationStore.activeItinerary(this)) }
        var routeDirection by rememberSaveable { mutableStateOf(DestinationStore.routeDirection(this)) }
        var monitorMode by rememberSaveable { mutableStateOf(DestinationStore.monitorMode(this)) }
        var selectedDestinationId by rememberSaveable { mutableStateOf(DestinationStore.selectedDestinationId(this) ?: "") }
        var destinationMenuExpanded by remember { mutableStateOf(false) }
        var routeMenuExpanded by remember { mutableStateOf(false) }
        var dashboardRefresh by remember { mutableIntStateOf(0) }
        var status by remember { mutableStateOf("Monitoramento parado") }
        var showStopConfirm by remember { mutableStateOf(false) }
        LaunchedEffect(stopConfirmRequested) {
            if (stopConfirmRequested) {
                stopConfirmRequested = false
                intent?.removeExtra(LocationMonitorService.EXTRA_CONFIRM_STOP)
                if (DestinationStore.monitoringActive(this@MainActivity)) showStopConfirm = true
            }
        }
        var stationImportMessage by rememberSaveable { mutableStateOf("") }
        var stationResult by remember { mutableStateOf<StationNavigationResult?>(null) }
        var stationLocationStatus by rememberSaveable { mutableStateOf("Toque em Atualizar posição para consultar o GPS.") }
        var stationLoading by remember { mutableStateOf(false) }
        var confirmClearRailData by remember { mutableStateOf(false) }
        val overpassStationsQuery = """[out:json][timeout:60];
(
  nwr["railway"~"^(station|halt)$"]({{bbox}});
  nwr["public_transport"="station"]({{bbox}});
);
out center;"""
        val overpassRoutesQuery = """[out:json][timeout:90];
(
  relation["route"~"^(subway|train|light_rail)$"]({{bbox}});
);
out geom;"""
        var pendingImport by remember { mutableStateOf<List<Destination>?>(null) }
        var importReport by remember { mutableStateOf("") }
        var decodedAddresses by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
        var attemptedAddressIds by remember { mutableStateOf<Set<String>>(emptySet()) }
        var pendingDelete by remember { mutableStateOf<Destination?>(null) }
        var pendingBackup by remember { mutableStateOf<org.json.JSONObject?>(null) }
        var pendingEdit by remember { mutableStateOf<Destination?>(null) }
        var pendingRenameRoute by remember { mutableStateOf<String?>(null) }
        var renameRouteName by rememberSaveable { mutableStateOf("") }
        var routeIcons by remember { mutableStateOf(DestinationStore.loadItineraryIcons(this)) }
        var pendingRouteIcon by remember { mutableStateOf<String?>(null) }
        val routeIconChoices = listOf("🗺️", "🚗", "🚙", "🚕", "🚌", "🚐", "🚚", "🏍️", "🚲", "🚶", "✈️", "🚆", "🚢", "🏖️", "🏕️", "🏨", "🏠", "💼", "🛒", "📦", "⭐", "❤️", "📍", "🎯")

        fun setRouteIcon(routeName: String, icon: String) {
            val updated = routeIcons.toMutableMap().apply { put(routeName, icon) }
            routeIcons = updated
            DestinationStore.saveItineraryIcons(this, updated)
        }
        var selectedSection by rememberSaveable { mutableStateOf("Início") }
        var expandedRouteCards by rememberSaveable { mutableStateOf(setOf<String>()) }
        var expandedDestinationCards by rememberSaveable { mutableStateOf(setOf<String>()) }
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        LaunchedEffect(selectedSection) {
            if (selectedSection == "Preferências") {
                val mapPrefs = getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE)
                showRailLinesOnMap = mapPrefs.getBoolean(MapActivity.PREF_SHOW_RAIL_LINES, true)
                showRailStationsOnMap = mapPrefs.getBoolean(MapActivity.PREF_SHOW_RAIL_STATIONS, true)
            }
        }

        fun save(list: List<Destination>) {
            destinations = list
            DestinationStore.save(this, list)
        }

        fun moveItineraryStop(itineraryName: String, destinationId: String, direction: Int) {
            val routeStops = destinations.filter { it.itineraryName == itineraryName }
            val currentIndex = routeStops.indexOfFirst { it.id == destinationId }
            val targetIndex = currentIndex + direction
            if (currentIndex !in routeStops.indices || targetIndex !in routeStops.indices) return

            // Reorder only the selected route's stops, preserving the positions of all other destinations.
            val reorderedStops = routeStops.toMutableList()
            val moved = reorderedStops.removeAt(currentIndex)
            reorderedStops.add(targetIndex, moved)
            var routeIndex = 0
            val reorderedAll = destinations.map { destination ->
                if (destination.itineraryName == itineraryName) reorderedStops[routeIndex++] else destination
            }
            save(reorderedAll)
            status = "Ordem das paradas de $itineraryName atualizada"
        }

        // "Voltar" volta ao Início (ou fecha o menu) em vez de sair do app.
        BackHandler(enabled = drawerState.isOpen || selectedSection != "Início") {
            if (drawerState.isOpen) scope.launch { drawerState.close() } else selectedSection = "Início"
        }

        // Mantém a tela sincronizada com o estado real do serviço e com alterações feitas por ele
        // (ex.: destino de alerta único desativado após disparar).
        DisposableEffect(Unit) {
            val prefs = getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE)
            val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
                when (key) {
                    DestinationStore.KEY_MONITORING -> monitoring = DestinationStore.monitoringActive(this@MainActivity)
                    DestinationStore.KEY -> destinations = DestinationStore.load(this@MainActivity)
                    DestinationStore.KEY_DASH_TARGET, DestinationStore.KEY_DASH_NEXT, DestinationStore.KEY_DASH_DISTANCE,
                    DestinationStore.KEY_DASH_ETA, DestinationStore.KEY_DASH_ETA_MIN, DestinationStore.KEY_DASH_ETA_MAX,
                    DestinationStore.KEY_DASH_ETA_CONFIDENCE, DestinationStore.KEY_DASH_DISTANCE_MODE, DestinationStore.KEY_LOCATION_INTERVAL_SECONDS,
                    DestinationStore.KEY_STATION_ROUTE, DestinationStore.KEY_STATION_OPERATOR,
                    DestinationStore.KEY_STATION_PREVIOUS, DestinationStore.KEY_STATION_CURRENT,
                    DestinationStore.KEY_STATION_NEXT, DestinationStore.KEY_STATION_NEXT_DISTANCE, DestinationStore.KEY_STATION_UPDATED -> dashboardRefresh++
                }
            }
            prefs.registerOnSharedPreferenceChangeListener(listener)
            monitoring = DestinationStore.monitoringActive(this@MainActivity)
            destinations = DestinationStore.load(this@MainActivity)
            onDispose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
        }

        fun showOnMap(items: List<Destination>) {
            if (items.isEmpty()) {
                status = "Não há destinos para mostrar no mapa"
                return
            }
            // Só os ids vão na Intent (limite ~1 MB); o mapa lê os dados do DestinationStore.
            startActivity(
                Intent(this@MainActivity, MapActivity::class.java)
                    .putStringArrayListExtra(MapActivity.EXTRA_DESTINATION_IDS, ArrayList(items.map { it.id }))
            )
        }

        fun startMonitoring() {
            val chosen = if (monitorMode == "individual") destinations.firstOrNull { it.id == selectedDestinationId && it.enabled } else null
            val routeStops = DestinationStore.orderedItineraryStops(this@MainActivity, destinations, activeItinerary)
            if (monitorMode == "individual" && chosen == null) {
                status = "Selecione um destino único habilitado antes de iniciar"
                return
            }
            if (monitorMode == "route" && (activeItinerary.isNullOrBlank() || routeStops.isEmpty())) {
                status = "Selecione um roteiro com paradas habilitadas antes de iniciar"
                return
            }
            DestinationStore.setMonitorSelection(this@MainActivity, monitorMode, chosen?.id, if (monitorMode == "route") activeItinerary else null)
            if (monitorMode == "route") {
                // O índice é relativo ao sentido escolhido (ida ou volta); pular a parada inicial
                // significa começar pela segunda parada da sequência exibida.
                DestinationStore.setItineraryIndex(this@MainActivity, if (skipInitialStop && routeStops.size > 1) 1 else 0)
            }
            // Evita exibir a sequência ferroviária da sessão anterior enquanto aguardamos o primeiro GPS.
            DestinationStore.saveStationNavigation(this@MainActivity, null)
            ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, LocationMonitorService::class.java))
            monitoring = true
            val warnings = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                    this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                warnings += "as notificações estão bloqueadas (o aviso visual não aparecerá)"
            }
            if (ContextCompat.checkSelfPermission(
                    this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                warnings += "só há localização aproximada (raios pequenos podem falhar)"
            }
            status = if (warnings.isEmpty()) "Monitoramento iniciado"
                     else "Monitoramento iniciado, mas " + warnings.joinToString("; ")
        }

        val mapPointPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                latitude = result.data!!.getDoubleExtra(MapActivity.EXTRA_SELECTED_LAT, 0.0).toString()
                longitude = result.data!!.getDoubleExtra(MapActivity.EXTRA_SELECTED_LON, 0.0).toString()
                if (name.isBlank()) name = "Ponto selecionado no mapa"
                place = "Ponto selecionado no mapa"
                status = "Ponto selecionado. Informe um nome e salve o destino."
            }
        }

        val soundPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val uri = result.data!!.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                val kind = soundPickerKind
                DestinationStore.setAlertSoundUri(this@MainActivity, kind, uri?.toString())
                val stored = DestinationStore.alertSoundUri(this@MainActivity, kind)
                when (kind) {
                    AlertKind.TRAIN -> trainSoundUri = stored
                    AlertKind.BUS_RADIUS -> busRadiusSoundUri = stored
                    AlertKind.BUS_DISTANCE -> busDistanceSoundUri = stored
                }
                val target = when (kind) {
                    AlertKind.TRAIN -> "trem/metrô"
                    AlertKind.BUS_RADIUS -> "ônibus (raio)"
                    AlertKind.BUS_DISTANCE -> "ônibus (distância)"
                }
                status = if (uri == null) "Som de $target: silencioso" else "Som de $target atualizado"
                recreateAlertChannel()
            }
        }

        val backupExportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
            if (uri != null) {
                runCatching {
                    contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(AppBackup.create(this@MainActivity)) }
                        ?: error("Não foi possível gravar o arquivo escolhido.")
                }.onSuccess { status = "Backup criado com sucesso." }
                    .onFailure { status = "Falha ao criar backup: ${it.message ?: "erro desconhecido"}" }
            }
        }

        val backupImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                runCatching {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("Não foi possível ler o arquivo escolhido.")
                    AppBackup.validate(raw)
                }.onSuccess { pendingBackup = it }
                    .onFailure { status = "Backup inválido: ${it.message ?: "arquivo não reconhecido"}" }
            }
        }

        val csvPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    contentResolver.openInputStream(uri)?.use { stream ->
                        val result = CsvImporter.parse(stream, destinations)
                        pendingImport = result.imported
                        importReport = buildString {
                            append("Prontos para importar: ${result.imported.size}\n")
                            append("Duplicados ignorados: ${result.duplicates}\n")
                            append("Erros: ${result.errors.size}")
                            if (result.errors.isNotEmpty()) append("\n\n" + result.errors.take(15).joinToString("\n"))
                        }
                        if (result.imported.isEmpty()) pendingImport = null
                    } ?: run { importReport = "Não foi possível abrir o arquivo." }
                } catch (e: Exception) {
                    importReport = "Falha ao ler CSV: ${e.message ?: "erro desconhecido"}"
                    pendingImport = null
                }
            }
        }

        val stationGeoJsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("Não foi possível abrir o arquivo selecionado.")
                    val count = StationNavigationStore.importGeoJson(this@MainActivity, raw, true)
                    stationImportMessage = "$count estações importadas. Agora importe o arquivo das linhas/rotas."
                    stationResult = null
                } catch (e: Exception) {
                    stationImportMessage = "Falha ao importar estações: ${e.message ?: "arquivo inválido"}"
                }
            }
        }

        val railRoutesGeoJsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("Não foi possível abrir o arquivo selecionado.")
                    val count = StationNavigationStore.importGeoJson(this@MainActivity, raw, false)
                    stationImportMessage = "$count linhas/rotas importadas. Os dados ficam salvos no aparelho para uso offline."
                    stationResult = null
                } catch (e: Exception) {
                    stationImportMessage = "Falha ao importar linhas/rotas: ${e.message ?: "arquivo inválido"}"
                }
            }
        }

        fun refreshStationPosition() {
            if (!StationNavigationStore.hasStations(this@MainActivity) || !StationNavigationStore.hasRoutes(this@MainActivity)) {
                stationLocationStatus = "Importe primeiro os GeoJSON de estações e de linhas/rotas."
                stationResult = null
                return
            }
            val fine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (!fine && !coarse) {
                stationLocationStatus = "Permissão de localização necessária. Autorize o acesso e tente novamente."
                return
            }
            stationLoading = true
            stationLocationStatus = "Obtendo posição GPS…"
            val token = CancellationTokenSource()
            try {
                LocationServices.getFusedLocationProviderClient(this@MainActivity)
                    .getCurrentLocation(if (fine) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY, token.token)
                    .addOnSuccessListener { loc: Location? ->
                        stationLoading = false
                        if (loc == null) {
                            stationLocationStatus = "Posição indisponível. Verifique se a localização está ligada e tente novamente."
                            stationResult = null
                        } else {
                            val result = StationNavigationStore.locate(this@MainActivity, loc)
                            stationResult = result
                            stationLocationStatus = if (result == null) {
                                "Não foi possível associar sua posição a uma linha/estação com confiança. Isso pode ocorrer fora da ferrovia, em túneis ou com dados incompletos."
                            } else {
                                "GPS atualizado • precisão aproximada de ${loc.accuracy.toInt()} m"
                            }
                        }
                    }
                    .addOnFailureListener { e ->
                        stationLoading = false
                        stationLocationStatus = "Falha ao obter GPS: ${e.message ?: "erro desconhecido"}"
                    }
            } catch (e: SecurityException) {
                stationLoading = false
                stationLocationStatus = "Permissão de localização não concedida."
            }
        }

        val testNotificationPermissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                showTestNotification()
                status = "Notificação de teste enviada"
            } else status = "Permissão de notificações negada pelo Android"
        }

        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { grants ->
            val fine = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true
            val coarse = grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
            if (fine || coarse) startMonitoring()
            else status = "Permissão de localização negada"
        }

        // Inicia o monitoramento pedindo antes as permissões que faltarem (usado pela viagem rápida).
        fun requestStartMonitoring() {
            val permissions = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
            val missing = permissions.filter {
                ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isEmpty()) startMonitoring() else permissionLauncher.launch(missing.toTypedArray())
        }

        // Ao abrir o app (depois da tela de abertura) sem monitoramento ativo, pergunta o que fazer.
        LaunchedEffect(Unit) {
            if (!startChooserHandled) {
                startChooserHandled = true
                delay(1_800)
                if (!DestinationStore.monitoringActive(this@MainActivity) && !stopConfirmRequested) showStartChooser = true
            }
        }
        // A viagem rápida só vale enquanto o usuário está no formulário de destino.
        LaunchedEffect(selectedSection) {
            if (selectedSection != "Adicionar destino") quickTrip = false
        }

        // Identifica endereços automaticamente quando a lista de destinos é aberta.
        // A consulta ocorre fora da thread principal para não congelar a interface.
        LaunchedEffect(destinations, selectedSection) {
            if (selectedSection == "Destinos cadastrados") {
                val pending = destinations.filter {
                    !decodedAddresses.containsKey(it.id) && !attemptedAddressIds.contains(it.id)
                }
                for (destination in pending) {
                    val address = withContext(Dispatchers.IO) {
                        try {
                            val geocoder = Geocoder(this@MainActivity, Locale("pt", "BR"))
                            @Suppress("DEPRECATION")
                            geocoder.getFromLocation(destination.latitude, destination.longitude, 1)
                                ?.firstOrNull()?.getAddressLine(0)
                        } catch (_: Exception) { null }
                    }
                    attemptedAddressIds = attemptedAddressIds + destination.id
                    if (!address.isNullOrBlank()) {
                        decodedAddresses = decodedAddresses + (destination.id to address)
                    }
                }
            }
        }

        // Identidade visual centralizada em ui/Theme.kt (AgTheme).
        val brandNavy = AgColors.OnSurface

        AgTheme {
            if (showStartChooser) {
                AlertDialog(
                    onDismissRequest = { showStartChooser = false },
                    title = { Text("O que deseja fazer?") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = {
                                    showStartChooser = false
                                    quickTrip = true
                                    entryMode = "Único"
                                    selectedSection = "Adicionar destino"
                                },
                                shape = RoundedCornerShape(16.dp),
                                contentPadding = PaddingValues(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("Destino único", style = MaterialTheme.typography.titleMedium)
                                    Text("Viagem rápida: informe o destino e o monitoramento começa na hora.", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            OutlinedButton(
                                onClick = {
                                    showStartChooser = false
                                    val routeNames = destinations.mapNotNull { it.itineraryName?.takeIf { n -> n.isNotBlank() } }.distinct()
                                    if (routeNames.isEmpty()) {
                                        entryMode = "Roteiro"
                                        selectedSection = "Adicionar destino"
                                        status = "Você ainda não tem roteiros: cadastre as paradas para começar"
                                    } else {
                                        showRoutePicker = true
                                    }
                                },
                                shape = RoundedCornerShape(16.dp),
                                contentPadding = PaddingValues(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("Roteiro", style = MaterialTheme.typography.titleMedium)
                                    Text("Siga as paradas de um roteiro que você já cadastrou.", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { showStartChooser = false }) { Text("Continuar para o app") } }
                )
            }
            if (showRoutePicker) {
                val routeNames = destinations.mapNotNull { it.itineraryName?.takeIf { n -> n.isNotBlank() } }.distinct()
                SettingsChoiceDialog(
                    title = "Escolha o roteiro",
                    options = routeNames.map { it to it },
                    selected = activeItinerary ?: "",
                    message = "Depois de escolher, toque em iniciar no Início para começar o monitoramento.",
                    onSelect = { routeName ->
                        activeItinerary = routeName
                        DestinationStore.setActiveItinerary(this@MainActivity, routeName)
                        monitorMode = "route"
                        selectedSection = "Início"
                        showRoutePicker = false
                    },
                    onDismiss = { showRoutePicker = false }
                )
            }
            if (showStopConfirm) {
                AlertDialog(
                    onDismissRequest = { showStopConfirm = false },
                    title = { Text("Parar o monitoramento?") },
                    text = { Text("Você deixará de receber os alertas de proximidade até iniciar o monitoramento novamente.") },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                stopService(Intent(this@MainActivity, LocationMonitorService::class.java))
                                DestinationStore.setMonitoringActive(this@MainActivity, false)
                                monitoring = false
                                status = "Monitoramento parado"
                                showStopConfirm = false
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) { Text("Parar monitoramento") }
                    },
                    dismissButton = { TextButton(onClick = { showStopConfirm = false }) { Text("Continuar monitorando") } }
                )
            }
            pendingBackup?.let { backup ->
                AlertDialog(
                    onDismissRequest = { pendingBackup = null },
                    title = { Text("Restaurar backup?") },
                    text = { Text("Isso substituirá os destinos, roteiros, preferências e dados ferroviários deste aparelho pelos dados do backup. O monitoramento ficará parado após a restauração.") },
                    confirmButton = {
                        TextButton(onClick = {
                            runCatching {
                                DestinationStore.setMonitoringActive(this@MainActivity, false)
                                stopService(Intent(this@MainActivity, LocationMonitorService::class.java))
                                AppBackup.restore(this@MainActivity, backup)
                            }.onSuccess {
                                pendingBackup = null
                                recreate()
                            }.onFailure {
                                pendingBackup = null
                                status = "Falha ao restaurar backup: ${it.message ?: "erro desconhecido"}"
                            }
                        }) { Text("Restaurar e substituir") }
                    },
                    dismissButton = { TextButton(onClick = { pendingBackup = null }) { Text("Cancelar") } }
                )
            }
            if (confirmClearRailData) {
                AlertDialog(
                    onDismissRequest = { confirmClearRailData = false },
                    title = { Text("Apagar todos os dados ferroviários?") },
                    text = { Text("Isso excluirá todas as estações e linhas/trilhos importados deste aparelho e limpará a estação atual estimada. Seus destinos e roteiros de alerta não serão apagados.") },
                    confirmButton = {
                        TextButton(onClick = {
                            StationNavigationStore.clearAll(this@MainActivity)
                            stationResult = null
                            stationImportMessage = "Todos os dados de estações e linhas/trilhos foram apagados."
                            stationLocationStatus = "Importe novamente os arquivos GeoJSON para usar a navegação ferroviária."
                            confirmClearRailData = false
                            dashboardRefresh++
                        }) { Text("Apagar tudo") }
                    },
                    dismissButton = { TextButton(onClick = { confirmClearRailData = false }) { Text("Cancelar") } }
                )
            }
            pendingEdit?.let { destination ->
                var editName by remember(destination.id) { mutableStateOf(destination.name) }
                var editLat by remember(destination.id) { mutableStateOf(destination.latitude.toString()) }
                var editLon by remember(destination.id) { mutableStateOf(destination.longitude.toString()) }
                var editLocation by remember(destination.id) { mutableStateOf(destination.locationLabel ?: decodedAddresses[destination.id].orEmpty()) }
                var editRadius by remember(destination.id) { mutableStateOf(destination.radiusMeters.toString()) }
                var editType by remember(destination.id) { mutableStateOf(destination.transportType) }
                var editDistanceAlert by remember(destination.id) { mutableStateOf(destination.distanceAlertMeters.toString()) }
                var editMessage by remember(destination.id) { mutableStateOf(destination.message) }
                var editComment by remember(destination.id) { mutableStateOf(destination.comment) }
                var editRoute by remember(destination.id) { mutableStateOf(destination.itineraryName.orEmpty()) }
                var editIcon by remember(destination.id) { mutableStateOf(destination.icon) }
                var editCoordinatesExpanded by remember(destination.id) { mutableStateOf(false) }
                AlertDialog(
                    onDismissRequest = { pendingEdit = null },
                    title = { Text("Editar destino") },
                    text = {
                        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(editName, { editName = it }, label = { Text("Nome do destino") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(editLocation, { editLocation = it }, label = { Text("Endereço ou identificação do local") }, placeholder = { Text("Ex.: Entrada principal, Rua das Flores...") }, modifier = Modifier.fillMaxWidth())
                            Text("Ícone do destino", style = MaterialTheme.typography.labelLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                                listOf("📍", "🏠", "💼", "⛽", "🛒", "🏥", "🏫", "🍽️", "🅿️", "🚉", "🏖️", "⭐").forEach { iconChoice ->
                                    FilterChip(selected = editIcon == iconChoice, onClick = { editIcon = iconChoice }, label = { Text(iconChoice) })
                                }
                            }
                            OutlinedButton(onClick = {
                                if (editLocation.isBlank()) status = "Informe um endereço ou local para pesquisar"
                                else {
                                    val query = editLocation.trim()
                                    status = "Procurando endereço…"
                                    scope.launch {
                                        val outcome = withContext(Dispatchers.IO) {
                                            runCatching {
                                                @Suppress("DEPRECATION")
                                                Geocoder(this@MainActivity, Locale("pt", "BR")).getFromLocationName(query, 1)?.firstOrNull()
                                            }
                                        }
                                        val found = outcome.getOrNull()
                                        if (found != null) {
                                            editLat = found.latitude.toString()
                                            editLon = found.longitude.toString()
                                            status = "Endereço localizado; salve para aplicar as coordenadas"
                                        } else status = "Endereço não encontrado. Confira o texto e tente novamente."
                                    }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Buscar endereço e atualizar local") }
                            OutlinedButton(onClick = { editCoordinatesExpanded = !editCoordinatesExpanded }, modifier = Modifier.fillMaxWidth()) { Text(if (editCoordinatesExpanded) "Ocultar coordenadas avançadas" else "Alterar coordenadas manualmente") }
                            if (editCoordinatesExpanded) {
                                OutlinedTextField(editLat, { editLat = it }, label = { Text("Latitude") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(editLon, { editLon = it }, label = { Text("Longitude") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                            Text("Tipo de transporte", style = MaterialTheme.typography.labelLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                listOf(TransportType.TRAIN to "🚆 Trem/Metrô", TransportType.BUS to "🚌 Ônibus").forEach { (type, label) ->
                                    FilterChip(
                                        selected = editType == type,
                                        onClick = {
                                            if (editType != type) {
                                                editType = type
                                                editRadius = TransportType.defaultRadius(type).toString()
                                            }
                                        },
                                        label = { Text(label) }
                                    )
                                }
                            }
                            OutlinedTextField(editRadius, { editRadius = it }, label = { Text("Raio de alerta (m)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            if (editType == TransportType.BUS) {
                                OutlinedTextField(editDistanceAlert, { editDistanceAlert = it }, label = { Text("Aviso por distância (m)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                            OutlinedTextField(editMessage, { editMessage = it }, label = { Text("Mensagem do alerta") })
                            OutlinedTextField(
                                editComment, { editComment = it.take(Destination.COMMENT_MAX_LENGTH) },
                                label = { Text("Comentário (opcional)") },
                                supportingText = { Text("${editComment.length}/${Destination.COMMENT_MAX_LENGTH}") },
                                singleLine = true
                            )
                            OutlinedTextField(editRoute, { editRoute = it }, label = { Text("Nome do roteiro (opcional)") }, singleLine = true)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val lat = editLat.replace(',', '.').toDoubleOrNull()
                            val lon = editLon.replace(',', '.').toDoubleOrNull()
                            val rad = editRadius.toIntOrNull()
                            val editDist = editDistanceAlert.trim().toIntOrNull()
                            if (editName.isNotBlank() && lat != null && lat in -90.0..90.0 && lon != null && lon in -180.0..180.0 && rad != null && rad > 0) {
                                if (editType == TransportType.BUS && (editDist == null || editDist <= rad || editDist > 10000)) {
                                    status = "A distância do aviso do ônibus deve ser maior que o raio (até 10000 m)"
                                } else {
                                    save(destinations.map { d -> if (d.id == destination.id) d.copy(name = editName.trim(), latitude = lat, longitude = lon, locationLabel = editLocation.trim().takeIf { it.isNotEmpty() }, icon = editIcon, radiusMeters = rad, message = editMessage, itineraryName = editRoute.trim().takeIf { it.isNotEmpty() }, transportType = editType, distanceAlertMeters = editDist ?: d.distanceAlertMeters, comment = editComment.trim()) else d })
                                    pendingEdit = null
                                    status = "Destino atualizado"
                                }
                            } else status = "Confira nome, coordenadas e raio antes de salvar"
                        }) { Text("Salvar") }
                    },
                    dismissButton = { TextButton(onClick = { pendingEdit = null }) { Text("Cancelar") } }
                )
            }
            pendingRouteIcon?.let { routeName ->
                AlertDialog(
                    onDismissRequest = { pendingRouteIcon = null },
                    title = { Text("Ícone do roteiro") },
                    text = {
                        Column(
                            modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Escolha um ícone para identificar ‘$routeName’.")
                            routeIconChoices.chunked(4).forEach { choices ->
                                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
                                    choices.forEach { choice ->
                                        FilterChip(
                                            selected = (routeIcons[routeName] ?: "🗺️") == choice,
                                            onClick = { setRouteIcon(routeName, choice) },
                                            label = { Text(choice) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { pendingRouteIcon = null }) { Text("Concluir") } },
                    dismissButton = { TextButton(onClick = { setRouteIcon(routeName, "🗺️"); pendingRouteIcon = null }) { Text("Restaurar padrão") } }
                )
            }
            pendingRenameRoute?.let { oldRouteName ->
                AlertDialog(
                    onDismissRequest = { pendingRenameRoute = null },
                    title = { Text("Renomear roteiro") },
                    text = {
                        OutlinedTextField(
                            value = renameRouteName,
                            onValueChange = { renameRouteName = it },
                            label = { Text("Nome do roteiro") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val newRouteName = renameRouteName.trim()
                            val nameAlreadyUsed = destinations.any {
                                !it.itineraryName.isNullOrBlank() &&
                                    it.itineraryName.equals(newRouteName, ignoreCase = true) &&
                                    it.itineraryName != oldRouteName
                            }
                            when {
                                newRouteName.isBlank() -> status = "Informe um nome para o roteiro"
                                newRouteName == oldRouteName -> pendingRenameRoute = null
                                nameAlreadyUsed -> status = "Já existe um roteiro com esse nome"
                                else -> {
                                    save(destinations.map { destination ->
                                        if (destination.itineraryName == oldRouteName) destination.copy(itineraryName = newRouteName)
                                        else destination
                                    })
                                    if (activeItinerary == oldRouteName) {
                                        DestinationStore.setActiveItinerary(this@MainActivity, newRouteName)
                                        activeItinerary = newRouteName
                                    }
                                    expandedRouteCards = expandedRouteCards - "main:$oldRouteName" + "main:$newRouteName"
                                    expandedDestinationCards = expandedDestinationCards - "dest-route:$oldRouteName" + "dest-route:$newRouteName"
                                    routeIcons[oldRouteName]?.let { oldIcon ->
                                        val updatedIcons = routeIcons.toMutableMap().apply {
                                            remove(oldRouteName)
                                            put(newRouteName, oldIcon)
                                        }
                                        routeIcons = updatedIcons
                                        DestinationStore.saveItineraryIcons(this@MainActivity, updatedIcons)
                                    }
                                    status = "Roteiro renomeado para: $newRouteName"
                                    pendingRenameRoute = null
                                }
                            }
                        }) { Text("Salvar") }
                    },
                    dismissButton = {
                        TextButton(onClick = { pendingRenameRoute = null }) { Text("Cancelar") }
                    }
                )
            }
            pendingDelete?.let { destination ->
                AlertDialog(
                    onDismissRequest = { pendingDelete = null },
                    title = { Text("Confirmar exclusão") },
                    text = { Text("Tem certeza de que deseja excluir \"${destination.name}\"${destination.itineraryName?.let { " do roteiro $it" } ?: ""}? Esta ação não pode ser desfeita.") },
                    confirmButton = {
                        TextButton(onClick = {
                            save(destinations.filterNot { it.id == destination.id })
                            pendingDelete = null
                            status = "Destino excluído"
                        }) { Text("Excluir") }
                    },
                    dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancelar") } }
                )
            }
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
ModalDrawerSheet(
                        drawerContainerColor = MaterialTheme.colorScheme.surface,
                        drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp)
                    ) {
                        DrawerHeader(versionName = appVersionName)
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Spacer(Modifier.height(8.dp))
                        listOf("Início", "Adicionar destino", "Destinos cadastrados", "Roteiros", "Estações", "Preferências", "Ajuda", "Sobre").forEach { section ->
                            val iconRes = when (section) {
                                "Início" -> R.drawable.ic_ui_home
                                "Adicionar destino" -> R.drawable.ic_ui_add
                                "Destinos cadastrados" -> R.drawable.ic_ui_pin
                                "Roteiros" -> R.drawable.ic_ui_route
                                "Estações" -> R.drawable.ic_ui_train
                                "Preferências" -> R.drawable.ic_ui_settings
                                "Ajuda" -> R.drawable.ic_ui_help
                                else -> R.drawable.ic_ui_info
                            }
                            NavigationDrawerItem(
                                icon = { AgIcon(iconRes) },
                                label = { Text(section, style = MaterialTheme.typography.labelLarge) },
                                selected = selectedSection == section,
                                onClick = {
                                    selectedSection = section
                                    scope.launch { drawerState.close() }
                                },
                                shape = RoundedCornerShape(16.dp),
                                colors = NavigationDrawerItemDefaults.colors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    unselectedContainerColor = Color.Transparent
                                ),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            ) {
            Scaffold(topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = brandNavy,
                        navigationIconContentColor = brandNavy
                    ),
                    title = {
                        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                            Text(selectedSection, style = MaterialTheme.typography.titleLarge)
                            Text("ALERTA GEOGRÁFICO", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Abrir menu")
                        }
                    },
                    actions = {
                        if (monitoring) StatusPill(active = true, modifier = Modifier.padding(end = 12.dp))
                    }
                )
            }) { padding ->
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (selectedSection == "Início") item {
                        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                    val dashUpdateTick = dashboardRefresh
                                    val dashPrefs = DestinationStore.dashboard(this@MainActivity)
                                    val dashTarget = dashPrefs.getString(DestinationStore.KEY_DASH_TARGET, null)
                                    val dashNext = dashPrefs.getString(DestinationStore.KEY_DASH_NEXT, "—") ?: "—"
                                    val dashDistance = dashPrefs.getInt(DestinationStore.KEY_DASH_DISTANCE, -1)
                                    val dashEta = dashPrefs.getInt(DestinationStore.KEY_DASH_ETA, -1)
                                    val dashEtaMin = dashPrefs.getInt(DestinationStore.KEY_DASH_ETA_MIN, dashEta)
                                    val dashEtaMax = dashPrefs.getInt(DestinationStore.KEY_DASH_ETA_MAX, dashEta)
                                    val dashEtaConfidence = dashPrefs.getString(DestinationStore.KEY_DASH_ETA_CONFIDENCE, "normal") ?: "normal"
                                    val dashDistanceMode = dashPrefs.getString(DestinationStore.KEY_DASH_DISTANCE_MODE, "straight") ?: "straight"
                                    val dashRouteProgress = dashPrefs.getFloat(DestinationStore.KEY_DASH_ROUTE_PROGRESS, 0f).coerceIn(0f, 1f)
                                    val dashTotalDistance = dashPrefs.getInt(DestinationStore.KEY_DASH_TOTAL_DISTANCE, -1)
                                    val dashTotalEtaMin = dashPrefs.getInt(DestinationStore.KEY_DASH_TOTAL_ETA_MIN, -1)
                                    val dashTotalEtaMax = dashPrefs.getInt(DestinationStore.KEY_DASH_TOTAL_ETA_MAX, -1)
                                    val etaText = when {
                                        !monitoring -> "—"
                                        monitorMode == "route" && dashNext == "Roteiro concluído" -> "roteiro concluído"
                                        dashEtaMin == 0 && dashEtaMax == 0 -> "dentro do raio da próxima parada"
                                        dashEtaMin > 0 && dashEtaMax >= dashEtaMin -> "${formatEtaMinutes(dashEtaMin)}–${formatEtaMinutes(dashEtaMax)}"
                                        else -> "aguardando dados GPS válidos"
                                    }
                                    val etaStatusText = when {
                                        monitorMode == "route" && dashNext == "Roteiro concluído" -> "Todas as paradas do roteiro foram concluídas."
                                        dashEtaConfidence == "paused" -> "Pausa breve — mantendo a última estimativa"
                                        dashEtaConfidence == "low_confidence" -> "Baixa confiança — localização imprecisa ou desatualizada"
                                        dashEtaConfidence == "unavailable" -> "Estimativa indisponível — aguardando GPS confiável"
                                        dashDistanceMode == "rail" -> "Distância calculada pela malha ferroviária importada do OpenStreetMap; o tempo continua sendo uma estimativa."
                                        else -> "Sem caminho ferroviário confiável entre os pontos; distância em linha reta."
                                    }
                                    val stationPrefs = DestinationStore.dashboard(this@MainActivity)
                                    val stationRouteName = stationPrefs.getString(DestinationStore.KEY_STATION_ROUTE, null)
                                    val stationOperator = stationPrefs.getString(DestinationStore.KEY_STATION_OPERATOR, null)
                                    val stationPrevious = stationPrefs.getString(DestinationStore.KEY_STATION_PREVIOUS, null)
                                    val stationCurrent = stationPrefs.getString(DestinationStore.KEY_STATION_CURRENT, null)
                                    val stationNext = stationPrefs.getString(DestinationStore.KEY_STATION_NEXT, null)
                            fun stationMessage(isMonitoring: Boolean, current: String?): String? = when {
                                !isMonitoring -> "Inicie o monitoramento para estimar as estações pela posição GPS."
                                current.isNullOrBlank() ->
                                    if (!StationNavigationStore.hasStations(this@MainActivity) || !StationNavigationStore.hasRoutes(this@MainActivity))
                                        "Importe os GeoJSON de estações e linhas na seção Estações para ativar esta identificação."
                                    else "Identificando a linha e as estações pela posição GPS…"
                                else -> null
                            }
                            val toggleMonitoring: () -> Unit = {
                                            if (monitoring || DestinationStore.monitoringActive(this@MainActivity)) {
                                                showStopConfirm = true
                                            } else {
                                                val permissions = mutableListOf(
                                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                                )
                                                if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
                                                val missing = permissions.filter {
                                                    ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
                                                }
                                                if (missing.isEmpty()) startMonitoring()
                                                else permissionLauncher.launch(missing.toTypedArray())
                                            }
                            }
                            val routeConcluded = monitorMode == "route" && dashNext == "Roteiro concluído"
                            val heroTitle = when {
                                !monitoring -> "Nenhum monitoramento ativo"
                                monitorMode == "route" -> dashNext
                                else -> dashTarget ?: "Aguardando localização"
                            }
                            val heroOverline = when {
                                !monitoring -> "Pronto para iniciar"
                                monitorMode == "route" -> "Próxima parada" + (activeItinerary?.let { " · $it" } ?: "")
                                else -> "Destino ativo"
                            }
                            val hasDistance = monitoring && dashDistance >= 0
                            val distanceValue = if (!hasDistance) "—" else if (dashDistance >= 1000) String.format(Locale.getDefault(), "%.1f", dashDistance / 1000.0) else "$dashDistance"
                            val distanceUnit = if (!hasDistance) "" else if (dashDistance >= 1000) "km" else "m"
                            val distanceCaption = when {
                                !hasDistance -> "Distância restante"
                                dashDistanceMode == "rail" -> "pela malha ferroviária"
                                monitorMode == "route" -> "até a próxima parada"
                                else -> "em linha reta"
                            }
                            val etaValue = when {
                                !monitoring -> "—"
                                routeConcluded -> "Concluído"
                                dashEtaMin == 0 && dashEtaMax == 0 -> "No raio"
                                dashEtaMin > 0 && dashEtaMax >= dashEtaMin -> "${formatEtaMinutes(dashEtaMin)}–${formatEtaMinutes(dashEtaMax)}"
                                else -> "—"
                            }
                            val etaCaption = when {
                                !monitoring || routeConcluded || etaValue == "No raio" -> ""
                                etaValue == "—" -> "aguardando GPS"
                                else -> "estimativa por GPS"
                            }
                            val showRouteProgress = monitoring && monitorMode == "route" && !routeConcluded
                            MonitoringHero(
                                monitoring = monitoring,
                                overline = heroOverline,
                                title = heroTitle,
                                distanceValue = distanceValue,
                                distanceUnit = distanceUnit,
                                distanceCaption = distanceCaption,
                                etaValue = etaValue,
                                etaCaption = etaCaption,
                                progress = if (showRouteProgress) dashRouteProgress else null,
                                progressCaption = if (showRouteProgress) "Progresso do roteiro · ${(dashRouteProgress * 100).toInt()}%" else null,
                                finalStopDetail = if (showRouteProgress && dashTotalDistance > 0) {
                                    val dist = if (dashTotalDistance >= 1000) String.format(Locale.getDefault(), "%.1f km", dashTotalDistance / 1000.0) else "$dashTotalDistance m"
                                    val time = when {
                                        dashTotalEtaMin <= 0 -> ""
                                        dashTotalEtaMax > dashTotalEtaMin -> " · ≈ ${formatEtaMinutes(dashTotalEtaMin)}–${formatEtaMinutes(dashTotalEtaMax)}"
                                        else -> " · ≈ ${formatEtaMinutes(dashTotalEtaMin)}"
                                    }
                                    "Faltam $dist$time até o fim"
                                } else null,
                                finalStop = if (showRouteProgress) DestinationStore.orderedItineraryStops(this@MainActivity, destinations, activeItinerary).lastOrNull()?.name else null,
                                helper = if (monitoring) etaStatusText else status,
                                onToggle = toggleMonitoring
                            )
var configExpanded by remember(monitoring) { mutableStateOf(!monitoring) }
val configSummary = if (monitorMode == "route") "Roteiro: ${activeItinerary ?: "nenhum selecionado"}" else "Destino único: ${dashTarget ?: "selecione abaixo"}"
val configCard: @Composable () -> Unit = {
Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
) {
    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { configExpanded = !configExpanded },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AgIcon(R.drawable.ic_ui_settings, tint = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f)) {
                Text("O que monitorar", style = MaterialTheme.typography.titleMedium)
                if (!configExpanded) Text(configSummary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            AgIcon(if (configExpanded) R.drawable.ic_ui_chevron_up else R.drawable.ic_ui_chevron_down, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        AnimatedVisibility(visible = configExpanded) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    if (monitoring && status.isNotBlank() && status != "Monitoramento parado") {
                                        Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                                        listOf("individual" to "Destino único", "route" to "Roteiro").forEachIndexed { index, (mode, label) ->
                                            SegmentedButton(
                                                selected = monitorMode == mode,
                                                onClick = { monitorMode = mode },
                                                shape = SegmentedButtonDefaults.itemShape(index = index, count = 2)
                                            ) { Text(label) }
                                        }
                                    }
                                    if (monitorMode == "individual") {
                                        Box {
                                            OutlinedButton(onClick = { destinationMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                                Text(destinations.firstOrNull { it.id == selectedDestinationId }?.let { it.name + if (it.enabled) "" else " (pausado)" } ?: "Selecionar destino")
                                            }
                                            DropdownMenu(expanded = destinationMenuExpanded, onDismissRequest = { destinationMenuExpanded = false }) {
                                                destinations.filter { it.itineraryName.isNullOrBlank() }.forEach { destination ->
                                                    DropdownMenuItem(text = { Text(destination.name + if (destination.enabled) "" else " (pausado)") }, enabled = destination.enabled, onClick = {
                                                        selectedDestinationId = destination.id
                                                        destinationMenuExpanded = false
                                                    })
                                                }
                                            }
                                        }
                                    } else {
                                        val selectedRouteStops = DestinationStore.orderedItineraryStops(this@MainActivity, destinations, activeItinerary)
                                        val routeNames = destinations.mapNotNull { it.itineraryName?.takeIf { name -> name.isNotBlank() } }.distinct()
                                        Box {
                                            OutlinedButton(onClick = { routeMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                                Text(activeItinerary ?: "Selecionar roteiro")
                                            }
                                            DropdownMenu(expanded = routeMenuExpanded, onDismissRequest = { routeMenuExpanded = false }) {
                                                routeNames.forEach { routeName ->
                                                    DropdownMenuItem(text = { Text(routeName) }, onClick = {
                                                        activeItinerary = routeName
                                                        DestinationStore.setActiveItinerary(this@MainActivity, routeName)
                                                        routeMenuExpanded = false
                                                    })
                                                }
                                            }
                                        }
                                        Text("Sentido do roteiro", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            FilterChip(
                                                selected = routeDirection == "ida",
                                                enabled = !monitoring,
                                                onClick = {
                                                    routeDirection = "ida"
                                                    DestinationStore.setRouteDirection(this@MainActivity, "ida")
                                                    status = "Sentido definido: ida"
                                                },
                                                label = { Text("Ida") },
                                                modifier = Modifier.weight(1f)
                                            )
                                            FilterChip(
                                                selected = routeDirection == "volta",
                                                enabled = !monitoring,
                                                onClick = {
                                                    routeDirection = "volta"
                                                    DestinationStore.setRouteDirection(this@MainActivity, "volta")
                                                    status = "Sentido definido: volta (ordem invertida)"
                                                },
                                                label = { Text("Volta") },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                        Text(
                                            if (monitoring) "Pare o monitoramento para trocar o sentido do roteiro."
                                            else if (routeDirection == "volta") "As paradas serão percorridas na ordem inversa, sem alterar o roteiro cadastrado."
                                            else "As paradas serão percorridas na ordem cadastrada.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                                        ) {
                                            Checkbox(
                                                checked = skipInitialStop,
                                                enabled = !monitoring && selectedRouteStops.size > 1,
                                                onCheckedChange = { checked ->
                                                    skipInitialStop = checked
                                                    DestinationStore.setSkipInitialStop(this@MainActivity, checked)
                                                }
                                            )
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text("Pular parada inicial", style = MaterialTheme.typography.bodyMedium)
                                                Text(
                                                    "Começar pela segunda parada do sentido selecionado.",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
            }
        }
    }
}
}
if (!monitoring) configCard()
                            StationTimelineCard(
                                title = "Estações ferroviárias",
                                subtitle = if (stationMessage(monitoring, stationCurrent) == null) listOfNotNull(stationRouteName, stationOperator?.takeIf { it.isNotBlank() }).joinToString(" • ").ifBlank { null } else null,
                                previous = stationPrevious,
                                current = stationCurrent,
                                next = stationNext,
                                message = stationMessage(monitoring, stationCurrent)
                            )
if (monitoring) configCard()
                            MapShortcutCard(onClick = { startActivity(Intent(this@MainActivity, MapActivity::class.java)) })
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatTile(R.drawable.ic_ui_pin, "${destinations.size}", "Destinos", Modifier.weight(1f))
                                StatTile(R.drawable.ic_ui_bell, "${destinations.count { it.enabled }}", "Ativos", Modifier.weight(1f))
                                StatTile(R.drawable.ic_ui_route, "${destinations.mapNotNull { it.itineraryName }.distinct().size}", "Roteiros", Modifier.weight(1f))
                            }
                            Text("Dica: mantenha a localização permitida e confira as restrições de bateria para melhorar a confiabilidade dos alertas.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (selectedSection == "Adicionar destino") item {
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(if (quickTrip) "Destino único" else "Novo local", style = MaterialTheme.typography.titleLarge)
                                Text(if (quickTrip) "Viagem rápida: informe o destino e o monitoramento começa assim que você salvar." else "Escolha um destino único ou adicione paradas a um roteiro.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (selectedSection == "Adicionar destino" && !quickTrip) item {
                        Text("Tipo de cadastro", style = MaterialTheme.typography.bodyMedium)
                        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                            listOf("Único" to "Destino único", "Roteiro" to "Roteiro de viagem").forEachIndexed { index, (mode, label) ->
                                SegmentedButton(
                                    selected = entryMode == mode,
                                    onClick = { entryMode = mode },
                                    shape = SegmentedButtonDefaults.itemShape(index = index, count = 2)
                                ) { Text(label) }
                            }
                        }
                    }
                    if (selectedSection == "Adicionar destino" && entryMode == "Roteiro" && !quickTrip) {
                        item {
                            OutlinedTextField(
                                itineraryName, { itineraryName = it },
                                label = { Text("Nome do roteiro") },
                                placeholder = { Text("Ex.: Viagem para o litoral") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text("Adicione os pontos um por vez usando o mesmo nome de roteiro. Eles aparecerão conectados no mapa na ordem cadastrada.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (selectedSection == "Adicionar destino") item { OutlinedTextField(name, { name = it }, label = { Text("Nome") }, modifier = Modifier.fillMaxWidth()) }
                    if (selectedSection == "Adicionar destino") item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Escolha um ícone para o destino", style = MaterialTheme.typography.labelLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                                listOf("📍", "🏠", "💼", "⛽", "🛒", "🏥", "🏫", "🍽️", "🅿️", "🚉", "🏖️", "⭐").forEach { iconChoice ->
                                    FilterChip(selected = selectedDestinationIcon == iconChoice, onClick = { selectedDestinationIcon = iconChoice }, label = { Text(iconChoice) })
                                }
                            }
                        }
                    }
                    if (selectedSection == "Adicionar destino") item {
                        OutlinedTextField(
                            place,
                            { place = it },
                            label = { Text("Local ou endereço") },
                            placeholder = { Text("Ex.: Praça da Sé, São Paulo") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (selectedSection == "Adicionar destino") item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    if (place.isBlank()) {
                                        status = "Informe o nome do local ou endereço primeiro"
                                    } else {
                                        val query = place.trim()
                                        status = "Procurando local…"
                                        scope.launch {
                                            // Rede fora da thread principal para não travar a interface.
                                            val outcome = withContext(Dispatchers.IO) {
                                                runCatching {
                                                    check(Geocoder.isPresent()) { "sem serviço de geocodificação" }
                                                    @Suppress("DEPRECATION")
                                                    val found = Geocoder(this@MainActivity, Locale("pt", "BR"))
                                                        .getFromLocationName(query, 1)?.firstOrNull()
                                                    found
                                                }
                                            }
                                            val result = outcome.getOrNull()
                                            status = when {
                                                outcome.isFailure ->
                                                    "Não foi possível localizar o endereço. Verifique a internet e tente novamente."
                                                result == null ->
                                                    "Local não encontrado. Tente informar endereço e cidade."
                                                else -> {
                                                    latitude = result.latitude.toString()
                                                    longitude = result.longitude.toString()
                                                    if (name.isBlank()) name = query
                                                    "Local encontrado: ${result.latitude}, ${result.longitude}"
                                                }
                                            }
                                        }
                                    }
                                }, modifier = Modifier.weight(1f)
                            ) { Text("Selecionar local") }
                            OutlinedButton(
                                onClick = {
                                    val lat = latitude.trim().replace(',', '.').toDoubleOrNull()
                                    val lon = longitude.trim().replace(',', '.').toDoubleOrNull()
                                    val rad = radius.trim().toIntOrNull()
                                    if (lat == null || lat !in -90.0..90.0 || lon == null || lon !in -180.0..180.0) {
                                        status = "Informe ou selecione um local para visualizar o raio no mapa"
                                    } else if (rad == null || rad !in 50..10000) {
                                        status = "Informe um raio válido entre 50 e 10000 metros"
                                    } else {
                                        val preview = Destination(
                                            name = name.ifBlank { place.ifBlank { "Prévia do destino" } },
                                            latitude = lat,
                                            longitude = lon,
                                            radiusMeters = rad,
                                            message = message.ifBlank { "Você está chegando ao destino" },
                                            enabled = true,
                                            itineraryName = if (entryMode == "Roteiro") itineraryName.ifBlank { null } else null,
                                            oneShot = oneShot,
                                            transportType = transportType,
                                            distanceAlertMeters = distanceAlert.trim().toIntOrNull() ?: TransportType.DEFAULT_BUS_DISTANCE_ALERT,
                                            comment = stopComment.trim()
                                        )
                                        val payload = org.json.JSONArray().put(preview.toJson()).toString()
                                        startActivity(Intent(this@MainActivity, MapActivity::class.java).putExtra(MapActivity.EXTRA_DESTINATIONS, payload))
                                    }
                                }, modifier = Modifier.weight(1f)
                            ) { Text("Pré-visualizar raio") }
                        }
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(this@MainActivity, MapActivity::class.java)
                                    .putExtra(MapActivity.EXTRA_DESTINATIONS, "[]")
                                    .putExtra(MapActivity.EXTRA_SELECT_POINT, true)
                                mapPointPicker.launch(intent)
                            }, modifier = Modifier.fillMaxWidth()
                        ) { Text("Adicionar a partir de um ponto no mapa") }
                        Text("Você pode pesquisar um endereço ou tocar diretamente no mapa. O ponto escolhido preencherá as coordenadas automaticamente.",
                            style = MaterialTheme.typography.bodySmall)
                    }
                    if (selectedSection == "Adicionar destino") item {
                        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Tipo de transporte", style = MaterialTheme.typography.labelLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                listOf(TransportType.TRAIN to "🚆 Trem/Metrô", TransportType.BUS to "🚌 Ônibus").forEach { (type, label) ->
                                    FilterChip(
                                        selected = transportType == type,
                                        onClick = {
                                            if (transportType != type) {
                                                transportType = type
                                                // Ao trocar o tipo, o raio é preenchido com o padrão dele (você ainda pode editar).
                                                radius = TransportType.defaultRadius(type).toString()
                                            }
                                        },
                                        label = { Text(label) }
                                    )
                                }
                            }
                            OutlinedTextField(radius, { radius = it }, label = { Text("Raio em metros (50–10000)") }, modifier = Modifier.fillMaxWidth())
                            if (transportType == TransportType.BUS) {
                                OutlinedTextField(distanceAlert, { distanceAlert = it }, label = { Text("Aviso por distância (m)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Text("Ônibus tem dois alertas: um ao chegar a essa distância e outro ao entrar no raio. Cada um tem seu som em Preferências.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("Pré-visualize a área circular onde o alerta será disparado antes de salvar o destino.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (selectedSection == "Adicionar destino") item { OutlinedTextField(message, { message = it }, label = { Text("Mensagem do alerta") }, modifier = Modifier.fillMaxWidth()) }
                    if (selectedSection == "Adicionar destino") item {
                        OutlinedTextField(
                            stopComment, { stopComment = it.take(Destination.COMMENT_MAX_LENGTH) },
                            label = { Text("Comentário (opcional)") },
                            supportingText = { Text("${stopComment.length}/${Destination.COMMENT_MAX_LENGTH} · aparece só nos roteiros e destinos cadastrados") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (selectedSection == "Adicionar destino") item {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Alertar só uma vez")
                                Text("O destino é desativado depois do primeiro alerta.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = oneShot, onCheckedChange = { oneShot = it })
                        }
                    }
                    if (selectedSection == "Adicionar destino") item {
                        Button(onClick = {
                            val lat = latitude.trim().replace(',', '.').toDoubleOrNull()
                            val lon = longitude.trim().replace(',', '.').toDoubleOrNull()
                            val rad = radius.toIntOrNull()
                            val distAlert = distanceAlert.trim().toIntOrNull()
                            // Viagem rápida: o nome é opcional (usa o local informado).
                            if (quickTrip && name.isBlank()) name = place.trim().ifBlank { "Destino da viagem" }
                            if (name.isBlank() || lat == null || lat !in -90.0..90.0 ||
                                lon == null || lon !in -180.0..180.0 || rad == null || rad !in 50..10000) {
                                status = "Confira nome, coordenadas e raio (50 a 10000 m)"
                            } else if (transportType == TransportType.BUS && (distAlert == null || distAlert !in 50..10000 || distAlert <= rad)) {
                                status = "A distância do aviso do ônibus deve ser maior que o raio (até 10000 m)"
                            } else {
                                if (!quickTrip && entryMode == "Roteiro" && itineraryName.isBlank()) {
                                    status = "Informe um nome para o roteiro"
                                } else {
                                    val created = Destination(name = name.trim(), latitude = lat, longitude = lon,
                                        radiusMeters = rad, message = message.ifBlank { "Você está chegando ao destino" },
                                        itineraryName = if (!quickTrip && entryMode == "Roteiro") itineraryName.trim() else null,
                                        oneShot = oneShot || quickTrip,
                                        locationLabel = place.trim().takeIf { it.isNotEmpty() },
                                        icon = selectedDestinationIcon,
                                        transportType = transportType,
                                        distanceAlertMeters = distAlert ?: TransportType.DEFAULT_BUS_DISTANCE_ALERT,
                                        comment = stopComment.trim())
                                    save(destinations + created)
                                    stopComment = ""
                                    name = ""; place = ""; latitude = ""; longitude = ""; radius = TransportType.defaultRadius(transportType).toString(); oneShot = false; selectedDestinationIcon = "📍"
                                    message = "Você está chegando ao destino"
                                    if (quickTrip) {
                                        // Viagem esporádica: seleciona o destino recém-criado e já inicia o monitoramento.
                                        quickTrip = false
                                        monitorMode = "individual"
                                        selectedDestinationId = created.id
                                        selectedSection = "Início"
                                        requestStartMonitoring()
                                    } else {
                                        status = if (entryMode == "Roteiro") "Ponto adicionado ao roteiro: ${itineraryName.trim()}" else "Destino adicionado"
                                    }
                                }
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text(if (quickTrip) "Salvar e iniciar monitoramento" else "Adicionar destino") }
                    }
                    if (selectedSection == "Adicionar destino" && !quickTrip) item {
                        Button(onClick = { csvPicker.launch(arrayOf("text/*", "application/*", "application/octet-stream")) },
                            modifier = Modifier.fillMaxWidth()) { Text("Importar destinos CSV") }
                    }
                    if (selectedSection == "Adicionar destino" && importReport.isNotBlank()) {
                        item {
                            Card {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Resultado da importação", style = MaterialTheme.typography.titleMedium)
                                    Text(importReport)
                                    pendingImport?.let { batch ->
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(onClick = {
                                                save(destinations + batch)
                                                pendingImport = null
                                                importReport = "Importação concluída: ${batch.size} destino(s) adicionado(s)."
                                            }) { Text("Confirmar") }
                                            OutlinedButton(onClick = {
                                                pendingImport = null
                                                importReport = "Importação cancelada."
                                            }) { Text("Cancelar") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (selectedSection == "Preferências") item {
                        fun pickSound(kind: AlertKind, current: String?, title: String) {
                            soundPickerKind = kind
                            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_ALARM)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, title)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                putExtra(
                                    RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                                    current?.takeIf { it.isNotEmpty() && !it.startsWith("android.resource://") }?.let { Uri.parse(it) }
                                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                                )
                            }
                            soundPicker.launch(intent)
                        }
                        fun testSound(kind: AlertKind) {
                            RoutedAlertSound.play(this@MainActivity, { status = it }, kind)
                            scope.launch { delay(5_000); RoutedAlertSound.stop() }
                        }
                        fun applyDisplayMode(mode: String) {
                            displayMode = mode
                            DestinationStore.setAlertDisplayMode(this@MainActivity, mode)
                            if (mode == DestinationStore.DISPLAY_POPUP) {
                                if (!Settings.canDrawOverlays(this@MainActivity)) {
                                    status = "Para o pop-up abrir sobre outros apps, permita “Exibir sobre outros apps” para o Alerta Geográfico."
                                    runCatching {
                                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                                    }
                                }
                                val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
                                if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent()) {
                                    runCatching {
                                        startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
                                    }
                                }
                            }
                        }
                        fun openAppSettings(errorMessage: String) {
                            runCatching {
                                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                            }.onFailure { status = errorMessage }
                        }
                        fun intervalLabel(seconds: Int) =
                            if (seconds < 60) "$seconds segundos"
                            else if (seconds % 60 == 0) "${seconds / 60} min"
                            else "${seconds / 60} min ${seconds % 60} s"
                        val etaMinutes = etaLead.toIntOrNull() ?: 0

                        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("Preferências", style = MaterialTheme.typography.headlineSmall, color = brandNavy)
                                Text("Valem para todos os destinos e roteiros.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            SettingsGroup("Alertas") {
                                SettingsValueRow(
                                    "Forma de exibir",
                                    value = if (displayMode == DestinationStore.DISPLAY_POPUP) "Pop-up na tela" else "Notificação",
                                    subtitle = "Como o aviso aparece quando você chega",
                                    onClick = { prefDialog = "display" }
                                )
                                SettingsValueRow(
                                    "Alerta antecipado",
                                    value = if (etaMinutes == 0) "Desativado" else "$etaMinutes min antes",
                                    subtitle = "Avisa pelo tempo estimado, antes de chegar ao raio",
                                    onClick = { prefDialog = "eta" }
                                )
                                SettingsSwitchRow(
                                    "Vibração", checked = vibration,
                                    onCheckedChange = { vibration = it; DestinationStore.setVibrationEnabled(this@MainActivity, it) }
                                )
                                SettingsSwitchRow(
                                    "Áudio de percurso concluído", checked = completionAudio,
                                    subtitle = "Toca depois do alerta da parada final",
                                    onCheckedChange = { completionAudio = it; DestinationStore.setCompletionAudioEnabled(this@MainActivity, it) }
                                )
                                SettingsValueRow(
                                    "Testar alerta",
                                    subtitle = "Envia uma notificação de teste",
                                    showDivider = false,
                                    onClick = {
                                        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                                                this@MainActivity, Manifest.permission.POST_NOTIFICATIONS
                                            ) != PackageManager.PERMISSION_GRANTED
                                        ) {
                                            testNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        } else {
                                            status = "Notificação de teste enviada; verificando saída de áudio…"
                                            showTestNotification { audioStatus -> status = audioStatus }
                                        }
                                    }
                                )
                            }

                            SettingsGroup("Sons") {
                                SettingsSwitchRow(
                                    "Ativar som", checked = sound,
                                    onCheckedChange = { sound = it; DestinationStore.setSoundEnabled(this@MainActivity, it); recreateAlertChannel() }
                                )
                                SettingsSwitchRow(
                                    "Modo alarme", checked = alarmMode,
                                    subtitle = "Toca mesmo com a mídia no mudo e repete até você tocar em OK (máx. 60 s)",
                                    onCheckedChange = { alarmMode = it; DestinationStore.setAlarmMode(this@MainActivity, it) }
                                )
                                SettingsValueRow(
                                    "🚆 Trem/Metrô",
                                    value = soundLabel(trainSoundUri, sound),
                                    subtitle = "Ao entrar no raio do destino",
                                    onClick = { pickSound(AlertKind.TRAIN, trainSoundUri, "Som do alerta de trem/metrô") },
                                    trailing = { TextButton(onClick = { testSound(AlertKind.TRAIN) }) { Text("Testar") } }
                                )
                                SettingsValueRow(
                                    "🚌 Ônibus — aviso por distância",
                                    value = soundLabel(busDistanceSoundUri, sound),
                                    subtitle = "Ao chegar à distância de aviso do destino",
                                    onClick = { pickSound(AlertKind.BUS_DISTANCE, busDistanceSoundUri, "Som do aviso de distância (ônibus)") },
                                    trailing = { TextButton(onClick = { testSound(AlertKind.BUS_DISTANCE) }) { Text("Testar") } }
                                )
                                SettingsValueRow(
                                    "🚌 Ônibus — chegada no raio",
                                    value = soundLabel(busRadiusSoundUri, sound),
                                    subtitle = "Ao entrar no raio do destino",
                                    onClick = { pickSound(AlertKind.BUS_RADIUS, busRadiusSoundUri, "Som da chegada no raio (ônibus)") },
                                    trailing = { TextButton(onClick = { testSound(AlertKind.BUS_RADIUS) }) { Text("Testar") } }
                                )
                                SettingsSliderRow(
                                    "Volume do alerta", "${(alertVolume * 100).toInt()}%",
                                    value = alertVolume,
                                    onValueChange = { alertVolume = it },
                                    onValueChangeFinished = { DestinationStore.setAlertVolume(this@MainActivity, alertVolume) },
                                    enabled = sound
                                )
                                SettingsValueRow(
                                    "Restaurar sons padrão do app",
                                    subtitle = "Volta ao áudio incluso para cada alerta",
                                    showDivider = false,
                                    onClick = {
                                        DestinationStore.resetSoundsToDefault(this@MainActivity)
                                        trainSoundUri = DestinationStore.alertSoundUri(this@MainActivity, AlertKind.TRAIN)
                                        busRadiusSoundUri = DestinationStore.alertSoundUri(this@MainActivity, AlertKind.BUS_RADIUS)
                                        busDistanceSoundUri = DestinationStore.alertSoundUri(this@MainActivity, AlertKind.BUS_DISTANCE)
                                        recreateAlertChannel()
                                        status = "Sons padrão do app restaurados"
                                    }
                                )
                            }

                            SettingsGroup("Saída de áudio") {
                                SettingsValueRow(
                                    "Canal de áudio",
                                    value = if (alertAudioMode == "media") "Volume de mídia" else "Volume de notificação",
                                    subtitle = "O Modo alarme tem prioridade sobre o canal",
                                    onClick = { prefDialog = "channel" }
                                )
                                SettingsValueRow(
                                    "Música tocando",
                                    value = if (alertMixMode == "duck") "Diminuir a música" else "Tocar sobre a música",
                                    onClick = { prefDialog = "mix" }
                                )
                                SettingsValueRow(
                                    "Onde tocar",
                                    value = if (alertAudioOutput == "speaker") "Alto-falante" else "Fone (se conectado)",
                                    subtitle = "Sem fone conectado, toca no alto-falante",
                                    showDivider = false,
                                    onClick = { prefDialog = "output" }
                                )
                            }

                            SettingsGroup("Monitoramento e bateria") {
                                SettingsValueRow(
                                    "Atualização da localização",
                                    value = "A cada ${intervalLabel(locationIntervalSeconds)}",
                                    subtitle = "Vale também com o monitoramento ativo",
                                    onClick = { prefDialog = "interval" }
                                )
                                SettingsValueRow(
                                    "Modo de monitoramento",
                                    value = when (batteryProfile) {
                                        "precision" -> "Precisão"
                                        "economy" -> "Economia"
                                        else -> "Equilibrado"
                                    },
                                    subtitle = "Equilíbrio entre precisão e consumo de bateria",
                                    onClick = { prefDialog = "battery" }
                                )
                                SettingsSwitchRow(
                                    "Avanço automático no roteiro", checked = autoSkipToLaterStop,
                                    subtitle = "Pula para uma parada posterior se o GPS confirmar que você já está nela",
                                    onCheckedChange = { autoSkipToLaterStop = it; DestinationStore.setAutoSkipToLaterStopEnabled(this@MainActivity, it) }
                                )
                                SettingsValueRow(
                                    "Uso de bateria",
                                    subtitle = "Abrir informações do app no Android",
                                    showDivider = false,
                                    onClick = { openAppSettings("Não foi possível abrir as informações do aplicativo nas configurações do Android") }
                                )
                            }

                            SettingsGroup("Mapa") {
                                SettingsSwitchRow(
                                    "Linhas ferroviárias", checked = showRailLinesOnMap,
                                    subtitle = "Mostrar por padrão ao abrir o mapa",
                                    onCheckedChange = { checked ->
                                        showRailLinesOnMap = checked
                                        getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE).edit().putBoolean(MapActivity.PREF_SHOW_RAIL_LINES, checked).apply()
                                    }
                                )
                                SettingsSwitchRow(
                                    "Estações", checked = showRailStationsOnMap,
                                    subtitle = "Mostrar por padrão ao abrir o mapa",
                                    showDivider = false,
                                    onCheckedChange = { checked ->
                                        showRailStationsOnMap = checked
                                        getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE).edit().putBoolean(MapActivity.PREF_SHOW_RAIL_STATIONS, checked).apply()
                                    }
                                )
                            }

                            SettingsGroup("Dados e permissões") {
                                SettingsValueRow(
                                    "Permissões do aplicativo",
                                    subtitle = "Localização, notificações e outras, no Android",
                                    onClick = { openAppSettings("Não foi possível abrir as permissões do aplicativo") }
                                )
                                SettingsValueRow(
                                    "Criar backup",
                                    subtitle = "Salva destinos, roteiros, preferências e dados ferroviários em um arquivo JSON",
                                    onClick = { backupExportLauncher.launch("AlertaGeografico_backup.json") }
                                )
                                SettingsValueRow(
                                    "Restaurar backup",
                                    subtitle = "Substitui os dados atuais e interrompe o monitoramento",
                                    showDivider = false,
                                    onClick = { backupImportLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }
                                )
                            }
                        }

                        when (prefDialog) {
                            "display" -> SettingsChoiceDialog(
                                title = "Forma de exibir",
                                options = listOf(
                                    DestinationStore.DISPLAY_NOTIFICATION to "Notificação",
                                    DestinationStore.DISPLAY_POPUP to "Pop-up na tela"
                                ),
                                selected = displayMode,
                                message = "O pop-up abre em primeiro plano, com OK, Soneca 5 min e Abrir app. Para abrir sobre outros apps precisa da permissão “Exibir sobre outros apps”; sem ela, só abre com a tela bloqueada.",
                                onSelect = { applyDisplayMode(it); prefDialog = null },
                                onDismiss = { prefDialog = null }
                            )
                            "eta" -> {
                                val values = (listOf(0, 1, 2, 3, 5, 7, 10, 15, 20, 30) + etaMinutes).distinct().sorted()
                                SettingsChoiceDialog(
                                    title = "Alerta antecipado",
                                    options = values.map { it.toString() to if (it == 0) "Desativado" else "$it min antes" },
                                    selected = etaMinutes.toString(),
                                    message = "Usa distância em linha reta e velocidade do GPS; não é previsão de rota.",
                                    onSelect = { choice ->
                                        val minutes = choice.toInt()
                                        DestinationStore.setEtaAlertMinutes(this@MainActivity, minutes)
                                        etaLead = minutes.toString()
                                        status = if (minutes == 0) "Alerta antecipado desativado" else "Alerta antecipado configurado para aproximadamente $minutes min"
                                        prefDialog = null
                                    },
                                    onDismiss = { prefDialog = null }
                                )
                            }
                            "channel" -> SettingsChoiceDialog(
                                title = "Canal de áudio",
                                options = listOf("media" to "Volume de mídia (como YouTube e Spotify)", "notification" to "Volume de notificação"),
                                selected = alertAudioMode,
                                onSelect = { alertAudioMode = it; DestinationStore.setAlertAudioMode(this@MainActivity, it); prefDialog = null },
                                onDismiss = { prefDialog = null }
                            )
                            "mix" -> SettingsChoiceDialog(
                                title = "Música tocando",
                                options = listOf("duck" to "Diminuir a música temporariamente", "overlap" to "Tocar o alerta sobre a música"),
                                selected = alertMixMode,
                                message = if (alertMixMode == "duck") "Pede foco de áudio temporário para reduzir a música enquanto o alerta toca. O resultado depende do outro player e do Android."
                                    else "Não pede foco de áudio e tenta tocar junto com a música. Alguns players ainda podem reduzir ou pausar.",
                                onSelect = { alertMixMode = it; DestinationStore.setAlertMixMode(this@MainActivity, it); prefDialog = null },
                                onDismiss = { prefDialog = null }
                            )
                            "output" -> SettingsChoiceDialog(
                                title = "Onde tocar o alerta",
                                options = listOf("headphones" to "Fone (Bluetooth, USB ou com fio)", "speaker" to "Alto-falante do celular"),
                                selected = alertAudioOutput,
                                onSelect = { alertAudioOutput = it; DestinationStore.setAlertAudioOutput(this@MainActivity, it); prefDialog = null },
                                onDismiss = { prefDialog = null }
                            )
                            "interval" -> SettingsChoiceDialog(
                                title = "Atualização da localização",
                                options = listOf(5, 10, 15, 30, 60, 120, 180, 240, 300).map { it.toString() to "A cada ${intervalLabel(it)}" },
                                selected = locationIntervalSeconds.toString(),
                                message = "Frequência pedida ao Android. O GPS pode variar conforme o sinal e o sistema.",
                                onSelect = { choice ->
                                    locationIntervalSeconds = choice.toInt()
                                    DestinationStore.setLocationIntervalSeconds(this@MainActivity, locationIntervalSeconds)
                                    prefDialog = null
                                },
                                onDismiss = { prefDialog = null }
                            )
                            "battery" -> SettingsChoiceDialog(
                                title = "Modo de monitoramento",
                                options = listOf("precision" to "Precisão", "balanced" to "Equilibrado", "economy" to "Economia"),
                                selected = batteryProfile,
                                message = when (batteryProfile) {
                                    "precision" -> "Usa o intervalo escolhido e localização de alta precisão. Consome mais bateria."
                                    "economy" -> "Reduz atualizações longe dos destinos ou parado e aumenta ao se aproximar. Os alertas podem atrasar mais."
                                    else -> "Atualizações menos frequentes longe dos destinos e maior precisão perto deles."
                                },
                                onSelect = { batteryProfile = it; DestinationStore.setBatteryProfile(this@MainActivity, it); prefDialog = null },
                                onDismiss = { prefDialog = null }
                            )
                            else -> Unit
                        }
                    }
                    if (selectedSection == "Destinos cadastrados") item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Seus locais", style = MaterialTheme.typography.titleLarge)
                                Text("${destinations.count { it.enabled }} ativos de ${destinations.size} cadastrados", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Destinos cadastrados (${destinations.size})", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            TextButton(onClick = { showOnMap(destinations) }, enabled = destinations.isNotEmpty()) { Text("Ver todos no mapa") }
                        }
                    }
                    val itineraryGroups = destinations.filter { !it.itineraryName.isNullOrBlank() }.groupBy { it.itineraryName!! }
                    if (selectedSection == "Roteiros" && itineraryGroups.isEmpty()) item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Nenhum roteiro ainda", style = MaterialTheme.typography.titleMedium)
                                Text("Ao adicionar um destino, escolha ‘Roteiro de viagem’ e informe o nome do roteiro.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Button(onClick = { selectedSection = "Adicionar destino"; entryMode = "Roteiro" }) { Text("Criar roteiro") }
                            }
                        }
                    }
                    if (selectedSection == "Destinos cadastrados" && destinations.isEmpty()) item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Nenhum destino cadastrado", style = MaterialTheme.typography.titleMedium)
                                Text("Adicione seu primeiro local para começar a receber alertas de proximidade.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Button(onClick = { selectedSection = "Adicionar destino" }) { Text("Adicionar destino") }
                            }
                        }
                    }
                    if (selectedSection == "Roteiros" && itineraryGroups.isNotEmpty()) {
                        item { Text("Roteiros de viagem", style = MaterialTheme.typography.titleMedium) }
                        items(itineraryGroups.entries.toList(), key = { "route-${it.key}" }) { route ->
                            val expanded = expandedRouteCards.contains("main:${route.key}")
                            Card(onClick = {
                                expandedRouteCards = if (expanded) expandedRouteCards - "main:${route.key}" else expandedRouteCards + "main:${route.key}"
                            }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                        Text(routeIcons[route.key] ?: "🗺️", style = MaterialTheme.typography.headlineSmall)
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Text(route.key, style = MaterialTheme.typography.titleMedium)
                                            Text("${route.value.size} parada(s) · ${route.value.count { it.enabled }} ativa(s)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        AgIcon(if (expanded) R.drawable.ic_ui_chevron_up else R.drawable.ic_ui_chevron_down, tint = MaterialTheme.colorScheme.primary)
                                    }
                                    if (expanded) {
                                        Text(route.value.mapIndexed { index, d -> "${index + 1}. ${d.name}" }.joinToString("  →  "), style = MaterialTheme.typography.bodyMedium)
                                        Text("Raio de alerta definido individualmente para cada parada.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(onClick = { showOnMap(route.value) }) { Text("Ver roteiro no mapa") }
                                            TextButton(onClick = { pendingRouteIcon = route.key }) { Text("Ícone") }
                                            TextButton(onClick = {
                                                renameRouteName = route.key
                                                pendingRenameRoute = route.key
                                            }) { Text("Renomear") }
                                            TextButton(onClick = {
                                                val next = if (activeItinerary == route.key) null else route.key
                                                DestinationStore.setActiveItinerary(this@MainActivity, next)
                                                activeItinerary = next
                                                if (next != null) monitorMode = "route"
                                                status = if (next == null) "Roteiro sequencial encerrado" else "Roteiro selecionado: ${route.key}. Volte ao Início e toque em Iniciar monitoramento."
                                            }) { Text(if (activeItinerary == route.key) "Parar sequência" else "Iniciar sequência") }
                                            TextButton(onClick = { selectedSection = "Adicionar destino"; entryMode = "Roteiro"; itineraryName = route.key }) { Text("Adicionar parada") }
                                        }
                                        if (activeItinerary == route.key) Text("Roteiro sequencial ativo: somente a próxima parada deste roteiro dispara o alerta. Parada ${DestinationStore.itineraryIndex(this@MainActivity) + 1} de ${route.value.size}.", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                    if (selectedSection == "Destinos cadastrados") {
                        val routeDestinations = destinations.filter { !it.itineraryName.isNullOrBlank() }
                        val individualDestinations = destinations.filter { it.itineraryName.isNullOrBlank() }

                        if (routeDestinations.isNotEmpty()) {
                            item { Text("Destinos agrupados por roteiro", style = MaterialTheme.typography.titleMedium) }
                            items(itineraryGroups.entries.toList(), key = { "dest-route-${it.key}" }) { route ->
                                val cardKey = "dest-route:${route.key}"
                                val expanded = expandedDestinationCards.contains(cardKey)
                                Card(onClick = {
                                    expandedDestinationCards = if (expanded) expandedDestinationCards - cardKey else expandedDestinationCards + cardKey
                                }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                            Text(routeIcons[route.key] ?: "🗺️", style = MaterialTheme.typography.headlineSmall)
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Text(route.key, style = MaterialTheme.typography.titleMedium)
                                                Text("${route.value.size} parada(s) · ${route.value.count { it.enabled }} ativa(s)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            AgIcon(if (expanded) R.drawable.ic_ui_chevron_up else R.drawable.ic_ui_chevron_down, tint = MaterialTheme.colorScheme.primary)
                                        }
                                        if (expanded) {
                                            HorizontalDivider()
                                            Text("Use as setas ↑ e ↓ para reorganizar a ordem das paradas.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            route.value.forEachIndexed { index, destination ->
                                                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                                        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(10.dp)) {
                                                            Text("${index + 1}", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge)
                                                        }
                                                        Spacer(Modifier.width(9.dp))
                                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                            Text("${destination.icon}  ${destination.name}", style = MaterialTheme.typography.titleSmall)
                                                            Text("${TransportType.label(destination.transportType)} · Raio: ${destination.radiusMeters} m · ${if (destination.enabled) "Ativo" else "Pausado"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                        }
                                                        Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                                                            IconButton(
                                                                onClick = { moveItineraryStop(route.key, destination.id, -1) },
                                                                enabled = index > 0,
                                                                modifier = Modifier.size(36.dp)
                                                            ) { AgIcon(R.drawable.ic_ui_arrow_up, size = 20.dp) }
                                                            IconButton(
                                                                onClick = { moveItineraryStop(route.key, destination.id, 1) },
                                                                enabled = index < route.value.lastIndex,
                                                                modifier = Modifier.size(36.dp)
                                                            ) { AgIcon(R.drawable.ic_ui_arrow_down, size = 20.dp) }
                                                        }
                                                        Switch(checked = destination.enabled, onCheckedChange = { enabled ->
                                                            save(destinations.map { if (it.id == destination.id) it.copy(enabled = enabled) else it })
                                                        })
                                                    }
                                                    if (destination.comment.isNotBlank()) Text("💬 ${destination.comment}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                                    val stopPlace = destination.locationLabel?.takeIf { it.isNotBlank() } ?: decodedAddresses[destination.id]
                                                    if (!stopPlace.isNullOrBlank()) Text("Local: $stopPlace", style = MaterialTheme.typography.bodySmall)
                                                    else Text("Localização registrada no mapa", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    Row {
                                                        TextButton(onClick = { pendingEdit = destination }) { Text("Editar") }
                                                        TextButton(onClick = { pendingDelete = destination }) { Text("Excluir parada") }
                                                    }
                                                }
                                                if (index < route.value.lastIndex) HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                                            }
                                            OutlinedButton(onClick = { selectedSection = "Adicionar destino"; entryMode = "Roteiro"; itineraryName = route.key }, modifier = Modifier.fillMaxWidth()) { Text("Adicionar parada a este roteiro") }
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                TextButton(onClick = { pendingRouteIcon = route.key }) { Text("Ícone do roteiro") }
                                                TextButton(onClick = {
                                                    renameRouteName = route.key
                                                    pendingRenameRoute = route.key
                                                }) { Text("Renomear roteiro") }
                                                TextButton(onClick = { showOnMap(route.value) }) { Text("Ver roteiro no mapa") }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (individualDestinations.isNotEmpty()) {
                            item { Text("Destinos individuais", style = MaterialTheme.typography.titleMedium) }
                            items(individualDestinations, key = { "individual-${it.id}" }) { destination ->
                                val cardKey = "individual:${destination.id}"
                                val expanded = expandedDestinationCards.contains(cardKey)
                                Card(onClick = {
                                    expandedDestinationCards = if (expanded) expandedDestinationCards - cardKey else expandedDestinationCards + cardKey
                                }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                            Text(destination.icon, style = MaterialTheme.typography.headlineSmall)
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Text(destination.name, style = MaterialTheme.typography.titleMedium)
                                                Text("${TransportType.label(destination.transportType)} · ${destination.radiusMeters} m · ${if (destination.enabled) "Ativo" else "Pausado"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            AgIcon(if (expanded) R.drawable.ic_ui_chevron_up else R.drawable.ic_ui_chevron_down, tint = MaterialTheme.colorScheme.primary)
                                        }
                                        if (expanded) {
                                            val savedPlace = destination.locationLabel?.takeIf { it.isNotBlank() }
                                            val decodedAddress = decodedAddresses[destination.id]
                                            when {
                                                !savedPlace.isNullOrBlank() -> Text("Local: $savedPlace")
                                                !decodedAddress.isNullOrBlank() -> Text("Endereço: $decodedAddress")
                                                attemptedAddressIds.contains(destination.id) -> Text("Endereço não disponível para estas coordenadas", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                                else -> Text("Identificando endereço automaticamente…", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                            }
                                            Text("${TransportType.label(destination.transportType)} · Raio: ${destination.radiusMeters} m${if (destination.oneShot) " · alerta único" else ""}")
                                            if (destination.hasDistanceAlert) Text("Aviso por distância: ${destination.distanceAlertMeters} m")
                                            Text(destination.message)
                                            if (destination.comment.isNotBlank()) Text("💬 ${destination.comment}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                                Text(if (destination.enabled) "Ativo" else "Desativado", modifier = Modifier.weight(1f))
                                                Switch(checked = destination.enabled, onCheckedChange = { enabled ->
                                                    save(destinations.map { if (it.id == destination.id) it.copy(enabled = enabled) else it })
                                                })
                                            }
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                OutlinedButton(onClick = { showOnMap(listOf(destination)) }) { Text("Ver no mapa") }
                                                TextButton(onClick = { pendingEdit = destination }) { Text("Editar") }
                                                TextButton(onClick = { pendingDelete = destination }) { Text("Excluir") }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (selectedSection == "Estações") item {
                        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Navegação por estações", style = MaterialTheme.typography.titleMedium)
                                    Text("Importe os arquivos GeoJSON do OpenStreetMap/Overpass Turbo: primeiro os pontos das estações e depois as geometrias das linhas/rotas. Se precisar dividir a Região Metropolitana em áreas menores por causa do timeout, importe vários arquivos do mesmo tipo: o app combina os dados. Depois, o GPS e os dados locais estimam a estação atual, a anterior e a próxima.", style = MaterialTheme.typography.bodyMedium)
                                    Text("Estações salvas: ${StationNavigationStore.stationCount(this@MainActivity)} • Linhas/rotas salvas: ${StationNavigationStore.routeCount(this@MainActivity)}", style = MaterialTheme.typography.labelLarge)
                                    HorizontalDivider()
                                    Text("Como obter os dados", style = MaterialTheme.typography.titleSmall)
                                    Text("1. Toque em Abrir Overpass Turbo. 2. No mapa, aproxime e enquadre uma área pequena da região que deseja baixar. 3. Copie a consulta abaixo, cole no editor do Overpass Turbo e toque em Executar. 4. Use Exportar → Dados → GeoJSON e salve o arquivo. Repita para estações e linhas/rotas. Se ocorrer timeout, reduza a área visível e tente novamente. Você pode importar vários arquivos de áreas diferentes.", style = MaterialTheme.typography.bodySmall)
                                    OutlinedButton(onClick = {
                                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://overpass-turbo.eu/")))
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Abrir Overpass Turbo") }
                                    Text("Consulta 1 — estações", style = MaterialTheme.typography.labelLarge)
                                    Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                                        Text(overpassStationsQuery, modifier = Modifier.fillMaxWidth().padding(10.dp), style = MaterialTheme.typography.bodySmall)
                                    }
                                    OutlinedButton(onClick = {
                                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Consulta Overpass - estações", overpassStationsQuery))
                                        stationImportMessage = "Consulta de estações copiada. Cole no editor do Overpass Turbo."
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Copiar código das estações") }
                                    Text("Consulta 2 — linhas/rotas ferroviárias", style = MaterialTheme.typography.labelLarge)
                                    Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                                        Text(overpassRoutesQuery, modifier = Modifier.fillMaxWidth().padding(10.dp), style = MaterialTheme.typography.bodySmall)
                                    }
                                    OutlinedButton(onClick = {
                                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Consulta Overpass - linhas e rotas", overpassRoutesQuery))
                                        stationImportMessage = "Consulta de linhas/rotas copiada. Cole no editor do Overpass Turbo."
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Copiar código das linhas/rotas") }
                                    ExpandableHelp("Depois de exportar cada resultado como GeoJSON, importe os dois tipos de arquivo nos botões abaixo. Os arquivos devem cobrir a área desejada. Atribuição: © OpenStreetMap contributors (ODbL).")
                                    OutlinedButton(onClick = { stationGeoJsonLauncher.launch(arrayOf("application/geo+json", "application/json", "application/octet-stream", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Importar GeoJSON de estações") }
                                    OutlinedButton(onClick = { railRoutesGeoJsonLauncher.launch(arrayOf("application/geo+json", "application/json", "application/octet-stream", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Importar GeoJSON de linhas/rotas") }
                                    OutlinedButton(onClick = { confirmClearRailData = true }, modifier = Modifier.fillMaxWidth(), enabled = StationNavigationStore.hasStations(this@MainActivity) || StationNavigationStore.hasRoutes(this@MainActivity), colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Apagar todos os dados de estações e trilhos") }
                                    if (stationImportMessage.isNotBlank()) Text(stationImportMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                    HorizontalDivider()
                                    Button(onClick = { refreshStationPosition() }, enabled = !stationLoading, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (stationLoading) "Atualizando posição…" else "Atualizar posição pelo GPS")
                                    }
                                    Text(stationLocationStatus, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            stationResult?.let { result ->
                                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("${result.routeName}${result.operator.takeIf { it.isNotBlank() }?.let { " • $it" } ?: ""}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        Text("ESTAÇÃO ANTERIOR", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f))
                                        Text(result.previous?.name ?: "Não identificada", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.18f))
                                        Text("ESTAÇÃO ATUAL (estimada)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f))
                                        Text(result.current.name, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        Text("Aproximadamente ${result.distanceToCurrentMeters.toInt()} m da estação • ${result.distanceToLineMeters.toInt()} m da linha", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.18f))
                                        Text("PRÓXIMA ESTAÇÃO", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f))
                                        Text(result.next?.name ?: "Não identificada", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        result.distanceToNextMeters?.let { distance ->
                                            Text("Distância estimada pelos trilhos até a próxima: ${if (distance >= 1000) String.format(Locale.getDefault(), "%.1f km", distance / 1000.0) else "$distance m"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        }
                                    }
                                }
                            }
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Importante", style = MaterialTheme.typography.titleSmall)
                                    ExpandableHelp("A estação atual é uma estimativa por proximidade e posição ao longo da geometria ferroviária; não é uma confirmação de que você está dentro de um trem. A precisão depende da qualidade e da cobertura dos arquivos OSM. Em linhas paralelas, ramificações ou túneis, confira o resultado. Os arquivos importados ficam no armazenamento privado do app e podem ser usados sem internet.")
                                    Text("Dados © OpenStreetMap contributors • ODbL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    if (selectedSection == "Ajuda") item {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("Ajuda", style = MaterialTheme.typography.headlineSmall, color = brandNavy)
                                Text("Versão $appVersionName · toque em um tópico para abrir", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            CollapsibleCard("Novidades desta versão", defaultExpanded = true) {
                                HelpText("• Ao abrir o app sem monitoramento ativo, aparece “O que deseja fazer?”: Destino único, Roteiro ou continuar para o app.")
                                HelpText("• Destino único é a viagem rápida: você informa o destino e o monitoramento já começa ao salvar.")
                                HelpText("• O app já vem com áudios próprios: “Desembarque na próxima parada” (trem/metrô e ônibus no raio) e “Atenção” (ônibus, aviso por distância). Você pode trocar quando quiser.")
                                HelpText("• Cada destino é Trem/Metrô ou Ônibus. O raio já vem preenchido (300 m no trem/metrô, 60 m no ônibus) e você pode alterar.")
                                HelpText("• Ônibus tem dois alertas: um ao chegar à distância de aviso (padrão 300 m) e outro ao entrar no raio.")
                                HelpText("• Som próprio para trem/metrô e para cada alerta do ônibus, em Preferências → Sons.")
                                HelpText("• Ao concluir o percurso toca um áudio de aviso e o monitoramento para sozinho.")
                                HelpText("• O alerta pode aparecer como notificação ou como pop-up na tela.")
                                HelpText("• Comentário curto em cada parada, visível em Roteiros e Destinos cadastrados.")
                                HelpText("• Quando a próxima parada já é a final, a notificação mostra só “Última parada”.")
                                HelpText("• Preferências reorganizadas em grupos, como as configurações do Android.")
                            }
                            CollapsibleCard("Como começar") {
                                HelpText("Ao abrir o app, escolha no pop-up “O que deseja fazer?”:")
                                HelpText("• Destino único: informe o destino (busca, mapa ou coordenadas), escolha Trem/Metrô ou Ônibus e toque em “Salvar e iniciar monitoramento”. É uma viagem esporádica: o monitoramento começa na hora e o destino fica salvo com alerta único.")
                                HelpText("• Roteiro: escolha um roteiro cadastrado e toque em iniciar no Início. Se ainda não houver roteiros, o app abre o cadastro das paradas.")
                                HelpText("• Continuar para o app: você navega livremente, sem iniciar nada.")
                                HelpText("Você também pode cadastrar destinos antes em “Adicionar destino” e iniciar pelo Início.")
                            }
                            CollapsibleCard("Trem/metrô e ônibus") {
                                HelpText("Trem/Metrô: um alerta ao entrar no raio do destino (padrão 300 m).")
                                HelpText("Ônibus: raio menor (padrão 60 m) e um aviso antecipado por distância, que toca uma vez ao chegar à distância configurada (padrão 300 m, sempre maior que o raio) e depois o alerta do raio. Se o GPS já te encontrar dentro do raio, só o alerta do raio toca.")
                                HelpText("Em Preferências → Sons você escolhe o som de cada alerta e pode testá-lo. Por padrão, trem/metrô e a chegada no raio do ônibus usam “Desembarque na próxima parada”, e o aviso por distância do ônibus usa “Atenção”. “Restaurar sons padrão do app” volta a esses áudios.")
                            }
                            CollapsibleCard("Destinos e roteiros") {
                                HelpText("Use “Destinos cadastrados” para consultar, ativar, editar, ver no mapa ou excluir locais. A exclusão pede confirmação.")
                                HelpText("Para montar um roteiro, cadastre várias paradas com o mesmo nome de roteiro. O monitoramento considera as paradas habilitadas do roteiro selecionado, na ordem; confira antes de iniciar.")
                                HelpText("Cada parada aceita um comentário curto (até 80 caracteres), útil para lembretes como “descer pela saída B”. Ele aparece só em Roteiros e Destinos cadastrados, nunca no Início.")
                                HelpText("Importação em lote por CSV: colunas nome, latitude, longitude, raio_metros, mensagem, roteiro, tipo (trem ou onibus) e comentario. As três primeiras são obrigatórias. Confira o relatório antes de importar.")
                            }
                            CollapsibleCard("Alertas, sons e pop-up") {
                                HelpText("O alerta dispara quando a localização entra no raio. Toque em OK para parar o som ou em Soneca 5 min para silenciar novos alertas por esse período.")
                                HelpText("Forma de exibir: Notificação (padrão) ou Pop-up na tela, que abre em primeiro plano com OK, Soneca e Abrir app. Para abrir sobre outros apps o Android pede a permissão “Exibir sobre outros apps”; sem ela o pop-up só abre com a tela bloqueada.")
                                HelpText("O Modo alarme toca como alarme, mesmo com a mídia no mudo, e repete até você tocar em OK (máximo 60 s).")
                                HelpText("O alerta antecipado avisa alguns minutos antes, por uma estimativa com distância em linha reta e velocidade do GPS. Não é previsão de rota.")
                            }
                            CollapsibleCard("Fim do percurso") {
                                HelpText("Ao chegar à parada final (último ponto do roteiro, ou o destino único), o alerta toca uma vez e em seguida vem o áudio de percurso concluído. Você pode desligá-lo em Preferências → Alertas.")
                                HelpText("O GPS é desligado na hora, o painel mostra o monitoramento parado e a notificação fixa some em cerca de 5 segundos. Para um novo trajeto, inicie o monitoramento de novo.")
                                HelpText("Na penúltima parada, quando a próxima já é a final, a notificação mostra “Última parada” sem repetir informações.")
                            }
                            CollapsibleCard("Estações e navegação ferroviária") {
                                HelpText("Na seção Estações, abra o Overpass Turbo, enquadre uma área pequena, copie a consulta de estações ou de linhas/rotas, execute e exporte em GeoJSON. Importe os arquivos no app; se der timeout, diminua a área e repita. Você pode importar várias áreas do mesmo tipo.")
                                HelpText("Com os dois tipos de dados, o app estima a estação anterior, atual e próxima pelo GPS e pela malha ferroviária. O mapa mostra linhas e estações, que podem ser tocadas para ver o nome.")
                                HelpText("A estimativa pode errar em ramificações, linhas paralelas, dados incompletos ou túneis, e não confirma que você está dentro de um trem.")
                            }
                            CollapsibleCard("Preferências") {
                                HelpText("As Preferências são organizadas em grupos: Alertas, Sons, Saída de áudio, Monitoramento e bateria, Mapa, e Dados e permissões. Toque em uma linha para alterar; as que mostram uma seta abrem uma lista de opções.")
                                HelpText("Perfil de bateria: Precisão usa o intervalo escolhido com localização de alta precisão; Equilibrado e Economia reduzem as atualizações longe dos destinos e aumentam ao se aproximar.")
                            }
                            CollapsibleCard("Backup e recuperação") {
                                HelpText("Em Preferências → Dados e permissões, toque em Criar backup e escolha onde salvar o arquivo JSON. Ele inclui destinos, roteiros, preferências e dados ferroviários.")
                                HelpText("Restaurar backup substitui os dados atuais e interrompe o monitoramento. Guarde o arquivo fora do celular.")
                            }
                            CollapsibleCard("Solução de problemas") {
                                HelpText("• Sem som: confira Ativar som, o volume do alerta, o canal de áudio, a saída e se o som daquele alerta não está em “Silencioso”. Em Sons, “Restaurar sons padrão do app” volta ao áudio incluso.")
                                HelpText("• O pop-up “O que deseja fazer?” não apareceu: ele só abre quando não há monitoramento ativo.")
                                HelpText("• Sem notificação: permita notificações nas configurações do Android e confira o canal do aplicativo.")
                                HelpText("• Pop-up não abre: permita “Exibir sobre outros apps” (e, no Android 14 ou mais novo, notificações em tela cheia) para o Alerta Geográfico.")
                                HelpText("• Alerta atrasado ou impreciso: permita localização precisa, ligue o GPS e confira o perfil de bateria. Raios pequenos exigem mais precisão.")
                                HelpText("• Monitoramento parou sozinho: é o esperado ao concluir o percurso. Se parar antes, confira as restrições de bateria do Android.")
                                HelpText("• Destino não encontrado: tente um endereço mais completo ou escolha o ponto no mapa.")
                            }
                        }
                    }
                    if (selectedSection == "Sobre") item {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Alerta Geográfico", style = MaterialTheme.typography.headlineSmall, color = brandNavy)
                                    Text("Versão $appVersionName", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("Criado por Daniel Jr", style = MaterialTheme.typography.titleMedium)
                                }
                            }
                            CollapsibleCard("Propósito", defaultExpanded = true) {
                                HelpText("O Alerta Geográfico avisa quando você está chegando a um lugar importante durante um deslocamento. Você cadastra destinos, ou organiza paradas em roteiros, define uma área de proximidade e recebe o aviso quando o aparelho detecta que você chegou perto.")
                                HelpText("A ideia é deixar viagens e deslocamentos mais tranquilos, sem depender de lembrar sozinho a hora de descer.")
                            }
                            CollapsibleCard("O que o app faz") {
                                HelpText("• Pergunta, ao abrir, se você quer um destino único (viagem rápida), um roteiro ou só usar o app.")
                                HelpText("• Destinos de trem/metrô e de ônibus, com raio padrão e sons próprios para cada tipo.")
                                HelpText("• Aviso por distância e alerta de chegada para ônibus.")
                                HelpText("• Roteiros com várias paradas e comentários curtos.")
                                HelpText("• Alerta em notificação ou pop-up, vibração, modo alarme e soneca.")
                                HelpText("• Áudio de percurso concluído e encerramento automático do monitoramento.")
                                HelpText("• Estimativa de estação anterior, atual e próxima com dados importados do OpenStreetMap.")
                                HelpText("• Backup e restauração dos seus dados.")
                            }
                            CollapsibleCard("Mapas e dados") {
                                HelpText("Os dados de estações e linhas são importados por você a partir do OpenStreetMap: © OpenStreetMap contributors, licença ODbL. O mapa base usa OpenFreeMap e precisa de internet.")
                                HelpText("Os GeoJSON importados ficam no armazenamento privado do app e funcionam sem internet. A busca de locais e o mapa base podem usar serviços externos.")
                            }
                            CollapsibleCard("Áudio") {
                                HelpText("Os áudios inclusos no app (percurso concluído, “Desembarque na próxima parada” e “Atenção”) são narrações; o de percurso concluído foi gerado com ElevenLabs. Você pode escolher qualquer som do aparelho para cada alerta.")
                            }
                            CollapsibleCard("Permissões e limitações") {
                                HelpText("O app usa localização (de preferência precisa), notificações e, de forma opcional, “Exibir sobre outros apps” e notificações em tela cheia, só para o pop-up.")
                                HelpText("Os alertas dependem das permissões do Android, da precisão da localização e das configurações de notificação e bateria do aparelho. A navegação ferroviária é uma estimativa. O app não substitui a atenção ao trajeto.")
                            }
                        }
                    }
                }
            }
            }
        }
    }
}
