package com.storageanalyzer.ultra

import com.storageanalyzer.ultra.core.DiskScanner
import com.storageanalyzer.ultra.core.DuplicateGroup
import com.storageanalyzer.ultra.core.Duplicates
import com.storageanalyzer.ultra.core.Format
import com.storageanalyzer.ultra.core.PathGuard
import com.storageanalyzer.ultra.core.QuarantineStore
import com.storageanalyzer.ultra.core.ReportData
import com.storageanalyzer.ultra.core.ReportFile
import com.storageanalyzer.ultra.core.Reports
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class CoreTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun write(f: File, text: String) { f.parentFile?.mkdirs(); f.writeText(text) }

    // ---------- scanner ----------
    @Test fun scanner_aggregates_sizes_and_indexes() = runBlocking {
        val root = tmp.newFolder("root")
        write(File(root, "a/x.bin"), "x".repeat(100))
        write(File(root, "a/b/y.bin"), "y".repeat(50))
        write(File(root, "z.txt"), "z".repeat(10))
        val r = DiskScanner().scan(root.path)
        assertEquals(160L, r.root.size)
        assertEquals(3L, r.fileCount)
        assertEquals(150L, r.node(File(root, "a").path)!!.size)
        assertEquals(listOf("x.bin"), r.search(query = "x.bin").map { it.name })
        assertEquals(1, r.search(extension = "txt").size)
    }

    @Test fun scanner_remove_subtree_updates_ancestors() = runBlocking {
        val root = tmp.newFolder("root2")
        write(File(root, "a/x.bin"), "x".repeat(100))
        write(File(root, "k.bin"), "k".repeat(7))
        val r = DiskScanner().scan(root.path)
        val removed = r.removeSubtree(File(root, "a").path)
        assertEquals(100L, removed)
        assertEquals(7L, r.root.size)
        assertNull(r.node(File(root, "a/x.bin").path))
    }

    @Test fun scanner_cancellation() {
        val root = tmp.newFolder("root3")
        repeat(30) { write(File(root, "d$it/f.bin"), "1") }
        val job = runBlocking {
            val d = async(Dispatchers.Default) { DiskScanner().scan(root.path) }
            d.cancel()
            try { d.await(); false } catch (e: CancellationException) { true }
        }
        assertTrue(job)
    }

    // ---------- duplicados ----------
    @Test fun duplicates_use_content_not_size() = runBlocking {
        val root = tmp.newFolder("dup")
        write(File(root, "a.txt"), "A".repeat(20))
        write(File(root, "b.txt"), "A".repeat(20))      // idêntico a a.txt
        write(File(root, "c.txt"), "B".repeat(20))      // mesmo tamanho, conteúdo diferente
        val r = DiskScanner().scan(root.path)
        val groups = Duplicates.find(r.allFiles(), minSize = 1)
        assertEquals(1, groups.size)
        assertEquals(setOf("a.txt", "b.txt"), groups[0].paths.map { File(it).name }.toSet())
        assertEquals(20L, groups[0].recoverableBytes)
    }

    @Test fun duplicates_big_files_need_full_hash() = runBlocking {
        val root = tmp.newFolder("dupbig")
        val head = "H".repeat(Duplicates.PARTIAL_BYTES)
        write(File(root, "a.bin"), head + "tail1")
        write(File(root, "b.bin"), head + "tail2")       // mesmo começo e tamanho, final diferente
        val r = DiskScanner().scan(root.path)
        assertTrue(Duplicates.find(r.allFiles(), 1).isEmpty())
    }

    // ---------- proteção de caminhos ----------
    @Test fun guard_protects_roots_android_dirs_and_system() {
        val g = PathGuard(listOf("/storage/emulated/0"))
        assertTrue(g.isProtected("/storage/emulated/0"))
        assertTrue(g.isProtected("/storage/emulated"))
        assertTrue(g.isProtected("/storage/emulated/0/Android"))
        assertTrue(g.isProtected("/storage/emulated/0/Android/data/com.x/files"))
        assertTrue(g.isProtected("/storage/emulated/0/Android/obb"))
        assertTrue(g.isProtected("/system/app"))
        assertTrue(g.isProtected("relativo/caminho"))
        assertTrue(g.isProtected("/storage/emulated/0/../../.."))   // normaliza antes de decidir
        assertFalse(g.isProtected("/storage/emulated/0/Download/a.zip"))
        assertFalse(g.isProtected("/storage/emulated/0/Android/media/com.whatsapp"))
    }

    // ---------- quarentena ----------
    @Test fun quarantine_move_restore_purge() {
        val dir = tmp.newFolder("q")
        val store = QuarantineStore(File(dir, "Quarantine"))
        val f = File(tmp.root, "data/file.txt").also { write(it, "hello") }
        val res = store.moveInBatch(listOf(f.path), "test")
        assertEquals(1, res.moved.size)
        assertFalse(f.exists())                              // saiu do lugar original
        assertEquals(5L, store.totalBytes())
        val (ok, failed) = store.restoreCategory("test")
        assertEquals(1, ok); assertEquals(0, failed)
        assertEquals("hello", f.readText())                  // voltou ao caminho exato
        assertEquals(0L, store.totalBytes())

        store.moveInBatch(listOf(f.path), "test")
        assertEquals(5L, store.purge())                      // só aqui libera de verdade
        assertTrue(store.entries().isEmpty())
    }

    @Test fun quarantine_restore_does_not_overwrite_existing() {
        val store = QuarantineStore(File(tmp.newFolder("q2"), "Quarantine"))
        val f = File(tmp.root, "d2/a.txt").also { write(it, "old") }
        store.moveInBatch(listOf(f.path), "c")
        write(f, "new")                                      // alguém recriou o arquivo
        store.restoreCategory("c")
        assertEquals("new", f.readText())
        assertEquals("old", File(f.parentFile, "a (restaurado).txt").readText())
    }

    @Test fun quarantine_missing_path_counts_as_failure() {
        val store = QuarantineStore(File(tmp.newFolder("q3"), "Quarantine"))
        val r = store.moveInBatch(listOf(File(tmp.root, "nao-existe").path), "c")
        assertEquals(1, r.failed); assertTrue(r.moved.isEmpty())
    }

    // ---------- relatórios ----------
    private fun sample(path: String) = ReportData(
        0L, "App", "1", emptyList(), null, 0, 0,
        listOf(ReportFile(path, 10, 0)), listOf(DuplicateGroup("h", 1, listOf(path, path))), emptyList(), 0,
    )

    @Test fun html_report_escapes_markup() {
        val html = Reports.html(sample("<script>alert(1)</script>"))
        assertFalse(html.contains("<script>alert"))
        assertTrue(html.contains("&lt;script&gt;"))
    }

    @Test fun csv_report_neutralizes_formulas() {
        assertEquals("\"'=HYPERLINK(1)\"", Reports.csvCell("=HYPERLINK(1)"))
        assertEquals("\"a\"\"b\"", Reports.csvCell("a\"b"))
    }

    @Test fun json_report_is_valid() {
        val obj = org.json.JSONObject(Reports.json(sample("/x")))
        assertNotNull(obj.getJSONArray("large_files"))
    }

    @Test fun format_bytes() {
        assertEquals("512 B", Format.bytes(512))
        assertTrue(Format.bytes(1536).startsWith("1") && Format.bytes(1536).endsWith("KB"))
    }
}
