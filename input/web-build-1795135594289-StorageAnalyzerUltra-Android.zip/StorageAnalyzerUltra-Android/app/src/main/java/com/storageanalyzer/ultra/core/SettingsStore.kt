package com.storageanalyzer.ultra.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(val time: Long, val text: String)

/** Configurações em SharedPreferences: tema, histórico de ações e aceite do termo (equivalente a settings.py + terms.json). */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var theme: String
        get() = prefs.getString("theme", "system") ?: "system"   // system | light | dark
        set(v) = prefs.edit().putString("theme", v).apply()

    fun termsAccepted(): Boolean = prefs.getString("terms_version", null) == About.TERMS_VERSION

    fun acceptTerms() {
        prefs.edit().putString("terms_version", About.TERMS_VERSION)
            .putLong("terms_time", System.currentTimeMillis()).apply()
    }

    fun history(): List<HistoryItem> = try {
        val arr = JSONArray(prefs.getString("history", "[]"))
        (0 until arr.length()).map { arr.getJSONObject(it).let { o -> HistoryItem(o.getLong("t"), o.getString("x")) } }
    } catch (e: Exception) { emptyList() }

    @Synchronized
    fun addHistory(text: String) {
        val list = (listOf(HistoryItem(System.currentTimeMillis(), text)) + history()).take(200)
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.time).put("x", it.text)) }
        prefs.edit().putString("history", arr.toString()).apply()
    }

    fun clearHistory() = prefs.edit().remove("history").apply()
}
