package com.storageanalyzer.ultra.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF4CC2FF), onPrimary = Color(0xFF00344D),
    background = Color(0xFF1B1B1F), surface = Color(0xFF1B1B1F),
    surfaceVariant = Color(0xFF2B2D33),
)
private val Light = lightColorScheme(primary = Color(0xFF0078D4))

@Composable
fun StorageTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
