package com.storageanalyzer.ultra.core

import java.io.File

class CleanupContext(val roots: List<String>, val scan: ScanResult?)

/** Definição de categoria como DADOS (igual ao get_definitions do Python): adicionar uma é só uma entrada na lista. */
class CleanupCategory(
    val id: String,
    val name: String,
    val description: String,
    val risk: Risk,
    val cleanable: Boolean = true,
    val requiresScan: Boolean = false,           // regras por extensão usam o índice do scan
    val collect: (CleanupContext) -> List<File>, // itens (arquivos ou pastas) que seriam movidos
)

data class CleanupDetection(
    val id: String,
    val name: String,
    val description: String,
    val risk: Risk,
    val cleanable: Boolean,
    val needsScan: Boolean,
    val sizeBytes: Long,
    val fileCount: Int,
    val items: List<String>,
    val canRestore: Boolean,
)

data class CleanResult(val movedPaths: List<String>, val failed: Int, val bytes: Long)

class CleanupService(private val store: QuarantineStore, private val roots: () -> List<String>) {

    private val tempExt = setOf(".tmp", ".temp", ".cache")
    private val logExt = setOf(".log", ".dmp", ".hprof", ".trace")
    private val apkExt = setOf(".apk", ".apks", ".xapk", ".apkm")
    private val archiveExt = setOf(".zip", ".rar", ".7z", ".iso", ".tar", ".gz", ".img")
    private val backupExt = setOf(".bak", ".old", ".orig")

    private fun contentsOf(ctx: CleanupContext, vararg relative: String): List<File> =
        ctx.roots.flatMap { r -> relative.flatMap { File(r, it).listFiles()?.toList() ?: emptyList() } }

    private fun scanFiles(ctx: CleanupContext, guard: PathGuard, pred: (ScanNode) -> Boolean): List<File> =
        ctx.scan?.index?.values.orEmpty()
            .filter { !it.isDir && !guard.isInsideAndroidDir(it.path) && pred(it) }
            .map { File(it.path) }

    fun definitions(): List<CleanupCategory> = listOf(
        CleanupCategory("thumbnails", "Miniaturas de fotos",
            "Cache de miniaturas da galeria (.thumbnails). O Android recria sozinho.", Risk.SAFE) { ctx ->
            contentsOf(ctx, "DCIM/.thumbnails", "Pictures/.thumbnails", ".thumbnails")
        },
        CleanupCategory("temp_files", "Arquivos temporários",
            "Arquivos .tmp, .temp, .cache e .thumbdata deixados por apps.", Risk.SAFE, requiresScan = true) { ctx ->
            val g = PathGuard(ctx.roots)
            scanFiles(ctx, g) { it.extension in tempExt || it.name.startsWith(".thumbdata") }
        },
        CleanupCategory("logs", "Logs e dumps",
            "Arquivos .log, .dmp, .hprof e .trace fora das pastas de dados de apps.", Risk.SAFE, requiresScan = true) { ctx ->
            val g = PathGuard(ctx.roots)
            scanFiles(ctx, g) { it.extension in logExt }
        },
        CleanupCategory("lost_dir", "LOST.DIR (cartão SD)",
            "Fragmentos de arquivos recuperados após falhas no cartão.", Risk.SAFE) { ctx ->
            contentsOf(ctx, "LOST.DIR")
        },
        CleanupCategory("apk_files", "Instaladores (APK)",
            "Arquivos de instalação já baixados. Se o app já está instalado, o APK costuma ser dispensável.",
            Risk.MODERATE, requiresScan = true) { ctx ->
            val g = PathGuard(ctx.roots)
            scanFiles(ctx, g) { it.extension in apkExt }
        },
        CleanupCategory("download_archives", "Compactados e imagens em Download",
            "ZIP, RAR, 7z, ISO etc. na pasta Download. Confira antes: podem ser seus backups.",
            Risk.MODERATE, requiresScan = true) { ctx ->
            val g = PathGuard(ctx.roots)
            scanFiles(ctx, g) { n ->
                n.extension in archiveExt && ctx.roots.any { n.path.startsWith("$it/Download/") }
            }
        },
        CleanupCategory("screenshots", "Capturas de tela",
            "Prints salvos em Screenshots. Podem conter informações que você quer guardar.", Risk.MODERATE) { ctx ->
            contentsOf(ctx, "Pictures/Screenshots", "DCIM/Screenshots", "Screenshots")
        },
        CleanupCategory("messaging_sent", "Mídia enviada (WhatsApp)",
            "Cópias locais de mídia que VOCÊ enviou (pastas \"Sent\"). O destinatário mantém a dele.", Risk.MODERATE) { ctx ->
            val bases = listOf(
                "Android/media/com.whatsapp/WhatsApp/Media", "WhatsApp/Media",
                "Android/media/com.whatsapp.w4b/WhatsApp Business/Media",
            )
            ctx.roots.flatMap { r ->
                bases.flatMap { b ->
                    File(r, b).listFiles()?.filter { it.isDirectory }.orEmpty().flatMap { media ->
                        File(media, "Sent").listFiles()?.toList().orEmpty()
                    }
                }
            }
        },
        CleanupCategory("backup_files", "Backups antigos (.bak/.old)",
            "Cópias de segurança de apps e editores. Verifique se não são as únicas que você tem.",
            Risk.MODERATE, requiresScan = true) { ctx ->
            val g = PathGuard(ctx.roots)
            scanFiles(ctx, g) { it.extension in backupExt }
        },
        CleanupCategory("obb", "Dados de jogos (Android/obb)",
            "Só visualização: dados pesados de jogos. Apagar obriga a baixar tudo de novo — use a Play Store/configurações do app.",
            Risk.RISKY, cleanable = false) { ctx ->
            contentsOf(ctx, "Android/obb")
        },
    )

    fun detect(scan: ScanResult?, onProgress: (String) -> Unit = {}): List<CleanupDetection> =
        definitions().map { onProgress("Analisando ${it.name}…"); detectOne(it, scan) }

    fun detectOne(def: CleanupCategory, scan: ScanResult?): CleanupDetection {
        val r = roots()
        val needsScan = def.requiresScan && scan == null
        val guard = PathGuard(r)
        val items = if (needsScan) emptyList() else
            def.collect(CleanupContext(r, scan)).filter { !def.cleanable || !guard.isProtected(it.path) }
        var size = 0L
        var count = 0
        for (f in items) { val (s, c) = Fs.sizeAndCount(f); size += s; count += c }
        return CleanupDetection(
            def.id, def.name, def.description, def.risk, def.cleanable, needsScan,
            size, count, items.map { it.path }, store.hasCategory(def.id),
        )
    }

    fun clean(id: String, scan: ScanResult?, onProgress: (String) -> Unit = {}): CleanResult {
        val def = definitions().first { it.id == id }
        require(def.cleanable) { "Esta categoria é somente visualização." }
        val det = detectOne(def, scan)
        val batch = store.moveInBatch(det.items, id) { done, total -> onProgress("Movendo para a quarentena… $done/$total") }
        return CleanResult(batch.moved.map { it.original }, batch.failed, batch.moved.sumOf { it.size })
    }
}
