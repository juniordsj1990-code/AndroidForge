package com.storageanalyzer.ultra.core

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Format {
    fun bytes(n: Long): String {
        var v = n.toDouble()
        if (v < 1024) return "${n} B"
        for (unit in listOf("KB", "MB", "GB", "TB")) {
            v /= 1024
            if (v < 1024 || unit == "TB") return String.format(Locale.getDefault(), "%.1f %s", v, unit)
        }
        return "${n} B"
    }

    fun date(millis: Long): String =
        if (millis <= 0) "—" else SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(millis))

    fun dateTime(millis: Long): String =
        if (millis <= 0) "—" else SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(millis))

    fun duration(ms: Long): String {
        val s = ms / 1000
        return if (s < 60) "${s}s" else "${s / 60}min ${s % 60}s"
    }
}
