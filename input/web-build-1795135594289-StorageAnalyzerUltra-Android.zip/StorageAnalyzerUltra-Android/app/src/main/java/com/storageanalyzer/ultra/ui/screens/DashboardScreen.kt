package com.storageanalyzer.ultra.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.storageanalyzer.ultra.core.Format
import com.storageanalyzer.ultra.core.VolumeInfo
import com.storageanalyzer.ultra.ui.AppViewModel
import com.storageanalyzer.ultra.ui.InfoCard
import com.storageanalyzer.ultra.ui.ScanUi

@Composable
fun DashboardScreen(vm: AppViewModel, onRequestStorage: () -> Unit) {
    val volumes by vm.volumes.collectAsState()
    val scanUi by vm.scanUi.collectAsState()
    val hasAccess by vm.hasAllFiles.collectAsState()
    val quarantine by vm.quarantineBytes.collectAsState()

    LazyColumn(Modifier.fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (!hasAccess) item {
            InfoCard(
                "Para analisar e limpar o armazenamento, o app precisa do acesso “Todos os arquivos”. " +
                    "Ele só é usado para o que você pedir, e você pode revogar quando quiser.",
                "Conceder acesso", onRequestStorage,
            )
        }
        if (scanUi is ScanUi.Failed) item { InfoCard("Falha no scan: ${(scanUi as ScanUi.Failed).message}") }
        items(volumes, key = { it.path }) { v -> VolumeCard(vm, v, scanUi, hasAccess) }
        if (quarantine > 0) item {
            InfoCard("Quarentena: ${Format.bytes(quarantine)} ainda ocupando espaço. Esvazie em Limpeza para liberar de verdade.")
        }
    }
}

@Composable
private fun VolumeCard(vm: AppViewModel, v: VolumeInfo, scanUi: ScanUi, hasAccess: Boolean) {
    val running = (scanUi as? ScanUi.Running)?.takeIf { it.root == v.path }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(v.label, style = MaterialTheme.typography.titleMedium)
            Text(v.path, style = MaterialTheme.typography.bodySmall)
            LinearProgressIndicator(progress = { v.usedFraction }, modifier = Modifier.fillMaxWidth())
            Text("${Format.bytes(v.usedBytes)} usados de ${Format.bytes(v.totalBytes)} • ${Format.bytes(v.freeBytes)} livres (${(v.usedFraction * 100).toInt()}%)")
            if (running != null) {
                val p = running.progress
                Text("Escaneando… ${p.files} arquivos • ${p.dirs} pastas • ${Format.bytes(p.bytes)} • ${Format.duration(p.elapsedMs)}")
                OutlinedButton(onClick = vm::cancelScan) { Text("Cancelar") }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.startScan(v.path) }, enabled = hasAccess && scanUi !is ScanUi.Running) { Text("Escanear") }
                }
            }
        }
    }
}
