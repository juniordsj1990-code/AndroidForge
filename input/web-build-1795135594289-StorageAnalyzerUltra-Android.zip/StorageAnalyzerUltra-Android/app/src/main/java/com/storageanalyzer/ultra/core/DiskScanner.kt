package com.storageanalyzer.ultra.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.attribute.BasicFileAttributes
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/** Resultado de um scan: árvore + índice plano (caminho -> nó) para busca/arquivos grandes/duplicados sem novo scan. */
class ScanResult(
    val rootPath: String,
    val root: ScanNode,
    val index: ConcurrentHashMap<String, ScanNode>,
    val fileCount: Long,
    val dirCount: Long,
    val durationMs: Long,
) {
    fun node(path: String): ScanNode? = index[path]

    fun allFiles(): List<ScanNode> = index.values.filter { !it.isDir }

    fun search(query: String = "", minSize: Long = 0, extension: String = "", limit: Int = 2000): List<ScanNode> {
        val q = query.trim()
        val ext = extension.trim().lowercase().let { if (it.isEmpty() || it.startsWith(".")) it else ".$it" }
        return index.values.asSequence()
            .filter { it.path != rootPath }
            .filter { q.isEmpty() || it.name.contains(q, ignoreCase = true) }
            .filter { it.size >= minSize }
            .filter { ext.isEmpty() || it.extension == ext }
            .sortedByDescending { it.size }
            .take(limit)
            .toList()
    }

    fun largeFiles(topN: Int, minSize: Long = 0, query: String = ""): List<ScanNode> =
        index.values.asSequence()
            .filter { !it.isDir && it.size >= minSize }
            .filter { query.isBlank() || it.name.contains(query.trim(), ignoreCase = true) }
            .sortedByDescending { it.size }
            .take(topN)
            .toList()

    /** Remove o nó (e descendentes) do índice/árvore e abate o tamanho dos ancestrais. Retorna bytes removidos. */
    fun removeSubtree(path: String): Long {
        if (path == rootPath) return 0L
        val node = index[path] ?: return 0L
        val removed = node.size
        val stack = ArrayDeque<ScanNode>()
        stack.add(node)
        while (stack.isNotEmpty()) {
            val n = stack.removeLast()
            index.remove(n.path)
            n.children?.let { stack.addAll(it) }
        }
        var parentPath: String? = File(path).parent
        index[parentPath ?: ""]?.children?.remove(node)
        while (parentPath != null) {
            index[parentPath]?.let { it.size -= removed }
            if (parentPath == rootPath) break
            parentPath = File(parentPath).parent
        }
        return removed
    }
}

class DiskScanner(private val ioParallelism: Int = 8) {

    private class Ctx(
        val permits: Semaphore,
        val index: ConcurrentHashMap<String, ScanNode> = ConcurrentHashMap(),
        val files: AtomicLong = AtomicLong(),
        val dirs: AtomicLong = AtomicLong(),
        val bytes: AtomicLong = AtomicLong(),
    )

    /** Cancelável: cancele a coroutine que chamou. Tolera pastas sem permissão (marca accessDenied). */
    suspend fun scan(rootPath: String, onProgress: (ScanProgress) -> Unit = {}): ScanResult =
        withContext(Dispatchers.IO) {
            val started = System.nanoTime()
            val ctx = Ctx(Semaphore(ioParallelism))
            fun snapshot(done: Boolean) = ScanProgress(
                ctx.files.get(), ctx.dirs.get(), ctx.bytes.get(), (System.nanoTime() - started) / 1_000_000, done,
            )

            val ticker = launch {
                while (true) {
                    delay(250)
                    onProgress(snapshot(false))
                }
            }
            try {
                val root = scanDir(File(rootPath), 0, ctx)
                ticker.cancel()
                val last = snapshot(true)
                onProgress(last)
                ScanResult(rootPath, root, ctx.index, last.files, last.dirs, last.elapsedMs)
            } finally {
                ticker.cancel()
            }
        }

    private suspend fun scanDir(dir: File, depth: Int, ctx: Ctx): ScanNode {
        currentCoroutineContext().ensureActive()
        ctx.dirs.incrementAndGet()
        val node = ScanNode(
            name = dir.name.ifEmpty { dir.path },
            path = dir.path,
            isDir = true,
            modified = dir.lastModified(),
            children = ArrayList(),
        )
        ctx.index[node.path] = node

        val subdirs = ArrayList<File>()
        val listed = ctx.permits.withPermit { listInto(dir, node, subdirs, ctx) }
        if (!listed) {
            node.accessDenied = true
            return node
        }

        val kids = node.children!!
        if (depth < 2 && subdirs.size > 1) {
            val results = coroutineScope { subdirs.map { async { scanDir(it, depth + 1, ctx) } }.awaitAll() }
            kids.addAll(results)
        } else {
            for (s in subdirs) kids.add(scanDir(s, depth + 1, ctx))
        }
        node.size = kids.sumOf { it.size }
        return node
    }

    /** Lista a pasta e cria os nós de arquivo; devolve false se não foi possível listar. */
    private fun listInto(dir: File, node: ScanNode, subdirs: MutableList<File>, ctx: Ctx): Boolean {
        val entries: Array<File>? = try { dir.listFiles() } catch (e: SecurityException) { null }
        if (entries == null) return false
        for (f in entries) {
            val attrs = try {
                Files.readAttributes(f.toPath(), BasicFileAttributes::class.java, LinkOption.NOFOLLOW_LINKS)
            } catch (e: Exception) {
                continue
            }
            when {
                attrs.isSymbolicLink -> continue            // evita loops/contagem em dobro
                attrs.isDirectory -> subdirs.add(f)
                attrs.isRegularFile -> {
                    val size = attrs.size()
                    val child = ScanNode(
                        name = f.name, path = f.path, isDir = false, size = size,
                        modified = attrs.lastModifiedTime().toMillis(), extension = extensionOf(f.name),
                    )
                    node.children!!.add(child)
                    ctx.index[child.path] = child
                    ctx.files.incrementAndGet()
                    ctx.bytes.addAndGet(size)
                }
            }
        }
        return true
    }

    companion object {
        fun extensionOf(name: String): String {
            val i = name.lastIndexOf('.')
            return if (i < 0) "" else name.substring(i).lowercase()
        }
    }
}
