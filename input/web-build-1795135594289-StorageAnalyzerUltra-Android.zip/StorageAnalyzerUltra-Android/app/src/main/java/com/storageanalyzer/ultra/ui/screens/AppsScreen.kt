package com.storageanalyzer.ultra.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.storageanalyzer.ultra.core.AppEntry
import com.storageanalyzer.ultra.core.AppsService
import com.storageanalyzer.ultra.core.Format
import com.storageanalyzer.ultra.core.Permissions
import com.storageanalyzer.ultra.ui.AppIcon
import com.storageanalyzer.ultra.ui.AppViewModel
import com.storageanalyzer.ultra.ui.ConfirmDialog
import com.storageanalyzer.ultra.ui.InfoCard

private enum class AppSort(val label: String) {
    SIZE("Maiores"), CACHE("Maior cache"), OLD("Mais antigos"), UNUSED("Sem uso (90d+)"), NAME("Nome")
}

@Composable
fun AppsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val ui by vm.appsUi.collectAsState()
    LaunchedEffect(Unit) { if (!ui.loaded) vm.loadApps() }

    var query by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(AppSort.SIZE) }
    var showSystem by remember { mutableStateOf(false) }
    var toUninstall by remember { mutableStateOf<AppEntry?>(null) }

    val now = System.currentTimeMillis()
    val list = remember(ui.apps, query, sort, showSystem) {
        val base = ui.apps.filter { (showSystem || !it.isSystem) && (query.isBlank() || it.label.contains(query, true) || it.packageName.contains(query, true)) }
        when (sort) {
            AppSort.SIZE -> base.sortedByDescending { it.sizeBytes ?: -1L }
            AppSort.CACHE -> base.sortedByDescending { it.cacheBytes ?: -1L }
            AppSort.OLD -> base.sortedBy { if (it.installTime <= 0) Long.MAX_VALUE else it.installTime }
            AppSort.UNUSED -> base.filter { AppsService.isPossiblyUnused(it, now) }.sortedBy { it.lastUsed ?: Long.MAX_VALUE }
            AppSort.NAME -> base.sortedBy { it.label.lowercase() }
        }
    }

    Column(Modifier.fillMaxWidth()) {
        if (!ui.usageAccess) {
            InfoCard(
                "Sem o acesso especial “Acesso ao uso”, o Android não informa tamanho nem último uso dos apps. " +
                    "Conceda e volte ao app para ver esses dados.",
                "Conceder acesso ao uso",
            ) { Permissions.openUsageAccessSettings(ctx) }
        }
        Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(query, { query = it }, label = { Text("Buscar app") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppSort.entries.forEach { s -> FilterChip(selected = sort == s, onClick = { sort = s }, label = { Text(s.label) }) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(showSystem, { showSystem = it })
                Text("  Mostrar apps do sistema", style = MaterialTheme.typography.bodySmall)
            }
            if (ui.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        }
        LazyColumn(Modifier.fillMaxWidth()) {
            items(list, key = { it.packageName }) { a ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(a.packageName)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            buildString {
                                append(a.sizeBytes?.let { Format.bytes(it) } ?: "tamanho: —")
                                a.cacheBytes?.let { append(" • cache ${Format.bytes(it)}") }
                                append(" • instalado ${Format.date(a.installTime)}")
                                append(" • uso ${a.lastUsed?.let { Format.date(it) } ?: "—"}")
                            },
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        // "Informações" abre a tela do Android, onde o usuário pode limpar o cache do app.
                        TextButton(onClick = { Permissions.openAppDetails(ctx, a.packageName) }) { Text("Info / cache") }
                        if (!a.isSystem) TextButton(onClick = { toUninstall = a }) { Text("Desinstalar") }
                    }
                }
            }
        }
    }

    toUninstall?.let { a ->
        ConfirmDialog(
            title = "Desinstalar ${a.label}?",
            text = "O Android vai pedir a confirmação final. Os dados do app serão removidos${a.sizeBytes?.let { " (${Format.bytes(it)})" } ?: ""}.",
            confirmLabel = "Continuar",
            danger = true,
            onConfirm = { Permissions.requestUninstall(ctx, a.packageName) },
            onDismiss = { toUninstall = null },
        )
    }
}
