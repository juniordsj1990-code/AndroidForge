package com.storageanalyzer.ultra.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.storageanalyzer.ultra.core.About

@Composable
fun AboutScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("${About.APP_NAME} ${About.VERSION}", style = MaterialTheme.typography.headlineSmall)
        Text(About.TAGLINE, style = MaterialTheme.typography.bodyMedium)
        Text(About.PRESENTATION)
        Text("Finalidade", style = MaterialTheme.typography.titleMedium)
        About.PURPOSE.forEach { Text("• $it") }
        Text(About.CREATION, style = MaterialTheme.typography.bodySmall)
        Text(About.TERMS_TITLE, style = MaterialTheme.typography.titleMedium)
        About.TERMS.forEach { (t, x) -> Text(t, style = MaterialTheme.typography.titleSmall); Text(x, style = MaterialTheme.typography.bodySmall) }
    }
}

/** Tela de aceite na 1ª execução (e quando TERMS_VERSION muda). Recusar fecha o app. */
@Composable
fun TermsScreen(onAccept: () -> Unit, onDecline: () -> Unit) {
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.safeDrawingPadding().padding(16.dp)) {
            Text(About.TERMS_TITLE, style = MaterialTheme.typography.headlineSmall)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                About.TERMS.forEach { (t, x) -> Text(t, style = MaterialTheme.typography.titleSmall); Text(x, style = MaterialTheme.typography.bodyMedium) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onDecline, modifier = Modifier.weight(1f)) { Text("Recusar e sair") }
                Button(onClick = onAccept, modifier = Modifier.weight(1f)) { Text("Aceitar e continuar") }
            }
        }
    }
}
