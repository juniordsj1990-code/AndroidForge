package com.storageanalyzer.ultra.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.nio.file.Files
import java.nio.file.attribute.BasicFileAttributes
import java.security.MessageDigest

/**
 * Duplicados por SHA-256 real (nunca só por nome/tamanho). Pipeline barato -> caro:
 * tamanho igual -> hash dos primeiros 64 KB -> hash completo.
 */
object Duplicates {
    const val PARTIAL_BYTES = 64 * 1024

    fun groupBySize(files: List<ScanNode>, minSize: Long): Map<Long, List<String>> =
        files.asSequence()
            .filter { !it.isDir && it.size >= maxOf(minSize, 1L) }
            .groupBy({ it.size }, { it.path })
            .filterValues { it.size > 1 }

    fun sha256(path: String, limit: Long? = null, shouldStop: () -> Boolean = { false }): String? {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            FileInputStream(path).use { input ->
                val buf = ByteArray(64 * 1024)
                var remaining = limit ?: Long.MAX_VALUE
                while (remaining > 0) {
                    if (shouldStop()) return null
                    val n = input.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                    if (n < 0) break
                    md.update(buf, 0, n)
                    remaining -= n
                }
            }
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            null
        }
    }

    /** Remove hard links do mesmo arquivo físico (não liberam espaço). Sem fileKey, trata como distintos. */
    fun distinctByFileKey(paths: List<String>): List<String> {
        val seen = HashSet<Any>()
        val out = ArrayList<String>()
        for (p in paths) {
            val key = try {
                Files.readAttributes(File(p).toPath(), BasicFileAttributes::class.java).fileKey()
            } catch (e: Exception) { null }
            if (key == null || seen.add(key)) out.add(p)
        }
        return out
    }

    suspend fun find(
        files: List<ScanNode>,
        minSize: Long = 1,
        onProgress: (String) -> Unit = {},
    ): List<DuplicateGroup> = withContext(Dispatchers.IO) {
        val candidates = groupBySize(files, minSize)
        val result = ArrayList<DuplicateGroup>()
        var done = 0
        for ((size, rawPaths) in candidates) {
            ensureActive()
            done++
            if (done % 20 == 0 || done == candidates.size) onProgress("Comparando grupo $done de ${candidates.size}…")

            val paths = distinctByFileKey(rawPaths)
            if (paths.size < 2) continue

            val byPartial = HashMap<String, MutableList<String>>()
            for (p in paths) {
                val h = sha256(p, PARTIAL_BYTES.toLong()) { !isActive } ?: continue
                byPartial.getOrPut(h) { ArrayList() }.add(p)
            }
            ensureActive()
            for ((partialHash, group) in byPartial) {
                if (group.size < 2) continue
                if (size <= PARTIAL_BYTES) {               // o hash parcial já cobre o arquivo inteiro
                    result.add(DuplicateGroup(partialHash, size, group.sorted()))
                    continue
                }
                val byFull = HashMap<String, MutableList<String>>()
                for (p in group) {
                    val h = sha256(p, null) { !isActive } ?: continue
                    byFull.getOrPut(h) { ArrayList() }.add(p)
                }
                ensureActive()
                for ((fullHash, same) in byFull) {
                    if (same.size >= 2) result.add(DuplicateGroup(fullHash, size, same.sorted()))
                }
            }
        }
        result.sortByDescending { it.recoverableBytes }
        result
    }
}
