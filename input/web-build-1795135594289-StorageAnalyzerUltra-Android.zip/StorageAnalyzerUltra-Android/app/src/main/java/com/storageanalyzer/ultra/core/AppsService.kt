package com.storageanalyzer.ultra.core

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.Process
import android.os.storage.StorageManager

/**
 * Aplicativos instalados (substitui uninstaller.py + programs_stats.py). Diferença boa em relação ao Windows:
 * o Android dá tamanho real e ÚLTIMO USO real (não heurística) — mas só com o acesso especial "Acesso ao uso".
 */
class AppsService(private val context: Context) {

    fun hasUsageAccess(): Boolean {
        val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    @Suppress("DEPRECATION")
    fun load(onProgress: (String) -> Unit = {}): List<AppEntry> {
        val pm = context.packageManager
        val access = hasUsageAccess()
        val stats = context.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val lastUsedMap = if (access) {
            runCatching { usm.queryAndAggregateUsageStats(now - 365L * 24 * 3600 * 1000, now) }.getOrNull()
        } else null

        val infos = pm.getInstalledApplications(0)
        val result = ArrayList<AppEntry>(infos.size)
        infos.forEachIndexed { i, info ->
            if (i % 25 == 0) onProgress("Lendo aplicativos… $i/${infos.size}")
            val pkg = info.packageName
            val pi = runCatching { pm.getPackageInfo(pkg, 0) }.getOrNull()
            val system = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            var size: Long? = null
            var cache: Long? = null
            if (access) {
                runCatching {
                    val s = stats.queryStatsForPackage(StorageManager.UUID_DEFAULT, pkg, Process.myUserHandle())
                    size = s.appBytes + s.dataBytes
                    cache = s.cacheBytes
                }
            }
            val last = lastUsedMap?.get(pkg)?.lastTimeUsed?.takeIf { it > 0 }
            result.add(
                AppEntry(
                    packageName = pkg,
                    label = runCatching { pm.getApplicationLabel(info).toString() }.getOrDefault(pkg),
                    versionName = pi?.versionName ?: "",
                    installTime = pi?.firstInstallTime ?: 0L,
                    lastUsed = last,
                    sizeBytes = size,
                    cacheBytes = cache,
                    isSystem = system,
                )
            )
        }
        return result
    }

    companion object {
        const val UNUSED_DAYS = 90L
        fun isPossiblyUnused(a: AppEntry, now: Long = System.currentTimeMillis()): Boolean {
            if (a.isSystem) return false
            val ref = a.lastUsed ?: return false          // sem dado ≠ sem uso
            return now - ref > UNUSED_DAYS * 24 * 3600 * 1000
        }
    }
}
