package com.storageanalyzer.ultra

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.storageanalyzer.ultra.core.Permissions
import com.storageanalyzer.ultra.ui.AppViewModel
import com.storageanalyzer.ultra.ui.MainScaffold
import com.storageanalyzer.ultra.ui.StorageTheme
import com.storageanalyzer.ultra.ui.screens.TermsScreen

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    private val legacyPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.refreshPermissions() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val theme by vm.theme.collectAsState()
            val accepted by vm.termsAccepted.collectAsState()
            StorageTheme(theme) {
                if (!accepted) TermsScreen(onAccept = vm::acceptTerms, onDecline = { finish() })
                else MainScaffold(vm, onRequestStorage = ::requestStorage)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshPermissions()   // o usuário volta da tela de configurações do Android
        vm.refreshVolumes()
    }

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) Permissions.openAllFilesSettings(this)
        else legacyPermission.launch(arrayOf(
            android.Manifest.permission.READ_EXTERNAL_STORAGE,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
        ))
    }
}
