package com.storageanalyzer.ultra.core

import java.io.File

object Fs {
    /** (bytes, quantidade de arquivos) — arquivo simples ou pasta (recursivo, sem seguir links). */
    fun sizeAndCount(f: File): Pair<Long, Int> {
        if (f.isFile) return f.length() to 1
        var size = 0L
        var count = 0
        f.walkTopDown().onEnter { !java.nio.file.Files.isSymbolicLink(it.toPath()) }.forEach {
            if (it.isFile) { size += it.length(); count++ }
        }
        return size to count
    }

    fun sizeOf(f: File): Long = sizeAndCount(f).first
}
