package com.storageanalyzer.ultra.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID

data class QuarantineEntry(
    val id: String,
    val original: String,
    val stored: String,
    val size: Long,
    val category: String,
    val time: Long,
)

data class BatchResult(val moved: List<QuarantineEntry>, val failed: Int)

/**
 * Quarentena com manifest.json (caminho original -> caminho guardado). "Limpar" NUNCA apaga direto:
 * só esvaziar a quarentena libera espaço. Mesmo princípio do cleanup.py.
 */
class QuarantineStore(private val root: File) {
    private val itemsDir get() = File(root, "items")
    private val manifestFile get() = File(root, "manifest.json")

    @Synchronized
    fun entries(): List<QuarantineEntry> {
        if (!manifestFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(manifestFile.readText())
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                QuarantineEntry(
                    o.getString("id"), o.getString("original"), o.getString("stored"),
                    o.getLong("size"), o.getString("category"), o.getLong("time"),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun totalBytes(): Long = entries().sumOf { it.size }

    @Synchronized
    fun hasCategory(category: String): Boolean = entries().any { it.category == category }

    private fun write(list: List<QuarantineEntry>) {
        root.mkdirs()
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("original", it.original).put("stored", it.stored)
                    .put("size", it.size).put("category", it.category).put("time", it.time)
            )
        }
        val tmp = File(root, "manifest.json.tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(manifestFile)) {
            manifestFile.writeText(arr.toString())
            tmp.delete()
        }
    }

    /** Move vários itens gravando o manifest em lotes (evita reescrever o JSON a cada arquivo). */
    @Synchronized
    fun moveInBatch(
        paths: List<String>,
        category: String,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> },
    ): BatchResult {
        val list = entries().toMutableList()
        val moved = ArrayList<QuarantineEntry>()
        var failed = 0
        try {
            paths.forEachIndexed { i, path ->
                try {
                    val src = File(path)
                    if (!src.exists()) throw IOException("Item não existe mais.")
                    val size = Fs.sizeOf(src)
                    val id = UUID.randomUUID().toString().replace("-", "").take(12)
                    val dst = File(File(itemsDir, id), src.name)
                    moveFile(src, dst)
                    val e = QuarantineEntry(id, src.absolutePath, dst.absolutePath, size, category, System.currentTimeMillis())
                    list.add(e)
                    moved.add(e)
                } catch (e: Exception) {
                    failed++
                }
                if ((i + 1) % 200 == 0) write(list)
                if ((i + 1) % 25 == 0 || i + 1 == paths.size) onProgress(i + 1, paths.size)
            }
        } finally {
            write(list)
        }
        return BatchResult(moved, failed)
    }

    @Synchronized
    fun restoreEntries(selected: List<QuarantineEntry>): Pair<Int, Int> {
        val remaining = entries().toMutableList()
        var ok = 0
        var failed = 0
        for (e in selected) {
            try {
                val stored = File(e.stored)
                if (!stored.exists()) throw IOException("sumiu da quarentena")
                moveFile(stored, uniqueTarget(File(e.original)))
                File(itemsDir, e.id).deleteRecursively()
                remaining.removeAll { it.id == e.id }
                ok++
            } catch (ex: Exception) {
                failed++
            }
        }
        write(remaining)
        return ok to failed
    }

    fun restoreCategory(category: String): Pair<Int, Int> = restoreEntries(entries().filter { it.category == category })

    /** Esvazia de verdade — só aqui o espaço é liberado. Retorna os bytes liberados. */
    @Synchronized
    fun purge(): Long {
        val bytes = totalBytes()
        itemsDir.deleteRecursively()
        write(emptyList())
        return bytes
    }

    private fun uniqueTarget(target: File): File {
        if (!target.exists()) return target
        val base = target.nameWithoutExtension
        val ext = if (target.extension.isEmpty()) "" else "." + target.extension
        var n = 1
        var candidate = File(target.parentFile, "$base (restaurado)$ext")
        while (candidate.exists()) candidate = File(target.parentFile, "$base (restaurado ${++n})$ext")
        return candidate
    }

    private fun moveFile(src: File, dst: File) {
        dst.parentFile?.mkdirs()
        if (src.renameTo(dst)) return                       // mesmo volume: instantâneo
        // Outro volume (ex.: cartão SD -> interno): copia e só então apaga a origem.
        if (src.isDirectory) {
            if (!src.copyRecursively(dst, overwrite = false)) {
                dst.deleteRecursively(); throw IOException("Falha ao copiar pasta")
            }
            if (!src.deleteRecursively()) { dst.deleteRecursively(); throw IOException("Falha ao remover origem") }
        } else {
            src.copyTo(dst, overwrite = false)
            dst.setLastModified(src.lastModified())
            if (!src.delete()) { dst.delete(); throw IOException("Falha ao remover origem") }
        }
    }
}
