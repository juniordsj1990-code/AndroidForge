package com.storageanalyzer.ultra.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.storageanalyzer.ultra.core.About
import com.storageanalyzer.ultra.ui.screens.AboutScreen
import com.storageanalyzer.ultra.ui.screens.AnalysisScreen
import com.storageanalyzer.ultra.ui.screens.AppsScreen
import com.storageanalyzer.ultra.ui.screens.CleanupScreen
import com.storageanalyzer.ultra.ui.screens.DashboardScreen
import com.storageanalyzer.ultra.ui.screens.DuplicatesScreen
import com.storageanalyzer.ultra.ui.screens.LargeFilesScreen
import com.storageanalyzer.ultra.ui.screens.ReportsScreen
import com.storageanalyzer.ultra.ui.screens.SettingsScreen
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScaffold(vm: AppViewModel, onRequestStorage: () -> Unit) {
    val screen by vm.screen.collectAsState()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }
    BackHandler(enabled = drawer.isOpen) { scope.launch { drawer.close() } }
    BackHandler(enabled = !drawer.isOpen && screen != Screen.Dashboard) { vm.navigate(Screen.Dashboard) }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text(About.APP_NAME, modifier = Modifier.padding(horizontal = 28.dp, vertical = 20.dp), style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
                Screen.entries.forEach { s ->
                    NavigationDrawerItem(
                        label = { Text(s.title) },
                        icon = { Icon(s.icon, null) },
                        selected = s == screen,
                        onClick = { vm.navigate(s); scope.launch { drawer.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp),
                    )
                }
            }
        },
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(screen.title) },
                    navigationIcon = { IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Filled.Menu, "Menu") } },
                )
            },
            snackbarHost = { SnackbarHost(snackbar) },
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when (screen) {
                    Screen.Dashboard -> DashboardScreen(vm, onRequestStorage)
                    Screen.Analysis -> AnalysisScreen(vm)
                    Screen.Cleanup -> CleanupScreen(vm)
                    Screen.Apps -> AppsScreen(vm)
                    Screen.Duplicates -> DuplicatesScreen(vm)
                    Screen.LargeFiles -> LargeFilesScreen(vm)
                    Screen.Reports -> ReportsScreen(vm)
                    Screen.Settings -> SettingsScreen(vm, onRequestStorage)
                    Screen.About -> AboutScreen()
                }
            }
        }
    }
}
