package com.storageanalyzer.ultra.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.storageanalyzer.ultra.ui.AppViewModel

@Composable
fun ReportsScreen(vm: AppViewModel) {
    val json = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u -> if (u != null) vm.writeReport(u, "json") }
    val csv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { u -> if (u != null) vm.writeReport(u, "csv") }
    val html = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { u -> if (u != null) vm.writeReport(u, "html") }

    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            "O relatório inclui volumes, último scan, os 100 maiores arquivos, duplicados detectados e os 100 maiores apps (se já abertos na tela Aplicativos). " +
                "Você escolhe onde salvar. Para PDF, abra o HTML no navegador e use Imprimir → Salvar como PDF.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Button(onClick = { json.launch("storage-report.json") }, modifier = Modifier.fillMaxWidth()) { Text("Salvar JSON") }
        Button(onClick = { csv.launch("storage-report.csv") }, modifier = Modifier.fillMaxWidth()) { Text("Salvar CSV") }
        Button(onClick = { html.launch("storage-report.html") }, modifier = Modifier.fillMaxWidth()) { Text("Salvar HTML") }
    }
}
