package com.storageanalyzer.ultra.core

import java.io.File

/**
 * Proteção de caminhos (equivalente ao safety.py). Nunca permite mexer em: raiz de volume, pais da raiz,
 * a pasta Android/ inteira, Android/data, Android/obb e diretórios do sistema.
 * A quarentena fica dentro de Android/data/<pacote>/ — portanto também é protegida por aqui.
 */
class PathGuard(volumeRoots: List<String>) {
    private val roots = volumeRoots.map { norm(it) }
    private val systemDirs = listOf("/system", "/data", "/proc", "/sys", "/vendor", "/apex", "/dev", "/etc")

    fun isProtected(path: String): Boolean {
        if (path.isBlank() || !path.startsWith("/")) return true
        val p = norm(path)
        if (p == "/") return true
        if (systemDirs.any { p == it || p.startsWith("$it/") }) return true
        for (r in roots) {
            if (p == r) return true                       // raiz do volume
            if (r.startsWith("$p/")) return true          // pai da raiz (/storage, /storage/emulated)
            val android = "$r/Android"
            if (p == android || p == "$android/data" || p.startsWith("$android/data/") ||
                p == "$android/obb" || p.startsWith("$android/obb/")
            ) return true
        }
        return false
    }

    /** Dentro de qualquer pasta Android/ (dados de apps) — usado pelas regras de limpeza por extensão. */
    fun isInsideAndroidDir(path: String): Boolean = norm(path).contains("/Android/")

    private fun norm(p: String): String = File(p).normalize().path.trimEnd('/').ifEmpty { "/" }
}
