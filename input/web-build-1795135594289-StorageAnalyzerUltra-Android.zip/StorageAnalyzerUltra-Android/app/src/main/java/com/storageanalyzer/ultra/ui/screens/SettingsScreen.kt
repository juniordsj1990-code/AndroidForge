package com.storageanalyzer.ultra.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.storageanalyzer.ultra.core.Format
import com.storageanalyzer.ultra.ui.AppViewModel

@Composable
fun SettingsScreen(vm: AppViewModel, onRequestStorage: () -> Unit) {
    val theme by vm.theme.collectAsState()
    val hasAccess by vm.hasAllFiles.collectAsState()
    val history by vm.history.collectAsState()

    LazyColumn(Modifier.fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Tema", style = MaterialTheme.typography.titleMedium) }
        item {
            Column {
                listOf("system" to "Seguir o sistema", "light" to "Claro", "dark" to "Escuro").forEach { (v, l) ->
                    Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(theme == v, { vm.setTheme(v) }); Text(l) }
                }
            }
        }
        item { Text("Permissões", style = MaterialTheme.typography.titleMedium) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(if (hasAccess) "Acesso a todos os arquivos: concedido" else "Acesso a todos os arquivos: NÃO concedido", Modifier.weight(1f))
                OutlinedButton(onClick = onRequestStorage) { Text("Abrir ajustes") }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Histórico de ações", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                if (history.isNotEmpty()) OutlinedButton(onClick = vm::clearHistory) { Text("Limpar") }
            }
        }
        if (history.isEmpty()) item { Text("Sem ações registradas.", style = MaterialTheme.typography.bodySmall) }
        items(history.take(50)) { h ->
            Column(Modifier.padding(vertical = 2.dp)) {
                Text(h.text, style = MaterialTheme.typography.bodySmall)
                Text(Format.dateTime(h.time), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
