package com.storageanalyzer.ultra.core

import org.json.JSONArray
import org.json.JSONObject

data class ReportFile(val path: String, val size: Long, val modified: Long)
data class ReportApp(val label: String, val packageName: String, val sizeBytes: Long?, val lastUsed: Long?)

data class ReportData(
    val generatedAt: Long,
    val appName: String,
    val appVersion: String,
    val volumes: List<VolumeInfo>,
    val scanRoot: String?,
    val scanFiles: Long,
    val scanBytes: Long,
    val largeFiles: List<ReportFile>,
    val duplicates: List<DuplicateGroup>,
    val apps: List<ReportApp>,
    val quarantineBytes: Long,
)

object Reports {
    fun json(d: ReportData): String = JSONObject().apply {
        put("app", "${d.appName} ${d.appVersion}")
        put("generated_at", Format.dateTime(d.generatedAt))
        put("volumes", JSONArray().also { a ->
            d.volumes.forEach { a.put(JSONObject().put("path", it.path).put("label", it.label)
                .put("total_bytes", it.totalBytes).put("free_bytes", it.freeBytes)) }
        })
        put("scan", JSONObject().put("root", d.scanRoot ?: JSONObject.NULL).put("files", d.scanFiles).put("bytes", d.scanBytes))
        put("large_files", JSONArray().also { a ->
            d.largeFiles.forEach { a.put(JSONObject().put("path", it.path).put("size", it.size).put("modified", it.modified)) }
        })
        put("duplicates", JSONArray().also { a ->
            d.duplicates.forEach { g ->
                a.put(JSONObject().put("sha256", g.sha256).put("size", g.sizeBytes)
                    .put("recoverable", g.recoverableBytes).put("paths", JSONArray(g.paths)))
            }
        })
        put("apps", JSONArray().also { a ->
            d.apps.forEach { a.put(JSONObject().put("label", it.label).put("package", it.packageName)
                .put("size", it.sizeBytes ?: JSONObject.NULL).put("last_used", it.lastUsed ?: JSONObject.NULL)) }
        })
        put("quarantine_bytes", d.quarantineBytes)
    }.toString(2)

    /** Células que começam com = + - @ viram texto (evita injeção de fórmula ao abrir no Excel/Planilhas). */
    fun csvCell(value: String): String {
        val safe = if (value.isNotEmpty() && value[0] in "=+-@\t\r") "'$value" else value
        return "\"" + safe.replace("\"", "\"\"") + "\""
    }

    fun csv(d: ReportData): String = buildString {
        appendLine("secao,caminho_ou_nome,tamanho_bytes,detalhe")
        d.volumes.forEach { appendLine("volume,${csvCell(it.path)},${it.usedBytes},${csvCell("total=${it.totalBytes}; livre=${it.freeBytes}")}") }
        d.largeFiles.forEach { appendLine("arquivo_grande,${csvCell(it.path)},${it.size},${csvCell(Format.date(it.modified))}") }
        d.duplicates.forEach { g ->
            g.paths.forEach { appendLine("duplicado,${csvCell(it)},${g.sizeBytes},${csvCell(g.sha256)}") }
        }
        d.apps.forEach { appendLine("app,${csvCell(it.label)},${it.sizeBytes ?: ""},${csvCell(it.packageName)}") }
    }

    fun escapeHtml(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")

    fun html(d: ReportData): String = buildString {
        fun e(s: String) = escapeHtml(s)
        appendLine("<!DOCTYPE html><html lang=\"pt-BR\"><head><meta charset=\"utf-8\">")
        appendLine("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">")
        appendLine("<title>${e(d.appName)} — Relatório</title>")
        appendLine("<style>body{font-family:sans-serif;margin:1.2rem;max-width:60rem}table{border-collapse:collapse;width:100%;margin:.5rem 0 1.5rem}td,th{border:1px solid #bbb;padding:.3rem .5rem;text-align:left;word-break:break-all}th{background:#eee}</style></head><body>")
        appendLine("<h1>${e(d.appName)} ${e(d.appVersion)}</h1><p>Gerado em ${e(Format.dateTime(d.generatedAt))}</p>")
        appendLine("<h2>Armazenamento</h2><table><tr><th>Volume</th><th>Usado</th><th>Livre</th><th>Total</th></tr>")
        d.volumes.forEach { appendLine("<tr><td>${e(it.label)}<br>${e(it.path)}</td><td>${e(Format.bytes(it.usedBytes))}</td><td>${e(Format.bytes(it.freeBytes))}</td><td>${e(Format.bytes(it.totalBytes))}</td></tr>") }
        appendLine("</table>")
        if (d.scanRoot != null) appendLine("<p>Último scan: ${e(d.scanRoot)} — ${d.scanFiles} arquivos, ${e(Format.bytes(d.scanBytes))}.</p>")
        appendLine("<h2>Arquivos grandes</h2><table><tr><th>Caminho</th><th>Tamanho</th><th>Modificado</th></tr>")
        d.largeFiles.forEach { appendLine("<tr><td>${e(it.path)}</td><td>${e(Format.bytes(it.size))}</td><td>${e(Format.date(it.modified))}</td></tr>") }
        appendLine("</table><h2>Duplicados</h2><table><tr><th>Tamanho</th><th>Recuperável</th><th>Caminhos</th></tr>")
        d.duplicates.forEach { g -> appendLine("<tr><td>${e(Format.bytes(g.sizeBytes))}</td><td>${e(Format.bytes(g.recoverableBytes))}</td><td>${g.paths.joinToString("<br>") { e(it) }}</td></tr>") }
        appendLine("</table><h2>Aplicativos</h2><table><tr><th>App</th><th>Pacote</th><th>Tamanho</th><th>Último uso</th></tr>")
        d.apps.forEach { appendLine("<tr><td>${e(it.label)}</td><td>${e(it.packageName)}</td><td>${e(it.sizeBytes?.let { b -> Format.bytes(b) } ?: "—")}</td><td>${e(it.lastUsed?.let { t -> Format.date(t) } ?: "—")}</td></tr>") }
        appendLine("</table><p>Quarentena: ${e(Format.bytes(d.quarantineBytes))}</p></body></html>")
    }
}
