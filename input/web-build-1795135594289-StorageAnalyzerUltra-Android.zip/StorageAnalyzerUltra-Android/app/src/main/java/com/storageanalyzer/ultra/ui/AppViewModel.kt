package com.storageanalyzer.ultra.ui

import android.app.Application
import android.net.Uri
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.storageanalyzer.ultra.core.About
import com.storageanalyzer.ultra.core.AppEntry
import com.storageanalyzer.ultra.core.AppsService
import com.storageanalyzer.ultra.core.CleanupDetection
import com.storageanalyzer.ultra.core.CleanupService
import com.storageanalyzer.ultra.core.DiskScanner
import com.storageanalyzer.ultra.core.DuplicateGroup
import com.storageanalyzer.ultra.core.Duplicates
import com.storageanalyzer.ultra.core.Format
import com.storageanalyzer.ultra.core.PathGuard
import com.storageanalyzer.ultra.core.Permissions
import com.storageanalyzer.ultra.core.QuarantineStore
import com.storageanalyzer.ultra.core.ReportApp
import com.storageanalyzer.ultra.core.ReportData
import com.storageanalyzer.ultra.core.ReportFile
import com.storageanalyzer.ultra.core.Reports
import com.storageanalyzer.ultra.core.ScanProgress
import com.storageanalyzer.ultra.core.ScanResult
import com.storageanalyzer.ultra.core.SettingsStore
import com.storageanalyzer.ultra.core.VolumeInfo
import com.storageanalyzer.ultra.core.Volumes
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Screen(val title: String, val icon: ImageVector) {
    Dashboard("Dashboard", Icons.Filled.Home),
    Analysis("Análise de armazenamento", Icons.Filled.PieChart),
    Cleanup("Limpeza", Icons.Filled.CleaningServices),
    Apps("Aplicativos", Icons.Filled.Apps),
    Duplicates("Arquivos duplicados", Icons.Filled.ContentCopy),
    LargeFiles("Arquivos grandes", Icons.Filled.Storage),
    Reports("Relatórios", Icons.Filled.Assessment),
    Settings("Configurações", Icons.Filled.Settings),
    About("Sobre", Icons.Filled.Info),
}

sealed interface ScanUi {
    data object Idle : ScanUi
    data class Running(val root: String, val progress: ScanProgress) : ScanUi
    data class Failed(val message: String) : ScanUi
}

sealed interface DupUi {
    data object Idle : DupUi
    data class Running(val message: String) : DupUi
    data class Done(val groups: List<DuplicateGroup>) : DupUi
    data class Failed(val message: String) : DupUi
}

data class CleanupUi(
    val items: List<CleanupDetection> = emptyList(),
    val busy: String? = null,        // mensagem de progresso enquanto ocupado
    val detected: Boolean = false,
)

data class AppsUi(
    val apps: List<AppEntry> = emptyList(),
    val loading: Boolean = false,
    val loaded: Boolean = false,
    val usageAccess: Boolean = false,
)

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val ctx get() = getApplication<Application>()

    val settings = SettingsStore(application)
    private val quarantine = QuarantineStore(File(application.getExternalFilesDir(null) ?: application.filesDir, "Quarantine"))
    private val scanner = DiskScanner()
    private val appsService = AppsService(application)
    private val cleanup = CleanupService(quarantine) { Volumes.roots(ctx) }

    // ---------- navegação / mensagens / tema / termo ----------
    val screen = MutableStateFlow(Screen.Dashboard)
    fun navigate(s: Screen) { screen.value = s }

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages = _messages.asSharedFlow()
    private fun say(text: String) { _messages.tryEmit(text) }

    val theme = MutableStateFlow(settings.theme)
    fun setTheme(value: String) { settings.theme = value; theme.value = value }

    val termsAccepted = MutableStateFlow(settings.termsAccepted())
    fun acceptTerms() { settings.acceptTerms(); termsAccepted.value = true; settings.addHistory("Termo de uso aceito (v${About.TERMS_VERSION})") }

    // ---------- permissões / volumes ----------
    val hasAllFiles = MutableStateFlow(Permissions.hasAllFilesAccess(application))
    val volumes = MutableStateFlow<List<VolumeInfo>>(emptyList())
    val history = MutableStateFlow(settings.history())

    fun refreshPermissions() {
        hasAllFiles.value = Permissions.hasAllFilesAccess(ctx)
        appsUi.value = appsUi.value.copy(usageAccess = appsService.hasUsageAccess())
    }

    fun refreshVolumes() {
        viewModelScope.launch { volumes.value = withContext(Dispatchers.IO) { Volumes.list(ctx) } }
    }

    private fun log(text: String) { settings.addHistory(text); history.value = settings.history() }
    private fun guard() = PathGuard(Volumes.roots(ctx))

    // ---------- scan ----------
    val scanUi = MutableStateFlow<ScanUi>(ScanUi.Idle)
    val currentScan = MutableStateFlow<ScanResult?>(null)
    /** Incrementa quando a árvore muda (remoções) para a UI recompor. */
    val treeVersion = MutableStateFlow(0)
    private val scans = HashMap<String, ScanResult>()
    private var scanJob: Job? = null

    fun startScan(root: String) {
        if (scanUi.value is ScanUi.Running) return
        scanUi.value = ScanUi.Running(root, ScanProgress())
        scanJob = viewModelScope.launch {
            try {
                val result = scanner.scan(root) { p -> scanUi.value = ScanUi.Running(root, p) }
                scans[root] = result
                currentScan.value = result
                dupUi.value = DupUi.Idle
                cleanupUi.value = CleanupUi()
                scanUi.value = ScanUi.Idle
                log("Scan de $root: ${result.fileCount} arquivos, ${Format.bytes(result.root.size)} em ${Format.duration(result.durationMs)}")
                navigate(Screen.Analysis)
            } catch (e: CancellationException) {
                scanUi.value = ScanUi.Idle
                say("Scan cancelado.")
                throw e
            } catch (e: Exception) {
                scanUi.value = ScanUi.Failed(e.message ?: "Erro desconhecido")
            }
        }
    }

    fun cancelScan() { scanJob?.cancel() }

    // ---------- quarentena de itens avulsos (menu de contexto) ----------
    val quarantineBytes = MutableStateFlow(quarantine.totalBytes())

    private fun forgetPaths(paths: List<String>) {
        for (p in paths) scans.values.forEach { it.removeSubtree(p) }
        val gone = paths.toSet()
        (dupUi.value as? DupUi.Done)?.let { d ->
            dupUi.value = DupUi.Done(
                d.groups.map { g -> g.copy(paths = g.paths.filter { it !in gone }) }.filter { it.paths.size > 1 }
            )
        }
        treeVersion.value++
        quarantineBytes.value = quarantine.totalBytes()
    }

    /** "Excluir" = mover para a quarentena (recuperável). O espaço só é liberado ao esvaziar a quarentena. */
    fun quarantinePath(path: String, category: String = "manual") {
        viewModelScope.launch {
            if (guard().isProtected(path)) { say("Item protegido: não pode ser movido."); return@launch }
            val r = withContext(Dispatchers.IO) { quarantine.moveInBatch(listOf(path), category) }
            if (r.moved.isEmpty()) { say("Não foi possível mover o item."); return@launch }
            forgetPaths(listOf(path))
            log("Movido para a quarentena: $path (${Format.bytes(r.moved[0].size)})")
            say("Movido para a quarentena. O espaço só é liberado ao esvaziá-la (Limpeza).")
        }
    }

    // ---------- duplicados ----------
    val dupUi = MutableStateFlow<DupUi>(DupUi.Idle)
    private var dupJob: Job? = null

    fun detectDuplicates(minSize: Long) {
        val scan = currentScan.value ?: return
        dupJob?.cancel()
        dupUi.value = DupUi.Running("Preparando…")
        dupJob = viewModelScope.launch {
            try {
                val files = withContext(Dispatchers.IO) { val g = guard(); scan.allFiles().filter { !g.isProtected(it.path) } }
                val groups = Duplicates.find(files, minSize) { msg -> dupUi.value = DupUi.Running(msg) }
                dupUi.value = DupUi.Done(groups)
                log("Duplicados: ${groups.size} grupos, ${Format.bytes(groups.sumOf { it.recoverableBytes })} recuperáveis")
            } catch (e: CancellationException) {
                dupUi.value = DupUi.Idle
                throw e
            } catch (e: Exception) {
                dupUi.value = DupUi.Failed(e.message ?: "Erro desconhecido")
            }
        }
    }

    fun cancelDuplicates() { dupJob?.cancel() }

    // ---------- limpeza ----------
    val cleanupUi = MutableStateFlow(CleanupUi())

    fun detectCleanup() {
        if (cleanupUi.value.busy != null) return
        cleanupUi.value = cleanupUi.value.copy(busy = "Detectando…")
        viewModelScope.launch {
            val items = withContext(Dispatchers.IO) {
                cleanup.detect(currentScan.value) { msg -> cleanupUi.value = cleanupUi.value.copy(busy = msg) }
            }
            cleanupUi.value = CleanupUi(items = items, busy = null, detected = true)
            quarantineBytes.value = quarantine.totalBytes()
        }
    }

    fun cleanCategory(id: String) {
        if (cleanupUi.value.busy != null) return
        cleanupUi.value = cleanupUi.value.copy(busy = "Limpando…")
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    cleanup.clean(id, currentScan.value) { msg -> cleanupUi.value = cleanupUi.value.copy(busy = msg) }
                }
            }
            result.onSuccess {
                forgetPaths(it.movedPaths)
                log("Limpeza '$id': ${it.movedPaths.size} itens, ${Format.bytes(it.bytes)} para a quarentena (${it.failed} falhas)")
                say("${it.movedPaths.size} itens movidos para a quarentena (${Format.bytes(it.bytes)}).")
            }.onFailure { say("Erro na limpeza: ${it.message}") }
            cleanupUi.value = cleanupUi.value.copy(busy = null)
            detectCleanup()
        }
    }

    fun restoreCategory(id: String) {
        if (cleanupUi.value.busy != null) return
        cleanupUi.value = cleanupUi.value.copy(busy = "Restaurando…")
        viewModelScope.launch {
            val (ok, failed) = withContext(Dispatchers.IO) { quarantine.restoreCategory(id) }
            log("Restauração '$id': $ok restaurados, $failed falhas")
            say("$ok itens restaurados" + if (failed > 0) " ($failed falharam)." else ". Faça um novo scan para atualizar a análise.")
            cleanupUi.value = cleanupUi.value.copy(busy = null)
            detectCleanup()
        }
    }

    fun purgeQuarantine() {
        if (cleanupUi.value.busy != null) return
        cleanupUi.value = cleanupUi.value.copy(busy = "Esvaziando quarentena…")
        viewModelScope.launch {
            val freed = withContext(Dispatchers.IO) { quarantine.purge() }
            log("Quarentena esvaziada: ${Format.bytes(freed)} liberados")
            say("${Format.bytes(freed)} liberados.")
            quarantineBytes.value = 0
            cleanupUi.value = cleanupUi.value.copy(busy = null)
            refreshVolumes()
            detectCleanup()
        }
    }

    // ---------- aplicativos ----------
    val appsUi = MutableStateFlow(AppsUi(usageAccess = appsService.hasUsageAccess()))

    fun loadApps() {
        if (appsUi.value.loading) return
        appsUi.value = appsUi.value.copy(loading = true, usageAccess = appsService.hasUsageAccess())
        viewModelScope.launch {
            val apps = withContext(Dispatchers.IO) { appsService.load() }
            appsUi.value = AppsUi(apps = apps, loading = false, loaded = true, usageAccess = appsService.hasUsageAccess())
        }
    }

    // ---------- relatórios ----------
    private suspend fun buildReport(): ReportData = withContext(Dispatchers.IO) {
        val scan = currentScan.value
        ReportData(
            generatedAt = System.currentTimeMillis(),
            appName = About.APP_NAME,
            appVersion = About.VERSION,
            volumes = Volumes.list(ctx),
            scanRoot = scan?.rootPath,
            scanFiles = scan?.fileCount ?: 0,
            scanBytes = scan?.root?.size ?: 0,
            largeFiles = scan?.largeFiles(100)?.map { ReportFile(it.path, it.size, it.modified) }.orEmpty(),
            duplicates = (dupUi.value as? DupUi.Done)?.groups.orEmpty(),
            apps = appsUi.value.apps.filter { !it.isSystem }.sortedByDescending { it.sizeBytes ?: -1L }.take(100)
                .map { ReportApp(it.label, it.packageName, it.sizeBytes, it.lastUsed) },
            quarantineBytes = quarantine.totalBytes(),
        )
    }

    /** `format`: json | csv | html. `uri` vem do seletor de documentos (SAF), escolhido pelo usuário. */
    fun writeReport(uri: Uri, format: String) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val data = buildReport()
                    val text = when (format) { "json" -> Reports.json(data); "csv" -> Reports.csv(data); else -> Reports.html(data) }
                    ctx.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                }.isSuccess
            }
            if (ok) { log("Relatório $format salvo"); say("Relatório salvo.") } else say("Não foi possível salvar o relatório.")
        }
    }

    fun clearHistory() { settings.clearHistory(); history.value = emptyList() }

    init { refreshVolumes() }
}
