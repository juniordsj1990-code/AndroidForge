package com.storageanalyzer.ultra.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.storageanalyzer.ultra.core.Format
import com.storageanalyzer.ultra.core.ScanNode
import com.storageanalyzer.ultra.ui.AppViewModel
import com.storageanalyzer.ultra.ui.EmptyState
import com.storageanalyzer.ultra.ui.ItemMenu
import com.storageanalyzer.ultra.ui.Screen

private sealed interface Row2 {
    data class Node(val node: ScanNode, val depth: Int, val parentSize: Long) : Row2
    data class More(val count: Int, val depth: Int, val key: String) : Row2
}

private const val MAX_CHILDREN = 300

private fun flatten(node: ScanNode, depth: Int, parentSize: Long, expanded: Set<String>, out: MutableList<Row2>) {
    out.add(Row2.Node(node, depth, parentSize))
    if (node.isDir && node.path in expanded) {
        val kids = node.sortedChildren()
        kids.take(MAX_CHILDREN).forEach { flatten(it, depth + 1, node.size, expanded, out) }
        if (kids.size > MAX_CHILDREN) out.add(Row2.More(kids.size - MAX_CHILDREN, depth + 1, node.path + "\u0000more"))
    }
}

@Composable
fun AnalysisScreen(vm: AppViewModel) {
    val scan by vm.currentScan.collectAsState()
    val version by vm.treeVersion.collectAsState()
    val s = scan
    if (s == null) {
        EmptyState("Nenhum scan ainda. Escaneie um volume no Dashboard.", "Ir para o Dashboard") { vm.navigate(Screen.Dashboard) }
        return
    }

    var query by remember { mutableStateOf("") }
    var minSize by remember { mutableStateOf(0L) }
    var expanded by remember(s) { mutableStateOf(setOf(s.root.path)) }
    val searching = query.isNotBlank() || minSize > 0

    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("${s.rootPath} — ${Format.bytes(s.root.size)} em ${s.fileCount} arquivos", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(query, { query = it }, label = { Text("Buscar por nome") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0L to "Todos", 10L * 1024 * 1024 to "≥ 10 MB", 100L * 1024 * 1024 to "≥ 100 MB", 1024L * 1024 * 1024 to "≥ 1 GB").forEach { (v, label) ->
                    FilterChip(selected = minSize == v, onClick = { minSize = v }, label = { Text(label) })
                }
            }
        }

        if (searching) {
            val results = remember(s, version, query, minSize) { s.search(query, minSize) }
            if (results.size >= 2000) Text("Mostrando os 2000 maiores resultados.", Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.bodySmall)
            LazyColumn(Modifier.fillMaxWidth()) {
                items(results, key = { it.path }) { n ->
                    NodeRow(n, 0, s.root.size, expandable = false, expanded = false, onClick = {}, onQuarantine = vm::quarantinePath)
                }
            }
        } else {
            val rows = remember(s, version, expanded) { ArrayList<Row2>().also { flatten(s.root, 0, s.root.size, expanded, it) } }
            LazyColumn(Modifier.fillMaxWidth()) {
                items(rows, key = { when (it) { is Row2.Node -> it.node.path; is Row2.More -> it.key } }) { row ->
                    when (row) {
                        is Row2.Node -> NodeRow(
                            row.node, row.depth, row.parentSize, expandable = row.node.isDir && !row.node.children.isNullOrEmpty(),
                            expanded = row.node.path in expanded,
                            onClick = {
                                if (row.node.isDir) expanded = if (row.node.path in expanded) expanded - row.node.path else expanded + row.node.path
                            },
                            onQuarantine = vm::quarantinePath,
                        )
                        is Row2.More -> Text("… mais ${row.count} itens menores (use a busca)", Modifier.padding(start = (16 + row.depth * 16).dp, top = 4.dp, bottom = 4.dp), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun NodeRow(
    node: ScanNode, depth: Int, parentSize: Long,
    expandable: Boolean, expanded: Boolean, onClick: () -> Unit, onQuarantine: (String) -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = (8 + depth * 16).dp, end = 0.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (node.isDir) {
            Icon(if (expanded) Icons.Filled.ExpandMore else Icons.Filled.ChevronRight, null, Modifier.size(20.dp))
        } else {
            Spacer(Modifier.size(20.dp))
        }
        Icon(if (node.isDir) Icons.Filled.Folder else Icons.Filled.InsertDriveFile, null, Modifier.padding(start = 4.dp).size(20.dp))
        Column(Modifier.weight(1f).padding(start = 8.dp, top = 6.dp, bottom = 6.dp)) {
            Text(node.name + if (node.accessDenied) "  (sem acesso)" else "", maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (parentSize > 0) LinearProgressIndicator(progress = { (node.size.toFloat() / parentSize).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 2.dp, end = 8.dp))
        }
        Text(Format.bytes(node.size), style = MaterialTheme.typography.labelMedium)
        ItemMenu(node.path, node.isDir, onQuarantine)
    }
}
