package com.storageanalyzer.ultra.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.storageanalyzer.ultra.core.Format
import com.storageanalyzer.ultra.ui.AppViewModel
import com.storageanalyzer.ultra.ui.EmptyState
import com.storageanalyzer.ultra.ui.ItemMenu
import com.storageanalyzer.ultra.ui.Screen

@Composable
fun LargeFilesScreen(vm: AppViewModel) {
    val scan by vm.currentScan.collectAsState()
    val version by vm.treeVersion.collectAsState()
    val s = scan
    if (s == null) {
        EmptyState("Faça um scan primeiro.", "Ir para o Dashboard") { vm.navigate(Screen.Dashboard) }
        return
    }
    var topN by remember { mutableStateOf(100) }
    var query by remember { mutableStateOf("") }
    val files = remember(s, version, topN, query) { s.largeFiles(topN, 0, query) }

    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(query, { query = it }, label = { Text("Filtrar por nome") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(100, 500, 1000).forEach { n -> FilterChip(selected = topN == n, onClick = { topN = n }, label = { Text("Top $n") }) }
            }
        }
        LazyColumn(Modifier.fillMaxWidth()) {
            items(files, key = { it.path }) { f ->
                Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(vertical = 6.dp)) {
                        Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(f.path, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Modificado em ${Format.date(f.modified)}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(Format.bytes(f.size), style = MaterialTheme.typography.labelLarge)
                    ItemMenu(f.path, false, vm::quarantinePath)
                }
            }
        }
    }
}
