package com.storageanalyzer.ultra.ui

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Image
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.storageanalyzer.ultra.core.FileActions
import com.storageanalyzer.ultra.core.Risk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun RiskBadge(risk: Risk) {
    val (label, color) = when (risk) {
        Risk.SAFE -> "🟢 Seguro" to Color(0xFF2E7D32)
        Risk.MODERATE -> "🟡 Moderado" to Color(0xFFB26A00)
        Risk.RISKY -> "🔴 Arriscado" to Color(0xFFC62828)
    }
    Surface(color = color.copy(alpha = 0.18f), shape = RoundedCornerShape(50)) {
        Text(label, color = color, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp))
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmLabel: String,
    danger: Boolean = false,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = if (danger) ({ Icon(Icons.Filled.Warning, null, tint = Color(0xFFC62828)) }) else null,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { Button(onClick = { onDismiss(); onConfirm() }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
fun EmptyState(message: String, actionLabel: String? = null, onAction: () -> Unit = {}) {
    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(message, style = MaterialTheme.typography.bodyLarge)
        if (actionLabel != null) Button(onClick = onAction) { Text(actionLabel) }
    }
}

@Composable
fun InfoCard(text: String, actionLabel: String? = null, onAction: () -> Unit = {}) {
    Card(Modifier.fillMaxWidth().padding(12.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text, style = MaterialTheme.typography.bodyMedium)
            if (actionLabel != null) Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

/** Menu ⋮ de um arquivo/pasta: abrir, compartilhar, mover para a quarentena. */
@Composable
fun ItemMenu(path: String, isDir: Boolean, onQuarantine: (String) -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Filled.MoreVert, "Mais ações") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (!isDir) {
                DropdownMenuItem(text = { Text("Abrir") }, onClick = { open = false; FileActions.open(ctx, path) })
                DropdownMenuItem(text = { Text("Compartilhar") }, onClick = { open = false; FileActions.share(ctx, path) })
            }
            DropdownMenuItem(
                text = { Text("Mover para a quarentena") },
                leadingIcon = { Icon(Icons.Filled.Delete, null) },
                onClick = { open = false; confirm = true },
            )
        }
    }
    if (confirm) {
        ConfirmDialog(
            title = "Mover para a quarentena?",
            text = "${path}\n\nO item sai do lugar atual, mas pode ser restaurado em Limpeza. O espaço só é liberado ao esvaziar a quarentena.",
            confirmLabel = "Mover",
            onConfirm = { onQuarantine(path) },
            onDismiss = { confirm = false },
        )
    }
}

@Composable
fun AppIcon(packageName: String, size: Dp = 40.dp) {
    val ctx: Context = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, packageName) {
        value = withContext(Dispatchers.IO) {
            runCatching { ctx.packageManager.getApplicationIcon(packageName).toBitmap(96, 96).asImageBitmap() }.getOrNull()
        }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(size)) else Box(Modifier.size(size))
}

@Composable
fun LabeledRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
