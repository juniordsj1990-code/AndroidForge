package com.storageanalyzer.ultra.core

/**
 * Nó da árvore escaneada (arquivo ou pasta). A árvore inteira fica em memória no processo;
 * a UI só desenha o que está expandido (equivalente ao lazy loading do get_children do Python).
 * `children` é null para arquivos (evita alocar uma lista por arquivo).
 */
class ScanNode(
    val name: String,
    val path: String,
    val isDir: Boolean,
    @Volatile var size: Long = 0L,
    val modified: Long = 0L,
    val extension: String = "",
    @Volatile var accessDenied: Boolean = false,
    val children: ArrayList<ScanNode>? = null,
) {
    fun sortedChildren(): List<ScanNode> = children?.sortedByDescending { it.size } ?: emptyList()
}

data class ScanProgress(
    val files: Long = 0,
    val dirs: Long = 0,
    val bytes: Long = 0,
    val elapsedMs: Long = 0,
    val done: Boolean = false,
)

data class VolumeInfo(
    val path: String,
    val label: String,
    val totalBytes: Long,
    val freeBytes: Long,
    val removable: Boolean,
) {
    val usedBytes: Long get() = totalBytes - freeBytes
    val usedFraction: Float get() = if (totalBytes <= 0) 0f else (usedBytes.toDouble() / totalBytes).toFloat()
}

data class DuplicateGroup(val sha256: String, val sizeBytes: Long, val paths: List<String>) {
    val recoverableBytes: Long get() = sizeBytes * (paths.size - 1)
}

data class AppEntry(
    val packageName: String,
    val label: String,
    val versionName: String,
    val installTime: Long,
    val lastUsed: Long?,      // null = sem permissão de uso OU nunca usado
    val sizeBytes: Long?,     // null = sem permissão de "Acesso ao uso"
    val cacheBytes: Long?,
    val isSystem: Boolean,
)

enum class Risk { SAFE, MODERATE, RISKY }
