package com.storageanalyzer.ultra.core

import android.content.Context
import android.os.Environment
import android.os.StatFs
import java.io.File

object Volumes {
    fun list(context: Context): List<VolumeInfo> {
        val result = LinkedHashMap<String, VolumeInfo>()

        fun add(root: File, label: String, removable: Boolean) {
            if (!root.exists() || result.containsKey(root.absolutePath)) return
            val (total, free) = try {
                val s = StatFs(root.absolutePath)
                s.totalBytes to s.availableBytes
            } catch (e: Exception) { 0L to 0L }
            result[root.absolutePath] = VolumeInfo(root.absolutePath, label, total, free, removable)
        }

        @Suppress("DEPRECATION")
        add(Environment.getExternalStorageDirectory(), "Armazenamento interno", false)

        // Volumes removíveis (cartão SD/USB): derivados dos diretórios de app em cada volume.
        for (dir in context.getExternalFilesDirs(null).filterNotNull()) {
            val root = File(dir.absolutePath.substringBefore("/Android/data"))
            if (root.absolutePath != dir.absolutePath) add(root, "Cartão SD / USB", true)
        }
        return result.values.toList()
    }

    fun roots(context: Context): List<String> = list(context).map { it.path }
}
