package com.storageanalyzer.ultra.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.storageanalyzer.ultra.core.CleanupDetection
import com.storageanalyzer.ultra.core.Format
import com.storageanalyzer.ultra.core.Risk
import com.storageanalyzer.ultra.ui.AppViewModel
import com.storageanalyzer.ultra.ui.ConfirmDialog
import com.storageanalyzer.ultra.ui.RiskBadge

@Composable
fun CleanupScreen(vm: AppViewModel) {
    val ui by vm.cleanupUi.collectAsState()
    val quarantine by vm.quarantineBytes.collectAsState()
    val scan by vm.currentScan.collectAsState()
    var preview by remember { mutableStateOf<CleanupDetection?>(null) }
    var toClean by remember { mutableStateOf<CleanupDetection?>(null) }
    var purge by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Nada é apagado direto: a limpeza move para a quarentena e dá para restaurar. O espaço só é liberado ao esvaziá-la.", style = MaterialTheme.typography.bodySmall)
                    if (scan == null) Text("Dica: faça um scan para detectar também temporários, logs, APKs e backups (regras por extensão).", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = vm::detectCleanup, enabled = ui.busy == null) { Text(if (ui.detected) "Detectar de novo" else "Detectar") }
                        OutlinedButton(onClick = { purge = true }, enabled = ui.busy == null && quarantine > 0) { Text("Esvaziar quarentena (${Format.bytes(quarantine)})") }
                    }
                    ui.busy?.let { Text(it); LinearProgressIndicator(Modifier.fillMaxWidth()) }
                }
            }
        }
        items(ui.items, key = { it.id }) { c -> CategoryCard(c, ui.busy == null, { preview = c }, { toClean = c }, { vm.restoreCategory(c.id) }) }
    }

    preview?.let { c ->
        AlertDialog(
            onDismissRequest = { preview = null },
            title = { Text(c.name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("${c.fileCount} arquivos • ${Format.bytes(c.sizeBytes)}", style = MaterialTheme.typography.titleSmall)
                    c.items.take(40).forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                    if (c.items.size > 40) Text("… e mais ${c.items.size - 40} itens", style = MaterialTheme.typography.bodySmall)
                    Text("\nPrévia: nada foi movido.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { preview = null }) { Text("Fechar") } },
        )
    }
    toClean?.let { c ->
        val extra = when (c.risk) {
            Risk.SAFE -> ""
            Risk.MODERATE -> "\n\n⚠ Categoria MODERADA: confira a prévia antes. Você poderá restaurar enquanto a quarentena não for esvaziada."
            Risk.RISKY -> ""
        }
        ConfirmDialog(
            title = "Limpar “${c.name}”?",
            text = "${c.fileCount} arquivos (${Format.bytes(c.sizeBytes)}) serão movidos para a quarentena.$extra",
            confirmLabel = "Mover para a quarentena",
            danger = c.risk != Risk.SAFE,
            onConfirm = { vm.cleanCategory(c.id) },
            onDismiss = { toClean = null },
        )
    }
    if (purge) {
        ConfirmDialog(
            title = "Esvaziar a quarentena?",
            text = "${Format.bytes(quarantine)} serão apagados DEFINITIVAMENTE. Depois disso não será possível restaurar.",
            confirmLabel = "Apagar definitivamente",
            danger = true,
            onConfirm = vm::purgeQuarantine,
            onDismiss = { purge = false },
        )
    }
}

@Composable
private fun CategoryCard(c: CleanupDetection, enabled: Boolean, onPreview: () -> Unit, onClean: () -> Unit, onRestore: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(c.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                RiskBadge(c.risk)
            }
            Text(c.description, style = MaterialTheme.typography.bodySmall)
            when {
                c.needsScan -> Text("Requer um scan do armazenamento (Dashboard).", style = MaterialTheme.typography.bodySmall)
                c.fileCount == 0 -> Text("Nada encontrado.", style = MaterialTheme.typography.bodySmall)
                else -> Text("${c.fileCount} arquivos • ${Format.bytes(c.sizeBytes)}", style = MaterialTheme.typography.titleSmall)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (c.fileCount > 0) OutlinedButton(onClick = onPreview, enabled = enabled) { Text("Visualizar") }
                if (c.cleanable && c.fileCount > 0) Button(onClick = onClean, enabled = enabled) { Text("Limpar") }
                if (c.canRestore) TextButton(onClick = onRestore, enabled = enabled) { Text("Restaurar") }
            }
        }
    }
}
