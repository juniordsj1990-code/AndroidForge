package com.storageanalyzer.ultra.core

/** Identidade do app: fonte única (apresentação, autoria e Termo de Uso). Aumente TERMS_VERSION ao mudar o termo. */
object About {
    const val APP_NAME = "Storage Analyzer Ultra"
    const val VERSION = "1.0.0"
    const val AUTHOR = "Daniel Jr."
    const val YEAR = "2026"
    const val TAGLINE = "Veja para onde seu espaço foi — e recupere com segurança."

    const val PRESENTATION =
        "O Storage Analyzer Ultra mostra, de forma visual, onde o armazenamento do seu Android está sendo usado " +
        "e ajuda a recuperá-lo com segurança, usando quarentena e restauração em vez de apagar tudo de imediato."

    val PURPOSE = listOf(
        "Analisar o armazenamento: árvore de pastas por tamanho, busca e filtros.",
        "Limpar miniaturas, temporários, logs, instaladores e outras sobras, com quarentena e restauração.",
        "Listar aplicativos por tamanho, cache e último uso, e abrir o desinstalador do sistema.",
        "Encontrar arquivos duplicados (por SHA-256) e arquivos grandes.",
        "Gerar relatórios em JSON, CSV e HTML.",
    )

    const val CREATION =
        "Criado por $AUTHOR, em $YEAR. Versão Android nativa (Kotlin + Jetpack Compose), derivada da versão Python/Windows. " +
        "Todo o processamento acontece no seu aparelho."

    const val TERMS_VERSION = "1.0"
    const val TERMS_TITLE = "Termo de Uso e Aceite"

    val TERMS = listOf(
        "1. Aceitação" to "Ao tocar em “Aceitar e continuar” você declara que leu e concorda com este termo. " +
            "Se não concordar, toque em “Recusar e sair”: o app será fechado e nada será executado.",
        "2. O que o app faz" to "O app é uma ferramenta de manutenção. Ele pode mover arquivos e pastas para uma quarentena, " +
            "esvaziá-la (apagando de forma definitiva) e abrir o desinstalador do sistema para apps que você escolher.",
        "3. Acesso a todos os arquivos" to "Para analisar e limpar o armazenamento, o app pede o acesso especial “Todos os arquivos”. " +
            "Ele é usado apenas para o que você solicitar. Você pode revogá-lo a qualquer momento nas configurações do Android.",
        "4. Uso por sua conta e risco" to "Você é o único responsável pelas ações que confirmar. Leia as descrições de cada operação e " +
            "faça backup dos dados importantes antes de mudanças maiores. Categorias “moderadas” exigem atenção redobrada.",
        "5. Quarentena e ações irreversíveis" to "A limpeza move arquivos para uma quarentena dentro do app; o espaço só é liberado " +
            "quando a quarentena é esvaziada. Esvaziar a quarentena é definitivo. Desinstalar o app também apaga a quarentena.",
        "6. Privacidade" to "O app não envia dados para a internet nem coleta informações pessoais. Configurações, histórico, " +
            "quarentena e o registro deste aceite ficam no próprio aparelho; relatórios são salvos onde você escolher.",
        "7. Sem garantias" to "O app é fornecido “como está”, sem garantia de funcionamento ininterrupto ou livre de erros. Na máxima " +
            "extensão permitida pela lei, o autor não responde por perda de dados ou outros danos decorrentes do uso.",
        "8. Direitos autorais" to "O app é obra de $AUTHOR e protegido por direitos autorais. Cópia, redistribuição ou modificação " +
            "dependem de autorização do autor.",
        "9. Alterações" to "Este termo pode ser atualizado em novas versões; nesse caso o aceite será solicitado novamente.",
    )
}
