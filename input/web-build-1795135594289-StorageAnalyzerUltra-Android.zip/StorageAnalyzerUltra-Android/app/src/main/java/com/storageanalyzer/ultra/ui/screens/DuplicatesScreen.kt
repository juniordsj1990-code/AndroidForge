package com.storageanalyzer.ultra.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.storageanalyzer.ultra.core.Format
import com.storageanalyzer.ultra.ui.AppViewModel
import com.storageanalyzer.ultra.ui.DupUi
import com.storageanalyzer.ultra.ui.EmptyState
import com.storageanalyzer.ultra.ui.ItemMenu
import com.storageanalyzer.ultra.ui.Screen

@Composable
fun DuplicatesScreen(vm: AppViewModel) {
    val scan by vm.currentScan.collectAsState()
    val ui by vm.dupUi.collectAsState()
    if (scan == null) {
        EmptyState("Faça um scan primeiro.", "Ir para o Dashboard") { vm.navigate(Screen.Dashboard) }
        return
    }
    var minSize by remember { mutableStateOf(1024L * 1024) }

    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Compara por conteúdo (SHA-256), não só por nome ou tamanho. Arquivos de sistema e de dados de apps ficam de fora.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(100L * 1024 to "≥ 100 KB", 1024L * 1024 to "≥ 1 MB", 10L * 1024 * 1024 to "≥ 10 MB").forEach { (v, l) ->
                    FilterChip(selected = minSize == v, onClick = { minSize = v }, label = { Text(l) })
                }
            }
            when (val u = ui) {
                is DupUi.Running -> {
                    Text(u.message)
                    OutlinedButton(onClick = vm::cancelDuplicates) { Text("Cancelar") }
                }
                else -> Button(onClick = { vm.detectDuplicates(minSize) }) { Text("Procurar duplicados") }
            }
            if (ui is DupUi.Failed) Text("Erro: ${(ui as DupUi.Failed).message}")
        }

        val done = ui as? DupUi.Done
        if (done != null) {
            Text(
                "${done.groups.size} grupos • ${Format.bytes(done.groups.sumOf { it.recoverableBytes })} recuperáveis",
                Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.titleSmall,
            )
            LazyColumn(Modifier.fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(done.groups, key = { it.sha256 + it.paths.first() }) { g ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${g.paths.size} cópias de ${Format.bytes(g.sizeBytes)} — recupera ${Format.bytes(g.recoverableBytes)}", style = MaterialTheme.typography.titleSmall)
                            g.paths.forEach { p ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(p, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    // Só permite remover enquanto sobrar ao menos outra cópia no grupo.
                                    if (g.paths.size > 1) ItemMenu(p, false, vm::quarantinePath)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
