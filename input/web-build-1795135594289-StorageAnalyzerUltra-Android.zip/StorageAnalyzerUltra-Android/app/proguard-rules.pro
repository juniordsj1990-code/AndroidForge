# Sem reflexão nem serialização por classe: as regras padrão do AGP bastam.
