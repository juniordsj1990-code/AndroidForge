# Storage Analyzer Ultra — versão Android

Projeto **Android Studio** (Kotlin + Jetpack Compose + Material 3), derivado da versão Python/Windows.
Não dá para reaproveitar o Python/pywebview no Android, então o *core* foi **portado** para Kotlin,
mantendo a mesma arquitetura e os mesmos princípios de segurança (quarentena em vez de apagar direto,
confirmação antes de qualquer ação, itens protegidos).

## Como abrir

1. Android Studio **Koala (2024.1.1)** ou mais novo, com JDK 17 (já vem embutido).
2. `File ▸ Open…` → escolha a pasta `StorageAnalyzerUltra-Android`.
3. Aguarde o *Gradle Sync* (ele baixa o Gradle 8.7 definido em `gradle/wrapper/gradle-wrapper.properties`).
4. Rode em um aparelho/emulador **Android 8.0+ (API 26)**.
5. Testes unitários (JVM, sem aparelho): `./gradlew test` ou botão direito em `app/src/test` ▸ Run.

> O `gradle-wrapper.jar` e o `gradlew` não vão no zip (são binários). O Android Studio resolve sozinho; se preferir
> a linha de comando, rode `gradle wrapper` uma vez.

## Primeira execução

1. Aceitar o Termo de Uso (adaptado para Android em `core/About.kt`).
2. No Dashboard, tocar em **Conceder acesso** → ligar **“Todos os arquivos”** para o app.
3. Em *Aplicativos*, conceder **“Acesso ao uso”** para ver tamanho e último uso dos apps.

## O que veio do Windows e como ficou

| Windows (Python)               | Android                                                                                       |
|--------------------------------|-----------------------------------------------------------------------------------------------|
| Dashboard (drives C:, D:…)     | Volumes: armazenamento interno + cartão SD/USB (`Volumes.kt`)                                  |
| Análise de Disco               | Árvore com expansão sob demanda + busca/filtros (`DiskScanner.kt`, `AnalysisScreen.kt`)        |
| Limpeza (21 categorias)        | 10 categorias Android, mesma escala 🟢🟡🔴, quarentena + restaurar (`Cleanup.kt`)               |
| Programas + Desinstalador      | Aplicativos: tamanho, cache, instalação, **último uso real**; desinstalar via sistema          |
| Arquivos Duplicados            | Igual: tamanho → hash parcial → SHA-256 completo (`Duplicates.kt`)                             |
| Arquivos Grandes               | Igual: Top 100/500/1000 + filtro                                                               |
| Relatórios JSON/CSV/HTML       | Igual, salvando onde você escolher (SAF); CSV protegido contra injeção de fórmula              |
| Configurações, Sobre, Termo    | Tema, histórico, aceite versionado                                                             |
| **Inicialização, Serviços, Windows Update, DISM/SFC/CHKDSK/TRIM, Registro** | **Não existem no Android — não foram portados** |

Diferenças de comportamento que valem saber:

- **"Excluir" = quarentena.** Não há Lixeira universal no Android; a quarentena fica em
  `Android/data/<pacote>/files/Quarantine`. O espaço só é liberado em *Limpeza ▸ Esvaziar quarentena*.
  **Desinstalar o app apaga a quarentena.**
- **Cache de outros apps:** o Android não permite que um app limpe o cache de terceiros. O botão
  *Info / cache* abre a tela do sistema desse app, onde você toca em “Limpar cache”.
- **Android/data e Android/obb** ficam bloqueados pelo próprio Android (11+) e são protegidos também por `PathGuard`.
- **Último uso de apps** é dado real do sistema (no Windows era heurística), mas exige “Acesso ao uso”.

## Permissões e publicação

`MANAGE_EXTERNAL_STORAGE`, `QUERY_ALL_PACKAGES` e `PACKAGE_USAGE_STATS` são **permissões restritas**.
Para instalar por APK/uso pessoal, funciona direto. Para publicar na **Google Play**, é preciso justificar cada uma no
formulário de declaração de permissões, e a aprovação não é garantida (o caso de uso “gerenciador de arquivos/limpeza”
é avaliado caso a caso). Sem elas o app perderia a análise completa do armazenamento e a lista de apps.

## Estrutura

```
app/src/main/java/com/storageanalyzer/ultra/
  core/   Models, DiskScanner, Duplicates, Quarantine, Cleanup, AppsService, Reports,
          Safety (PathGuard), SettingsStore, About, FileActions/Permissions, Volumes, Format, Fs
  ui/     AppViewModel (estado + ações), MainScaffold (menu lateral), Theme, Components
  ui/screens/  Dashboard, Analysis, Cleanup, Apps, Duplicates, LargeFiles, Reports, Settings, About/Terms
app/src/test/  CoreTest.kt — scanner, duplicados (hash real), quarentena (mover/restaurar/esvaziar),
               PathGuard, relatórios (escape HTML, fórmulas CSV)
```

O `core/` não depende de Compose; só `Volumes`, `AppsService`, `SettingsStore` e `FileActions` usam `Context`.
Os testes JVM cobrem todo o restante.

## Fora do escopo (como na versão Windows)

Plugins, atualizador automático e múltiplos idiomas (só pt-BR). Também não portado: favoritos e importar/exportar configurações.

## Honestidade sobre o estado do código

Este projeto foi escrito **sem acesso a um Android SDK/Kotlin compiler** no ambiente de criação. Ele **nunca foi compilado
nem executado**: só passou por revisão manual e checagem de balanceamento de sintaxe/XML. É provável que o primeiro
Sync/Build mostre alguns erros de compilação ou ajustes de import. Se acontecer, cole a saída do Gradle e eu corrijo.
O comportamento em aparelhos reais (principalmente permissões e Android 13/14) também precisa ser validado por você.
