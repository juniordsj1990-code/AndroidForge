# PDF Pro (Android)

Leitor e editor de PDF em Kotlin + Jetpack Compose. 100% offline (sem permissão de internet).

## Como abrir
1. Android Studio (Ladybug ou mais novo) > File > Open > pasta `PdfPro`.
2. Aguarde o Gradle sincronizar (baixa dependências; precisa de internet na 1ª vez).
3. Run (▶) no celular, ou Build > Build APK(s).

Requisitos: Android 10+ (minSdk 29), JDK 17 (o Android Studio já traz).
Para usar `./gradlew` no terminal: rode `gradle wrapper` uma vez (o jar do wrapper não vem no zip).

## Estrutura
- `Ops.kt` – operações PdfBox-Android (mesclar, dividir, páginas, proteger, formulário, gravar anotações...)
- `PdfHolder.kt` – renderização com PdfRenderer nativo
- `MainViewModel.kt` – estado e fluxo (versões/desfazer, salvar, compartilhar)
- `ViewerScreen.kt` / `PagesScreen.kt` / `HomeScreen.kt` / `Dialogs.kt` – telas

## Scanner (Foto/Imagens → PDF)

Fluxo: câmera própria (CameraX) ou galeria → revisão das páginas → edição por página → PDF.

- **Câmera**: aberta uma vez, disparo contínuo com miniaturas, detecção automática de bordas ao vivo,
  captura automática (chip "Auto"), grade, modos Documento / RG-Cartão (frente e verso numa página A4) / Livro
  (uma foto vira duas páginas). Foto salva em ~8 MP para ser rápida.
- **Edição**: recorte com cantos ajustáveis e correção de perspectiva, giro, filtros (Original, Mágico, P&B, Cinza,
  Clarear), brilho/contraste, remover sombra e ruído, "aplicar a todas".
- **Revisão**: reordenar, girar e excluir páginas antes de gerar o PDF (toque longo seleciona).
- **Opções do PDF**: A4 / Carta / ajustar à imagem, margens, qualidade (Alta/Média/Baixa), numeração,
  marca d'água de texto e OCR (PDF pesquisável, ML Kit com modelo embutido, funciona offline).

Arquivos novos: `CameraScreen`, `ScanReviewScreen`, `ScanEditScreen`, `ScanModels`, `ImageProc`, `ScanOps`.
A detecção de bordas é própria (sem OpenCV): Otsu claro/escuro + preenchimento de fundo por bordas.

## Rascunhos (retomar depois)

- **Digitalização**: as fotos ficam em `filesDir/scan` e a lista de páginas/opções em `scan_draft.json`,
  gravada automaticamente a cada mudança e ao sair do app. Se o Android encerrar o app, a tela inicial mostra
  "Digitalização em andamento" com Continuar/Descartar. Ao sair da revisão há a opção **Salvar rascunho**.
  Começar uma nova digitalização com uma em andamento pergunta antes (nunca sobrescreve em silêncio).
- **Edição de PDF**: ao sair de primeiro plano com alterações não salvas, o app grava uma cópia do arquivo de
  trabalho + anotações em `filesDir/doc_draft` (um único rascunho). A tela inicial mostra "Edição não salva".
  O rascunho é apagado ao salvar uma cópia, descartar ou fechar o documento.
- Abrir outro PDF por fora do app (intent VIEW) com alterações não salvas abre o diálogo Salvar cópia / Descartar / Cancelar.
- Lista de **Recentes**: limite de 30 (`Store.touch`).

## Exportar como PNG

Menu ⋮ do visualizador > **Exportar como PNG…**: escolha as páginas (vazio = todas, ex.: `1-3,5`) e a resolução
(1200 / 2000 / 3000 px de largura). **Salvar** grava em `Downloads/PdfPro` (`nome_p01.png`, `nome_p02.png`…);
**Compartilhar** abre o menu do Android com todas as imagens. Anotações ainda não salvas entram na imagem.
Código: `Ops.exportPng`, `MainViewModel.exportPng`, `ExportPngDialog` (Dialogs.kt).

## Selecionar texto e zoom com toque duplo

- **Copiar texto**: no modo **Ler**, segure o dedo sobre uma palavra e arraste; a seleção (azul) vale para uma página.
  Na barra que aparece: **Copiar**, **Página toda** e ✕ (tocar fora também limpa). PDF escaneado sem OCR não tem texto
  para selecionar (o app avisa). O texto da página é extraído sob demanda (`Ops.pageWords`, cache em `PdfHolder.words`).
- **Toque duplo**: alterna entre 1x e 2,5x mantendo o ponto tocado no lugar (a pinça continua funcionando, 1x a 3x).
Código: `SelectionLayer`, `TextSel`, `doubleTapZoom` (ViewerScreen.kt), `WordStripper` (Ops.kt), `WordBox` (Models.kt).

## Novos recursos (editar anotações, leitura, OCR, imprimir, marca d'água, margens, tarjas)

- **Editar/apagar anotação** (modo Ler): toque numa anotação ainda não gravada → barra com Editar (texto), − / +, cor, Excluir;
  arraste sobre ela para mover. Depois de gravada no PDF (salvar, organizar páginas, etc.) ela vira parte da página.
- **Modos de leitura** (menu ⋮): contínuo ou página a página (deslizar na horizontal; zoom por pinça/toque duplo, e com zoom
  a página rola em vez de trocar). **Tela sempre acesa** também no menu. As duas escolhas ficam salvas.
- **OCR em PDF existente** (menu): acrescenta texto invisível (ML Kit, alfabeto latino) nas páginas escaneadas; opção de pular páginas que já têm texto.
- **Imprimir** (menu): grava as anotações e abre o serviço de impressão do Android.
- **Marca d'água e numeração** e **Recortar margens** (menu): em todas ou numa faixa de páginas. Margens: automático (corta o branco) ou manual em mm; só muda a área visível.
- **Ocultar (tarja preta)**: ferramenta na barra; desenhe as tarjas e toque em **Aplicar tarjas**. As páginas atingidas viram imagem
  (o texto por baixo é apagado de verdade) e deixam de ser pesquisáveis; links de outras páginas continuam apontando para elas.
  Campos de formulário preenchidos, se houver, não são limpos.
Código novo: `Extras.kt` (operações e geometria), `ExtraDialogs.kt`; ligações em `MainViewModel.kt` e `ViewerScreen.kt`.
