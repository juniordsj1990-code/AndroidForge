package com.pdfpro.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

private fun rangeField(s: String) = s.filter { c -> c.isDigit() || c in "-,; " }

private fun numField(s: String) = s.filter { c -> c.isDigit() || c == '.' || c == ',' }.replace(',', '.')

@Composable
fun StampDialog(vm: MainViewModel, pageCount: Int, onDismiss: () -> Unit) {
    var wm by remember { mutableStateOf("") }
    var num by remember { mutableIntStateOf(0) }
    var range by remember { mutableStateOf("") }
    val styles = NumberStyle.values()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Marca d'água e numeração") },
        text = {
            Column(
                Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    wm, { wm = it }, singleLine = true, label = { Text("Marca d'água (opcional)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Numeração das páginas", style = MaterialTheme.typography.labelLarge)
                styles.forEachIndexed { i, st ->
                    Row(
                        Modifier.fillMaxWidth().clickable { num = i },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = num == i, onClick = { num = i })
                        Text(st.label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                OutlinedTextField(
                    range, { range = rangeField(it) }, singleLine = true,
                    label = { Text("Páginas (vazio = todas, $pageCount)") },
                    placeholder = { Text("ex.: 1-3,5") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Fica gravado no PDF. Dá para desfazer logo depois.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.stampPages(range, wm, styles[num]); onDismiss() }) { Text("Aplicar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun CropDialog(vm: MainViewModel, pageCount: Int, currentPage: Int, onDismiss: () -> Unit) {
    var auto by remember { mutableStateOf(true) }
    var top by remember { mutableStateOf("") }
    var bottom by remember { mutableStateOf("") }
    var left by remember { mutableStateOf("") }
    var right by remember { mutableStateOf("") }
    var range by remember { mutableStateOf("") }
    fun mm(s: String) = s.toFloatOrNull() ?: 0f
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Recortar margens") },
        text = {
            Column(
                Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(Modifier.fillMaxWidth().clickable { auto = true }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = auto, onClick = { auto = true })
                    Text("Automático (corta o branco em volta do conteúdo)", style = MaterialTheme.typography.bodyMedium)
                }
                Row(Modifier.fillMaxWidth().clickable { auto = false }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = !auto, onClick = { auto = false })
                    Text("Manual, em milímetros", style = MaterialTheme.typography.bodyMedium)
                }
                if (!auto) {
                    val kb = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(top, { top = numField(it) }, singleLine = true, label = { Text("Topo") }, keyboardOptions = kb, modifier = Modifier.weight(1f))
                        OutlinedTextField(bottom, { bottom = numField(it) }, singleLine = true, label = { Text("Base") }, keyboardOptions = kb, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(left, { left = numField(it) }, singleLine = true, label = { Text("Esquerda") }, keyboardOptions = kb, modifier = Modifier.weight(1f))
                        OutlinedTextField(right, { right = numField(it) }, singleLine = true, label = { Text("Direita") }, keyboardOptions = kb, modifier = Modifier.weight(1f))
                    }
                }
                OutlinedTextField(
                    range, { range = rangeField(it) }, singleLine = true,
                    label = { Text("Páginas (vazio = todas, $pageCount)") },
                    placeholder = { Text("ex.: 1-3,5") },
                    modifier = Modifier.fillMaxWidth()
                )
                TextButton(onClick = { range = (currentPage + 1).toString() }) { Text("Só a página atual (${currentPage + 1})") }
                Text(
                    "Só muda a área visível: o conteúdo continua no arquivo. Dá para desfazer.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.cropPages(range, auto, mm(top), mm(bottom), mm(left), mm(right))
                onDismiss()
            }) { Text("Recortar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun OcrDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var skip by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reconhecer texto (OCR)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Lê as páginas que são imagem (PDF escaneado) e acrescenta um texto invisível por cima, " +
                        "para você poder pesquisar e copiar. O visual do PDF não muda.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Row(Modifier.fillMaxWidth().clickable { skip = !skip }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = skip, onCheckedChange = { skip = it })
                    Text("Pular páginas que já têm texto", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(end = 4.dp))
                }
                Text(
                    "Pode demorar em PDFs grandes. Funciona melhor com texto impresso em alfabeto latino.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = { TextButton(onClick = { vm.ocrPages(skip); onDismiss() }) { Text("Reconhecer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
