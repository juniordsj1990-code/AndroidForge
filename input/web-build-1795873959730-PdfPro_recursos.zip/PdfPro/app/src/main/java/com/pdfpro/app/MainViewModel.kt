package com.pdfpro.app

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Screen { HOME, VIEWER, PAGES, CAMERA, SCAN_REVIEW, SCAN_EDIT, SCAN_VIEW }

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    private val docsDir = File(app.cacheDir, "docs").apply { mkdirs() }
    private val sigFile = File(app.filesDir, "signature.png")

    var screen by mutableStateOf(Screen.HOME)
    var holder by mutableStateOf<PdfHolder?>(null)
    var title by mutableStateOf("")
    var docId by mutableIntStateOf(0)
    var startPage = 0
    var currentPage by mutableIntStateOf(0)

    val annots = mutableStateListOf<Annot>()
    var tool by mutableStateOf(Tool.NONE)
    var color by mutableIntStateOf(0xFFFFEB3B.toInt())
    var penWidth by mutableFloatStateOf(0.004f)
    var textSize by mutableFloatStateOf(0.035f)
    var imageWidth by mutableFloatStateOf(0.3f)
    var stampBitmap by mutableStateOf<Bitmap?>(null)

    var darkReader by mutableStateOf(store.darkReader)
    var pageMode by mutableStateOf(store.pageMode)
    var keepAwake by mutableStateOf(store.keepAwake)
    /** Anotação (ainda não gravada no PDF) escolhida na tela para mover, editar ou excluir. */
    var selAnnot by mutableStateOf<Annot?>(null)
    var busy by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    var needPassword by mutableStateOf(false)
    var passwordError by mutableStateOf(false)
    var bookmarks by mutableStateOf<List<Int>>(emptyList())
    var recents by mutableStateOf(store.recents())
    var matches by mutableStateOf<List<SearchMatch>>(emptyList())
    var matchIndex by mutableIntStateOf(-1)
    var matchJump by mutableIntStateOf(0)
    var matchPages by mutableStateOf<Map<Int, List<Int>>>(emptyMap())
    var searching by mutableStateOf(false)
    var outline by mutableStateOf<List<OutlineItem>>(emptyList())
    var fields by mutableStateOf<List<FormField>>(emptyList())
    var canUndoFile by mutableStateOf(false)

    // ---- escanear (Foto/Imagens → PDF) ----
    var scan by mutableStateOf<ScanSession?>(null)
    var camMode by mutableStateOf(CamMode.DOC)
    var camAuto by mutableStateOf(true)
    var camGrid by mutableStateOf(false)
    var cardFront by mutableStateOf<ScanPage?>(null)
    var editId by mutableLongStateOf(-1L)
    // fotos do scan ficam em filesDir (e não em cache) para sobreviverem se o Android encerrar o app
    private val scanDir = File(app.filesDir, "scan").apply { mkdirs() }
    private val shotLock = Mutex()

    // ---- rascunhos (retomar depois) ----
    private val draftFile = File(app.filesDir, "scan_draft.json")
    private val docDraftDir = File(app.filesDir, "doc_draft")

    /** Nº de páginas de uma digitalização salva em disco, ainda não retomada (0 = nenhuma). */
    var draftPages by mutableIntStateOf(0)

    /** Título da edição de PDF salva em disco, ainda não retomada (null = nenhuma). */
    var docDraftTitle by mutableStateOf<String?>(null)

    /** Outro PDF pediu para abrir enquanto há alterações não salvas: aguarda decisão do usuário. */
    var pendingOpen by mutableStateOf<Uri?>(null)

    private var restoredDirty by mutableStateOf(false)
    private var draftOwned = false
    private var lastDraftWork: String? = null

    val pendingScanPages: Int get() = scan?.pages?.size ?: draftPages
    val hasPendingScan: Boolean get() = pendingScanPages > 0

    val hasChanges: Boolean get() = annots.isNotEmpty() || canUndoFile || restoredDirty

    private var work: File? = null
    private var sourceUri: Uri? = null
    private val versions = ArrayDeque<File>()
    private var pendingFile: File? = null
    private var pendingTitle = ""
    private var pendingUri: Uri? = null

    init {
        docsDir.listFiles()?.forEach { it.delete() }
        File(app.cacheDir, "scan").deleteRecursively() // pasta antiga (versões anteriores)
        initScanDraft()
        docDraftTitle = DocDraft.title(docDraftDir)
        startDraftAutosave()
    }

    private fun newFile() = File(docsDir, "w_${System.nanoTime()}.pdf")

    fun nameOf(uri: Uri): String = try {
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: (uri.lastPathSegment ?: "documento.pdf")
    } catch (e: Exception) {
        uri.lastPathSegment ?: "documento.pdf"
    }

    private fun copyUri(uri: Uri): File {
        val f = newFile()
        app.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f
    }

    // ---------- abrir / fechar ----------

    fun open(uri: Uri) = viewModelScope.launch {
        busy = "Abrindo…"
        try {
            try {
                app.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
                try {
                    app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
            }
            val f = withContext(Dispatchers.IO) { copyUri(uri) }
            loadFile(f, nameOf(uri), uri)
        } catch (e: Exception) {
            message = "Não foi possível abrir o arquivo: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            busy = null
        }
    }

    private suspend fun loadFile(f: File, name: String, uri: Uri?) {
        val h = try {
            withContext(Dispatchers.IO) { PdfHolder(f) }
        } catch (e: SecurityException) {
            pendingFile = f
            pendingTitle = name
            pendingUri = uri
            passwordError = false
            needPassword = true
            return
        }
        val old = holder
        holder = h
        work = f
        sourceUri = uri
        title = name
        versions.clear()
        versions.addLast(f)
        canUndoFile = false
        restoredDirty = false
        annots.clear()
        clearSearch()
        tool = Tool.NONE
        startPage = uri?.let { store.lastPage(it.toString()) }?.coerceIn(0, h.pageCount - 1) ?: 0
        currentPage = startPage
        bookmarks = uri?.let { store.bookmarks(it.toString()) } ?: emptyList()
        docId++
        screen = Screen.VIEWER
        if (uri != null) {
            store.touch(uri.toString(), name, startPage)
            recents = store.recents()
        }
        withContext(Dispatchers.IO) { old?.close() }
    }

    fun unlock(pw: String) = viewModelScope.launch {
        val src = pendingFile ?: return@launch
        busy = "Desbloqueando…"
        try {
            val out = newFile()
            withContext(Dispatchers.IO) { Ops.unlock(src, pw, out) }
            needPassword = false
            loadFile(out, pendingTitle, pendingUri)
        } catch (e: Exception) {
            passwordError = true
        } finally {
            busy = null
        }
    }

    fun closeDoc() {
        val old = holder
        holder = null
        annots.clear()
        versions.clear()
        work = null
        sourceUri = null
        canUndoFile = false
        restoredDirty = false
        if (draftOwned) discardDocDraft()
        clearSearch()
        tool = Tool.NONE
        screen = Screen.HOME
        recents = store.recents()
        viewModelScope.launch(Dispatchers.IO) { old?.close() }
    }

    // ---------- escanear: câmera, importação, edição e geração do PDF ----------

    fun scanFile(): File = File(scanDir, "s_${System.nanoTime()}.jpg")

    private fun session(): ScanSession = scan ?: (restoreScanDraft() ?: ScanSession()).also { scan = it }

    private fun addScanPage(file: File, filter: ScanFilter, corners: List<Float>?) {
        val s = session()
        s.pages.add(ScanPage(s.newId(), file, corners, 0, filter))
    }

    private fun detectOn(file: File): List<Float>? {
        val b = ImageProc.decode(file, 900) ?: return null
        val d = ImageProc.detectQuad(ImageProc.grayFromBitmap(b))
        b.recycle()
        return d?.takeIf { it.area >= 0.25f }?.q
    }

    fun openCamera() {
        session()
        cardFront = null
        screen = Screen.CAMERA
    }

    fun changeCamMode(m: CamMode) {
        if (m == camMode) return
        camMode = m
        viewModelScope.launch { flushFront() }
    }

    private suspend fun flushFront() {
        shotLock.withLock {
            val f = cardFront ?: return
            cardFront = null
            val out = withContext(Dispatchers.Default) { ScanOps.composeCards(scanDir, f, null) }
            addScanPage(out, ScanFilter.ORIGINAL, null)
        }
    }

    fun skipCardBack() {
        viewModelScope.launch { flushFront() }
    }

    /** Chamado pela câmera depois de cada foto salva: detecta as bordas e cria a(s) página(s). */
    fun onShot(file: File) {
        viewModelScope.launch {
            shotLock.withLock {
                try {
                    val mode = camMode
                    val corners = withContext(Dispatchers.Default) { detectOn(file) }
                    when (mode) {
                        CamMode.DOC -> addScanPage(file, ScanFilter.MAGIC, corners)
                        CamMode.BOOK -> {
                            val (l, r) = ImageProc.splitSpread(corners)
                            addScanPage(file, ScanFilter.MAGIC, l)
                            addScanPage(file, ScanFilter.MAGIC, r)
                        }
                        CamMode.CARD -> {
                            val front = cardFront
                            if (front == null) {
                                cardFront = ScanPage(session().newId(), file, corners)
                            } else {
                                cardFront = null
                                val back = ScanPage(0, file, corners)
                                val out = withContext(Dispatchers.Default) { ScanOps.composeCards(scanDir, front, back) }
                                addScanPage(out, ScanFilter.ORIGINAL, null)
                            }
                        }
                    }
                } catch (e: Exception) {
                    message = "Não foi possível processar a foto: ${e.message ?: e.javaClass.simpleName}"
                }
            }
        }
    }

    fun finishCamera() {
        viewModelScope.launch {
            flushFront()
            screen = if (scan?.pages?.isNotEmpty() == true) Screen.SCAN_REVIEW else Screen.HOME
            if (screen == Screen.HOME) discardScan()
        }
    }

    fun leaveCamera() = finishCamera()

    fun importImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            busy = "Carregando imagens…"
            try {
                val loaded = withContext(Dispatchers.IO) {
                    uris.mapNotNull { u ->
                        try {
                            val f = scanFile()
                            app.contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                            f to detectOn(f)
                        } catch (e: Exception) {
                            null
                        }
                    }
                }
                if (loaded.isEmpty()) {
                    message = "Não foi possível abrir as imagens"
                    return@launch
                }
                loaded.forEach { (f, c) -> addScanPage(f, ScanFilter.ORIGINAL, c) }
                screen = Screen.SCAN_REVIEW
            } finally {
                busy = null
            }
        }
    }

    fun openView(id: Long) {
        editId = id
        screen = Screen.SCAN_VIEW
    }

    fun openEdit(id: Long) {
        editId = id
        screen = Screen.SCAN_EDIT
    }

    fun closeEdit() {
        screen = Screen.SCAN_REVIEW
    }

    fun discardScan() {
        scan = null
        draftPages = 0
        draftFile.delete()
        cardFront = null
        editId = -1L
        ScanCache.clear()
        scanDir.listFiles()?.forEach { it.delete() }
    }

    fun exitScan() {
        discardScan()
        screen = Screen.HOME
    }

    // ---------- rascunhos ----------

    /** Ao abrir o app: mantém as fotos de um rascunho válido; se não houver, limpa o que sobrou. */
    private fun initScanDraft() {
        val d = ScanDraft.read(draftFile, scanDir)
        if (d == null) {
            draftFile.delete()
            scanDir.listFiles()?.forEach { it.delete() }
            draftPages = 0
        } else {
            val keep = d.pages.map { it.src.name }.toSet()
            scanDir.listFiles()?.forEach { if (it.name !in keep) it.delete() }
            draftPages = d.pages.size
        }
    }

    /** Grava o rascunho automaticamente (com pequeno atraso) a cada mudança na sessão do scan. */
    private fun startDraftAutosave() {
        viewModelScope.launch {
            snapshotFlow {
                val s = scan
                if (s == null) null else Triple(s.pages.toList(), s.options, s.nextSeq)
            }.collectLatest { snap ->
                if (snap == null) {
                    // sem sessão aberta: só apaga o arquivo se não houver rascunho aguardando retomada
                    if (draftPages == 0) {
                        withContext(Dispatchers.IO) { draftFile.delete() }
                    }
                    return@collectLatest
                }
                delay(500)
                withContext(Dispatchers.IO) {
                    try {
                        if (snap.first.isEmpty()) {
                            draftFile.delete()
                        } else {
                            ScanDraft.write(draftFile, snap.first, snap.second, snap.third)
                        }
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }

    private fun restoreScanDraft(): ScanSession? {
        if (draftPages <= 0) return null
        val d = ScanDraft.read(draftFile, scanDir)
        if (d == null) {
            draftPages = 0
            return null
        }
        val s = ScanSession()
        s.restore(d.pages, d.options, d.nextSeq)
        draftPages = 0
        return s
    }

    /** Volta para a revisão da digitalização em andamento (em memória ou salva em disco). */
    fun resumeScan() {
        if (scan == null) {
            val s = restoreScanDraft()
            if (s == null) {
                message = "Rascunho não encontrado"
                return
            }
            scan = s
        }
        cardFront = null
        screen = Screen.SCAN_REVIEW
    }

    /** Sai da digitalização sem perder as páginas: grava o rascunho agora e volta para a tela inicial. */
    fun leaveScanKeepingDraft() {
        val s = scan ?: return
        if (s.pages.isEmpty()) {
            exitScan()
            return
        }
        try {
            ScanDraft.write(draftFile, s.pages.toList(), s.options, s.nextSeq)
        } catch (e: Exception) {
            message = "Não foi possível salvar o rascunho"
            return
        }
        draftPages = s.pages.size
        scan = null
        cardFront = null
        editId = -1L
        ScanCache.clear()
        screen = Screen.HOME
        message = "Rascunho salvo. Continue pela tela inicial"
    }

    /** Chamado quando o app sai de primeiro plano: grava na hora o que estiver em andamento. */
    fun saveDrafts() {
        val s = scan
        if (s != null && s.pages.isNotEmpty()) {
            try {
                ScanDraft.write(draftFile, s.pages.toList(), s.options, s.nextSeq)
            } catch (e: Exception) {
            }
        }
        saveDocDraft()
    }

    private fun saveDocDraft() {
        if (screen != Screen.VIEWER && screen != Screen.PAGES) return
        if (holder == null) return
        if (!hasChanges) {
            // o usuário desfez tudo: o rascunho gravado antes deste documento não vale mais
            if (draftOwned) discardDocDraft()
            return
        }
        val w = work ?: return
        val list = annots.toList()
        val t = title
        val u = sourceUri?.toString()
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    docDraftDir.mkdirs()
                    val target = File(docDraftDir, DocDraft.WORK)
                    if (lastDraftWork != w.absolutePath || !target.exists()) {
                        val tmp = File(docDraftDir, "work.tmp")
                        w.copyTo(tmp, overwrite = true)
                        if (!tmp.renameTo(target)) {
                            tmp.copyTo(target, overwrite = true)
                            tmp.delete()
                        }
                        lastDraftWork = w.absolutePath
                    }
                    DocDraft.writeState(docDraftDir, t, u, list)
                    true
                } catch (e: Exception) {
                    false
                }
            }
            if (ok) {
                draftOwned = true
                docDraftTitle = null
            }
        }
    }

    fun resumeDocDraft() = viewModelScope.launch {
        busy = "Abrindo rascunho…"
        try {
            val d = withContext(Dispatchers.IO) { DocDraft.read(docDraftDir) }
            if (d == null) {
                docDraftTitle = null
                message = "Rascunho não encontrado"
                return@launch
            }
            val f = withContext(Dispatchers.IO) { File(docDraftDir, DocDraft.WORK).copyTo(newFile(), overwrite = true) }
            loadFile(f, d.title, d.uri?.let { Uri.parse(it) })
            if (work == f) {
                annots.addAll(d.annots)
                restoredDirty = true
                draftOwned = true
                lastDraftWork = f.absolutePath
                docDraftTitle = null
            }
        } catch (e: Exception) {
            message = "Não foi possível abrir o rascunho: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            busy = null
        }
    }

    fun discardDocDraft() {
        docDraftDir.deleteRecursively()
        docDraftTitle = null
        draftOwned = false
        lastDraftWork = null
    }

    /** Pedido externo para abrir um PDF: se há alterações não salvas no documento atual, pergunta antes. */
    fun requestOpen(uri: Uri) {
        if ((screen == Screen.VIEWER || screen == Screen.PAGES) && holder != null && hasChanges) {
            pendingOpen = uri
        } else {
            open(uri)
        }
    }

    fun createScanPdf() {
        val s = scan ?: return
        if (s.pages.isEmpty()) return
        val snapshot = s.pages.toList()
        val opt = s.options
        viewModelScope.launch {
            busy = if (opt.ocr) "Criando PDF e reconhecendo texto…" else "Criando PDF…"
            try {
                val out = newFile()
                val res = withContext(Dispatchers.Default) {
                    ScanOps.buildPdf(snapshot, opt, out) { i, n ->
                        busy = (if (opt.ocr) "Criando PDF e reconhecendo texto… " else "Criando PDF… ") + "$i/$n"
                    }
                }
                val name = "Scan_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date()) + ".pdf"
                loadFile(out, name, null)
                discardScan()
                if (opt.ocr && res.ocrFailed > 0) message = "PDF criado, mas o OCR falhou em ${res.ocrFailed} página(s)"
            } catch (e: Exception) {
                message = "Falha ao criar o PDF: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = null
            }
        }
    }

    fun removeRecent(uri: String) {
        store.remove(uri)
        recents = store.recents()
    }

    // ---------- estado de leitura ----------

    fun onPageChanged(i: Int) {
        currentPage = i
        sourceUri?.let { store.updatePage(it.toString(), i) }
    }

    fun toggleBookmark() {
        bookmarks = if (bookmarks.contains(currentPage)) bookmarks - currentPage else (bookmarks + currentPage).sorted()
        sourceUri?.let { store.setBookmarks(it.toString(), bookmarks) }
    }

    fun removeBookmark(p: Int) {
        bookmarks = bookmarks - p
        sourceUri?.let { store.setBookmarks(it.toString(), bookmarks) }
    }

    fun toggleDark() {
        darkReader = !darkReader
        store.darkReader = darkReader
    }

    fun togglePageMode() {
        pageMode = !pageMode
        store.pageMode = pageMode
    }

    fun toggleKeepAwake() {
        keepAwake = !keepAwake
        store.keepAwake = keepAwake
    }

    // ---------- ferramentas de anotação ----------

    fun selectTool(t: Tool) {
        tool = t
        when (t) {
            Tool.HIGHLIGHT -> color = 0xFFFFEB3B.toInt()
            Tool.UNDERLINE -> color = 0xFF1E88E5.toInt()
            Tool.PEN -> color = 0xFFE53935.toInt()
            Tool.TEXT -> color = 0xFF000000.toInt()
            else -> {}
        }
    }

    fun hasSignature() = sigFile.exists()

    fun useSignature() {
        stampBitmap = BitmapFactory.decodeFile(sigFile.absolutePath)
    }

    fun saveSignature(b: Bitmap) {
        sigFile.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        stampBitmap = b
        selectTool(Tool.IMAGE)
    }

    fun loadStamp(uri: Uri) = viewModelScope.launch {
        val b = withContext(Dispatchers.IO) { Ops.decode(app, uri, 1000, true) }
        if (b == null) {
            message = "Não foi possível abrir a imagem"
        } else {
            stampBitmap = b
            selectTool(Tool.IMAGE)
        }
    }

    fun undo() {
        if (annots.isNotEmpty()) {
            annots.removeAt(annots.lastIndex)
            return
        }
        if (versions.size > 1) {
            viewModelScope.launch {
                versions.removeLast()
                val prev = versions.last()
                try {
                    val nh = withContext(Dispatchers.IO) { PdfHolder(prev) }
                    val old = holder
                    holder = nh
                    work = prev
                    canUndoFile = versions.size > 1
                    withContext(Dispatchers.IO) { old?.close() }
                } catch (e: Exception) {
                    message = "Não foi possível desfazer"
                }
            }
        }
    }

    // ---------- editar a anotação selecionada ----------

    private fun selIndex(): Int {
        val s = selAnnot ?: return -1
        return annots.indexOfFirst { it === s }
    }

    private fun replaceSel(n: Annot) {
        val i = selIndex()
        if (i >= 0) {
            annots[i] = n
            selAnnot = n
        }
    }

    fun deleteSelAnnot() {
        val i = selIndex()
        if (i >= 0) annots.removeAt(i)
        selAnnot = null
    }

    /** Move a anotação selecionada; [dx]/[dy] em fração da página. Mantém tudo dentro da página. */
    fun moveSelAnnot(dx: Float, dy: Float) {
        val a = selAnnot ?: return
        fun lim(lo: Float, hi: Float, d: Float) = d.coerceIn(-lo, 1f - hi)
        when (a) {
            is Annot.Highlight -> {
                val mx = lim(a.l, a.r, dx); val my = lim(a.t, a.b, dy)
                replaceSel(a.copy(l = a.l + mx, r = a.r + mx, t = a.t + my, b = a.b + my))
            }
            is Annot.Underline -> {
                val mx = lim(a.l, a.r, dx); val my = lim(a.t, a.b, dy)
                replaceSel(a.copy(l = a.l + mx, r = a.r + mx, t = a.t + my, b = a.b + my))
            }
            is Annot.Redact -> {
                val mx = lim(a.l, a.r, dx); val my = lim(a.t, a.b, dy)
                replaceSel(a.copy(l = a.l + mx, r = a.r + mx, t = a.t + my, b = a.b + my))
            }
            is Annot.Ink -> {
                val mx = lim(a.pts.minOf { it.first }, a.pts.maxOf { it.first }, dx)
                val my = lim(a.pts.minOf { it.second }, a.pts.maxOf { it.second }, dy)
                replaceSel(a.copy(pts = a.pts.map { (it.first + mx) to (it.second + my) }))
            }
            is Annot.Text -> replaceSel(a.copy(x = (a.x + dx).coerceIn(0f, 1f), y = (a.y + dy).coerceIn(0f, 1f)))
            is Annot.Picture -> {
                val mx = lim(a.l, a.r, dx); val my = lim(a.t, a.b, dy)
                replaceSel(Annot.Picture(a.page, a.l + mx, a.t + my, a.r + mx, a.b + my, a.bitmap))
            }
        }
    }

    fun recolorSelAnnot(c: Int) {
        when (val a = selAnnot ?: return) {
            is Annot.Highlight -> replaceSel(a.copy(color = c))
            is Annot.Underline -> replaceSel(a.copy(color = c))
            is Annot.Ink -> replaceSel(a.copy(color = c))
            is Annot.Text -> replaceSel(a.copy(color = c))
            else -> {}
        }
    }

    /** Aumenta/diminui (texto, traço e imagem). */
    fun scaleSelAnnot(f: Float) {
        when (val a = selAnnot ?: return) {
            is Annot.Text -> replaceSel(a.copy(size = (a.size * f).coerceIn(0.01f, 0.12f)))
            is Annot.Ink -> replaceSel(a.copy(width = (a.width * f).coerceIn(0.001f, 0.03f)))
            is Annot.Picture -> {
                val cx = (a.l + a.r) / 2f
                val cy = (a.t + a.b) / 2f
                val hw = (a.r - a.l) / 2f * f
                val hh = (a.b - a.t) / 2f * f
                if (hw * 2f in 0.03f..1f && hh * 2f in 0.03f..1f) {
                    var l = cx - hw
                    var t = cy - hh
                    l = l.coerceIn(0f, 1f - hw * 2f)
                    t = t.coerceIn(0f, 1f - hh * 2f)
                    replaceSel(Annot.Picture(a.page, l, t, l + hw * 2f, t + hh * 2f, a.bitmap))
                }
            }
            else -> {}
        }
    }

    fun setSelAnnotText(t: String) {
        val a = selAnnot as? Annot.Text ?: return
        if (t.isBlank()) deleteSelAnnot() else replaceSel(a.copy(text = t))
    }

    // ---------- tarjas, marca d'água, margens, OCR, impressão ----------

    /** Grava as anotações (inclui aplicar as tarjas) no PDF de trabalho. */
    fun applyRedactions() = viewModelScope.launch {
        val n = annots.count { it is Annot.Redact }
        busy = "Aplicando tarjas…"
        try {
            commitInternal()
            tool = Tool.NONE
            message = if (n > 0) "Tarjas aplicadas: o texto por baixo foi removido" else "Nenhuma tarja desenhada"
        } catch (e: Exception) {
            message = "Erro: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            busy = null
        }
    }

    private fun pagesFrom(range: String): List<Int>? {
        val n = holder?.pageCount ?: return null
        if (range.isBlank()) return (0 until n).toList()
        val p = Ops.parseRanges(range, n)
        if (p.isEmpty()) {
            message = "Intervalo inválido. Exemplo: 1-3,5"
            return null
        }
        return p
    }

    fun stampPages(range: String, watermark: String, numbering: NumberStyle) {
        if (watermark.isBlank() && numbering == NumberStyle.NONE) {
            message = "Escreva uma marca d'água ou escolha uma numeração"
            return
        }
        val pages = pagesFrom(range) ?: return
        op("Aplicando…") { s, o ->
            Extras.decorate(s, o, pages, watermark, numbering)
            "Aplicado em ${pages.size} página(s)"
        }
    }

    fun cropPages(range: String, auto: Boolean, topMm: Float, bottomMm: Float, leftMm: Float, rightMm: Float) {
        val pages = pagesFrom(range) ?: return
        if (!auto && topMm + bottomMm + leftMm + rightMm <= 0f) {
            message = "Informe pelo menos uma margem"
            return
        }
        val k = 72f / 25.4f
        op("Recortando margens…") { s, o ->
            val n = Extras.cropMargins(s, o, pages, auto, topMm * k, bottomMm * k, leftMm * k, rightMm * k)
            if (n == 0) "Nenhuma página foi recortada" else "Margens recortadas em $n página(s)"
        }
    }

    fun ocrPages(skipWithText: Boolean) {
        op("Reconhecendo texto…") { s, o ->
            val r = Extras.ocrPdf(s, o, skipWithText) { i, n -> busy = "Reconhecendo texto… $i/$n" }
            when {
                r.ok == 0 && r.failed == 0 -> "Nenhuma página precisou de OCR (já têm texto)"
                r.failed > 0 -> "OCR feito em ${r.ok} página(s); falhou em ${r.failed}"
                else -> "Texto reconhecido em ${r.ok} página(s). Agora dá para pesquisar e selecionar"
            }
        }
    }

    /** Grava as anotações e entrega uma cópia do PDF para a impressão. */
    fun preparePrint(onReady: (File, String) -> Unit) = viewModelScope.launch {
        busy = "Preparando impressão…"
        try {
            commitInternal()
            val f = work ?: return@launch
            val copy = newFile()
            withContext(Dispatchers.IO) { f.copyTo(copy, overwrite = true) }
            onReady(copy, baseName().ifBlank { "Documento" })
        } catch (e: Exception) {
            message = "Erro: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            busy = null
        }
    }

    // ---------- núcleo: gravar anotações e aplicar operações ----------

    private suspend fun swap(newFile: File) {
        val nh = withContext(Dispatchers.IO) { PdfHolder(newFile) }
        val old = holder
        holder = nh
        work = newFile
        versions.addLast(newFile)
        canUndoFile = versions.size > 1
        withContext(Dispatchers.IO) { old?.close() }
    }

    private suspend fun commitInternal() {
        if (annots.isEmpty()) return
        val src = work ?: return
        val out = newFile()
        val list = annots.toList()
        withContext(Dispatchers.IO) {
            Ops.flatten(src, out, list)
            // tarjas: as páginas atingidas viram imagem, para o texto por baixo sumir de verdade
            val redacted = list.filterIsInstance<Annot.Redact>().map { it.page }.toSet()
            if (redacted.isNotEmpty()) {
                val tmp = newFile()
                Extras.rasterizePages(out, tmp, redacted)
                tmp.copyTo(out, overwrite = true)
                tmp.delete()
            }
        }
        annots.clear()
        selAnnot = null
        swap(out)
    }

    private suspend fun runOp(label: String, block: (File, File) -> String?): Boolean {
        busy = label
        return try {
            commitInternal()
            val src = work ?: return false
            val out = newFile()
            val msg = withContext(Dispatchers.IO) { block(src, out) }
            swap(out)
            clearSearch()
            if (msg != null) message = msg
            true
        } catch (e: Exception) {
            message = "Erro: ${e.message ?: e.javaClass.simpleName}"
            false
        } finally {
            busy = null
        }
    }

    private fun op(label: String, block: (File, File) -> String?) = viewModelScope.launch { runOp(label, block) }

    private fun baseName() = title.removeSuffix(".pdf").removeSuffix(".PDF")

    // ---------- operações de página ----------

    fun goPages() = viewModelScope.launch {
        busy = "Preparando…"
        try {
            commitInternal()
            screen = Screen.PAGES
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    fun applyPages(order: List<Int>, rot: Map<Int, Int>) = viewModelScope.launch {
        if (runOp("Aplicando…") { s, o -> Ops.rebuild(s, o, order, rot); null }) screen = Screen.VIEWER
    }

    fun extractPages(order: List<Int>) = viewModelScope.launch {
        busy = "Extraindo…"
        try {
            commitInternal()
            val src = work ?: return@launch
            val tmp = newFile()
            val name = "${baseName()}_extraido.pdf"
            val uri = withContext(Dispatchers.IO) {
                Ops.rebuild(src, tmp, order, emptyMap())
                Ops.saveToDownloads(app, tmp, name)
            }
            message = if (uri != null) "Salvo em Downloads/PdfPro/$name" else "Falha ao salvar"
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    fun extractRange(text: String) {
        val n = holder?.pageCount ?: return
        val pages = Ops.parseRanges(text, n)
        if (pages.isEmpty()) message = "Intervalo inválido. Exemplo: 1-3,5" else extractPages(pages)
    }

    fun splitEvery(n: Int) = viewModelScope.launch {
        if (n < 1) {
            message = "Informe um número válido"
            return@launch
        }
        busy = "Dividindo…"
        try {
            commitInternal()
            val src = work ?: return@launch
            val dir = File(docsDir, "split_${System.nanoTime()}")
            val base = baseName()
            val count = withContext(Dispatchers.IO) {
                val files = Ops.splitEvery(src, n, dir)
                files.forEachIndexed { i, f -> Ops.saveToDownloads(app, f, "${base}_parte${i + 1}.pdf") }
                files.size
            }
            message = "$count arquivos salvos em Downloads/PdfPro"
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    fun appendPdfs(uris: List<Uri>) = op("Mesclando…") { s, o ->
        val extra = uris.map { copyUri(it) }
        Ops.merge(listOf(s) + extra, o)
        "PDFs adicionados ao final"
    }

    fun mergeUris(uris: List<Uri>) = viewModelScope.launch {
        busy = "Mesclando…"
        try {
            val out = newFile()
            withContext(Dispatchers.IO) { Ops.merge(uris.map { copyUri(it) }, out) }
            loadFile(out, "Mesclado.pdf", null)
        } catch (e: Exception) {
            message = "Erro ao mesclar: ${e.message}"
        } finally {
            busy = null
        }
    }

    fun imagesToPdf(uris: List<Uri>) = viewModelScope.launch {
        busy = "Criando PDF…"
        try {
            val out = newFile()
            withContext(Dispatchers.IO) { Ops.imagesToPdf(app, uris, out) }
            loadFile(out, "Imagens.pdf", null)
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    fun compress(level: Int) {
        val (q, dim) = when (level) {
            0 -> 80 to 2000
            1 -> 60 to 1500
            else -> 40 to 1100
        }
        op("Comprimindo…") { s, o ->
            Ops.compress(s, o, q, dim)
            "Tamanho: ${s.length() / 1024} KB → ${o.length() / 1024} KB"
        }
    }

    fun protect(pw: String) = viewModelScope.launch {
        busy = "Protegendo…"
        try {
            commitInternal()
            val src = work ?: return@launch
            val tmp = newFile()
            val name = "${baseName()}_protegido.pdf"
            val uri = withContext(Dispatchers.IO) {
                Ops.protect(src, tmp, pw)
                Ops.saveToDownloads(app, tmp, name)
            }
            message = if (uri != null) "Protegido e salvo em Downloads/PdfPro/$name" else "Falha ao salvar"
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    // ---------- busca, índice, formulário ----------

    fun search(q: String) = viewModelScope.launch {
        val f = work ?: return@launch
        searching = true
        val res = try {
            withContext(Dispatchers.IO) { Ops.search(f, q) }
        } catch (e: Exception) {
            emptyList()
        }
        matches = res
        matchPages = res.withIndex().groupBy({ it.value.page }, { it.index })
        matchIndex = -1
        searching = false
        if (res.isEmpty()) message = "Nada encontrado (PDFs escaneados não têm texto pesquisável)"
    }

    /** Seleciona a ocorrência [i] (circular) e pede à tela para rolar até ela. */
    fun selectMatch(i: Int) {
        val n = matches.size
        if (n == 0) return
        matchIndex = ((i % n) + n) % n
        matchJump++
    }

    fun clearSearch() {
        matches = emptyList()
        matchPages = emptyMap()
        matchIndex = -1
    }

    fun loadOutline() = viewModelScope.launch {
        val f = work ?: return@launch
        outline = try {
            withContext(Dispatchers.IO) { Ops.outline(f) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun loadFields() = viewModelScope.launch {
        val f = work ?: return@launch
        fields = try {
            withContext(Dispatchers.IO) { Ops.formFields(f) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun fillForm(values: Map<String, String>) = op("Salvando formulário…") { s, o ->
        Ops.fillForm(s, o, values)
        "Formulário preenchido"
    }

    // ---------- salvar / compartilhar ----------

    fun saveCopy(onDone: (() -> Unit)? = null) = viewModelScope.launch {
        busy = "Salvando…"
        try {
            commitInternal()
            val f = work ?: return@launch
            val name = "${baseName()}_editado.pdf"
            val uri = withContext(Dispatchers.IO) { Ops.saveToDownloads(app, f, name) }
            message = if (uri != null) "Salvo em Downloads/PdfPro/$name" else "Falha ao salvar"
            if (uri != null) onDone?.invoke()
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    fun overwriteOriginal() = viewModelScope.launch {
        val u = sourceUri
        if (u == null) {
            message = "Este documento não tem arquivo original. Use Salvar cópia."
            return@launch
        }
        busy = "Salvando…"
        try {
            commitInternal()
            val f = work ?: return@launch
            withContext(Dispatchers.IO) {
                app.contentResolver.openOutputStream(u, "wt")!!.use { o -> f.inputStream().use { it.copyTo(o) } }
            }
            message = "Arquivo original atualizado"
        } catch (e: Exception) {
            message = "Sem permissão para sobrescrever. Use Salvar cópia."
        } finally {
            busy = null
        }
    }

    /** Exporta páginas como PNG. range vazio = todas. share=true abre o menu de compartilhar; false salva em Downloads/PdfPro. */
    fun exportPng(range: String, widthPx: Int, share: Boolean) = viewModelScope.launch {
        val total = holder?.pageCount ?: return@launch
        val pages = if (range.isBlank()) (0 until total).toList() else Ops.parseRanges(range, total)
        if (pages.isEmpty()) {
            message = "Intervalo inválido. Exemplo: 1-3,5"
            return@launch
        }
        busy = "Gerando PNG…"
        try {
            commitInternal()
            val src = work ?: return@launch
            val base = baseName().replace(Regex("[^\\w .-]"), "_")
            val dir = File(app.cacheDir, "share").apply { mkdirs() }
            val files = withContext(Dispatchers.IO) {
                dir.listFiles()?.filter { it.extension.equals("png", true) }?.forEach { it.delete() }
                Ops.exportPng(src, pages, widthPx, dir, base)
            }
            if (share) {
                val uris = ArrayList(files.map { FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", it) })
                val send = if (uris.size == 1) {
                    Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_STREAM, uris[0]) }
                } else {
                    Intent(Intent.ACTION_SEND_MULTIPLE).apply { putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris) }
                }
                send.type = "image/png"
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                app.startActivity(Intent.createChooser(send, "Compartilhar PNG").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } else {
                val ok = withContext(Dispatchers.IO) { files.count { Ops.saveToDownloads(app, it, it.name) != null } }
                message = if (ok == files.size) "${files.size} imagem(ns) salva(s) em Downloads/PdfPro" else "Falha ao salvar algumas imagens"
            }
        } catch (e: Throwable) {
            message = "Erro: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            busy = null
        }
    }

    fun share() = viewModelScope.launch {
        busy = "Preparando…"
        try {
            commitInternal()
            val f = work ?: return@launch
            val dir = File(app.cacheDir, "share").apply { mkdirs() }
            var safe = title.replace(Regex("[^\\w .-]"), "_")
            if (!safe.endsWith(".pdf", ignoreCase = true)) safe += ".pdf"
            val out = File(dir, safe)
            withContext(Dispatchers.IO) { f.copyTo(out, overwrite = true) }
            val uri = FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", out)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            app.startActivity(Intent.createChooser(send, "Compartilhar PDF").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }
}
