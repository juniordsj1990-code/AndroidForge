package com.pdfpro.app

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.PDResources
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.graphics.state.RenderingMode
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.util.Matrix
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ---------- geometria das anotações (para selecionar / mover na tela) ----------

/** Retângulo da anotação em pixels de uma página de [w] x [h] pixels. */
internal fun annotBounds(a: Annot, w: Float, h: Float): RectF = when (a) {
    is Annot.Highlight -> RectF(a.l * w, a.t * h, a.r * w, a.b * h)
    is Annot.Redact -> RectF(a.l * w, a.t * h, a.r * w, a.b * h)
    is Annot.Underline -> RectF(a.l * w, a.b * h - 2f, a.r * w, a.b * h + 2f)
    is Annot.Picture -> RectF(a.l * w, a.t * h, a.r * w, a.b * h)
    is Annot.Ink -> {
        val pad = a.width * w / 2f
        RectF(
            a.pts.minOf { it.first } * w - pad, a.pts.minOf { it.second } * h - pad,
            a.pts.maxOf { it.first } * w + pad, a.pts.maxOf { it.second } * h + pad
        )
    }
    is Annot.Text -> {
        val size = a.size * w
        val paint = Paint().apply {
            textSize = size
            typeface = Typeface.SANS_SERIF
        }
        val lines = a.text.split("\n")
        val tw = lines.maxOf { paint.measureText(it) }
        RectF(a.x * w, a.y * h, a.x * w + tw, a.y * h + size * (1f + 1.2f * (lines.size - 1)) + size * 0.3f)
    }
}

/** O ponto (em pixels) toca a anotação, com uma folga para o dedo? */
internal fun annotHit(a: Annot, x: Float, y: Float, w: Float, h: Float): Boolean {
    val r = annotBounds(a, w, h)
    val pad = 24f
    return x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad
}

internal fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

// ---------- imprimir ----------

/** Entrega um arquivo PDF ao serviço de impressão do Android. */
class PdfPrintAdapter(private val file: File, private val name: String) : PrintDocumentAdapter() {
    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes?,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback,
        extras: Bundle?
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback.onLayoutCancelled()
            return
        }
        val info = PrintDocumentInfo.Builder(name)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
            .build()
        callback.onLayoutFinished(info, true)
    }

    override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback
    ) {
        Thread {
            try {
                FileInputStream(file).use { input ->
                    FileOutputStream(destination.fileDescriptor).use { output -> input.copyTo(output) }
                }
                callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback.onWriteFailed(e.message)
            }
        }.start()
    }
}

// ---------- operações em PDF aberto ----------

class OcrResult(val ok: Int, val failed: Int, val skipped: Int)

/** Operações bloqueantes (chame em Dispatchers.IO) sobre o PDF aberto: marca d'água, margens, tarjas e OCR. */
object Extras {
    private const val MEM = 24L * 1024 * 1024

    private fun open(f: File): PDDocument = PDDocument.load(f, "", MemoryUsageSetting.setupMixed(MEM))

    /** Página "como exibida" (com rotação): largura/altura em pontos e a matriz para o espaço da página. */
    private class Geo(val box: PDRectangle, val wd: Float, val hd: Float, val m: FloatArray, val rot: Int)

    private fun geo(page: PDPage): Geo {
        val box = page.cropBox
        val w = box.width
        val h = box.height
        val rot = ((page.rotation % 360) + 360) % 360
        val wd = if (rot == 90 || rot == 270) h else w
        val hd = if (rot == 90 || rot == 270) w else h
        val m = when (rot) {
            90 -> floatArrayOf(0f, 1f, -1f, 0f, w, 0f)
            180 -> floatArrayOf(-1f, 0f, 0f, -1f, w, h)
            270 -> floatArrayOf(0f, -1f, 1f, 0f, 0f, h)
            else -> floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
        }
        return Geo(box, wd, hd, m, rot)
    }

    private fun PDPageContentStream.enterView(g: Geo) {
        transform(Matrix(g.m[0], g.m[1], g.m[2], g.m[3], g.m[4] + g.box.lowerLeftX, g.m[5] + g.box.lowerLeftY))
    }

    // ----- marca d'água e numeração -----

    fun decorate(src: File, out: File, pages: List<Int>, watermark: String, numbering: NumberStyle) {
        open(src).use { doc ->
            val font: PDFont = PDType1Font.HELVETICA
            val bold: PDFont = PDType1Font.HELVETICA_BOLD
            val wm = ScanOps.sanitize(bold, watermark.trim(), "")
            val total = doc.numberOfPages
            for (i in pages) {
                if (i !in 0 until total) continue
                val page = doc.getPage(i)
                val g = geo(page)
                val pw = g.wd
                val ph = g.hd
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.enterView(g)
                    if (wm.isNotEmpty()) {
                        val sw = bold.getStringWidth(wm) / 1000f
                        val diag = hypot(pw, ph)
                        val fs = if (sw > 0f) (diag * 0.62f / sw).coerceIn(18f, 120f) else 40f
                        val tw = sw * fs
                        val a = atan2(ph, pw).toDouble()
                        val cosA = cos(a).toFloat()
                        val sinA = sin(a).toFloat()
                        val x0 = pw / 2f - (tw / 2f) * cosA + (fs * 0.35f) * sinA
                        val y0 = ph / 2f - (tw / 2f) * sinA - (fs * 0.35f) * cosA
                        cs.saveGraphicsState()
                        val gs = PDExtendedGraphicsState()
                        gs.setNonStrokingAlphaConstant(0.28f)
                        cs.setGraphicsStateParameters(gs)
                        cs.setNonStrokingColor(110, 110, 110)
                        cs.beginText()
                        cs.setFont(bold, fs)
                        cs.setTextMatrix(Matrix.getRotateInstance(a, x0, y0))
                        cs.showText(wm)
                        cs.endText()
                        cs.restoreGraphicsState()
                    }
                    if (numbering != NumberStyle.NONE) {
                        val raw = if (numbering == NumberStyle.PLAIN) "${i + 1}" else "Página ${i + 1} de $total"
                        val t = ScanOps.sanitize(font, raw, "?")
                        val fs = 10f
                        val tw = font.getStringWidth(t) / 1000f * fs
                        cs.saveGraphicsState()
                        cs.setNonStrokingColor(70, 70, 70)
                        cs.beginText()
                        cs.setFont(font, fs)
                        cs.newLineAtOffset((pw - tw) / 2f, 14f)
                        cs.showText(t)
                        cs.endText()
                        cs.restoreGraphicsState()
                    }
                }
            }
            doc.save(out)
        }
    }

    // ----- recorte de margens (só muda a área visível; o conteúdo continua no arquivo) -----

    /** Devolve em quantas páginas o recorte foi aplicado. Margens manuais em pontos, no sentido "como exibido". */
    fun cropMargins(
        src: File, out: File, pages: List<Int>, auto: Boolean,
        topPt: Float, bottomPt: Float, leftPt: Float, rightPt: Float
    ): Int {
        var done = 0
        val pfd = if (auto) ParcelFileDescriptor.open(src, ParcelFileDescriptor.MODE_READ_ONLY) else null
        val renderer = if (pfd != null) PdfRenderer(pfd) else null
        try {
            open(src).use { doc ->
                for (i in pages) {
                    if (i !in 0 until doc.numberOfPages) continue
                    val page = doc.getPage(i)
                    val g = geo(page)
                    var t = topPt
                    var b = bottomPt
                    var l = leftPt
                    var r = rightPt
                    if (auto) {
                        val f = contentBounds(renderer!!, i) ?: continue
                        val pad = 0.012f
                        l = max(0f, f.left - pad) * g.wd
                        r = max(0f, 1f - f.right - pad) * g.wd
                        t = max(0f, f.top - pad) * g.hd
                        b = max(0f, 1f - f.bottom - pad) * g.hd
                    }
                    // margens "como exibidas" -> lados da página sem rotação
                    val uL: Float
                    val uR: Float
                    val uT: Float
                    val uB: Float
                    when (g.rot) {
                        90 -> { uL = t; uT = r; uR = b; uB = l }
                        180 -> { uL = r; uR = l; uT = b; uB = t }
                        270 -> { uL = b; uT = l; uR = t; uB = r }
                        else -> { uL = l; uR = r; uT = t; uB = b }
                    }
                    val nw = g.box.width - uL - uR
                    val nh = g.box.height - uB - uT
                    if (nw < 36f || nh < 36f) continue
                    page.cropBox = PDRectangle(g.box.lowerLeftX + uL, g.box.lowerLeftY + uB, nw, nh)
                    done++
                }
                doc.save(out)
            }
        } finally {
            renderer?.close()
            pfd?.close()
        }
        return done
    }

    /** Área com conteúdo (fora do branco) da página, em frações 0..1 da página exibida; null se estiver em branco. */
    private fun contentBounds(r: PdfRenderer, index: Int): RectF? {
        r.openPage(index).use { pg ->
            val w = 360
            val h = (w.toFloat() * pg.height / pg.width).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            try {
                bmp.eraseColor(Color.WHITE)
                pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                val px = IntArray(w * h)
                bmp.getPixels(px, 0, w, 0, 0, w, h)
                var minX = w
                var minY = h
                var maxX = -1
                var maxY = -1
                for (y in 0 until h) {
                    for (x in 0 until w) {
                        val c = px[y * w + x]
                        val lum = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
                        if (lum < 240) {
                            if (x < minX) minX = x
                            if (x > maxX) maxX = x
                            if (y < minY) minY = y
                            if (y > maxY) maxY = y
                        }
                    }
                }
                if (maxX < 0) return null
                return RectF(minX.toFloat() / w, minY.toFloat() / h, (maxX + 1).toFloat() / w, (maxY + 1).toFloat() / h)
            } finally {
                bmp.recycle()
            }
        }
    }

    // ----- tarjas: as páginas viram imagem (o texto por baixo some de verdade) -----

    fun rasterizePages(src: File, out: File, pages: Set<Int>, maxDim: Int = 2400) {
        val pfd = ParcelFileDescriptor.open(src, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        try {
            open(src).use { doc ->
                for (i in pages.sorted()) {
                    if (i !in 0 until doc.numberOfPages) continue
                    val pg = r.openPage(i)
                    val wPt = pg.width.toFloat()
                    val hPt = pg.height.toFloat()
                    val scale = maxDim / max(wPt, hPt)
                    val bmp = Bitmap.createBitmap(
                        (wPt * scale).toInt().coerceAtLeast(1), (hPt * scale).toInt().coerceAtLeast(1),
                        Bitmap.Config.ARGB_8888
                    )
                    try {
                        bmp.eraseColor(Color.WHITE)
                        pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        pg.close()
                        // reaproveita o mesmo objeto de página (links/índice continuam apontando para ele),
                        // mas esvazia tudo o que havia: conteúdo, recursos e anotações
                        val page = doc.getPage(i)
                        val rect = PDRectangle(wPt, hPt)
                        page.resources = PDResources()
                        page.annotations = emptyList()
                        page.mediaBox = rect
                        page.cropBox = rect
                        page.rotation = 0
                        val img = JPEGFactory.createFromImage(doc, bmp, 0.92f)
                        PDPageContentStream(doc, page, PDPageContentStream.AppendMode.OVERWRITE, true).use {
                            it.drawImage(img, 0f, 0f, wPt, hPt)
                        }
                    } finally {
                        bmp.recycle()
                    }
                }
                doc.save(out)
            }
        } finally {
            r.close()
            pfd.close()
        }
    }

    // ----- OCR em PDF existente: acrescenta uma camada de texto invisível -----

    private fun pageHasText(doc: PDDocument, i: Int): Boolean = try {
        val st = PDFTextStripper()
        st.startPage = i + 1
        st.endPage = i + 1
        st.getText(doc).trim().length >= 8
    } catch (e: Exception) {
        false
    }

    fun ocrPdf(src: File, out: File, skipWithText: Boolean, progress: (Int, Int) -> Unit): OcrResult {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val pfd = ParcelFileDescriptor.open(src, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        var ok = 0
        var failed = 0
        var skipped = 0
        try {
            open(src).use { doc ->
                val font: PDFont = PDType1Font.HELVETICA
                val n = doc.numberOfPages
                for (i in 0 until n) {
                    progress(i + 1, n)
                    if (skipWithText && pageHasText(doc, i)) {
                        skipped++
                        continue
                    }
                    val pg = r.openPage(i)
                    val wPt = pg.width.toFloat()
                    val hPt = pg.height.toFloat()
                    val scale = 1800f / max(wPt, hPt)
                    val bmp = Bitmap.createBitmap(
                        (wPt * scale).toInt().coerceAtLeast(1), (hPt * scale).toInt().coerceAtLeast(1),
                        Bitmap.Config.ARGB_8888
                    )
                    val lines: List<ScanOps.OcrLine>
                    try {
                        bmp.eraseColor(Color.WHITE)
                        pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        pg.close()
                        lines = try {
                            ScanOps.recognize(recognizer, bmp).also { ok++ }
                        } catch (e: Exception) {
                            failed++
                            emptyList()
                        }
                    } finally {
                        bmp.recycle()
                    }
                    if (lines.isEmpty()) continue
                    val page = doc.getPage(i)
                    val g = geo(page)
                    val k = wPt / (wPt * scale).toInt().coerceAtLeast(1)
                    val fs = 10f
                    PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                        cs.enterView(g)
                        cs.beginText()
                        cs.setRenderingMode(RenderingMode.NEITHER)
                        for (ln in lines) {
                            val t = ScanOps.sanitize(font, ln.text, "?")
                            if (t.isBlank()) continue
                            val nat = font.getStringWidth(t) / 1000f * fs
                            if (nat <= 0f) continue
                            val sx = (ln.width * k) / nat
                            val sy = (ln.height * k * 0.9f) / fs
                            val x = ln.left * k
                            val y = g.hd - (ln.bottom - ln.height * 0.2f) * k
                            cs.setFont(font, fs)
                            cs.setTextMatrix(Matrix(sx, 0f, 0f, sy, x, y))
                            cs.showText(t)
                        }
                        cs.endText()
                    }
                }
                doc.save(out)
            }
        } finally {
            recognizer.close()
            r.close()
            pfd.close()
        }
        return OcrResult(ok, failed, skipped)
    }
}
