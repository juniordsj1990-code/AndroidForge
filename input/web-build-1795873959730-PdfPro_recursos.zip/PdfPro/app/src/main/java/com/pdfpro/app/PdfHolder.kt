package com.pdfpro.app

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import java.io.File
import java.io.IOException

/** Abre um PDF com o PdfRenderer nativo e renderiza páginas em bitmaps (com cache). */
class PdfHolder(val file: File) {
    private val pfd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer: PdfRenderer = try {
        PdfRenderer(pfd)
    } catch (e: Throwable) {
        pfd.close()
        throw e
    }
    private val lock = Any()
    private var closed = false

    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 6).toInt().coerceAtLeast(8 shl 20)
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    val pageCount: Int = renderer.pageCount

    /** Tamanho de cada página em pontos, já considerando a rotação. */
    val sizes: List<Pair<Float, Float>> = (0 until pageCount).map { i ->
        renderer.openPage(i).use { it.width.toFloat() to it.height.toFloat() }
    }

    init {
        if (pageCount == 0) {
            close()
            throw IOException("PDF sem páginas")
        }
    }

    private val wordCache = HashMap<Int, List<WordBox>>()

    fun cachedWords(page: Int): List<WordBox>? = synchronized(wordCache) { wordCache[page] }

    /** Palavras da página (para selecionar/copiar texto). Chamar fora da thread principal. */
    fun words(page: Int): List<WordBox> {
        cachedWords(page)?.let { return it }
        val w = Ops.pageWords(file, page)
        synchronized(wordCache) { wordCache[page] = w }
        return w
    }

    fun render(index: Int, widthPx: Int): Bitmap {
        val w = widthPx.coerceIn(96, 2400)
        val key = "$index:$w"
        cache.get(key)?.let { return it }
        val (pw, ph) = sizes[index]
        val h = (w * ph / pw).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        synchronized(lock) {
            if (closed) return bmp
            renderer.openPage(index).use {
                it.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            }
        }
        cache.put(key, bmp)
        return bmp
    }

    fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            try {
                renderer.close()
            } catch (_: Exception) {
            }
            try {
                pfd.close()
            } catch (_: Exception) {
            }
        }
        cache.evictAll()
        synchronized(wordCache) { wordCache.clear() }
    }
}
