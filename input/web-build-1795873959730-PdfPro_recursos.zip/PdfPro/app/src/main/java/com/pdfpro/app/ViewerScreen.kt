@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pdfpro.app

import android.print.PrintManager
import android.view.WindowManager
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.runtime.rememberUpdatedState
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val palette = listOf(0xFFFFEB3B, 0xFF8BC34A, 0xFFFF80AB, 0xFFE53935, 0xFF1E88E5, 0xFF000000).map { it.toInt() }

private val invertFilter = ColorFilter.colorMatrix(
    ColorMatrix(
        floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        )
    )
)

/** Seleção de texto numa página: palavras [a]..[b] (em qualquer ordem). */
private class TextSel(val page: Int, val words: List<WordBox>, val a: Int, val b: Int) {
    val lo: Int get() = min(a, b)
    val hi: Int get() = max(a, b)

    fun text(): String {
        val sb = StringBuilder()
        for (i in lo..hi) {
            val w = words[i]
            if (i > lo) sb.append(if (w.newLine) '\n' else ' ')
            sb.append(w.text)
        }
        return sb.toString()
    }
}

/** Índice da palavra mais próxima do ponto (normalizado), ou -1 se estiver além de [maxDist] pontos. */
private fun nearestWord(words: List<WordBox>, pw: Float, ph: Float, nx: Float, ny: Float, maxDist: Float): Int {
    var best = -1
    var bestD = Float.MAX_VALUE
    for (i in words.indices) {
        val r = words[i].rect
        val dx = max(max(r.left - nx, nx - r.right), 0f) * pw
        val dy = max(max(r.top - ny, ny - r.bottom), 0f) * ph
        val d = dx * dx + dy * dy * 2.25f
        if (d < bestD) {
            bestD = d
            best = i
        }
    }
    if (best < 0) return -1
    return if (maxDist >= Float.MAX_VALUE || bestD <= maxDist * maxDist) best else -1
}

private enum class Dlg { NONE, GOTO, SEARCH, OUTLINE, FORMS, SPLIT, COMPRESS, PROTECT, SIGN, EXPORT_PNG, DISCARD, STAMP, CROP, OCR }

@Composable
fun ViewerScreen(vm: MainViewModel) {
    val holder = vm.holder ?: return
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val density = LocalDensity.current
    var zoom by remember(vm.docId) { mutableFloatStateOf(1f) }
    var settled by remember(vm.docId) { mutableFloatStateOf(1f) }
    var menuOpen by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf(Dlg.NONE) }
    var textTap by remember { mutableStateOf<Triple<Int, Float, Float>?>(null) }
    var sel by remember(holder) { mutableStateOf<TextSel?>(null) }
    var selStamp by remember { mutableStateOf(0L) }
    val ctx = LocalContext.current
    val pagerState = rememberPagerState(initialPage = vm.startPage.coerceIn(0, max(0, holder.pageCount - 1))) { holder.pageCount }
    val curPage = if (vm.pageMode) pagerState.currentPage else listState.firstVisibleItemIndex
    var editText by remember { mutableStateOf(false) }
    val selA = vm.selAnnot?.takeIf { a -> vm.annots.any { it === a } }

    val mergePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.appendPdfs(uris)
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.loadStamp(uri)
    }

    LaunchedEffect(zoom) {
        delay(300)
        settled = zoom
    }
    LaunchedEffect(vm.tool) {
        if (vm.tool != Tool.NONE) {
            zoom = 1f
            settled = 1f
            sel = null
            vm.selAnnot = null
        }
    }
    LaunchedEffect(vm.selAnnot) {
        if (vm.selAnnot != null) sel = null
    }
    LaunchedEffect(vm.docId) {
        val p = vm.startPage.coerceIn(0, max(0, holder.pageCount - 1))
        if (vm.pageMode) pagerState.scrollToPage(p) else listState.scrollToItem(p)
    }
    LaunchedEffect(vm.pageMode) {
        val target = vm.currentPage.coerceIn(0, max(0, holder.pageCount - 1))
        zoom = 1f
        settled = 1f
        if (vm.pageMode) pagerState.scrollToPage(target) else listState.scrollToItem(target)
    }
    LaunchedEffect(vm.pageMode, listState, pagerState) {
        if (vm.pageMode) {
            snapshotFlow { pagerState.currentPage }.collect { vm.onPageChanged(it) }
        } else {
            snapshotFlow { listState.firstVisibleItemIndex }.collect { vm.onPageChanged(it) }
        }
    }
    DisposableEffect(vm.keepAwake) {
        val w = ctx.findActivity()?.window
        if (vm.keepAwake) w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    fun jumpTo(p: Int) {
        val t = p.coerceIn(0, holder.pageCount - 1)
        scope.launch { if (vm.pageMode) pagerState.animateScrollToPage(t) else listState.animateScrollToItem(t) }
    }

    fun goBack() {
        when {
            sel != null -> sel = null
            vm.tool != Tool.NONE -> vm.tool = Tool.NONE
            vm.hasChanges -> dlg = Dlg.DISCARD
            else -> vm.closeDoc()
        }
    }

    BackHandler { goBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        vm.title.removeSuffix(".pdf").removeSuffix(".PDF"),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    actionIconContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                ),
                navigationIcon = {
                    IconButton(onClick = { goBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                },
                actions = {
                    IconButton(onClick = { vm.undo() }, enabled = vm.annots.isNotEmpty() || vm.canUndoFile) {
                        Icon(Icons.AutoMirrored.Filled.Undo, "Desfazer")
                    }
                    IconButton(onClick = { dlg = Dlg.SEARCH }) { Icon(Icons.Default.Search, "Buscar") }
                    IconButton(onClick = { vm.toggleBookmark() }) {
                        Icon(
                            if (vm.bookmarks.contains(vm.currentPage)) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            "Marcador"
                        )
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Mais") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            MenuItem(Icons.Default.Tag, "Ir para página…") { menuOpen = false; dlg = Dlg.GOTO }
                            MenuItem(Icons.Default.Bookmarks, "Índice e marcadores") { menuOpen = false; vm.loadOutline(); dlg = Dlg.OUTLINE }
                            MenuItem(Icons.Default.EditNote, "Preencher formulário") { menuOpen = false; vm.loadFields(); dlg = Dlg.FORMS }
                            MenuItem(
                                if (vm.darkReader) Icons.Default.LightMode else Icons.Default.DarkMode,
                                if (vm.darkReader) "Modo noturno: desligar" else "Modo noturno: ligar"
                            ) {
                                menuOpen = false; vm.toggleDark()
                            }
                            MenuItem(
                                Icons.Default.ViewAgenda,
                                if (vm.pageMode) "Leitura: voltar ao modo contínuo" else "Leitura: página a página"
                            ) {
                                menuOpen = false; vm.togglePageMode()
                            }
                            MenuItem(
                                Icons.Default.Visibility,
                                if (vm.keepAwake) "Tela sempre acesa: desligar" else "Tela sempre acesa: ligar"
                            ) {
                                menuOpen = false; vm.toggleKeepAwake()
                            }
                            HorizontalDivider()
                            MenuItem(Icons.Default.ViewModule, "Organizar páginas") { menuOpen = false; vm.goPages() }
                            MenuItem(Icons.Default.ContentCut, "Extrair / dividir") { menuOpen = false; dlg = Dlg.SPLIT }
                            MenuItem(Icons.Default.Layers, "Mesclar com outros PDFs") {
                                menuOpen = false; mergePicker.launch(arrayOf("application/pdf"))
                            }
                            MenuItem(Icons.Default.Compress, "Comprimir") { menuOpen = false; dlg = Dlg.COMPRESS }
                            MenuItem(Icons.Default.Lock, "Proteger com senha") { menuOpen = false; dlg = Dlg.PROTECT }
                            MenuItem(Icons.Default.Opacity, "Marca d'água e numeração…") { menuOpen = false; dlg = Dlg.STAMP }
                            MenuItem(Icons.Default.Crop, "Recortar margens…") { menuOpen = false; dlg = Dlg.CROP }
                            MenuItem(Icons.Default.TextFields, "Reconhecer texto (OCR)…") { menuOpen = false; dlg = Dlg.OCR }
                            HorizontalDivider()
                            MenuItem(Icons.Default.SaveAlt, "Salvar cópia (Downloads)") { menuOpen = false; vm.saveCopy() }
                            MenuItem(Icons.Default.Save, "Sobrescrever original") { menuOpen = false; vm.overwriteOriginal() }
                            MenuItem(Icons.Default.Share, "Compartilhar") { menuOpen = false; vm.share() }
                            MenuItem(Icons.Default.ImageIcon, "Exportar como PNG…") { menuOpen = false; dlg = Dlg.EXPORT_PNG }
                            MenuItem(Icons.Default.Print, "Imprimir…") {
                                menuOpen = false
                                vm.preparePrint { f, name ->
                                    val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
                                    pm.print(name, PdfPrintAdapter(f, name), null)
                                }
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surfaceContainerLowest, tonalElevation = 0.dp, shadowElevation = 8.dp) {
                Column(Modifier.navigationBarsPadding()) {
                    if (vm.tool != Tool.NONE) {
                        ToolOptions(
                            vm = vm,
                            page = curPage,
                            count = holder.pageCount,
                            onPrev = { jumpTo(curPage - 1) },
                            onNext = { jumpTo(curPage + 1) },
                            onRedraw = { dlg = Dlg.SIGN },
                            onApplyRedact = { vm.applyRedactions() }
                        )
                    }
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ToolBtn(Icons.Default.PanTool, "Ler", vm.tool == Tool.NONE) { vm.selectTool(Tool.NONE) }
                        ToolBtn(Icons.Default.Highlight, "Marcar", vm.tool == Tool.HIGHLIGHT) { vm.selectTool(Tool.HIGHLIGHT) }
                        ToolBtn(Icons.Default.FormatUnderlined, "Sublinhar", vm.tool == Tool.UNDERLINE) { vm.selectTool(Tool.UNDERLINE) }
                        ToolBtn(Icons.Default.Edit, "Caneta", vm.tool == Tool.PEN) { vm.selectTool(Tool.PEN) }
                        ToolBtn(Icons.Default.TextFields, "Texto", vm.tool == Tool.TEXT) { vm.selectTool(Tool.TEXT) }
                        ToolBtn(Icons.Default.Gesture, "Assinar", vm.tool == Tool.IMAGE) {
                            if (vm.hasSignature()) {
                                vm.useSignature()
                                vm.selectTool(Tool.IMAGE)
                            } else {
                                dlg = Dlg.SIGN
                            }
                        }
                        ToolBtn(Icons.Default.ImageIcon, "Imagem", false) { imagePicker.launch("image/*") }
                        ToolBtn(Icons.Default.VisibilityOff, "Ocultar", vm.tool == Tool.REDACT) { vm.selectTool(Tool.REDACT) }
                    }
                }
            }
        }
    ) { pad ->
        BoxWithConstraints(
            Modifier.padding(pad).fillMaxSize().background(
                if (vm.darkReader) PdfColors.ReaderBgInverted
                else if (isSystemInDarkTheme()) PdfColors.ReaderBgDark
                else PdfColors.ReaderBgLight
            )
        ) {
            val baseW = maxWidth
            val pageW = baseW * zoom - 16.dp
            val hScroll = rememberScrollState()

            // Toque duplo: alterna entre zoom 1x e 2,5x mantendo o ponto tocado no mesmo lugar.
            val doubleTapZoom: (Offset) -> Unit = { tap ->
                val old = zoom
                val target = if (old < 1.5f) 2.5f else 1f
                val baseWpx = with(density) { baseW.toPx() }
                val info = listState.layoutInfo
                val hit = info.visibleItemsInfo.firstOrNull { tap.y < it.offset + it.size }
                    ?: info.visibleItemsInfo.lastOrNull()
                val frac = if (hit != null && hit.size > 0) ((tap.y - hit.offset) / hit.size).coerceIn(0f, 1f) else 0f
                val newPageHpx = if (hit != null) {
                    val (pw, ph) = holder.sizes[hit.index]
                    with(density) { (baseW * target - 16.dp).toPx() } * ph / pw
                } else 0f
                val targetX = ((hScroll.value + tap.x) / (baseWpx * old) * baseWpx * target - tap.x)
                    .roundToInt().coerceAtLeast(0)
                scope.launch {
                    zoom = target
                    repeat(2) { withFrameNanos { } }
                    if (hit != null) {
                        listState.scrollToItem(
                            hit.index,
                            (info.beforeContentPadding + frac * newPageHpx - tap.y).roundToInt()
                        )
                    }
                    hScroll.scrollTo(targetX)
                }
            }
            val renderPx = (with(density) { (baseW * settled - 16.dp).toPx() } / 64f).roundToInt().times(64).coerceIn(256, 2400)

            LaunchedEffect(vm.matchJump) {
                val m = vm.matches.getOrNull(vm.matchIndex) ?: return@LaunchedEffect
                if (m.page !in 0 until holder.pageCount) return@LaunchedEffect
                if (vm.pageMode) {
                    pagerState.animateScrollToPage(m.page)
                    return@LaunchedEffect
                }
                val (pw, ph) = holder.sizes[m.page]
                val pageHpx = with(density) { pageW.toPx() } * ph / pw
                val top = (m.rects.firstOrNull()?.top ?: 0f) * pageHpx
                val viewport = listState.layoutInfo.viewportSize.height
                listState.animateScrollToItem(m.page, (top - viewport / 3f).roundToInt().coerceAtLeast(0))
            }

            if (!vm.pageMode) Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(vm.tool) {
                        if (vm.tool == Tool.NONE) detectPinch { z -> zoom = (zoom * z).coerceIn(1f, 3f) }
                    }
                    .pointerInput(vm.tool, holder, baseW) {
                        if (vm.tool == Tool.NONE) detectTapGestures(
                            onDoubleTap = { off -> doubleTapZoom(off) },
                            onTap = {
                                if (sel != null && System.currentTimeMillis() - selStamp > 400) sel = null
                            }
                        )
                    }
                    .horizontalScroll(hScroll)
            ) {
                LazyColumn(
                    state = listState,
                    userScrollEnabled = vm.tool == Tool.NONE,
                    modifier = Modifier.width(baseW * zoom).fillMaxHeight(),
                    contentPadding = PaddingValues(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(holder.pageCount, key = { it }) { i ->
                        PageView(
                            vm = vm,
                            holder = holder,
                            index = i,
                            width = pageW,
                            renderPx = renderPx,
                            dark = vm.darkReader,
                            onTextTap = { p, x, y -> textTap = Triple(p, x, y) },
                            sel = sel,
                            onSel = { sel = it; selStamp = System.currentTimeMillis() },
                            onSelEnd = { selStamp = System.currentTimeMillis() }
                        )
                    }
                }
            } else {
                PagedReader(
                    vm = vm,
                    holder = holder,
                    pagerState = pagerState,
                    viewW = baseW,
                    viewH = maxHeight,
                    zoom = zoom,
                    settled = settled,
                    setZoom = { zoom = it },
                    onTextTap = { p, x, y -> textTap = Triple(p, x, y) },
                    sel = sel,
                    onSel = { sel = it; selStamp = System.currentTimeMillis() },
                    onSelEnd = { selStamp = System.currentTimeMillis() },
                    onTapClear = { if (sel != null && System.currentTimeMillis() - selStamp > 400) sel = null }
                )
            }

            if (vm.matches.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    tonalElevation = 0.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier.align(Alignment.TopCenter).padding(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { vm.selectMatch(if (vm.matchIndex < 0) -1 else vm.matchIndex - 1) }) {
                            Icon(Icons.Default.KeyboardArrowUp, "Anterior")
                        }
                        Text("${vm.matchIndex + 1} / ${vm.matches.size}", style = MaterialTheme.typography.labelLarge)
                        IconButton(onClick = { vm.selectMatch(vm.matchIndex + 1) }) {
                            Icon(Icons.Default.KeyboardArrowDown, "Próximo")
                        }
                        IconButton(onClick = { vm.clearSearch() }) { Icon(Icons.Default.Close, "Limpar busca") }
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xE6101216),
                modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp)
            ) {
                Text(
                    "${curPage + 1} / ${holder.pageCount}",
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            sel?.let { s ->
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    tonalElevation = 0.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = if (vm.matches.isNotEmpty()) 72.dp else 8.dp, start = 8.dp, end = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = {
                            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("PDF", s.text()))
                            vm.message = "Texto copiado"
                            sel = null
                        }) { Text("Copiar") }
                        TextButton(onClick = {
                            sel = TextSel(s.page, s.words, 0, s.words.lastIndex)
                            selStamp = System.currentTimeMillis()
                        }) { Text("Página toda") }
                        IconButton(onClick = { sel = null }) { Icon(Icons.Default.Close, "Limpar seleção") }
                    }
                }
            }

            selA?.let { a ->
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    tonalElevation = 0.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = if (vm.matches.isNotEmpty()) 72.dp else 8.dp, start = 8.dp, end = 8.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (a is Annot.Text) TextButton(onClick = { editText = true }) { Text("Editar") }
                            if (a is Annot.Text || a is Annot.Ink || a is Annot.Picture) {
                                TextButton(onClick = { vm.scaleSelAnnot(0.9f) }) { Text("−") }
                                TextButton(onClick = { vm.scaleSelAnnot(1.1f) }) { Text("+") }
                            }
                            TextButton(onClick = { vm.deleteSelAnnot() }) { Text("Excluir") }
                            IconButton(onClick = { vm.selAnnot = null }) { Icon(Icons.Default.Close, "Fechar") }
                        }
                        if (a is Annot.Highlight || a is Annot.Underline || a is Annot.Ink || a is Annot.Text) {
                            Row {
                                palette.forEach { c ->
                                    Box(
                                        Modifier
                                            .padding(4.dp)
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(Color(c))
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                                            .clickable { vm.recolorSelAnnot(c) }
                                    )
                                }
                            }
                        }
                        Text(
                            "Arraste para mover",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                }
            }
        }
    }

    val close = { dlg = Dlg.NONE }
    when (dlg) {
        Dlg.GOTO -> GotoDialog(holder.pageCount, { jumpTo(it - 1) }, close)
        Dlg.SEARCH -> SearchDialog(vm, close)
        Dlg.OUTLINE -> OutlineDialog(vm, { jumpTo(it) }, close)
        Dlg.FORMS -> FormsDialog(vm, close)
        Dlg.SPLIT -> SplitDialog(vm, close)
        Dlg.COMPRESS -> CompressDialog(vm, close)
        Dlg.PROTECT -> ProtectDialog(vm, close)
        Dlg.EXPORT_PNG -> ExportPngDialog(vm, holder.pageCount, curPage, close)
        Dlg.STAMP -> StampDialog(vm, holder.pageCount, close)
        Dlg.CROP -> CropDialog(vm, holder.pageCount, curPage, close)
        Dlg.OCR -> OcrDialog(vm, close)
        Dlg.SIGN -> SignatureDialog({ vm.saveSignature(it) }, close)
        Dlg.DISCARD -> DiscardDialog(
            onSave = { dlg = Dlg.NONE; vm.saveCopy { vm.closeDoc() } },
            onDiscard = { dlg = Dlg.NONE; vm.closeDoc() },
            onDismiss = close
        )
        Dlg.NONE -> {}
    }

    if (editText && selA is Annot.Text) {
        TextInputDialog(
            onDismiss = { editText = false },
            onOk = { t -> vm.setSelAnnotText(t); editText = false },
            initial = selA.text,
            confirm = "Salvar"
        )
    }

    textTap?.let { (pg, nx, ny) ->
        TextInputDialog(
            onDismiss = { textTap = null },
            onOk = { t ->
                if (t.isNotBlank()) vm.annots.add(Annot.Text(pg, nx, ny, t, vm.textSize, vm.color))
                textTap = null
            }
        )
    }
}

@Composable
private fun MenuItem(icon: ImageVector, text: String, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(text, style = MaterialTheme.typography.bodyMedium) },
        leadingIcon = { Icon(icon, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant) },
        onClick = onClick
    )
}

@Composable
private fun ToolBtn(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .clip(shape)
            .background(if (selected) cs.primaryContainer else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, Modifier.size(22.dp), tint = if (selected) cs.primary else cs.onSurfaceVariant)
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = if (selected) cs.primary else cs.onSurfaceVariant
        )
    }
}

@Composable
private fun ToolOptions(
    vm: MainViewModel,
    page: Int,
    count: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onRedraw: () -> Unit,
    onApplyRedact: () -> Unit
) {
    Column(Modifier.padding(horizontal = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (vm.tool == Tool.REDACT) {
                TextButton(onClick = onApplyRedact) { Text("Aplicar tarjas") }
            } else if (vm.tool != Tool.IMAGE) {
                palette.forEach { c ->
                    Box(
                        Modifier
                            .padding(4.dp)
                            .size(if (vm.color == c) 30.dp else 24.dp)
                            .clip(CircleShape)
                            .background(Color(c))
                            .border(
                                if (vm.color == c) 2.5.dp else 1.dp,
                                if (vm.color == c) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant,
                                CircleShape
                            )
                            .clickable { vm.color = c }
                    )
                }
            } else {
                TextButton(onClick = onRedraw) { Text("Nova assinatura") }
            }
            Box(Modifier.weight(1f))
            IconButton(onClick = onPrev) { Icon(Icons.Default.KeyboardArrowUp, "Página anterior") }
            Text("${page + 1}/$count", style = MaterialTheme.typography.labelLarge)
            IconButton(onClick = onNext) { Icon(Icons.Default.KeyboardArrowDown, "Próxima página") }
        }
        when (vm.tool) {
            Tool.PEN -> LabeledSlider("Espessura", vm.penWidth, 0.002f..0.015f) { vm.penWidth = it }
            Tool.TEXT -> LabeledSlider("Tamanho", vm.textSize, 0.015f..0.08f) { vm.textSize = it }
            Tool.IMAGE -> LabeledSlider("Largura", vm.imageWidth, 0.1f..0.8f) { vm.imageWidth = it }
            else -> {}
        }
        Text(
            when (vm.tool) {
                Tool.HIGHLIGHT, Tool.UNDERLINE -> "Arraste sobre o texto para marcar"
                Tool.PEN -> "Desenhe com o dedo"
                Tool.TEXT -> "Toque onde quer escrever"
                Tool.IMAGE -> "Arraste na página e solte para posicionar"
                Tool.REDACT -> "Arraste sobre o que quer esconder e toque em Aplicar tarjas. A página vira imagem e o texto por baixo é apagado"
                else -> ""
            },
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
        )
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(80.dp))
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun PageView(
    vm: MainViewModel,
    holder: PdfHolder,
    index: Int,
    width: Dp,
    renderPx: Int,
    dark: Boolean,
    onTextTap: (Int, Float, Float) -> Unit,
    sel: TextSel?,
    onSel: (TextSel?) -> Unit,
    onSelEnd: () -> Unit
) {
    val (pw, ph) = holder.sizes[index]
    val height = width * (ph / pw)
    var bmp by remember(holder, index) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(holder, index, renderPx) {
        bmp = withContext(Dispatchers.IO) { holder.render(index, renderPx) }
    }
    val img = remember(bmp) { bmp?.asImageBitmap() }
    Box(
        Modifier
            .width(width)
            .height(height)
            .shadow(5.dp, RoundedCornerShape(2.dp), clip = false)
            .background(Color.White)
    ) {
        if (img != null) {
            Image(
                bitmap = img,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds,
                colorFilter = if (dark) invertFilter else null
            )
        }
        AnnotLayer(vm, index, onTextTap)
        SelectionLayer(vm, holder, index, sel, onSel, onSelEnd)
    }
}

/** Seleção de texto: segure e arraste sobre o texto (só no modo Ler). */
@Composable
private fun SelectionLayer(
    vm: MainViewModel,
    holder: PdfHolder,
    page: Int,
    sel: TextSel?,
    onSel: (TextSel?) -> Unit,
    onEnd: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val (pw, ph) = holder.sizes[page]
    val mine = if (sel != null && sel.page == page) sel else null
    val selAnnot = vm.selAnnot?.takeIf { a -> a.page == page && vm.annots.any { it === a } }
    val gestures = if (vm.tool == Tool.NONE) {
        Modifier.pointerInput(page) {
            // toque numa anotação seleciona; com ela selecionada, arrastar em cima dela a move
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val w = size.width.toFloat()
                val h = size.height.toFloat()
                val cur = vm.selAnnot?.takeIf { a -> a.page == page && vm.annots.any { it === a } }
                val dragging = cur != null && annotHit(cur, down.position.x, down.position.y, w, h)
                val start = down.position
                val slop = viewConfiguration.touchSlop
                val t0 = down.uptimeMillis
                while (true) {
                    val ev = awaitPointerEvent()
                    if (ev.changes.size > 1) return@awaitEachGesture
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: return@awaitEachGesture
                    if (ch.isConsumed && !dragging) return@awaitEachGesture
                    if (ch.changedToUp()) {
                        if (!dragging && ch.uptimeMillis - t0 < 350 && (ch.position - start).getDistance() <= slop) {
                            vm.selAnnot = vm.annots.lastOrNull {
                                it.page == page && annotHit(it, ch.position.x, ch.position.y, w, h)
                            }
                        }
                        return@awaitEachGesture
                    }
                    if (dragging) {
                        val d = ch.positionChange()
                        if (d != Offset.Zero) {
                            vm.moveSelAnnot(d.x / w, d.y / h)
                            ch.consume()
                        }
                    } else if ((ch.position - start).getDistance() > slop) {
                        return@awaitEachGesture
                    }
                }
            }
        }.pointerInput(holder, page) {
            var loaded: List<WordBox>? = holder.cachedWords(page)
            var anchor = -1
            var pending = Offset.Zero
            var job: Job? = null
            detectDragGesturesAfterLongPress(
                onDragStart = { off ->
                    pending = off
                    anchor = -1
                    job?.cancel()
                    job = scope.launch {
                        val ws = loaded ?: withContext(Dispatchers.IO) {
                            try {
                                holder.words(page)
                            } catch (e: Throwable) {
                                emptyList()
                            }
                        }.also { loaded = it }
                        if (ws.isEmpty()) {
                            vm.message = "Esta página não tem texto selecionável"
                            return@launch
                        }
                        val a = nearestWord(ws, pw, ph, pending.x / size.width, pending.y / size.height, 28f)
                        if (a < 0) return@launch
                        anchor = a
                        val f = nearestWord(ws, pw, ph, pending.x / size.width, pending.y / size.height, Float.MAX_VALUE)
                        onSel(TextSel(page, ws, a, if (f >= 0) f else a))
                    }
                },
                onDrag = { change, _ ->
                    pending = change.position
                    val ws = loaded
                    if (anchor >= 0 && ws != null) {
                        val f = nearestWord(
                            ws, pw, ph,
                            change.position.x / size.width, change.position.y / size.height,
                            Float.MAX_VALUE
                        )
                        if (f >= 0) onSel(TextSel(page, ws, anchor, f))
                    }
                },
                onDragEnd = { onEnd() },
                onDragCancel = { onEnd() }
            )
        }
    } else Modifier
    Canvas(Modifier.fillMaxSize().then(gestures)) {
        val w = size.width
        val h = size.height
        if (selAnnot != null) {
            val r = annotBounds(selAnnot, w, h)
            drawRect(
                Color(0xFF3D8BFD),
                Offset(r.left - 6f, r.top - 6f),
                Size(r.width() + 12f, r.height() + 12f),
                style = Stroke(width = 3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
            )
        }
        val s = mine ?: return@Canvas
        for (i in s.lo..s.hi) {
            val r = s.words[i].rect
            var right = r.right
            if (i < s.hi && !s.words[i + 1].newLine) right = max(right, s.words[i + 1].rect.left)
            drawRect(
                Color(0x663D8BFD),
                Offset(r.left * w, r.top * h),
                Size((right - r.left) * w, (r.bottom - r.top) * h)
            )
        }
    }
}

@Composable
private fun AnnotLayer(vm: MainViewModel, page: Int, onTextTap: (Int, Float, Float) -> Unit) {
    val tool = vm.tool
    val color = vm.color
    val stamp = vm.stampBitmap
    val stampImg = remember(stamp) { stamp?.asImageBitmap() }
    var pts by remember { mutableStateOf<List<Offset>>(emptyList()) }
    val mine = vm.annots.filter { it.page == page }

    Canvas(
        Modifier
            .fillMaxSize()
            .pointerInput(tool, color, vm.penWidth, vm.imageWidth, stamp) {
                if (tool == Tool.NONE) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val start = down.position
                    var last = start
                    var moved = false
                    pts = listOf(start)
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) break
                        last = ch.position
                        if ((last - start).getDistance() > 10f) moved = true
                        pts = if (tool == Tool.PEN) pts + last else listOf(start, last)
                        ch.consume()
                    }
                    fun nx(v: Float) = (v / w).coerceIn(0f, 1f)
                    fun ny(v: Float) = (v / h).coerceIn(0f, 1f)
                    when (tool) {
                        Tool.HIGHLIGHT, Tool.UNDERLINE -> if (moved) {
                            val l = nx(min(start.x, last.x))
                            val r = nx(max(start.x, last.x))
                            val t = ny(min(start.y, last.y))
                            val b = ny(max(start.y, last.y))
                            if (r - l > 0.005f && b - t > 0.002f) {
                                vm.annots.add(
                                    if (tool == Tool.HIGHLIGHT) Annot.Highlight(page, l, t, r, b, color)
                                    else Annot.Underline(page, l, t, r, b, color)
                                )
                            }
                        }
                        Tool.REDACT -> if (moved) {
                            val l = nx(min(start.x, last.x))
                            val r = nx(max(start.x, last.x))
                            val t = ny(min(start.y, last.y))
                            val b = ny(max(start.y, last.y))
                            if (r - l > 0.005f && b - t > 0.003f) vm.annots.add(Annot.Redact(page, l, t, r, b))
                        }
                        Tool.PEN -> vm.annots.add(Annot.Ink(page, pts.map { nx(it.x) to ny(it.y) }, color, vm.penWidth))
                        Tool.TEXT -> if (!moved) onTextTap(page, nx(start.x), ny(start.y))
                        Tool.IMAGE -> if (stamp != null) {
                            val wN = vm.imageWidth
                            val hN = (wN * w * stamp.height / stamp.width) / h
                            val l = (nx(last.x) - wN / 2f).coerceIn(0f, max(0f, 1f - wN))
                            val t = (ny(last.y) - hN / 2f).coerceIn(0f, max(0f, 1f - hN))
                            vm.annots.add(Annot.Picture(page, l, t, l + wN, t + hN, stamp))
                        }
                        else -> {}
                    }
                    pts = emptyList()
                }
            }
    ) {
        val w = size.width
        val h = size.height
        mine.forEach { drawAnnot(it, w, h) }
        vm.matchPages[page]?.forEach { idx ->
            val m = vm.matches.getOrNull(idx) ?: return@forEach
            val current = idx == vm.matchIndex
            m.rects.forEach { r ->
                val tl = Offset(r.left * w, r.top * h)
                val sz = Size((r.right - r.left) * w, (r.bottom - r.top) * h)
                drawRect(
                    if (current) Color(0xFFFF6D00).copy(alpha = 0.5f) else Color(0xFFFFC107).copy(alpha = 0.35f),
                    tl,
                    sz
                )
                if (current) drawRect(Color(0xFFE65100), tl, sz, style = Stroke(width = 3f))
            }
        }
        if (pts.isNotEmpty()) {
            val c = Color(color)
            val a = pts.first()
            val b = pts.last()
            when (tool) {
                Tool.HIGHLIGHT -> drawRect(
                    c.copy(alpha = 0.4f),
                    Offset(min(a.x, b.x), min(a.y, b.y)),
                    Size(abs(a.x - b.x), abs(a.y - b.y))
                )
                Tool.REDACT -> drawRect(
                    Color.Black.copy(alpha = 0.85f),
                    Offset(min(a.x, b.x), min(a.y, b.y)),
                    Size(abs(a.x - b.x), abs(a.y - b.y))
                )
                Tool.UNDERLINE -> drawLine(
                    c,
                    Offset(min(a.x, b.x), max(a.y, b.y)),
                    Offset(max(a.x, b.x), max(a.y, b.y)),
                    strokeWidth = max(2f, w * 0.0025f)
                )
                Tool.PEN -> {
                    val p = Path()
                    pts.forEachIndexed { i, o -> if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }
                    drawPath(p, c, style = Stroke(width = vm.penWidth * w, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                Tool.IMAGE -> if (stampImg != null && stamp != null) {
                    val gw = vm.imageWidth * w
                    val gh = gw * stamp.height / stamp.width
                    drawImage(
                        stampImg,
                        dstOffset = IntOffset((b.x - gw / 2f).roundToInt(), (b.y - gh / 2f).roundToInt()),
                        dstSize = IntSize(gw.roundToInt(), gh.roundToInt()),
                        alpha = 0.6f
                    )
                }
                else -> {}
            }
        }
    }
}

private fun DrawScope.drawAnnot(a: Annot, w: Float, h: Float) {
    when (a) {
        is Annot.Highlight -> drawRect(
            Color(a.color).copy(alpha = 0.4f),
            Offset(a.l * w, a.t * h),
            Size((a.r - a.l) * w, (a.b - a.t) * h)
        )
        is Annot.Redact -> drawRect(
            Color.Black,
            Offset(a.l * w, a.t * h),
            Size((a.r - a.l) * w, (a.b - a.t) * h)
        )
        is Annot.Underline -> drawLine(
            Color(a.color),
            Offset(a.l * w, a.b * h),
            Offset(a.r * w, a.b * h),
            strokeWidth = max(2f, w * 0.0025f)
        )
        is Annot.Ink -> {
            val p = Path()
            a.pts.forEachIndexed { i, o ->
                if (i == 0) p.moveTo(o.first * w, o.second * h) else p.lineTo(o.first * w, o.second * h)
            }
            if (a.pts.size == 1) p.lineTo(a.pts[0].first * w + 0.1f, a.pts[0].second * h)
            drawPath(p, Color(a.color), style = Stroke(width = a.width * w, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        is Annot.Text -> drawIntoCanvas { c ->
            val paint = android.graphics.Paint().apply {
                isAntiAlias = true
                color = a.color
                textSize = a.size * w
                typeface = Typeface.SANS_SERIF
            }
            a.text.split("\n").forEachIndexed { i, line ->
                c.nativeCanvas.drawText(line, a.x * w, a.y * h + a.size * w * (1f + 1.2f * i), paint)
            }
        }
        is Annot.Picture -> drawImage(
            a.image,
            dstOffset = IntOffset((a.l * w).roundToInt(), (a.t * h).roundToInt()),
            dstSize = IntSize(((a.r - a.l) * w).roundToInt(), ((a.b - a.t) * h).roundToInt())
        )
    }
}

/** Leitura página a página: cada página cabe na tela; deslize na horizontal para trocar de página. */
@Composable
private fun PagedReader(
    vm: MainViewModel,
    holder: PdfHolder,
    pagerState: PagerState,
    viewW: Dp,
    viewH: Dp,
    zoom: Float,
    settled: Float,
    setZoom: (Float) -> Unit,
    onTextTap: (Int, Float, Float) -> Unit,
    sel: TextSel?,
    onSel: (TextSel?) -> Unit,
    onSelEnd: () -> Unit,
    onTapClear: () -> Unit
) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val zoomNow by rememberUpdatedState(zoom)
    HorizontalPager(
        state = pagerState,
        modifier = Modifier.fillMaxSize(),
        userScrollEnabled = vm.tool == Tool.NONE && zoom <= 1.01f,
        key = { it }
    ) { i ->
        val (pw, ph) = holder.sizes[i]
        val fitW = minOf(viewW - 16.dp, (viewH - 16.dp) * (pw / ph))
        val pageW = fitW * zoom
        val renderPx = (with(density) { (fitW * settled).toPx() } / 64f).roundToInt().times(64).coerceIn(256, 2400)
        val vs = rememberScrollState()
        val hs = rememberScrollState()
        val zoomed = zoom > 1.01f

        // Toque duplo: 1x <-> 2,5x mantendo o ponto tocado no mesmo lugar.
        val doubleTap: (Offset) -> Unit = { tap ->
            val old = zoomNow
            val target = if (old < 1.5f) 2.5f else 1f
            val vwPx = with(density) { viewW.toPx() }
            val vhPx = with(density) { viewH.toPx() }
            val fwPx = with(density) { fitW.toPx() }
            val fhPx = fwPx * ph / pw
            val oldW = fwPx * old
            val oldH = fhPx * old
            val newW = fwPx * target
            val newH = fhPx * target
            val leftOld = max(0f, (vwPx - oldW) / 2f)
            val topOld = max(0f, (vhPx - oldH) / 2f)
            val leftNew = max(0f, (vwPx - newW) / 2f)
            val topNew = max(0f, (vhPx - newH) / 2f)
            val fx = ((hs.value + tap.x - leftOld) / oldW).coerceIn(0f, 1f)
            val fy = ((vs.value + tap.y - topOld) / oldH).coerceIn(0f, 1f)
            val tx = (fx * newW + leftNew - tap.x).roundToInt().coerceAtLeast(0)
            val ty = (fy * newH + topNew - tap.y).roundToInt().coerceAtLeast(0)
            scope.launch {
                setZoom(target)
                repeat(2) { withFrameNanos { } }
                hs.scrollTo(tx)
                vs.scrollTo(ty)
            }
        }

        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(vm.tool) {
                    if (vm.tool == Tool.NONE) detectPinch { z -> setZoom((zoomNow * z).coerceIn(1f, 3f)) }
                }
                .pointerInput(vm.tool) {
                    if (vm.tool == Tool.NONE) detectTapGestures(
                        onDoubleTap = { off -> doubleTap(off) },
                        onTap = { onTapClear() }
                    )
                }
                .verticalScroll(vs, enabled = zoomed)
                .horizontalScroll(hs, enabled = zoomed)
        ) {
            Box(
                Modifier.widthIn(min = viewW).heightIn(min = viewH),
                contentAlignment = Alignment.Center
            ) {
                PageView(vm, holder, i, pageW, renderPx, vm.darkReader, onTextTap, sel, onSel, onSelEnd)
            }
        }
    }
}

/** Pinça com 2+ dedos; com 1 dedo deixa a lista rolar normalmente. */
private suspend fun PointerInputScope.detectPinch(onZoom: (Float) -> Unit) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        do {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            if (event.changes.count { it.pressed } >= 2) {
                val z = event.calculateZoom()
                if (z != 1f) {
                    onZoom(z)
                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                }
            }
        } while (event.changes.any { it.pressed })
    }
}
