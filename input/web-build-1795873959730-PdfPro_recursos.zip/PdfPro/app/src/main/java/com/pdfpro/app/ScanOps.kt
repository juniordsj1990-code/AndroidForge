package com.pdfpro.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.graphics.state.RenderingMode
import com.tom_roush.pdfbox.util.Matrix
import java.io.File
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Geração do PDF a partir das páginas escaneadas (bloqueante: chame fora da thread principal). */
object ScanOps {

    class Result(val ocrOk: Int, val ocrFailed: Int)

    internal class OcrLine(val text: String, val left: Float, val bottom: Float, val width: Float, val height: Float)

    fun buildPdf(pages: List<ScanPage>, opt: PdfOptions, out: File, progress: (Int, Int) -> Unit): Result {
        val doc = PDDocument()
        var ocrOk = 0
        var ocrFail = 0
        val recognizer: TextRecognizer? =
            if (opt.ocr) TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) else null
        try {
            val font: PDFont = PDType1Font.HELVETICA
            val bold: PDFont = PDType1Font.HELVETICA_BOLD
            val wm = sanitize(bold, opt.watermark.trim(), "")
            pages.forEachIndexed { idx, pg ->
                progress(idx + 1, pages.size)
                val bmp = ImageProc.render(pg, opt.quality.maxDim)
                    ?: throw IllegalStateException("não foi possível ler a imagem da página ${idx + 1}")
                try {
                    var lines: List<OcrLine> = emptyList()
                    if (recognizer != null) {
                        try {
                            lines = recognize(recognizer, bmp)
                            ocrOk++
                        } catch (e: Exception) {
                            ocrFail++
                        }
                    }
                    addPage(doc, bmp, opt, idx, pages.size, font, bold, wm, lines)
                } finally {
                    bmp.recycle()
                }
            }
            doc.save(out)
        } finally {
            recognizer?.close()
            doc.close()
        }
        return Result(ocrOk, ocrFail)
    }

    internal fun recognize(rec: TextRecognizer, bmp: Bitmap): List<OcrLine> {
        val res = Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)))
        val out = ArrayList<OcrLine>()
        for (block in res.textBlocks) {
            for (ln in block.lines) {
                val r = ln.boundingBox ?: continue
                if (r.width() <= 0 || r.height() <= 0) continue
                out.add(OcrLine(ln.text, r.left.toFloat(), r.bottom.toFloat(), r.width().toFloat(), r.height().toFloat()))
            }
        }
        return out
    }

    /** Mantém só caracteres que a fonte (WinAnsi) consegue codificar. */
    internal fun sanitize(font: PDFont, s: String, replacement: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            if (ch == '\n' || ch == '\r' || ch == '\t') {
                sb.append(' ')
                continue
            }
            if (ch.code < 32) continue
            try {
                font.encode(ch.toString())
                sb.append(ch)
            } catch (e: Exception) {
                sb.append(replacement)
            }
        }
        return sb.toString()
    }

    private fun addPage(
        doc: PDDocument, bmp: Bitmap, opt: PdfOptions, idx: Int, total: Int,
        font: PDFont, bold: PDFont, wm: String, lines: List<OcrLine>
    ) {
        val m = opt.margin.pt
        val bw = bmp.width.toFloat()
        val bh = bmp.height.toFloat()
        val pw: Float
        val ph: Float
        val iw: Float
        val ih: Float
        if (opt.size == PageSize.FIT) {
            val k = 72f / 200f
            iw = bw * k
            ih = bh * k
            pw = iw + 2 * m
            ph = ih + 2 * m
        } else {
            val base = if (opt.size == PageSize.A4) PDRectangle.A4 else PDRectangle.LETTER
            val land = bw > bh
            pw = if (land) base.height else base.width
            ph = if (land) base.width else base.height
            val k = min((pw - 2 * m) / bw, (ph - 2 * m) / bh)
            iw = bw * k
            ih = bh * k
        }
        val page = PDPage(PDRectangle(pw, ph))
        doc.addPage(page)
        val ix = (pw - iw) / 2f
        val iy = (ph - ih) / 2f
        val img = JPEGFactory.createFromImage(doc, bmp, opt.quality.jpeg)

        PDPageContentStream(doc, page).use { cs ->
            cs.drawImage(img, ix, iy, iw, ih)

            // marca d'água diagonal, semitransparente
            if (wm.isNotEmpty()) {
                val sw = bold.getStringWidth(wm) / 1000f
                val diag = hypot(pw, ph)
                val fs = if (sw > 0f) (diag * 0.62f / sw).coerceIn(18f, 120f) else 40f
                val tw = sw * fs
                val a = atan2(ph, pw).toDouble()
                val cosA = cos(a).toFloat()
                val sinA = sin(a).toFloat()
                val x0 = pw / 2f - (tw / 2f) * cosA + (fs * 0.35f) * sinA
                val y0 = ph / 2f - (tw / 2f) * sinA - (fs * 0.35f) * cosA
                cs.saveGraphicsState()
                val gs = PDExtendedGraphicsState()
                gs.setNonStrokingAlphaConstant(0.28f)
                cs.setGraphicsStateParameters(gs)
                cs.setNonStrokingColor(110, 110, 110)
                cs.beginText()
                cs.setFont(bold, fs)
                cs.setTextMatrix(Matrix.getRotateInstance(a, x0, y0))
                cs.showText(wm)
                cs.endText()
                cs.restoreGraphicsState()
            }

            // numeração de páginas
            if (opt.numbering != NumberStyle.NONE) {
                val raw = if (opt.numbering == NumberStyle.PLAIN) "${idx + 1}" else "Página ${idx + 1} de $total"
                val t = sanitize(font, raw, "?")
                val fs = 10f
                val tw = font.getStringWidth(t) / 1000f * fs
                cs.saveGraphicsState()
                cs.setNonStrokingColor(70, 70, 70)
                cs.beginText()
                cs.setFont(font, fs)
                cs.newLineAtOffset((pw - tw) / 2f, 14f)
                cs.showText(t)
                cs.endText()
                cs.restoreGraphicsState()
            }

            // camada de texto invisível (OCR): o PDF fica pesquisável e selecionável
            if (lines.isNotEmpty()) {
                val k = iw / bw
                val fs = 10f
                cs.saveGraphicsState()
                cs.beginText()
                cs.setRenderingMode(RenderingMode.NEITHER)
                for (ln in lines) {
                    val t = sanitize(font, ln.text, "?")
                    if (t.isBlank()) continue
                    val nat = font.getStringWidth(t) / 1000f * fs
                    if (nat <= 0f) continue
                    val sx = (ln.width * k) / nat
                    val sy = (ln.height * k * 0.9f) / fs
                    val x = ix + ln.left * k
                    val y = iy + ih - (ln.bottom - ln.height * 0.2f) * k
                    cs.setFont(font, fs)
                    cs.setTextMatrix(Matrix(sx, 0f, 0f, sy, x, y))
                    cs.showText(t)
                }
                cs.endText()
                cs.restoreGraphicsState()
            }
        }
    }

    /** RG/cartão: junta frente e verso numa única página A4 (como o CamScanner). */
    fun composeCards(dir: File, front: ScanPage, back: ScanPage?): File {
        val cw = 1654
        val ch = 2339
        val canvasBmp = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
        val cv = Canvas(canvasBmp)
        cv.drawColor(Color.WHITE)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            color = 0xFFBBBBBB.toInt()
        }

        fun draw(p: ScanPage, centerY: Float) {
            val src = ImageProc.decode(p.src, 2400) ?: return
            val wp = ImageProc.warp(src, p.corners, 1600)
            if (wp !== src) src.recycle()
            val card = if (wp.height > wp.width) ImageProc.rotate(wp, 90) else wp
            if (card !== wp) wp.recycle()
            var s = 1100f / card.width
            if (card.height * s > 1000f) s = 1000f / card.height
            val dw = card.width * s
            val dh = card.height * s
            val l = (cw - dw) / 2f
            val t = centerY - dh / 2f
            cv.drawBitmap(card, null, android.graphics.RectF(l, t, l + dw, t + dh), paint)
            cv.drawRect(l, t, l + dw, t + dh, border)
            card.recycle()
        }

        if (back == null) {
            draw(front, ch * 0.30f)
        } else {
            draw(front, ch * 0.27f)
            draw(back, ch * 0.70f)
        }
        val out = File(dir, "card_${System.nanoTime()}.jpg")
        out.outputStream().use { canvasBmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        canvasBmp.recycle()
        return out
    }
}
