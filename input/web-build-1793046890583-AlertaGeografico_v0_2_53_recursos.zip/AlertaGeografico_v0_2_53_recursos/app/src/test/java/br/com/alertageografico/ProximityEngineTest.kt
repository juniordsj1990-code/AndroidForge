package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProximityEngineTest {
    private val dest = Destination(id = "a", name = "A", latitude = -23.0, longitude = -46.0, radiusMeters = 200)

    // ~1 grau de latitude = 111,2 km → 0,001° ≈ 111 m
    private fun fixAt(dLat: Double, accuracy: Float = 10f) = Fix(dest.latitude + dLat, dest.longitude, accuracy)

    @Test fun triggersOnceWhenEntering() {
        val e = ProximityEngine()
        assertTrue(e.process(fixAt(0.01), listOf(dest)).triggered.isEmpty())
        assertEquals(1, e.process(fixAt(0.0005), listOf(dest)).triggered.size)
        assertTrue(e.process(fixAt(0.0004), listOf(dest)).triggered.isEmpty())
    }

    @Test fun rearmsOnlyAfterLeavingWithMargin() {
        val e = ProximityEngine()
        e.process(fixAt(0.0), listOf(dest))
        assertTrue(e.process(fixAt(0.0020), listOf(dest)).triggered.isEmpty()) // ~222 m: ainda na margem
        assertTrue(e.process(fixAt(0.0), listOf(dest)).triggered.isEmpty())    // não rearmou
        e.process(fixAt(0.01), listOf(dest))                                    // saiu de vez
        assertEquals(1, e.process(fixAt(0.0), listOf(dest)).triggered.size)
    }

    @Test fun poorAccuracyNeverTriggers() {
        val e = ProximityEngine()
        assertTrue(e.process(fixAt(0.0, accuracy = 400f), listOf(dest)).triggered.isEmpty())
        assertTrue(e.process(fixAt(0.0, accuracy = 400f), listOf(dest)).lowAccuracy)
    }

    @Test fun validFixInsideRadiusTriggersImmediatelyEvenWithMediocreAccuracy() {
        val e = ProximityEngine()
        assertEquals(1, e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.size)
        assertTrue(e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.isEmpty())
    }

    @Test fun reentryTriggersOnlyAfterLeavingRearmMargin() {
        val e = ProximityEngine()
        assertEquals(1, e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.size)
        assertTrue(e.process(fixAt(0.01, accuracy = 60f), listOf(dest)).triggered.isEmpty())
        assertEquals(1, e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.size)
    }

    @Test fun disabledDestinationsAreIgnored() {
        val e = ProximityEngine()
        val r = e.process(fixAt(0.0), listOf(dest.copy(enabled = false)))
        assertTrue(r.triggered.isEmpty())
        assertNull(r.nearestEdgeMeters)
    }

    @Test fun nearestEdgeIsZeroInsideAndPositiveOutside() {
        val e = ProximityEngine()
        assertEquals(0.0, e.process(fixAt(0.0), listOf(dest)).nearestEdgeMeters!!, 0.001)
        val far = e.process(fixAt(0.01), listOf(dest)).nearestEdgeMeters
        assertNotNull(far)
        assertTrue(far!! in 880.0..920.0) // ~1112 m − 200 m
    }

    @Test fun intervalScalesWithDistance() {
        assertEquals(60_000L, ProximityEngine.recommendedIntervalMs(null))
        assertEquals(60_000L, ProximityEngine.recommendedIntervalMs(50_000.0))
        assertEquals(3_000L, ProximityEngine.recommendedIntervalMs(0.0))
        assertEquals(3_000L, ProximityEngine.recommendedIntervalMs(200.0))
        assertEquals(11_111L, ProximityEngine.recommendedIntervalMs(1_000.0))
    }

    // --- Ônibus: aviso por distância + alerta do raio ---
    private val bus = Destination(
        id = "b", name = "B", latitude = -23.0, longitude = -46.0, radiusMeters = 60,
        transportType = TransportType.BUS, distanceAlertMeters = 300
    )
    private fun busFix(dLat: Double) = Fix(bus.latitude + dLat, bus.longitude, 10f)

    @Test fun busFiresDistanceAlertThenRadiusAlert() {
        val e = ProximityEngine()
        assertTrue(e.process(busFix(0.01), listOf(bus)).distanceTriggered.isEmpty())
        val atDistance = e.process(busFix(0.002), listOf(bus)) // ~222 m
        assertEquals(1, atDistance.distanceTriggered.size)
        assertTrue(atDistance.triggered.isEmpty())
        assertTrue(e.process(busFix(0.0018), listOf(bus)).distanceTriggered.isEmpty()) // não repete
        val atRadius = e.process(busFix(0.0003), listOf(bus)) // ~33 m
        assertEquals(1, atRadius.triggered.size)
        assertTrue(atRadius.distanceTriggered.isEmpty())
    }

    @Test fun busEnteringRadiusDirectlySkipsDistanceAlert() {
        val e = ProximityEngine()
        val r = e.process(busFix(0.0003), listOf(bus))
        assertEquals(1, r.triggered.size)
        assertTrue(r.distanceTriggered.isEmpty())
    }

    @Test fun trainNeverFiresDistanceAlert() {
        val e = ProximityEngine()
        val train = bus.copy(transportType = TransportType.TRAIN)
        assertTrue(e.process(busFix(0.002), listOf(train)).distanceTriggered.isEmpty())
    }

    @Test fun destinationJsonKeepsTransportAndDefaultsOldDataToTrain() {
        val restored = Destination.fromJson(bus.toJson())
        assertEquals(TransportType.BUS, restored.transportType)
        assertEquals(300, restored.distanceAlertMeters)
        val old = org.json.JSONObject().put("name", "X").put("latitude", 1.0).put("longitude", 2.0)
        assertEquals(TransportType.TRAIN, Destination.fromJson(old).transportType)
    }

    @Test fun commentSurvivesJsonAndIsLimited() {
        val d = bus.copy(comment = "Descer pela saída B")
        assertEquals("Descer pela saída B", Destination.fromJson(d.toJson()).comment)
        val long = org.json.JSONObject(bus.toJson().toString()).put("comment", "x".repeat(300))
        assertEquals(Destination.COMMENT_MAX_LENGTH, Destination.fromJson(long).comment.length)
        val old = org.json.JSONObject().put("name", "X").put("latitude", 1.0).put("longitude", 2.0)
        assertEquals("", Destination.fromJson(old).comment)
    }

    // --- v0.2.53: cruzamento do raio entre fixes, raio efetivo e histerese ---
    // Ônibus sem aviso por distância (distanceAlertMeters = raio): o raio efetivo só depende da velocidade.
    private val busStop = Destination(id = "c", name = "C", latitude = -23.0, longitude = -46.0, radiusMeters = 60, transportType = TransportType.BUS, distanceAlertMeters = 60)
    // 0,001° de latitude ≈ 111 m
    private fun tFix(dLat: Double, t: Long, speed: Float? = null, acc: Float = 8f, d: Destination = busStop) =
        Fix(d.latitude + dLat, d.longitude, acc, t, speed)

    @Test fun triggersWhenSegmentCrossesRadiusBetweenFixes() {
        val e = ProximityEngine()
        // 300 m antes e 300 m depois do centro, 12 s entre as leituras: nenhum ponto cai nos 60 m.
        assertTrue(e.process(tFix(-0.0027, 1_000), listOf(busStop)).triggered.isEmpty())
        val r = e.process(tFix(0.0027, 13_000), listOf(busStop))
        assertEquals(1, r.triggered.size)
        // não dispara de novo na leitura seguinte
        assertTrue(e.process(tFix(0.0040, 25_000), listOf(busStop)).triggered.isEmpty())
    }

    @Test fun segmentThatPassesFarFromCenterDoesNotTrigger() {
        val e = ProximityEngine()
        // Passa a ~400 m do centro (em longitude), sem cruzar o raio.
        e.process(Fix(busStop.latitude - 0.0027, busStop.longitude + 0.0036, 8f, 1_000), listOf(busStop))
        val r = e.process(Fix(busStop.latitude + 0.0027, busStop.longitude + 0.0036, 8f, 13_000), listOf(busStop))
        assertTrue(r.triggered.isEmpty())
    }

    @Test fun crossingIsIgnoredWithoutTimestampsOrAfterLongGap() {
        val e = ProximityEngine()
        e.process(tFix(-0.0027, 0), listOf(busStop))
        assertTrue(e.process(tFix(0.0027, 0), listOf(busStop)).triggered.isEmpty()) // sem tempo
        val e2 = ProximityEngine()
        e2.process(tFix(-0.0027, 1_000), listOf(busStop))
        assertTrue(e2.process(tFix(0.0027, 200_000), listOf(busStop)).triggered.isEmpty()) // lacuna longa
    }

    @Test fun impossibleJumpDoesNotCountAsCrossing() {
        val e = ProximityEngine()
        e.process(tFix(-0.05, 1_000), listOf(busStop))          // ~5,5 km
        assertTrue(e.process(tFix(0.05, 3_000), listOf(busStop)).triggered.isEmpty()) // 11 km em 2 s
    }

    @Test fun effectiveRadiusGrowsWithSpeedAndIsCapped() {
        val train = dest.copy(radiusMeters = 300)
        assertEquals(300.0, ProximityEngine.effectiveRadius(train, null), 0.001)
        assertEquals(300.0, ProximityEngine.effectiveRadius(train, 1.0f), 0.001)      // devagar: raio configurado
        assertEquals(625.0, ProximityEngine.effectiveRadius(train, 25f), 0.001)       // 25 m/s × 25 s
        assertEquals(1000.0, ProximityEngine.effectiveRadius(train, 60f), 0.001)      // teto
        assertEquals(275.0, ProximityEngine.effectiveRadius(busStop, 11f), 0.001)     // 40 km/h, ônibus
        // com aviso por distância de 300 m, o raio fica abaixo de 60% dele
        assertEquals(180.0, ProximityEngine.effectiveRadius(bus, 20f), 0.001)
    }

    @Test fun fastTrainTriggersEarlierThanConfiguredRadius() {
        val e = ProximityEngine()
        // 25 m/s: dispara a ~500 m (dentro do raio efetivo de 625 m), não só a 300 m.
        val r = e.process(tFix(-0.0045, 1_000, speed = 25f, d = dest), listOf(dest.copy(radiusMeters = 300)))
        assertEquals(1, r.triggered.size)
        val slow = ProximityEngine().process(tFix(-0.0045, 1_000, speed = 3f, d = dest), listOf(dest.copy(radiusMeters = 300)))
        assertTrue(slow.triggered.isEmpty())
    }

    @Test fun slowingDownAfterTriggerDoesNotRearmAndRetrigger() {
        val e = ProximityEngine()
        val stop = busStop
        assertEquals(1, e.process(tFix(-0.0022, 1_000, speed = 11f), listOf(stop)).triggered.size) // ~245 m, r efetivo 275
        // Ônibus quase para no trânsito (r efetivo volta a 60 m) e volta a andar: não repete.
        assertTrue(e.process(tFix(-0.0020, 6_000, speed = 1f), listOf(stop)).triggered.isEmpty())
        assertTrue(e.process(tFix(-0.0019, 11_000, speed = 11f), listOf(stop)).triggered.isEmpty())
    }

    @Test fun busDistanceAlertAndRadiusAlertStaySeparatedAtSpeed() {
        val e = ProximityEngine()
        val b = bus.copy(distanceAlertMeters = 300)
        val far = e.process(Fix(b.latitude - 0.0030, b.longitude, 8f, 1_000, 11f), listOf(b)) // ~333 m
        assertTrue(far.triggered.isEmpty() && far.distanceTriggered.isEmpty())
        val mid = e.process(Fix(b.latitude - 0.0025, b.longitude, 8f, 5_000, 11f), listOf(b)) // ~278 m
        assertEquals(1, mid.distanceTriggered.size)
        assertTrue(mid.triggered.isEmpty()) // raio efetivo ≤ 180 m
    }

    @Test fun markTriggeredPreventsDuplicateWhenSignalReturns() {
        val e = ProximityEngine()
        assertTrue(e.markTriggered(dest))
        assertTrue(e.process(fixAt(0.0), listOf(dest)).triggered.isEmpty())
        assertTrue(!e.markTriggered(dest))
    }

    @Test fun adaptiveIntervalUsesMeasuredSpeed() {
        // 1000 m da borda a 5 m/s: bem mais folgado que o pior caso de 30 m/s
        val slow = ProximityEngine.recommendedIntervalMs(1_000.0, 5.0)
        val worst = ProximityEngine.recommendedIntervalMs(1_000.0)
        assertTrue(slow > worst)
        assertEquals(12_000L, ProximityEngine.bucketIntervalMs(slow.coerceAtMost(12_500L)))
        assertEquals(3_000L, ProximityEngine.bucketIntervalMs(1_000L))
        assertEquals(60_000L, ProximityEngine.bucketIntervalMs(120_000L))
    }
}
