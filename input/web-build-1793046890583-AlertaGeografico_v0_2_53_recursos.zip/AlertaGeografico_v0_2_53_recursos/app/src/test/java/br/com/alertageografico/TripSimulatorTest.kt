package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TripSimulatorTest {
    private val target = -23.5505 to -46.6333

    @Test fun startsAboutOffsetAwayAndEndsOnTarget() {
        val sim = TripSimulator(listOf(target), speedMps = 20.0, startOffsetMeters = 1500.0)
        assertEquals(1500.0, sim.totalMeters, 5.0)
        var fix = sim.step(0.0)
        assertEquals(1500.0, TripSimulator.distance(fix.latitude to fix.longitude, target), 5.0)
        assertFalse(fix.finished)
        repeat(200) { fix = sim.step(1.0) }
        assertTrue(fix.finished)
        assertEquals(0.0, TripSimulator.distance(fix.latitude to fix.longitude, target), 1.0)
    }

    @Test fun distanceToTargetNeverIncreasesOnSingleLeg() {
        val sim = TripSimulator(listOf(target), speedMps = 15.0)
        var last = Double.MAX_VALUE
        repeat(120) {
            val f = sim.step(1.0)
            val d = TripSimulator.distance(f.latitude to f.longitude, target)
            assertTrue(d <= last + 0.01)
            last = d
        }
    }

    @Test fun passesThroughEveryWaypointInOrder() {
        val second = -23.5605 to -46.6433
        val sim = TripSimulator(listOf(target, second), speedMps = 25.0)
        var minToFirst = Double.MAX_VALUE
        var fix = sim.step(0.0)
        repeat(600) {
            fix = sim.step(1.0)
            minToFirst = minOf(minToFirst, TripSimulator.distance(fix.latitude to fix.longitude, target))
        }
        assertTrue(minToFirst < 30.0)
        assertTrue(fix.finished)
        assertEquals(0.0, TripSimulator.distance(fix.latitude to fix.longitude, second), 1.0)
    }
}
