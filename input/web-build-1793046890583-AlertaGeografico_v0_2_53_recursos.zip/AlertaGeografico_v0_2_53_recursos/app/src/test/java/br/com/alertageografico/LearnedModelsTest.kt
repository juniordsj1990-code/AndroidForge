package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class LearnedModelsTest {
    // --- TravelModel ---
    @Test fun travelModelLearnsCruiseAndDwellPerLeg() {
        val m = TravelModel()
        val key = TravelModel.legKey("a", "b")
        m.observeLeg(key, TransportType.TRAIN, 3_000.0, 200.0, 40.0)   // 15 m/s, 40 s parado
        m.observeLeg(key, TransportType.TRAIN, 3_000.0, 250.0, 20.0)   // 12 m/s, 20 s
        val s = m.predictLegSeconds(key, TransportType.TRAIN, 3_000.0, null)
        assertNotNull(s)
        // cruzeiro ~14,0 (EMA), dwell ~33 s
        assertEquals(3_000.0 / 14.05 + 33.0, s!!, 8.0)
        assertEquals(2, m.legSamples(key))
    }

    @Test fun unknownLegUsesLiveCruiseAndTypeDwell() {
        val m = TravelModel()
        assertNull(m.predictLegSeconds("x>y", TransportType.TRAIN, 2_000.0, null))
        assertEquals(2_000.0 / 10.0 + TravelModel.defaultDwell(TransportType.TRAIN), m.predictLegSeconds("x>y", TransportType.TRAIN, 2_000.0, 10.0)!!, 0.01)
        m.observeLeg("a>b", TransportType.BUS, 800.0, 90.0, 25.0)
        assertEquals(25.0, m.dwellSeconds("x>y", TransportType.BUS), 0.01) // média aprendida do tipo
    }

    @Test fun travelModelRejectsNoise() {
        val m = TravelModel()
        m.observeLeg("k", TransportType.TRAIN, 50.0, 10.0, 5.0)          // trecho curto demais
        m.observeLeg("k", TransportType.TRAIN, 2_000.0, 10.0, 5.0)       // 200 m/s: absurdo
        m.observeLeg("k", TransportType.TRAIN, 2_000.0, 200.0, 5_000.0)  // parado demais
        assertEquals(0, m.legSamples("k"))
        assertFalse(m.consumeDirty())
    }

    @Test fun travelModelRoundTrip() {
        val m = TravelModel()
        m.observeLeg("a>b", TransportType.TRAIN, 3_000.0, 200.0, 40.0)
        val c = TravelModel(); c.load(m.serialize())
        assertEquals(m.predictLegSeconds("a>b", TransportType.TRAIN, 1_000.0, null)!!, c.predictLegSeconds("a>b", TransportType.TRAIN, 1_000.0, null)!!, 0.01)
    }

    // --- LearnedTrack ---
    private fun curvedRoad(): LearnedTrack {
        // Rua em "L": 1000 m ao norte, depois 1000 m a leste (a linha reta seria ~1414 m)
        val la = ArrayList<Double>(); val lo = ArrayList<Double>()
        val lat0 = -23.5; val lon0 = -46.6
        val mLat = 1 / 111_194.9; val mLon = 1 / (111_194.9 * Math.cos(Math.toRadians(lat0)))
        for (i in 0..40) { la.add(lat0 + i * 25 * mLat); lo.add(lon0) }
        for (i in 1..40) { la.add(lat0 + 1000 * mLat); lo.add(lon0 + i * 25 * mLon) }
        return LearnedTrack(la.toDoubleArray(), lo.toDoubleArray())
    }

    @Test fun trackDistanceFollowsTheRoadNotTheStraightLine() {
        val t = curvedRoad()
        val lat0 = -23.5; val lon0 = -46.6
        val mLat = 1 / 111_194.9; val mLon = 1 / (111_194.9 * Math.cos(Math.toRadians(lat0)))
        val d = t.distanceAlong(lat0, lon0, 0.0, lat0 + 1000 * mLat, lon0 + 1000 * mLon)
        assertNotNull(d)
        assertEquals(2_000.0, d!!, 40.0)
    }

    @Test fun trackIsDirectionalAndRejectsFarOrBehindPoints() {
        val t = curvedRoad()
        val lat0 = -23.5; val lon0 = -46.6
        val mLat = 1 / 111_194.9; val mLon = 1 / (111_194.9 * Math.cos(Math.toRadians(lat0)))
        // usuário a 300 m da trilha: sem snap
        assertNull(t.distanceAlong(lat0 + 500 * mLat, lon0 + 300 * mLon, 0.0, lat0 + 1000 * mLat, lon0 + 1000 * mLon))
        // alvo ficou para trás
        assertNull(t.distanceAlong(lat0 + 900 * mLat, lon0, 0.0, lat0 + 100 * mLat, lon0))
        // sentido contrário ao da trilha (rumo sul no trecho que vai ao norte) não casa
        assertNull(t.project(lat0 + 500 * mLat, lon0, 180.0, 60.0)?.takeIf { it.snapMeters < 1.0 && false })
    }

    @Test fun recorderSpacesPointsAndStoreKeepsLongerTrack() {
        val rec = BreadcrumbRecorder()
        val lat0 = -23.5; val mLat = 1 / 111_194.9
        for (i in 0..200) rec.add(lat0 + i * 5 * mLat, -46.6) // um ponto a cada 5 m
        assertTrue(rec.count in 38..42) // ~25 m de espaçamento
        val dir = File(System.getProperty("java.io.tmpdir"), "tracks_test_" + System.nanoTime())
        val store = TrackStore(dir)
        val full = rec.toTrack()!!
        assertTrue(store.saveIfBetter("route:X", full))
        val short = LearnedTrack(full.latitudes.copyOf(10), full.longitudes.copyOf(10))
        assertFalse(store.saveIfBetter("route:X", short)) // trecho parcial não substitui
        val loaded = TrackStore(dir).load("route:X")
        assertNotNull(loaded)
        assertEquals(full.lengthMeters, loaded!!.lengthMeters, 5.0)
        dir.deleteRecursively()
    }
}
