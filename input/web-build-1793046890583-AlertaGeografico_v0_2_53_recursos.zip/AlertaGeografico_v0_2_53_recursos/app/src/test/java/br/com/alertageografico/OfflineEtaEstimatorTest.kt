package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class OfflineEtaEstimatorTest {
    private val lat0 = -23.5
    private val lon = -46.6
    private fun lat(distanceFromTarget: Double) = lat0 + distanceFromTarget / 111_194.9

    /** Simula uma viagem a velocidade constante em direção ao alvo (em lat0). */
    private fun fix(t: Long, distanceToTarget: Double, speed: Double?) =
        EtaFix(t, lat(distanceToTarget), lon, 8f, speed, 0.5)

    private fun run(est: OfflineEtaEstimator, stepMs: Long, speed: Double, startDist: Double, seconds: Int, mode: EtaMode = EtaMode.RAIL): EtaEstimate {
        var last: EtaEstimate? = null
        var t = 1_000L
        var d = startDist
        val end = t + seconds * 1000L
        while (t <= end) {
            last = est.update(fix(t, d, speed), t, d, 0, mode)
            t += stepMs; d -= speed * stepMs / 1000.0
        }
        return last!!
    }

    @Test fun smoothedEtaHasNoUpwardBiasAtLongIntervals() {
        // 20 m/s, 12 km restantes = 600 s. Atualizações a cada 30 s: antes, o EMA ficava ~minutos acima.
        val est = OfflineEtaEstimator()
        val e = run(est, 30_000, 20.0, 12_000.0, 150)
        val remainingS = (12_000.0 - 20.0 * 150) / 20.0 // 450 s
        assertEquals(remainingS, e.midSeconds, 12.0)
    }

    @Test fun etaIsCenteredOnTrueTimeAtShortIntervals() {
        val est = OfflineEtaEstimator()
        val e = run(est, 5_000, 15.0, 6_000.0, 100)
        val remainingS = (6_000.0 - 15.0 * 100) / 15.0 // 300 s
        assertEquals(remainingS, e.midSeconds, 6.0)
        assertTrue(e.minSeconds <= remainingS && e.maxSeconds >= remainingS)
    }

    @Test fun priorBandIsNarrowerThanOldTwoXRatio() {
        val est = OfflineEtaEstimator()
        val e = run(est, 5_000, 15.0, 3_000.0, 60) // ~120 s restantes
        assertTrue("faixa ${e.minSeconds}–${e.maxSeconds}", e.maxSeconds / e.minSeconds < 1.6)
    }

    @Test fun gpsLossCountsDownInsteadOfFreezing() {
        val est = OfflineEtaEstimator()
        val before = run(est, 5_000, 15.0, 9_000.0, 60) // posição/tempo do último fix: t≈61 s
        val lastT = 61_000L
        // 90 s depois, sem fix novo (leitura ruim): contagem regressiva
        val low = est.update(EtaFix(lastT + 90_000, lat(1.0), lon, 300f, null, null), lastT + 90_000, 5_000.0, 0)
        assertEquals(EtaConfidence.LOW, low.confidence)
        assertTrue("min ${before.minSeconds} → ${low.minSeconds}", low.minSeconds < before.minSeconds - 80.0)
        val peek = est.peek(lastT + 90_000, 7_000)
        assertEquals(EtaConfidence.NO_GPS, peek.confidence)
        assertEquals(low.minSeconds, peek.minSeconds, 8.0)
    }

    @Test fun stationDwellFreezesTheWindow() {
        val est = OfflineEtaEstimator()
        val moving = run(est, 5_000, 15.0, 6_000.0, 60)
        var t = 61_000L
        var paused: EtaEstimate? = null
        for (k in 0 until 8) { // 40 s parado
            t += 5_000
            paused = est.update(EtaFix(t, lat(5_100.0), lon, 8f, 0.0, 0.3), t, 5_100.0, 0)
        }
        assertTrue(paused!!.confidence == EtaConfidence.PAUSED || paused.confidence == EtaConfidence.LOW)
        assertEquals(moving.midSeconds, paused.midSeconds, 1.0)
        assertTrue("janela congelada: ${moving.maxSeconds} vs ${paused.maxSeconds}", abs(moving.maxSeconds - paused.maxSeconds) < 12.0)
    }

    @Test fun extraDwellAddsToEta() {
        val a = run(OfflineEtaEstimator(), 5_000, 15.0, 6_000.0, 30)
        val est = OfflineEtaEstimator()
        var t = 1_000L; var d = 6_000.0; var b: EtaEstimate? = null
        while (t <= 31_000L) { b = est.update(fix(t, d, 15.0), t, d, 0, EtaMode.RAIL, 90.0); t += 5_000; d -= 75.0 }
        assertEquals(a.midSeconds + 90.0, b!!.midSeconds, 8.0)
    }

    @Test fun busUsesAverageSpeedIncludingStops() {
        val bus = OfflineEtaEstimator()
        val rail = OfflineEtaEstimator()
        var t = 1_000L; var d = 4_000.0
        var eb: EtaEstimate? = null; var er: EtaEstimate? = null
        // 2 min andando a 10 m/s alternando com 30 s parado (semáforo/trânsito)
        for (cycle in 0 until 3) {
            for (k in 0 until 8) { eb = bus.update(fix(t, d, 10.0), t, d, 0, EtaMode.BUS); er = rail.update(fix(t, d, 10.0), t, d, 0, EtaMode.RAIL); t += 5_000; d -= 50.0 }
            for (k in 0 until 6) { eb = bus.update(fix(t, d, 0.0), t, d, 0, EtaMode.BUS); er = rail.update(fix(t, d, 0.0), t, d, 0, EtaMode.RAIL); t += 5_000 }
        }
        assertTrue("ônibus (${eb!!.midSeconds}) deve prever mais tempo que cruzeiro (${er!!.midSeconds})", eb.midSeconds > er.midSeconds * 1.15)
        assertTrue(eb.filteredSpeedMps!! < 8.0)
    }

    @Test fun calibratorLearnsFromRealArrivalsAndNarrowsOrShiftsBand() {
        val cal = EtaCalibrator()
        // 10 viagens em que o trem demora ~30% mais que o previsto
        repeat(10) {
            val est = OfflineEtaEstimator(cal)
            var t = 1_000L; var d = 3_000.0
            // previsão a 20 m/s, mas o trem anda a ~15 m/s depois dos primeiros fixes (relatado 20)
            while (d > 30.0) {
                val real = 15.0
                est.update(fix(t, d, 20.0), t, d, 0)
                t += 5_000; d -= real * 5
            }
            est.update(fix(t, 10.0, 15.0), t, 10.0, 0)
        }
        assertTrue(cal.sampleCount("rail", 200.0) >= EtaCalibrator.MIN_SAMPLES)
        val m = cal.multipliers("rail", 200.0)
        assertTrue("multiplicadores aprendidos", m != null && m.second > 1.15)
        assertTrue(cal.dirty)
        val copy = EtaCalibrator(); copy.load(cal.serialize())
        assertEquals(cal.multipliers("rail", 200.0)!!.second, copy.multipliers("rail", 200.0)!!.second, 0.01)
    }
}
