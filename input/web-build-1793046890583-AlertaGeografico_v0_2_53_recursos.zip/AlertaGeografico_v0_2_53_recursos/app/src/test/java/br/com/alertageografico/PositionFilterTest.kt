package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random
import kotlin.math.cos
import kotlin.math.hypot

class PositionFilterTest {
    private val lat0 = -23.5
    private val lon0 = -46.6
    private fun mLat(m: Double) = m / 111_194.9
    private fun mLon(m: Double) = m / (111_194.9 * cos(Math.toRadians(lat0)))

    @Test fun smoothsNoiseOnConstantVelocityTrack() {
        val rnd = Random(7)
        val f = PositionFilter()
        var rawErr = 0.0; var filtErr = 0.0; var n = 0
        for (i in 0 until 120) {
            val t = i * 1_000L
            val trueNorth = 15.0 * i // 15 m/s para o norte
            val noisyLat = lat0 + mLat(trueNorth + rnd.nextGaussian() * 12)
            val noisyLon = lon0 + mLon(rnd.nextGaussian() * 12)
            val out = f.update(FilterInput(t, noisyLat, noisyLon, 12.0))
            if (i >= 20) {
                rawErr += hypot((noisyLat - (lat0 + mLat(trueNorth))) * 111_194.9, (noisyLon - lon0) * 111_194.9 * cos(Math.toRadians(lat0)))
                filtErr += hypot((out.latitude - (lat0 + mLat(trueNorth))) * 111_194.9, (out.longitude - lon0) * 111_194.9 * cos(Math.toRadians(lat0)))
                n++
            }
        }
        assertTrue("filtrado ${filtErr / n} deve ser menor que bruto ${rawErr / n}", filtErr / n < rawErr / n * 0.75)
    }

    @Test fun estimatesSpeedAndBearing() {
        val f = PositionFilter()
        var last: FilteredFix? = null
        for (i in 0 until 40) {
            last = f.update(FilterInput(i * 1_000L, lat0 + mLat(10.0 * i), lon0, 5.0))
        }
        assertEquals(10.0, last!!.speedMps, 1.0)
        val b = last.bearingDeg
        assertNotNull(b)
        assertTrue(b!! < 5.0 || b > 355.0)
    }

    @Test fun rejectsSingleJumpAndKeepsTrack() {
        val f = PositionFilter()
        for (i in 0 until 30) f.update(FilterInput(i * 1_000L, lat0 + mLat(10.0 * i), lon0, 6.0))
        // salto de 800 m com precisão reportada "boa"
        val bad = f.update(FilterInput(30_000L, lat0 + mLat(300.0 + 800.0), lon0, 8.0))
        assertTrue(bad.rejected)
        assertEquals(300.0, (bad.latitude - lat0) * 111_194.9, 25.0)
    }

    @Test fun acceptsRealJumpAfterRepeatedRejects() {
        val f = PositionFilter()
        for (i in 0 until 30) f.update(FilterInput(i * 1_000L, lat0 + mLat(10.0 * i), lon0, 6.0))
        var out: FilteredFix? = null
        for (k in 0 until 4) out = f.update(FilterInput((30 + k) * 1_000L, lat0 + mLat(2_000.0 + 10.0 * k), lon0, 6.0))
        assertFalse(out!!.rejected)
        assertEquals(2_030.0, (out.latitude - lat0) * 111_194.9, 40.0)
    }

    @Test fun longGapRestartsFilter() {
        val f = PositionFilter()
        f.update(FilterInput(0, lat0, lon0, 8.0))
        val out = f.update(FilterInput(300_000L, lat0 + mLat(5_000.0), lon0, 8.0))
        assertFalse(out.rejected)
        assertEquals(5_000.0, (out.latitude - lat0) * 111_194.9, 5.0)
    }

    @Test fun zeroVelocityUpdateHoldsPositionWhenStopped() {
        val rnd = Random(3)
        val f = PositionFilter()
        var maxDrift = 0.0
        for (i in 0 until 60) {
            val out = f.update(FilterInput(i * 1_000L, lat0 + mLat(rnd.nextGaussian() * 8), lon0 + mLon(rnd.nextGaussian() * 8), 8.0, speedMps = 0.0, speedAccuracyMps = 0.4))
            if (i > 15) maxDrift = maxOf(maxDrift, hypot((out.latitude - lat0) * 111_194.9, (out.longitude - lon0) * 111_194.9 * cos(Math.toRadians(lat0))))
        }
        assertTrue("deriva $maxDrift", maxDrift < 6.0)
        assertNull(f.update(FilterInput(61_000L, lat0, lon0, 8.0, speedMps = 0.0, speedAccuracyMps = 0.4)).bearingDeg)
    }
}
