package br.com.alertageografico

import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.util.Locale

data class CsvImportResult(
    val imported: List<Destination>,
    val errors: List<String>,
    val duplicates: Int
)

object CsvImporter {
    fun parse(input: InputStream, existing: List<Destination>): CsvImportResult {
        val lines = BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readLines()
        if (lines.isEmpty()) return CsvImportResult(emptyList(), listOf("O arquivo está vazio."), 0)

        val first = lines.first().removePrefix("\uFEFF")
        val delimiter = if (first.count { it == ';' } > first.count { it == ',' }) ';' else ','
        val header = splitCsv(first, delimiter).map { it.trim().lowercase(Locale.ROOT) }
        val nameIdx = header.indexOfFirst { it in listOf("nome", "name", "destino") }
        val latIdx = header.indexOfFirst { it in listOf("latitude", "lat") }
        val lonIdx = header.indexOfFirst { it in listOf("longitude", "lon", "lng") }
        val radiusIdx = header.indexOfFirst { it in listOf("raio_metros", "raio", "radius", "radius_meters") }
        val messageIdx = header.indexOfFirst { it in listOf("mensagem", "message") }
        val routeIdx = header.indexOfFirst { it in listOf("roteiro", "itinerary", "route") }
        val commentIdx = header.indexOfFirst { it in listOf("comentario", "comentário", "comment") }
        val typeIdx = header.indexOfFirst { it in listOf("tipo", "transporte", "type", "transport") }

        if (nameIdx < 0 || latIdx < 0 || lonIdx < 0) {
            return CsvImportResult(emptyList(),
                listOf("Cabeçalho inválido. Use nome,latitude,longitude,raio_metros,mensagem."), 0)
        }

        val imported = mutableListOf<Destination>()
        val errors = mutableListOf<String>()
        var duplicates = 0

        lines.drop(1).forEachIndexed { index, raw ->
            val lineNo = index + 2
            if (raw.isBlank()) return@forEachIndexed
            val cols = splitCsv(raw, delimiter)
            fun value(i: Int, fallback: String = "") = if (i >= 0 && i < cols.size) cols[i].trim() else fallback
            val name = value(nameIdx)
            val lat = value(latIdx).replace(',', '.').toDoubleOrNull()
            val lon = value(lonIdx).replace(',', '.').toDoubleOrNull()
            // Vazio usa o padrão do tipo (300 trem/metrô, 60 ônibus); texto não numérico passa a ser erro em vez de virar 300 em silêncio.
            val typeRaw = value(typeIdx).lowercase(Locale.ROOT)
            val transport = if (typeRaw.startsWith("onib") || typeRaw.startsWith("ônib") || typeRaw == "bus") TransportType.BUS else TransportType.TRAIN
            val radiusRaw = value(radiusIdx)
            val radius: Int? = if (radiusRaw.isBlank()) TransportType.defaultRadius(transport) else radiusRaw.toIntOrNull()
            val route = value(routeIdx).takeIf { it.isNotBlank() }
            val message = value(messageIdx, "Você está chegando ao destino").ifBlank {
                "Você está chegando ao destino"
            }

            val issue = when {
                name.isBlank() -> "nome vazio"
                lat == null || lat !in -90.0..90.0 -> "latitude inválida"
                lon == null || lon !in -180.0..180.0 -> "longitude inválida"
                radius == null -> "raio não numérico"
                radius !in 50..10000 -> "raio deve estar entre 50 e 10000 metros"
                else -> null
            }
            if (issue != null) {
                errors += "Linha $lineNo: $issue."
                return@forEachIndexed
            }

            val candidate = Destination(
                name = name,
                latitude = lat!!,
                longitude = lon!!,
                radiusMeters = radius!!,
                message = message,
                itineraryName = route,
                transportType = transport,
                comment = value(commentIdx).trim().take(Destination.COMMENT_MAX_LENGTH)
            )
            val duplicate = (existing + imported).any {
                it.name.equals(candidate.name, ignoreCase = true) &&
                    kotlin.math.abs(it.latitude - candidate.latitude) < 0.0001 &&
                    kotlin.math.abs(it.longitude - candidate.longitude) < 0.0001
            }
            if (duplicate) duplicates++ else imported += candidate
        }
        return CsvImportResult(imported, errors, duplicates)
    }

    private fun splitCsv(line: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    field.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                c == delimiter && !quoted -> {
                    result += field.toString()
                    field.setLength(0)
                }
                else -> field.append(c)
            }
            i++
        }
        result += field.toString()
        return result
    }
}
