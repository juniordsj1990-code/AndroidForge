package br.com.alertageografico

/**
 * Aprende, pelo histórico de viagens, a velocidade de cruzeiro e o tempo parado (dwell) de cada
 * trecho entre paradas consecutivas de um roteiro. O tempo previsto do trecho é
 * distância ÷ cruzeiro + dwell. Sem dados do trecho, usa a velocidade de cruzeiro ao vivo e o
 * dwell médio aprendido para o tipo de transporte (ou um padrão).
 */
class TravelModel {
    private class Leg(var cruise: Double, var dwell: Double, var n: Int)
    private class TypeDwell(var dwell: Double, var n: Int)

    private val legs = LinkedHashMap<String, Leg>()
    private val types = HashMap<String, TypeDwell>()
    var dirty = false
        private set

    fun consumeDirty(): Boolean { val d = dirty; dirty = false; return d }

    fun observeLeg(key: String, transportType: String, modelDistanceMeters: Double, movingSeconds: Double, stoppedSeconds: Double) {
        if (modelDistanceMeters < MIN_LEG_METERS || movingSeconds < MIN_MOVING_S) return
        if (stoppedSeconds < 0.0 || stoppedSeconds > MAX_STOPPED_S) return
        val cruise = modelDistanceMeters / movingSeconds
        if (cruise < 1.5 || cruise > 45.0) return
        val leg = legs[key]
        if (leg == null) legs[key] = Leg(cruise, stoppedSeconds, 1)
        else {
            leg.cruise += ALPHA * (cruise - leg.cruise)
            leg.dwell += ALPHA * (stoppedSeconds - leg.dwell)
            leg.n++
        }
        val t = types[transportType]
        if (t == null) types[transportType] = TypeDwell(stoppedSeconds, 1)
        else { t.dwell += TYPE_ALPHA * (stoppedSeconds - t.dwell); t.n++ }
        while (legs.size > MAX_LEGS) legs.remove(legs.keys.first())
        dirty = true
    }

    fun dwellSeconds(key: String?, transportType: String): Double =
        key?.let { legs[it]?.dwell } ?: types[transportType]?.dwell ?: defaultDwell(transportType)

    fun typeDwellSeconds(transportType: String): Double = types[transportType]?.dwell ?: defaultDwell(transportType)

    fun legSamples(key: String): Int = legs[key]?.n ?: 0

    /** Tempo previsto (s) do trecho; null se não há velocidade de cruzeiro aprendida nem ao vivo. */
    fun predictLegSeconds(key: String?, transportType: String, modelDistanceMeters: Double, liveCruiseMps: Double?): Double? {
        val cruise = key?.let { legs[it]?.cruise } ?: liveCruiseMps?.takeIf { it > 1.0 } ?: return null
        return modelDistanceMeters / cruise + dwellSeconds(key, transportType)
    }

    fun serialize(): String {
        val sb = StringBuilder()
        for ((k, l) in legs) sb.append("L|").append(k).append('|').append(fmt(l.cruise)).append('|').append(fmt(l.dwell)).append('|').append(l.n).append('\n')
        for ((k, t) in types) sb.append("T|").append(k).append('|').append(fmt(t.dwell)).append('|').append(t.n).append('\n')
        return sb.toString()
    }

    fun load(text: String?) {
        legs.clear(); types.clear()
        if (text.isNullOrBlank()) return
        for (line in text.lines()) {
            val p = line.split('|')
            if (p.size == 5 && p[0] == "L") {
                val c = p[2].toDoubleOrNull(); val d = p[3].toDoubleOrNull(); val n = p[4].toIntOrNull()
                if (c != null && d != null && n != null) legs[p[1]] = Leg(c, d, n)
            } else if (p.size == 4 && p[0] == "T") {
                val d = p[2].toDoubleOrNull(); val n = p[3].toIntOrNull()
                if (d != null && n != null) types[p[1]] = TypeDwell(d, n)
            }
        }
        dirty = false
    }

    private fun fmt(v: Double) = String.format(java.util.Locale.US, "%.3f", v)

    companion object {
        private const val ALPHA = 0.35
        private const val TYPE_ALPHA = 0.2
        private const val MIN_LEG_METERS = 150.0
        private const val MIN_MOVING_S = 20.0
        private const val MAX_STOPPED_S = 900.0
        private const val MAX_LEGS = 400
        fun legKey(fromId: String, toId: String) = "$fromId>$toId"
        fun defaultDwell(transportType: String): Double = if (transportType == TransportType.BUS) 15.0 else 30.0
    }
}
