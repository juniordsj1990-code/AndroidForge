package br.com.alertageografico

import android.location.Location
import android.os.SystemClock

/**
 * Tempo monotônico do fix (ms, base de elapsedRealtime). Usa elapsedRealtimeNanos, que não salta
 * com ajustes do relógio de parede; se o provedor não o informa, converte o horário do fix.
 */
fun Location.fixElapsedMs(): Long {
    val nanos = elapsedRealtimeNanos
    if (nanos > 0L) return nanos / 1_000_000L
    val ageMs = System.currentTimeMillis() - time
    return SystemClock.elapsedRealtime() - ageMs
}

/** Adapta o Location do Android ao formato do estimador de ETA. */
fun Location.toEtaFix(): EtaFix = EtaFix(
    elapsedMs = fixElapsedMs(),
    latitude = latitude,
    longitude = longitude,
    accuracyMeters = if (hasAccuracy()) accuracy else null,
    speedMps = if (hasSpeed()) speed.toDouble() else null,
    speedAccuracyMps = if (hasSpeedAccuracy()) speedAccuracyMetersPerSecond.toDouble() else null
)
