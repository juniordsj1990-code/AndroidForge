package br.com.alertageografico.ui

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.material3.LocalContentColor
import br.com.alertageografico.R

/**
 * Biblioteca única de ícones de destino e roteiro (vetoriais, res/drawable/ic_pick_*).
 * Substitui os emojis. Valores antigos (emoji salvos em destinos, roteiros e backups) são
 * convertidos para a chave equivalente por [normalize], então nada que já foi salvo se perde.
 */
object AppIcons {
    class Entry(val key: String, @DrawableRes val res: Int, val label: String)

    val all: List<Entry> = listOf(
        Entry("pin", R.drawable.ic_pick_pin, "Local"),
        Entry("home", R.drawable.ic_pick_home, "Casa"),
        Entry("work", R.drawable.ic_pick_work, "Trabalho"),
        Entry("school", R.drawable.ic_pick_school, "Escola"),
        Entry("train", R.drawable.ic_pick_train, "Estação"),
        Entry("bus", R.drawable.ic_pick_bus, "Ônibus"),
        Entry("car", R.drawable.ic_pick_car, "Carro"),
        Entry("bike", R.drawable.ic_pick_bike, "Bicicleta"),
        Entry("walk", R.drawable.ic_pick_walk, "A pé"),
        Entry("plane", R.drawable.ic_pick_plane, "Avião"),
        Entry("cart", R.drawable.ic_pick_cart, "Compras"),
        Entry("fuel", R.drawable.ic_pick_fuel, "Posto"),
        Entry("hospital", R.drawable.ic_pick_hospital, "Saúde"),
        Entry("restaurant", R.drawable.ic_pick_restaurant, "Restaurante"),
        Entry("parking", R.drawable.ic_pick_parking, "Estacionamento"),
        Entry("beach", R.drawable.ic_pick_beach, "Lazer"),
        Entry("map", R.drawable.ic_pick_map, "Mapa"),
        Entry("star", R.drawable.ic_pick_star, "Favorito"),
        Entry("heart", R.drawable.ic_pick_heart, "Querido")
    )

    const val DEFAULT_DESTINATION = "pin"
    const val DEFAULT_ROUTE = "map"

    // Emojis usados nas versões anteriores -> chave atual.
    private val legacy: Map<String, String> = mapOf(
        "📍" to "pin", "🏠" to "home", "💼" to "work", "⛽" to "fuel", "🛒" to "cart",
        "🏥" to "hospital", "🏫" to "school", "🍽️" to "restaurant", "🍽" to "restaurant",
        "🅿️" to "parking", "🅿" to "parking", "🚉" to "train", "🏖️" to "beach", "🏖" to "beach",
        "⭐" to "star", "🗺️" to "map", "🗺" to "map",
        "🚗" to "car", "🚙" to "car", "🚕" to "car", "🚌" to "bus", "🚐" to "bus", "🚚" to "car",
        "🏍️" to "bike", "🏍" to "bike", "🚲" to "bike", "🚶" to "walk", "✈️" to "plane", "✈" to "plane",
        "🚆" to "train", "🚢" to "map", "🏕️" to "beach", "🏕" to "beach", "🏨" to "home",
        "📦" to "cart", "❤️" to "heart", "❤" to "heart"
    )

    /** Chave válida para qualquer texto salvo (chave atual, emoji antigo ou vazio). */
    fun normalize(raw: String?, fallback: String = DEFAULT_DESTINATION): String {
        val value = raw?.trim().orEmpty()
        if (value.isEmpty()) return fallback
        if (all.any { it.key == value }) return value
        return legacy[value] ?: fallback
    }

    @DrawableRes
    fun resFor(raw: String?, fallback: String = DEFAULT_DESTINATION): Int {
        val key = normalize(raw, fallback)
        return all.first { it.key == key }.res
    }
}

/** Ícone de destino/roteiro pela chave (ou emoji antigo). */
@Composable
fun PickIcon(
    key: String?,
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    tint: Color = LocalContentColor.current,
    fallback: String = AppIcons.DEFAULT_DESTINATION
) {
    AgIcon(AppIcons.resFor(key, fallback), modifier = modifier, size = size, tint = tint)
}
