package br.com.alertageografico

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Uma viagem registrada pelo serviço de monitoramento. */
data class Trip(
    val id: String,
    val startedAt: Long,
    val endedAt: Long = 0L,
    /** "individual" (destino único) ou "route" (roteiro). */
    val mode: String,
    val title: String,
    val transportType: String = TransportType.TRAIN,
    val stopsTotal: Int = 1,
    val stopsReached: Int = 0,
    val distanceMeters: Int = 0,
    /** "andamento", "concluida" ou "interrompida". */
    val outcome: String = OUTCOME_ONGOING,
    val simulated: Boolean = false
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("startedAt", startedAt); put("endedAt", endedAt); put("mode", mode)
        put("title", title); put("transportType", transportType); put("stopsTotal", stopsTotal)
        put("stopsReached", stopsReached); put("distanceMeters", distanceMeters)
        put("outcome", outcome); put("simulated", simulated)
    }

    companion object {
        const val OUTCOME_ONGOING = "andamento"
        const val OUTCOME_DONE = "concluida"
        const val OUTCOME_STOPPED = "interrompida"

        fun fromJson(o: JSONObject) = Trip(
            id = o.getString("id"),
            startedAt = o.optLong("startedAt", 0L),
            endedAt = o.optLong("endedAt", 0L),
            mode = o.optString("mode", "individual"),
            title = o.optString("title", "Viagem"),
            transportType = TransportType.normalize(o.optString("transportType", TransportType.TRAIN)),
            stopsTotal = o.optInt("stopsTotal", 1),
            stopsReached = o.optInt("stopsReached", 0),
            distanceMeters = o.optInt("distanceMeters", 0),
            outcome = o.optString("outcome", OUTCOME_STOPPED),
            simulated = o.optBoolean("simulated", false)
        )
    }
}

/** Histórico das últimas viagens, guardado nas preferências do app (entra no backup). */
object TripHistory {
    private const val KEY = "trip_history"
    const val MAX_TRIPS = 60

    /** Da mais recente para a mais antiga. */
    fun load(context: Context): List<Trip> {
        val raw = context.getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { runCatching { Trip.fromJson(array.getJSONObject(it)) }.getOrNull() }
        }.getOrDefault(emptyList()).sortedByDescending { it.startedAt }
    }

    private fun write(context: Context, trips: List<Trip>) {
        val array = JSONArray()
        trips.take(MAX_TRIPS).forEach { array.put(it.toJson()) }
        context.getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }

    /** Insere ou atualiza (pelo id) e mantém só as [MAX_TRIPS] mais recentes. */
    @Synchronized
    fun upsert(context: Context, trip: Trip) {
        val others = load(context).filter { it.id != trip.id }
        write(context, (listOf(trip) + others).sortedByDescending { it.startedAt })
    }

    @Synchronized
    fun clear(context: Context) = write(context, emptyList())
}
