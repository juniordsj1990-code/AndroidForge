package br.com.alertageografico

import kotlin.math.floor

/**
 * Calibra a faixa min–max do ETA com os erros reais: para cada previsão registrada durante o
 * trajeto, guarda a razão (tempo real até chegar ÷ tempo previsto). A faixa passa a ser os
 * quantis 15% e 85% dessas razões, por tipo de transporte e por horizonte (curto/médio/longo).
 * Sem amostras suficientes, o estimador usa a faixa a priori.
 */
class EtaCalibrator(private val maxSamplesPerBucket: Int = 60) {
    private val buckets = LinkedHashMap<String, ArrayDeque<Double>>()
    var dirty = false
        private set

    fun consumeDirty(): Boolean { val d = dirty; dirty = false; return d }

    fun sampleCount(mode: String, midSeconds: Double): Int = buckets[key(mode, midSeconds)]?.size ?: 0

    fun record(mode: String, predictedSeconds: Double, actualSeconds: Double) {
        if (predictedSeconds < MIN_PREDICTED_S || actualSeconds < MIN_ACTUAL_S) return
        val ratio = (actualSeconds / predictedSeconds).coerceIn(MIN_RATIO, MAX_RATIO)
        val list = buckets.getOrPut(key(mode, predictedSeconds)) { ArrayDeque() }
        list.addLast(ratio)
        while (list.size > maxSamplesPerBucket) list.removeFirst()
        dirty = true
    }

    /** (fator inferior, fator superior) a aplicar ao tempo previsto; null sem amostras suficientes. */
    fun multipliers(mode: String, midSeconds: Double): Pair<Double, Double>? {
        val list = buckets[key(mode, midSeconds)] ?: return null
        if (list.size < MIN_SAMPLES) return null
        val sorted = list.sorted()
        val low = quantile(sorted, 0.15).coerceIn(0.4, 1.1)
        val high = quantile(sorted, 0.85).coerceIn(0.9, 2.5).coerceAtLeast(low + 0.1)
        return low to high
    }

    fun serialize(): String = buckets.entries.joinToString("\n") { (k, v) ->
        k + "|" + v.joinToString(",") { String.format(java.util.Locale.US, "%.3f", it) }
    }

    fun load(text: String?) {
        buckets.clear()
        if (text.isNullOrBlank()) return
        for (line in text.lines()) {
            val parts = line.split('|')
            if (parts.size != 2) continue
            val values = parts[1].split(',').mapNotNull { it.toDoubleOrNull() }
            if (values.isEmpty()) continue
            buckets[parts[0]] = ArrayDeque(values.takeLast(maxSamplesPerBucket))
        }
        dirty = false
    }

    private fun key(mode: String, seconds: Double) = mode + ":" + when {
        seconds < 120.0 -> "s"
        seconds < 420.0 -> "m"
        else -> "l"
    }

    private fun quantile(sorted: List<Double>, q: Double): Double {
        if (sorted.size == 1) return sorted[0]
        val pos = q * (sorted.size - 1)
        val lo = floor(pos).toInt()
        val hi = minOf(lo + 1, sorted.lastIndex)
        return sorted[lo] + (pos - lo) * (sorted[hi] - sorted[lo])
    }

    companion object {
        const val MIN_SAMPLES = 8
        private const val MIN_PREDICTED_S = 20.0
        private const val MIN_ACTUAL_S = 5.0
        private const val MIN_RATIO = 0.25
        private const val MAX_RATIO = 4.0
    }
}
