package br.com.alertageografico

import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Leitura de posição independente de Android, para permitir testes de unidade. */
data class Fix(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    /** Tempo monotônico do fix (elapsedRealtime, ms). 0 = desconhecido (desliga o teste de cruzamento). */
    val timeMillis: Long = 0L,
    /** Velocidade (m/s); null = desconhecida. Alimenta o raio efetivo. */
    val speedMps: Float? = null
)

data class ProximityResult(
    /** Destinos cujo alerta deve ser disparado agora. */
    val triggered: List<Destination>,
    /** Menor distância até a borda de um raio ativo (0 se estiver dentro de algum). Null sem destinos ativos. */
    val nearestEdgeMeters: Double?,
    /** Verdadeiro se a leitura foi descartada por baixa precisão (para qualquer destino). */
    val lowAccuracy: Boolean,
    /** Ônibus que acabaram de entrar na distância do aviso antecipado (ainda fora do raio). */
    val distanceTriggered: List<Destination> = emptyList()
)

/**
 * Decide quando alertar. Regras:
 *  - leituras com precisão pior que min(maxAccuracy, max(raio, 50 m)) não podem disparar nem rearmar;
 *  - dispara na primeira leitura válida dentro do raio, sem aguardar uma segunda atualização;
 *  - dispara também se o segmento entre o fix anterior e o atual cruzou o raio (o GPS pode "pular"
 *    o círculo entre duas leituras, principalmente em trem rápido e ônibus com raio de 60 m);
 *  - raio efetivo = max(raio, velocidade × [LEAD_SECONDS]), limitado (ver [effectiveRadius]), para que
 *    o aviso venha com tempo útil mesmo em velocidade alta;
 *  - rearma após sair do raio usado no disparo × [rearmFactor] + [rearmExtraMeters];
 *  - ônibus com distância de aviso maior que o raio também disparam um aviso por distância, uma vez por aproximação;
 *  - estado de destinos removidos é descartado.
 */
class ProximityEngine(
    private val maxAccuracyMeters: Float = 150f,
    private val strongAccuracyMeters: Float = 25f,
    private val rearmFactor: Double = 1.15,
    private val rearmExtraMeters: Double = 15.0
) {
    private val inside = mutableMapOf<String, Boolean>()
    private val distanceInside = mutableMapOf<String, Boolean>()
    // Raio efetivamente usado no disparo: o rearme usa esse valor, para que a variação da
    // velocidade (e do raio efetivo) depois do disparo não rearme o alerta no meio da aproximação.
    private val triggerRadius = mutableMapOf<String, Double>()
    private var previousFix: Fix? = null

    fun process(fix: Fix, destinations: List<Destination>): ProximityResult {
        val active = destinations.filter { it.enabled }
        val activeIds = active.mapTo(HashSet()) { it.id }
        inside.keys.retainAll(activeIds)
        distanceInside.keys.retainAll(activeIds)
        triggerRadius.keys.retainAll(activeIds)
        val previous = previousFix
        previousFix = fix

        val triggered = mutableListOf<Destination>()
        val distanceTriggered = mutableListOf<Destination>()
        var nearestEdge: Double? = null
        var anyLowAccuracy = false

        for (d in active) {
            val distance = distanceMeters(fix.latitude, fix.longitude, d.latitude, d.longitude)
            val edge = max(0.0, distance - d.radiusMeters)
            nearestEdge = nearestEdge?.let { min(it, edge) } ?: edge
            val effRadius = effectiveRadius(d, fix.speedMps)

            // Aviso antecipado por distância (só ônibus): dispara uma vez ao cruzar a distância,
            // sem esperar o raio. Se a primeira leitura já cair dentro do raio, só o alerta do
            // raio importa, então o aviso por distância é marcado como já consumido.
            if (d.hasDistanceAlert) {
                val distanceGate = min(maxAccuracyMeters, max(d.distanceAlertMeters.toFloat(), 50f))
                if (fix.accuracyMeters <= distanceGate) {
                    val wasInsideDistance = distanceInside[d.id] ?: false
                    val reached = distance <= d.distanceAlertMeters ||
                        crossesCircle(previous, fix, d, d.distanceAlertMeters.toDouble(), distanceGate)
                    if (reached) {
                        if (!wasInsideDistance) {
                            distanceInside[d.id] = true
                            if (distance > effRadius) distanceTriggered += d
                        }
                    } else if (wasInsideDistance && distance > d.distanceAlertMeters * rearmFactor + rearmExtraMeters) {
                        distanceInside[d.id] = false
                    }
                }
            }

            val gate = min(maxAccuracyMeters, max(d.radiusMeters.toFloat(), 50f))
            if (fix.accuracyMeters > gate) {
                anyLowAccuracy = true
                continue // leitura pouco confiável: não altera estado
            }

            val wasInside = inside[d.id] ?: false
            // Entrou no raio nesta leitura, ou o trecho percorrido desde a leitura anterior o cruzou.
            val hit = distance <= effRadius || crossesCircle(previous, fix, d, effRadius, gate)
            if (hit) {
                // O requisito do produto é alertar ao entrar no raio. Uma única posição
                // válida já dispara; exigir duas leituras podia perder a chegada quando
                // o usuário passava rapidamente pelo raio entre atualizações do GPS.
                if (!wasInside) {
                    inside[d.id] = true
                    triggerRadius[d.id] = effRadius
                    triggered += d
                }
            } else {
                val armedRadius = max(triggerRadius[d.id] ?: 0.0, d.radiusMeters.toDouble())
                if (wasInside && distance > armedRadius * rearmFactor + rearmExtraMeters) {
                    inside[d.id] = false
                    triggerRadius.remove(d.id)
                }
            }
        }
        return ProximityResult(triggered, nearestEdge, anyLowAccuracy, distanceTriggered)
    }

    fun reset() { inside.clear(); distanceInside.clear(); triggerRadius.clear(); previousFix = null }

    /**
     * Marca o destino como já alertado sem uma leitura de GPS (alerta por estimativa, p.ex. em túnel),
     * para que o retorno do sinal não dispare o mesmo alerta de novo. Retorna true se era a primeira vez.
     */
    fun markTriggered(d: Destination): Boolean {
        val was = inside[d.id] ?: false
        inside[d.id] = true
        triggerRadius[d.id] = d.radiusMeters.toDouble()
        return !was
    }

    /** Raio usado no disparo: max(raio, velocidade × [LEAD_SECONDS]); ver [effectiveRadius]. */
    fun effectiveRadius(d: Destination, speedMps: Float?): Double = Companion.effectiveRadius(d, speedMps)

    /** Verdadeiro se o segmento [previous]→[current] passa a menos de [radius] do centro do destino. */
    private fun crossesCircle(previous: Fix?, current: Fix, d: Destination, radius: Double, gate: Float): Boolean {
        if (previous == null) return false
        if (previous.timeMillis <= 0L || current.timeMillis <= previous.timeMillis) return false
        val dt = current.timeMillis - previous.timeMillis
        if (dt > MAX_SEGMENT_MS) return false
        if (previous.accuracyMeters > gate) return false
        return segmentDistanceToPoint(previous, current, d.latitude, d.longitude, dt / 1000.0) <= radius
    }

    companion object {
        private const val EARTH_RADIUS_M = 6_371_000.0
        private const val ASSUMED_MAX_SPEED_MPS = 30.0 // ~108 km/h
        const val MIN_INTERVAL_MS = 3_000L
        const val MAX_INTERVAL_MS = 60_000L
        /** Antecedência desejada (s) do aviso do raio: o raio efetivo cresce com a velocidade. */
        const val LEAD_SECONDS = 25.0
        const val MAX_EFFECTIVE_RADIUS_M = 1_000.0
        private const val MIN_SPEED_FOR_LEAD_MPS = 2.0
        private const val MAX_SPEED_FOR_LEAD_MPS = 45.0
        private const val MAX_SEGMENT_MS = 60_000L
        private const val MAX_SEGMENT_SPEED_MPS = 70.0
        private val INTERVAL_BUCKETS_MS = longArrayOf(3_000, 5_000, 8_000, 12_000, 20_000, 30_000, 45_000, 60_000)

        /**
         * Raio efetivo do alerta de chegada: max(raio, velocidade × 25 s). Para ônibus com aviso por
         * distância, fica abaixo de 60% dessa distância, para que os dois alertas continuem separados.
         */
        fun effectiveRadius(d: Destination, speedMps: Float?): Double {
            val base = d.radiusMeters.toDouble()
            if (speedMps == null || !speedMps.isFinite() || speedMps < MIN_SPEED_FOR_LEAD_MPS) return base
            val speed = min(speedMps.toDouble(), MAX_SPEED_FOR_LEAD_MPS)
            var cap = MAX_EFFECTIVE_RADIUS_M
            if (d.hasDistanceAlert) cap = min(cap, max(base, d.distanceAlertMeters * 0.6))
            return max(base, min(speed * LEAD_SECONDS, cap))
        }

        /** Menor distância (m) do ponto ao segmento entre dois fixes, em plano local. */
        private fun segmentDistanceToPoint(a: Fix, b: Fix, lat: Double, lon: Double, dtSeconds: Double): Double {
            val latScale = EARTH_RADIUS_M * Math.PI / 180.0
            val lonScale = latScale * cos(Math.toRadians(lat))
            val ax = (a.longitude - lon) * lonScale
            val ay = (a.latitude - lat) * latScale
            val bx = (b.longitude - lon) * lonScale
            val by = (b.latitude - lat) * latScale
            val dx = bx - ax; val dy = by - ay
            val len = sqrt(dx * dx + dy * dy)
            // Salto fisicamente impossível: não é movimento real, não deve "cruzar" o raio.
            if (len > MAX_SEGMENT_SPEED_MPS * dtSeconds + 100.0) return Double.MAX_VALUE
            val denom = dx * dx + dy * dy
            val t = if (denom == 0.0) 0.0 else (-(ax * dx + ay * dy) / denom).coerceIn(0.0, 1.0)
            val px = ax + t * dx; val py = ay + t * dy
            return sqrt(px * px + py * py)
        }

        /** Maior intervalo padronizado que não ultrapassa [ms]; evita reconfigurar o GPS a cada fix. */
        fun bucketIntervalMs(ms: Long): Long = INTERVAL_BUCKETS_MS.lastOrNull { it <= ms } ?: INTERVAL_BUCKETS_MS.first()

        fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
            val p1 = Math.toRadians(lat1)
            val p2 = Math.toRadians(lat2)
            val dp = p2 - p1
            val dl = Math.toRadians(lon2 - lon1)
            val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
            return 2 * EARTH_RADIUS_M * asin(min(1.0, sqrt(a)))
        }

        /**
         * Intervalo de atualização seguro: no máximo 1/3 do tempo que levaria para alcançar a borda
         * do raio na velocidade medida (ou assumida), limitado a 3–60 s. Sem destinos ativos, usa o máximo.
         */
        fun recommendedIntervalMs(nearestEdgeMeters: Double?, speedMps: Double? = null): Long {
            if (nearestEdgeMeters == null) return MAX_INTERVAL_MS
            // Com a velocidade medida, planeja pela velocidade real (com folga); sem ela, pela máxima assumida.
            val planningSpeed = if (speedMps == null) ASSUMED_MAX_SPEED_MPS
                else max(speedMps * 1.3, 8.0).coerceAtMost(40.0)
            val ms = nearestEdgeMeters / planningSpeed * 1000.0 / 3.0
            return ms.toLong().coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)
        }
    }
}
