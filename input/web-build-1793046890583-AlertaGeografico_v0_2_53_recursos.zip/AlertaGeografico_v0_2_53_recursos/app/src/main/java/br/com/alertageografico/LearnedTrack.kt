package br.com.alertageografico

import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Trilha gravada de uma viagem concluída. Serve de "malha" offline para ônibus e trajetos sem
 * trilhos: a posição atual e a parada-alvo são projetadas na trilha e a distância é medida
 * ao longo dela (por rua), em vez de em linha reta.
 */
class LearnedTrack(val latitudes: DoubleArray, val longitudes: DoubleArray) {
    private val cumulative = DoubleArray(latitudes.size)

    init {
        for (i in 1 until latitudes.size) {
            cumulative[i] = cumulative[i - 1] + haversine(latitudes[i - 1], longitudes[i - 1], latitudes[i], longitudes[i])
        }
    }

    val size: Int get() = latitudes.size
    val lengthMeters: Double get() = if (size < 2) 0.0 else cumulative.last()

    class Projection(val alongMeters: Double, val snapMeters: Double)

    /**
     * Projeta o ponto na trilha. Com [headingDeg], segmentos em sentido oposto são penalizados
     * (a trilha é direcional). [minAlongMeters] limita a busca a trechos à frente.
     */
    fun project(lat: Double, lon: Double, headingDeg: Double? = null, maxSnapMeters: Double = 60.0, minAlongMeters: Double = 0.0): Projection? {
        if (size < 2) return null
        val latScale = METERS_PER_DEG
        val lonScale = METERS_PER_DEG * cos(Math.toRadians(lat)).coerceAtLeast(0.01)
        var bestScore = Double.MAX_VALUE
        var bestAlong = 0.0
        var bestDist = Double.MAX_VALUE
        for (i in 0 until size - 1) {
            if (cumulative[i + 1] < minAlongMeters) continue
            val ax = (longitudes[i] - lon) * lonScale
            val ay = (latitudes[i] - lat) * latScale
            val bx = (longitudes[i + 1] - lon) * lonScale
            val by = (latitudes[i + 1] - lat) * latScale
            val dx = bx - ax; val dy = by - ay
            val denom = dx * dx + dy * dy
            if (denom < 1e-6) continue
            val t = (-(ax * dx + ay * dy) / denom).coerceIn(0.0, 1.0)
            val dist = hypot(ax + t * dx, ay + t * dy)
            if (dist > maxSnapMeters) continue
            var score = dist
            if (headingDeg != null) {
                val segBearing = (Math.toDegrees(atan2(dx, dy)) + 360.0) % 360.0
                val delta = abs((segBearing - headingDeg + 540.0) % 360.0 - 180.0)
                if (delta > 100.0) score += 80.0 else score += delta * 0.3
            }
            if (score < bestScore) {
                bestScore = score
                bestDist = dist
                bestAlong = cumulative[i] + t * (cumulative[i + 1] - cumulative[i])
            }
        }
        return if (bestDist == Double.MAX_VALUE) null else Projection(bestAlong, bestDist)
    }

    /**
     * Distância ao longo da trilha da posição atual até o alvo (à frente). Null se a posição ou
     * o alvo estão longe da trilha, se o alvo ficou para trás ou se o resultado é incoerente
     * com a linha reta.
     */
    fun distanceAlong(userLat: Double, userLon: Double, headingDeg: Double?, targetLat: Double, targetLon: Double): Double? {
        val user = project(userLat, userLon, headingDeg, USER_SNAP_M) ?: return null
        val target = project(targetLat, targetLon, null, TARGET_SNAP_M, user.alongMeters - 15.0) ?: return null
        val along = target.alongMeters - user.alongMeters
        if (along < -15.0) return null
        val d = max(0.0, along)
        val straight = haversine(userLat, userLon, targetLat, targetLon)
        if (d > straight * 3.0 + 500.0) return null
        if (d < straight * 0.7 - 60.0) return null
        return d
    }

    companion object {
        private const val METERS_PER_DEG = 6_371_000.0 * PI / 180.0
        const val USER_SNAP_M = 60.0
        const val TARGET_SNAP_M = 90.0
        const val MIN_SPACING_M = 25.0
        const val MAX_POINTS = 3000

        fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
            val r = 6_371_000.0
            val dLat = Math.toRadians(lat2 - lat1); val dLon = Math.toRadians(lon2 - lon1)
            val a = Math.pow(Math.sin(dLat / 2), 2.0) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * Math.pow(Math.sin(dLon / 2), 2.0)
            return r * 2 * atan2(Math.sqrt(a), Math.sqrt((1 - a).coerceAtLeast(0.0)))
        }
    }
}

/** Acumula pontos da viagem com espaçamento mínimo, para gravar a trilha ao concluir. */
class BreadcrumbRecorder(private val minSpacingMeters: Double = LearnedTrack.MIN_SPACING_M) {
    private val lats = ArrayList<Double>()
    private val lons = ArrayList<Double>()
    val count: Int get() = lats.size

    fun clear() { lats.clear(); lons.clear() }

    fun add(lat: Double, lon: Double) {
        if (lats.isNotEmpty() && LearnedTrack.haversine(lats.last(), lons.last(), lat, lon) < minSpacingMeters) return
        lats.add(lat); lons.add(lon)
        if (lats.size > LearnedTrack.MAX_POINTS * 2) thin()
    }

    private fun thin() {
        val nl = ArrayList<Double>(); val no = ArrayList<Double>()
        for (i in lats.indices step 2) { nl.add(lats[i]); no.add(lons[i]) }
        lats.clear(); lats.addAll(nl); lons.clear(); lons.addAll(no)
    }

    fun toTrack(): LearnedTrack? {
        if (lats.size < 2) return null
        var la = lats.toDoubleArray(); var lo = lons.toDoubleArray()
        while (la.size > LearnedTrack.MAX_POINTS) {
            la = DoubleArray((la.size + 1) / 2) { la[it * 2] }
            lo = DoubleArray((lo.size + 1) / 2) { lo[it * 2] }
        }
        return LearnedTrack(la, lo)
    }
}

/** Persistência das trilhas aprendidas (um arquivo de texto por chave). */
class TrackStore(private val dir: File, private val maxFiles: Int = 30) {
    private val cache = HashMap<String, LearnedTrack?>()

    private fun file(key: String) = File(dir, "t_" + Integer.toHexString(key.hashCode()) + ".txt")

    @Synchronized
    fun load(key: String): LearnedTrack? {
        if (cache.containsKey(key)) return cache[key]
        val f = file(key)
        val track = runCatching {
            if (!f.exists()) null else {
                val la = ArrayList<Double>(); val lo = ArrayList<Double>()
                f.useLines { lines ->
                    lines.forEachIndexed { index, line ->
                        if (index == 0) return@forEachIndexed // primeira linha: a chave
                        val p = line.split(',')
                        if (p.size == 2) {
                            val a = p[0].toDoubleOrNull(); val b = p[1].toDoubleOrNull()
                            if (a != null && b != null) { la.add(a); lo.add(b) }
                        }
                    }
                }
                if (la.size >= 2) LearnedTrack(la.toDoubleArray(), lo.toDoubleArray()) else null
            }
        }.getOrNull()
        cache[key] = track
        return track
    }

    /** Grava a nova trilha se não houver outra ou se ela cobrir ao menos 80% da anterior. */
    @Synchronized
    fun saveIfBetter(key: String, track: LearnedTrack): Boolean {
        if (track.size < 8 || track.lengthMeters < 300.0) return false
        val old = load(key)
        if (old != null && track.lengthMeters < old.lengthMeters * 0.8) return false
        return runCatching {
            dir.mkdirs()
            val sb = StringBuilder(key.replace('\n', ' ')).append('\n')
            for (i in 0 until track.size) {
                sb.append(String.format(java.util.Locale.US, "%.5f,%.5f\n", track.latitudes[i], track.longitudes[i]))
            }
            file(key).writeText(sb.toString())
            cache[key] = track
            prune()
            true
        }.getOrDefault(false)
    }

    private fun prune() {
        val files = dir.listFiles { f -> f.name.startsWith("t_") }?.sortedBy { it.lastModified() } ?: return
        if (files.size > maxFiles) files.take(files.size - maxFiles).forEach { it.delete() }
    }

    companion object {
        fun routeKey(itineraryName: String) = "route:$itineraryName"
        fun destinationKey(destinationId: String) = "dest:$destinationId"
    }
}
