package br.com.alertageografico

import android.content.Context
import android.location.Location
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.PriorityQueue
import kotlin.math.*

/** Offline navigator built from GeoJSON exported from OpenStreetMap/Overpass Turbo. */
data class RailStation(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val operator: String,
    val lineHint: String
)

data class RailRoute(
    val id: String,
    val name: String,
    val operator: String,
    val paths: List<List<GeoPoint>>
)

data class GeoPoint(val latitude: Double, val longitude: Double)

data class StationNavigationResult(
    val routeName: String,
    val operator: String,
    val previous: RailStation?,
    val current: RailStation,
    val next: RailStation?,
    val distanceToLineMeters: Double,
    val distanceToCurrentMeters: Double,
    val distanceToNextMeters: Int? = null
)

object StationNavigationStore {
    private const val STATIONS_FILE = "osm_stations.geojson"
    private const val ROUTES_FILE = "osm_routes.geojson"

    // Os GeoJSON podem ser grandes. Mantém os dados analisados em memória para que o serviço
    // de localização não reabra e reinterprete todos os arquivos a cada atualização do GPS.
    @Volatile private var cachedStations: List<RailStation>? = null
    @Volatile private var cachedStationsModified = -1L
    @Volatile private var cachedStationsLength = -1L
    @Volatile private var cachedRoutes: List<RailRoute>? = null
    @Volatile private var cachedRoutesModified = -1L
    @Volatile private var cachedRoutesLength = -1L
    @Volatile private var cachedNetwork: RailNetwork? = null
    @Volatile private var cachedNetworkModified = -1L
    @Volatile private var cachedNetworkLength = -1L
    // Histórico curto de posições para estimar o rumo quando o bearing do Android é instável.
    @Volatile private var lastFixForHeading: Location? = null
    @Volatile private var smoothedHeadingDegrees: Double? = null
    @Volatile private var lastChosenRouteId: String? = null
    // Feature (linha) em que a posição do usuário foi encaixada por último; dá continuidade ao snap.
    @Volatile private var lastSnapFeatureId: Int? = null
    // Estações projetadas em cada rota (posição ao longo da rota), calculadas uma vez por rota.
    private val routeStationAlong = HashMap<String, DoubleArray>()
    @Volatile private var routeStationAlongStamp = -1L

    private data class NetworkEdge(val to: String, val meters: Double)
    private data class RailSegment(
        val aKey: String, val bKey: String, val a: GeoPoint, val b: GeoPoint,
        val lengthMeters: Double, val minLat: Double, val maxLat: Double,
        val minLon: Double, val maxLon: Double,
        /** Índice da feature GeoJSON de origem; permite preferir a mesma linha em sobreposições. */
        val featureId: Int = -1
    )
    private data class RailNetwork(
        val adjacency: Map<String, List<NetworkEdge>>,
        val segments: List<RailSegment>
    )
    private data class SegmentProjection(val segment: RailSegment, val t: Double, val distanceMeters: Double)
    private data class QueueEntry(val key: String, val distance: Double)

    fun hasStations(context: Context) = File(context.filesDir, STATIONS_FILE).exists()
    fun hasRoutes(context: Context) = File(context.filesDir, ROUTES_FILE).exists()

    /** Apaga os GeoJSON ferroviários importados e invalida os caches relacionados. */
    @Synchronized
    fun clearAll(context: Context) {
        File(context.filesDir, STATIONS_FILE).delete()
        File(context.filesDir, ROUTES_FILE).delete()
        cachedStations = null
        cachedStationsModified = -1L
        cachedStationsLength = -1L
        cachedRoutes = null
        cachedRoutesModified = -1L
        cachedRoutesLength = -1L
        cachedNetwork = null
        cachedNetworkModified = -1L
        cachedNetworkLength = -1L
        lastFixForHeading = null
        smoothedHeadingDegrees = null
        lastChosenRouteId = null
        lastSnapFeatureId = null
        routeStationAlong.clear()
        DestinationStore.dashboard(context).edit()
            .remove(DestinationStore.KEY_STATION_ROUTE)
            .remove(DestinationStore.KEY_STATION_OPERATOR)
            .remove(DestinationStore.KEY_STATION_PREVIOUS)
            .remove(DestinationStore.KEY_STATION_CURRENT)
            .remove(DestinationStore.KEY_STATION_NEXT)
            .remove(DestinationStore.KEY_STATION_LINE_DISTANCE)
            .remove(DestinationStore.KEY_STATION_CURRENT_DISTANCE)
            .remove(DestinationStore.KEY_STATION_NEXT_DISTANCE)
            .remove(DestinationStore.KEY_STATION_UPDATED)
            .apply()
    }
    fun stationCount(context: Context): Int = runCatching { stationsGeoJsonForMap(context).optJSONArray("features")?.length() ?: 0 }.getOrDefault(0)
    fun routeCount(context: Context): Int = runCatching { routesGeoJsonForMap(context).optJSONArray("features")?.length() ?: 0 }.getOrDefault(0)

    fun importGeoJson(context: Context, raw: String, isStations: Boolean): Int {
        val root = JSONObject(raw)
        require(root.optString("type") == "FeatureCollection") { "O arquivo precisa ser um GeoJSON FeatureCollection." }
        val features = root.optJSONArray("features") ?: JSONArray()
        require(features.length() > 0) { "O GeoJSON não contém elementos." }
        val parsed = if (isStations) parseStations(root) else parseRoutes(root)
        // A exportação do Overpass pode trazer estações como polígonos e trilhos sem nome.
        // Esses elementos ainda podem ser exibidos no mapa, mesmo que não sirvam ao cálculo offline.
        val renderableForMap = (0 until features.length()).any { index ->
            val feature = features.optJSONObject(index) ?: return@any false
            val geometry = feature.optJSONObject("geometry") ?: return@any false
            val props = feature.optJSONObject("properties") ?: JSONObject()
            val tags = props.optJSONObject("tags")
            val hasName = props.optString("name").isNotBlank() || props.optString("name:pt").isNotBlank() ||
                props.optString("official_name").isNotBlank() || (tags?.optString("name")?.isNotBlank() == true)
            if (isStations) hasName && geometry.optString("type") in setOf("Point", "Polygon", "MultiPolygon")
            else geometry.optString("type") in setOf("LineString", "MultiLineString", "GeometryCollection")
        }
        require(parsed.isNotEmpty() || renderableForMap) {
            if (isStations) "Nenhuma estação reconhecível foi encontrada. Verifique se o GeoJSON contém nome e geometria das estações."
            else "Nenhuma linha ferroviária com geometria foi encontrada. Exporte as linhas/trilhos como GeoJSON."
        }
        val target = File(context.filesDir, if (isStations) STATIONS_FILE else ROUTES_FILE)
        // Overpass may need several smaller bounding boxes; merge each import instead of replacing prior areas.
        val merged = JSONArray()
        val seen = linkedSetOf<String>()
        fun addFeatures(source: JSONArray?) {
            if (source == null) return
            for (i in 0 until source.length()) {
                val feature = source.optJSONObject(i) ?: continue
                val properties = feature.optJSONObject("properties") ?: JSONObject()
                val geometry = feature.optJSONObject("geometry") ?: JSONObject()
                val id = properties.optString("@id").takeIf { it.isNotBlank() }
                    ?: properties.optString("id").takeIf { it.isNotBlank() }
                    ?: "${properties.optString("name")}|${geometry.toString()}"
                if (seen.add(id)) merged.put(feature)
            }
        }
        if (target.exists()) runCatching { addFeatures(JSONObject(target.readText()).optJSONArray("features")) }
        addFeatures(features)
        val combined = JSONObject().put("type", "FeatureCollection").put("features", merged)
        target.writeText(combined.toString())
        if (isStations) {
            cachedStations = null
            cachedStationsModified = -1L
            cachedStationsLength = -1L
        } else {
            cachedRoutes = null
            cachedRoutesModified = -1L
            cachedRoutesLength = -1L
            cachedNetwork = null
            cachedNetworkModified = -1L
            cachedNetworkLength = -1L
        }
        return if (isStations) maxOf(parseStations(combined).size, runCatching { stationsGeoJsonForMap(context).optJSONArray("features")?.length() ?: 0 }.getOrDefault(0))
        else maxOf(parseRoutes(combined).size, runCatching { routesGeoJsonForMap(context).optJSONArray("features")?.length() ?: 0 }.getOrDefault(0))
    }

    @Synchronized
    fun loadStations(context: Context): List<RailStation> {
        val file = File(context.filesDir, STATIONS_FILE)
        if (!file.exists()) return emptyList()
        val modified = file.lastModified()
        val length = file.length()
        cachedStations?.let { if (modified == cachedStationsModified && length == cachedStationsLength) return it }
        val parsed = parseStations(JSONObject(file.readText()))
        cachedStations = parsed
        cachedStationsModified = modified
        cachedStationsLength = length
        return parsed
    }

    @Synchronized
    fun loadRoutes(context: Context): List<RailRoute> {
        val file = File(context.filesDir, ROUTES_FILE)
        if (!file.exists()) return emptyList()
        val modified = file.lastModified()
        val length = file.length()
        cachedRoutes?.let { if (modified == cachedRoutesModified && length == cachedRoutesLength) return it }
        val parsed = parseRoutes(JSONObject(file.readText()))
        cachedRoutes = parsed
        cachedRoutesModified = modified
        cachedRoutesLength = length
        return parsed
    }

    /** GeoJSON normalizado para desenhar estações no mapa, incluindo estações OSM mapeadas como áreas. */
    fun stationsGeoJsonForMap(context: Context): JSONObject {
        val file = File(context.filesDir, STATIONS_FILE)
        if (!file.exists()) return JSONObject().put("type", "FeatureCollection").put("features", JSONArray())
        val source = runCatching { JSONObject(file.readText()).optJSONArray("features") }.getOrNull() ?: JSONArray()
        val output = JSONArray()
        val seen = linkedSetOf<String>()
        fun collectCoordinates(value: Any?, target: MutableList<Pair<Double, Double>>) {
            when (value) {
                is JSONArray -> {
                    if (value.length() >= 2 && value.opt(0) is Number && value.opt(1) is Number) {
                        val lon = value.optDouble(0, Double.NaN); val lat = value.optDouble(1, Double.NaN)
                        if (lon.isFinite() && lat.isFinite() && lon in -180.0..180.0 && lat in -90.0..90.0) target += lon to lat
                    } else for (i in 0 until value.length()) collectCoordinates(value.opt(i), target)
                }
            }
        }
        for (i in 0 until source.length()) {
            val feature = source.optJSONObject(i) ?: continue
            val geometry = feature.optJSONObject("geometry") ?: continue
            val props = feature.optJSONObject("properties") ?: JSONObject()
            val tags = props.optJSONObject("tags")
            fun prop(vararg keys: String): String {
                for (key in keys) {
                    val value = props.optString(key).takeIf { it.isNotBlank() && it != "null" }
                        ?: tags?.optString(key)?.takeIf { it.isNotBlank() && it != "null" }
                    if (value != null) return value
                }
                return ""
            }
            val name = prop("name", "name:pt", "official_name")
            if (name.isBlank()) continue
            val coords = geometry.optJSONArray("coordinates")
            val point = if (geometry.optString("type") == "Point" && coords != null && coords.length() >= 2) {
                val lon = coords.optDouble(0, Double.NaN); val lat = coords.optDouble(1, Double.NaN)
                if (lon.isFinite() && lat.isFinite()) lon to lat else null
            } else {
                val all = mutableListOf<Pair<Double, Double>>()
                collectCoordinates(coords, all)
                if (all.isEmpty()) null else all.reduce { acc, pair -> (acc.first + pair.first) to (acc.second + pair.second) }.let { it.first / all.size to it.second / all.size }
            } ?: continue
            val key = "${name.lowercase()}|${(point.first * 100000).toInt()}|${(point.second * 100000).toInt()}"
            if (!seen.add(key)) continue
            val pointGeometry = JSONObject().put("type", "Point").put("coordinates", JSONArray().put(point.first).put(point.second))
            val outputProps = JSONObject().put("name", name).put("operator", prop("operator", "network"))
                .put("lineHint", prop("line", "railway:line", "route_ref", "ref"))
            output.put(JSONObject().put("type", "Feature").put("properties", outputProps).put("geometry", pointGeometry))
        }
        return JSONObject().put("type", "FeatureCollection").put("features", output)
    }

    /** Normaliza linhas e segmentos ferroviários diretamente do GeoJSON importado para desenho no mapa. */
    fun routesGeoJsonForMap(context: Context): JSONObject {
        val file = File(context.filesDir, ROUTES_FILE)
        if (!file.exists()) return JSONObject().put("type", "FeatureCollection").put("features", JSONArray())
        val source = runCatching { JSONObject(file.readText()).optJSONArray("features") }.getOrNull() ?: JSONArray()
        val output = JSONArray()
        fun addLine(coords: JSONArray?, props: JSONObject, id: String, fallbackName: String) {
            if (coords == null || coords.length() < 2) return
            val clean = JSONArray()
            for (j in 0 until coords.length()) {
                val pair = coords.optJSONArray(j) ?: continue
                if (pair.length() < 2) continue
                val lon = pair.optDouble(0, Double.NaN); val lat = pair.optDouble(1, Double.NaN)
                if (lon.isFinite() && lat.isFinite() && lon in -180.0..180.0 && lat in -90.0..90.0) clean.put(JSONArray().put(lon).put(lat))
            }
            if (clean.length() < 2) return
            val tags = props.optJSONObject("tags")
            fun prop(vararg keys: String): String {
                for (key in keys) {
                    val value = props.optString(key).takeIf { it.isNotBlank() && it != "null" }
                        ?: tags?.optString(key)?.takeIf { it.isNotBlank() && it != "null" }
                    if (value != null) return value
                }
                return ""
            }
            val name = prop("name", "ref", "route", "line").ifBlank { fallbackName }
            val railway = prop("railway")
            val operator = prop("operator", "network")
            val routeColorKey = prop("name", "ref", "route", "line").ifBlank { "$operator|$railway".trim('|').ifBlank { "railway" } }
            output.put(JSONObject().put("type", "Feature")
                .put("properties", JSONObject().put("routeId", routeColorKey).put("name", name).put("operator", operator).put("osmId", id))
                .put("geometry", JSONObject().put("type", "LineString").put("coordinates", clean)))
        }
        for (i in 0 until source.length()) {
            val feature = source.optJSONObject(i) ?: continue
            val geometry = feature.optJSONObject("geometry") ?: continue
            val props = feature.optJSONObject("properties") ?: JSONObject()
            val id = props.optString("@id").ifBlank { props.optString("id").ifBlank { "rail-map-$i" } }
            val type = geometry.optString("type")
            val coords = geometry.optJSONArray("coordinates")
            when (type) {
                "LineString" -> addLine(coords, props, id, "Trecho ferroviário")
                "MultiLineString" -> if (coords != null) for (j in 0 until coords.length()) addLine(coords.optJSONArray(j), props, "$id-$j", "Trecho ferroviário")
                "GeometryCollection" -> {
                    val geometries = geometry.optJSONArray("geometries") ?: continue
                    for (j in 0 until geometries.length()) {
                        val child = geometries.optJSONObject(j) ?: continue
                        if (child.optString("type") == "LineString") addLine(child.optJSONArray("coordinates"), props, "$id-$j", "Trecho ferroviário")
                    }
                }
            }
        }
        return JSONObject().put("type", "FeatureCollection").put("features", output)
    }

    private fun parseStations(root: JSONObject): List<RailStation> {
        val features = root.optJSONArray("features") ?: return emptyList()
        val result = mutableListOf<RailStation>()
        for (i in 0 until features.length()) {
            val f = features.optJSONObject(i) ?: continue
            val g = f.optJSONObject("geometry") ?: continue
            if (g.optString("type") != "Point") continue
            val coords = g.optJSONArray("coordinates") ?: continue
            if (coords.length() < 2) continue
            val lon = coords.optDouble(0, Double.NaN); val lat = coords.optDouble(1, Double.NaN)
            if (!lat.isFinite() || !lon.isFinite() || lat !in -90.0..90.0 || lon !in -180.0..180.0) continue
            val p = f.optJSONObject("properties") ?: JSONObject()
            val tags = p.optJSONObject("tags")
            fun prop(vararg keys: String): String {
                for (key in keys) {
                    val v = p.optString(key).takeIf { it.isNotBlank() && it != "null" }
                        ?: tags?.optString(key)?.takeIf { it.isNotBlank() && it != "null" }
                    if (v != null) return v
                }
                return ""
            }
            val name = prop("name", "name:pt", "official_name")
            if (name.isBlank()) continue
            val id = p.optString("@id").takeIf { it.isNotBlank() }
                ?: p.optString("id").takeIf { it.isNotBlank() } ?: "station-$i-$lat-$lon"
            result += RailStation(id, name, lat, lon, prop("operator", "network"), prop("line", "railway:line", "route_ref", "ref"))
        }
        return result.distinctBy { "${it.name.lowercase()}|${round(it.latitude * 100_000.0) / 100_000.0}|${round(it.longitude * 100_000.0) / 100_000.0}" }
    }

    private fun parseRoutes(root: JSONObject): List<RailRoute> {
        val features = root.optJSONArray("features") ?: return emptyList()
        val result = mutableListOf<RailRoute>()
        for (i in 0 until features.length()) {
            val f = features.optJSONObject(i) ?: continue
            val g = f.optJSONObject("geometry") ?: continue
            val p = f.optJSONObject("properties") ?: JSONObject()
            val tags = p.optJSONObject("tags")
            fun prop(vararg keys: String): String {
                for (key in keys) {
                    val v = p.optString(key).takeIf { it.isNotBlank() && it != "null" }
                        ?: tags?.optString(key)?.takeIf { it.isNotBlank() && it != "null" }
                    if (v != null) return v
                }
                return ""
            }
            val name = prop("name", "ref", "route", "line")
            if (name.isBlank()) continue
            val paths = mutableListOf<List<GeoPoint>>()
            when (g.optString("type")) {
                "LineString" -> readCoordinates(g.optJSONArray("coordinates"), mutableListOf()).takeIf { it.size >= 2 }?.let(paths::add)
                "MultiLineString" -> {
                    val lines = g.optJSONArray("coordinates") ?: continue
                    for (j in 0 until lines.length()) readCoordinates(lines.optJSONArray(j), mutableListOf()).takeIf { it.size >= 2 }?.let(paths::add)
                }
                "GeometryCollection" -> {
                    val geometries = g.optJSONArray("geometries") ?: continue
                    for (j in 0 until geometries.length()) {
                        val child = geometries.optJSONObject(j) ?: continue
                        if (child.optString("type") == "LineString") readCoordinates(child.optJSONArray("coordinates"), mutableListOf()).takeIf { it.size >= 2 }?.let(paths::add)
                    }
                }
            }
            if (paths.isEmpty()) continue
            val id = p.optString("@id").takeIf { it.isNotBlank() }
                ?: p.optString("id").takeIf { it.isNotBlank() } ?: "route-$i-$name"
            result += RailRoute(id, name, prop("operator", "network"), paths)
        }
        return result
    }

    private fun readCoordinates(coords: JSONArray?, target: MutableList<GeoPoint>): List<GeoPoint> {
        if (coords == null) return target
        for (i in 0 until coords.length()) {
            val c = coords.optJSONArray(i) ?: continue
            if (c.length() < 2) continue
            val lon = c.optDouble(0, Double.NaN); val lat = c.optDouble(1, Double.NaN)
            if (lat.isFinite() && lon.isFinite() && lat in -90.0..90.0 && lon in -180.0..180.0) target += GeoPoint(lat, lon)
        }
        return target
    }

    fun locate(context: Context, location: Location): StationNavigationResult? {
        val stations = loadStations(context)
        val routes = loadRoutes(context)
        if (stations.isEmpty() || routes.isEmpty()) return null
        val user = GeoPoint(location.latitude, location.longitude)
        val heading = estimateHeading(location)
        // Considera distância, continuidade da linha escolhida e alinhamento com o movimento.
        // Isso reduz trocas entre linhas paralelas por oscilações pequenas do GPS.
        val candidates = routes.map { route -> route to projectOntoRoute(user, route.paths) }
        val chosen = candidates.minByOrNull { (route, projection) ->
            var score = projection.distanceMeters
            if (lastChosenRouteId != null && route.id != lastChosenRouteId && projection.distanceMeters < 180.0) score += 35.0
            if (heading != null) {
                val delta = angularDifference(heading, projection.bearingDegrees)
                val undirectedDelta = minOf(delta, 180.0 - delta)
                score += undirectedDelta * 0.9
            }
            score
        } ?: return null
        val route = chosen.first
        val projection = chosen.second
        lastChosenRouteId = route.id
        // A GPS point well away from rail geometry is not enough to assert a train station.
        if (projection.distanceMeters > 350.0) return null

        // Primeiro limita as estações à vizinhança do GPS; evita projetar cada estação de toda a
        // Região Metropolitana sobre todos os segmentos da linha em cada atualização.
        val nearbyStations = stations.filter { station ->
            haversineMeters(location.latitude, location.longitude, station.latitude, station.longitude) <= 6_000.0
        }
        val ordered = nearbyStations.mapNotNull { station ->
            val p = GeoPoint(station.latitude, station.longitude)
            val projected = projectOntoRoute(p, route.paths)
            if (projected.distanceMeters > 350.0) null else station to projected.alongMeters
        }.sortedBy { it.second }.distinctBy { it.first.id }
        if (ordered.isEmpty()) return null

        // If OSM has multiple route relations for the same service, collapse nearby duplicate stations.
        val unique = ordered.fold(mutableListOf<Pair<RailStation, Double>>()) { acc, item ->
            val duplicate = acc.lastOrNull()?.let { haversineMeters(it.first.latitude, it.first.longitude, item.first.latitude, item.first.longitude) < 80.0 } ?: false
            if (!duplicate) acc += item
            acc
        }
        if (unique.isEmpty()) return null
        val nearestIndex = unique.indices.minByOrNull { index ->
            abs(unique[index].second - projection.alongMeters) +
                haversineMeters(location.latitude, location.longitude, unique[index].first.latitude, unique[index].first.longitude) * 0.15
        } ?: return null
        val nearestDistance = haversineMeters(
            location.latitude, location.longitude,
            unique[nearestIndex].first.latitude, unique[nearestIndex].first.longitude
        )
        // A direção confiável permite alinhar a sequência ao percurso mesmo se o monitoramento
        // for iniciado entre estações: usa a última estação no sentido da viagem, não uma parada
        // que esteja à frente apenas por ser ligeiramente mais próxima em linha reta.
        val reliableGpsBearing = location.hasBearing() && location.hasSpeed() && location.speed >= 1.2f
        val effectiveHeading = if (reliableGpsBearing) location.bearing.toDouble() else heading
        val movingWithReliableBearing = effectiveHeading != null
        val reverseOrder = effectiveHeading != null && angularDifference(effectiveHeading, projection.bearingDegrees) > 120.0
        val currentIndex = when {
            nearestDistance <= 150.0 -> nearestIndex // junto à plataforma, a estação mais próxima é a atual
            !movingWithReliableBearing -> nearestIndex
            reverseOrder -> unique.indices.firstOrNull { unique[it].second >= projection.alongMeters } ?: unique.lastIndex
            else -> unique.indices.lastOrNull { unique[it].second <= projection.alongMeters } ?: 0
        }
        val currentPair = unique[currentIndex]
        val currentDistance = haversineMeters(location.latitude, location.longitude, currentPair.first.latitude, currentPair.first.longitude)
        // Do not display a misleading “current station” if the nearest station is too far away.
        if (currentDistance > 2_500.0) return null
        val previousIndex = if (reverseOrder) currentIndex + 1 else currentIndex - 1
        val nextIndex = if (reverseOrder) currentIndex - 1 else currentIndex + 1
        val nextStation = unique.getOrNull(nextIndex)?.first
        val distanceToNext = nextStation?.let {
            distanceAlongRailMeters(context, location.latitude, location.longitude, it.latitude, it.longitude, headingDegrees = effectiveHeading)
        }
        return StationNavigationResult(
            route.name, route.operator.ifBlank { currentPair.first.operator },
            unique.getOrNull(previousIndex)?.first, currentPair.first,
            nextStation, projection.distanceMeters, currentDistance, distanceToNext
        )
    }

    /**
     * Quantas estações intermediárias há, ao longo da linha atual, entre a posição do usuário e o
     * alvo (sem contar a estação do usuário nem a do alvo). Cada uma soma uma parada ao tempo de
     * viagem. Null se a linha não é conhecida ou o usuário/alvo estão longe dela.
     */
    @Synchronized
    fun stationsBetween(context: Context, location: Location, targetLatitude: Double, targetLongitude: Double): Int? {
        val routeId = lastChosenRouteId ?: return null
        val route = loadRoutes(context).firstOrNull { it.id == routeId } ?: return null
        val user = projectOntoRoute(GeoPoint(location.latitude, location.longitude), route.paths)
        val target = projectOntoRoute(GeoPoint(targetLatitude, targetLongitude), route.paths)
        if (user.distanceMeters > 350.0 || target.distanceMeters > 350.0) return null
        val stamp = File(context.filesDir, STATIONS_FILE).lastModified() + File(context.filesDir, ROUTES_FILE).lastModified()
        if (stamp != routeStationAlongStamp) { routeStationAlong.clear(); routeStationAlongStamp = stamp }
        val alongs = routeStationAlong.getOrPut(route.id) {
            val allPoints = route.paths.flatten()
            if (allPoints.isEmpty()) DoubleArray(0) else {
                val minLat = allPoints.minOf { it.latitude } - 0.004; val maxLat = allPoints.maxOf { it.latitude } + 0.004
                val minLon = allPoints.minOf { it.longitude } - 0.004; val maxLon = allPoints.maxOf { it.longitude } + 0.004
                loadStations(context)
                    .filter { it.latitude in minLat..maxLat && it.longitude in minLon..maxLon }
                    .mapNotNull { st ->
                        val p = projectOntoRoute(GeoPoint(st.latitude, st.longitude), route.paths)
                        if (p.distanceMeters > 350.0) null else p.alongMeters
                    }.sorted().fold(ArrayList<Double>()) { acc, a ->
                        if (acc.isEmpty() || a - acc.last() >= 120.0) acc.add(a)
                        acc
                    }.toDoubleArray()
            }
        }
        val lo = minOf(user.alongMeters, target.alongMeters)
        val hi = maxOf(user.alongMeters, target.alongMeters)
        return alongs.count { it > lo + 150.0 && it < hi - 150.0 }
    }

    /** Rumo suavizado atual (graus) ou null se ainda não há movimento suficiente para estimar. */
    fun currentHeadingDegrees(): Double? = smoothedHeadingDegrees

    /** Estima rumo por deslocamento entre fixes, mesmo quando o Android não fornece bearing confiável. */
    @Synchronized
    private fun estimateHeading(current: Location): Double? {
        val previous = lastFixForHeading
        var derived: Double? = null
        if (previous != null) {
            val dt = (current.fixElapsedMs() - previous.fixElapsedMs()) / 1000.0
            val moved = haversineMeters(previous.latitude, previous.longitude, current.latitude, current.longitude)
            val accuracyOk = (!current.hasAccuracy() || current.accuracy <= 65f) &&
                (!previous.hasAccuracy() || previous.accuracy <= 65f)
            if (dt in 1.0..90.0 && moved in 18.0..1_500.0 && accuracyOk) {
                derived = bearingDegrees(
                    GeoPoint(previous.latitude, previous.longitude),
                    GeoPoint(current.latitude, current.longitude)
                )
                val old = smoothedHeadingDegrees
                smoothedHeadingDegrees = if (old == null) derived else {
                    val delta = ((derived - old + 540.0) % 360.0) - 180.0
                    (old + delta * 0.45 + 360.0) % 360.0
                }
            } else if (dt > 90.0 || dt <= 0.0 || moved > 1_500.0) {
                smoothedHeadingDegrees = null
            }
        }
        lastFixForHeading = Location(current)
        if (current.hasBearing() && current.hasSpeed() && current.speed >= 1.2f) {
            val gpsHeading = current.bearing.toDouble()
            val old = smoothedHeadingDegrees
            smoothedHeadingDegrees = if (old == null) gpsHeading else {
                val delta = ((gpsHeading - old + 540.0) % 360.0) - 180.0
                (old + delta * 0.35 + 360.0) % 360.0
            }
        }
        return smoothedHeadingDegrees ?: derived
    }

    /**
     * Distância estimada seguindo a malha ferroviária importada. Retorna null se a posição
     * ou o destino estiverem longe demais dos trilhos, ou se não houver caminho conectado.
     * Nesse caso, o chamador deve usar a estimativa geográfica convencional.
     */
    fun distanceAlongRailMeters(
        context: Context,
        fromLatitude: Double,
        fromLongitude: Double,
        toLatitude: Double,
        toLongitude: Double,
        maxSnapDistanceMeters: Double = 350.0,
        headingDegrees: Double? = null
    ): Int? {
        if (!fromLatitude.isFinite() || !fromLongitude.isFinite() || !toLatitude.isFinite() || !toLongitude.isFinite()) return null
        val network = loadNetwork(context) ?: return null
        if (network.segments.isEmpty()) return null
        val from = GeoPoint(fromLatitude, fromLongitude)
        val to = GeoPoint(toLatitude, toLongitude)
        // Com rumo (posição do usuário em movimento), o encaixe considera o alinhamento do segmento
        // com o deslocamento e a continuidade da linha anterior: em linhas paralelas ou sobrepostas
        // (metrô sobre trem) a mais próxima nem sempre é a linha em que o usuário viaja.
        val start = nearestSegment(from, network.segments, maxSnapDistanceMeters, headingDegrees,
            if (headingDegrees != null) lastSnapFeatureId else null) ?: return null
        if (headingDegrees != null) lastSnapFeatureId = start.segment.featureId
        val finish = nearestSegment(to, network.segments, maxSnapDistanceMeters) ?: return null
        if (start.distanceMeters > maxSnapDistanceMeters || finish.distanceMeters > maxSnapDistanceMeters) return null

        val startSeg = start.segment
        val endSeg = finish.segment
        var best = Double.POSITIVE_INFINITY
        // Os dois pontos podem estar no mesmo trecho; considere seguir diretamente pelo segmento.
        if (sameUndirectedEdge(startSeg, endSeg)) {
            val finishTOnStartOrientation = if (startSeg.aKey == endSeg.aKey) finish.t else 1.0 - finish.t
            best = abs(start.t - finishTOnStartOrientation) * startSeg.lengthMeters
        }

        val distances = HashMap<String, Double>()
        val queue = PriorityQueue<QueueEntry>(compareBy { it.distance })
        fun seed(key: String, distance: Double) {
            if (distance < (distances[key] ?: Double.POSITIVE_INFINITY)) {
                distances[key] = distance
                queue.add(QueueEntry(key, distance))
            }
        }
        seed(startSeg.aKey, start.t * startSeg.lengthMeters)
        seed(startSeg.bKey, (1.0 - start.t) * startSeg.lengthMeters)
        val endCosts = mapOf(
            endSeg.aKey to finish.t * endSeg.lengthMeters,
            endSeg.bKey to (1.0 - finish.t) * endSeg.lengthMeters
        )
        val straightLine = haversineMeters(fromLatitude, fromLongitude, toLatitude, toLongitude)
        val searchLimit = maxOf(20_000.0, straightLine * 5.0 + 5_000.0)
        var visited = 0
        while (queue.isNotEmpty() && visited < 120_000) {
            val current = queue.poll()
            if (current.distance != distances[current.key]) continue
            if (current.distance >= best) break
            if (current.distance > searchLimit) break
            visited++
            val finishCost = endCosts[current.key]
            if (finishCost != null) best = minOf(best, current.distance + finishCost)
            for (edge in network.adjacency[current.key].orEmpty()) {
                val candidate = current.distance + edge.meters
                if (candidate < (distances[edge.to] ?: Double.POSITIVE_INFINITY) && candidate < best) {
                    distances[edge.to] = candidate
                    queue.add(QueueEntry(edge.to, candidate))
                }
            }
        }
        if (!best.isFinite() || best < 0.0) return null
        return best.roundToInt()
    }

    @Synchronized
    private fun loadNetwork(context: Context): RailNetwork? {
        val file = File(context.filesDir, ROUTES_FILE)
        if (!file.exists()) return null
        val modified = file.lastModified()
        val length = file.length()
        cachedNetwork?.let { if (modified == cachedNetworkModified && length == cachedNetworkLength) return it }
        val adjacency = HashMap<String, MutableList<NetworkEdge>>()
        val segments = ArrayList<RailSegment>()
        fun key(point: GeoPoint): String = "${round(point.latitude * 100_000.0).toInt()}:${round(point.longitude * 100_000.0).toInt()}"
        fun addNode(nodeKey: String) { adjacency.getOrPut(nodeKey) { mutableListOf() } }
        // Para a distância, lê todos os traçados, inclusive ways sem nome. A navegação
        // que identifica nomes de linhas continua usando parseRoutes, que exige nome/referência.
        val features = runCatching { JSONObject(file.readText()).optJSONArray("features") }.getOrNull() ?: JSONArray()
        for (featureIndex in 0 until features.length()) {
            val feature = features.optJSONObject(featureIndex) ?: continue
            val geometry = feature.optJSONObject("geometry") ?: continue
            val paths = mutableListOf<List<GeoPoint>>()
            when (geometry.optString("type")) {
                "LineString" -> readCoordinates(geometry.optJSONArray("coordinates"), mutableListOf())
                    .takeIf { it.size >= 2 }?.let(paths::add)
                "MultiLineString" -> {
                    val lines = geometry.optJSONArray("coordinates") ?: continue
                    for (lineIndex in 0 until lines.length()) {
                        readCoordinates(lines.optJSONArray(lineIndex), mutableListOf()).takeIf { it.size >= 2 }?.let(paths::add)
                    }
                }
                "GeometryCollection" -> {
                    val geometries = geometry.optJSONArray("geometries") ?: continue
                    for (lineIndex in 0 until geometries.length()) {
                        val child = geometries.optJSONObject(lineIndex) ?: continue
                        if (child.optString("type") == "LineString") {
                            readCoordinates(child.optJSONArray("coordinates"), mutableListOf()).takeIf { it.size >= 2 }?.let(paths::add)
                        }
                    }
                }
            }
            for (path in paths) {
                for (i in 0 until path.lastIndex) {
                    val a = path[i]; val b = path[i + 1]
                    val meters = haversineMeters(a.latitude, a.longitude, b.latitude, b.longitude)
                    if (!meters.isFinite() || meters < 0.2 || meters > 5_000.0) continue
                    val aKey = key(a); val bKey = key(b)
                    if (aKey == bKey) continue
                    addNode(aKey); addNode(bKey)
                    adjacency[aKey]!!.add(NetworkEdge(bKey, meters))
                    adjacency[bKey]!!.add(NetworkEdge(aKey, meters))
                    segments.add(RailSegment(aKey, bKey, a, b, meters,
                        minOf(a.latitude, b.latitude), maxOf(a.latitude, b.latitude),
                        minOf(a.longitude, b.longitude), maxOf(a.longitude, b.longitude), featureIndex))
                }
            }
        }
        if (segments.isEmpty()) return null
        val network = RailNetwork(adjacency.mapValues { it.value.toList() }, segments)
        cachedNetwork = network
        cachedNetworkModified = modified
        cachedNetworkLength = length
        return network
    }

    private fun nearestSegment(
        point: GeoPoint,
        segments: List<RailSegment>,
        maxDistanceMeters: Double,
        headingDegrees: Double? = null,
        preferFeature: Int? = null
    ): SegmentProjection? {
        val latMargin = maxDistanceMeters / 110_000.0 + 0.00005
        val lonMargin = maxDistanceMeters / (110_000.0 * cos(Math.toRadians(point.latitude)).coerceAtLeast(0.05)) + 0.00005
        var best: SegmentProjection? = null
        var bestScore = Double.MAX_VALUE
        for (segment in segments) {
            if (point.latitude < segment.minLat - latMargin || point.latitude > segment.maxLat + latMargin ||
                point.longitude < segment.minLon - lonMargin || point.longitude > segment.maxLon + lonMargin) continue
            val latScale = 111_320.0
            val lonScale = 111_320.0 * cos(Math.toRadians(point.latitude)).coerceAtLeast(0.01)
            val ax = (segment.a.longitude - point.longitude) * lonScale
            val ay = (segment.a.latitude - point.latitude) * latScale
            val bx = (segment.b.longitude - point.longitude) * lonScale
            val by = (segment.b.latitude - point.latitude) * latScale
            val dx = bx - ax; val dy = by - ay
            val denom = dx * dx + dy * dy
            val t = if (denom == 0.0) 0.0 else (-(ax * dx + ay * dy) / denom).coerceIn(0.0, 1.0)
            val distance = hypot(ax + t * dx, ay + t * dy)
            if (distance > maxDistanceMeters) continue
            var score = distance
            if (headingDegrees != null) {
                val delta = angularDifference(headingDegrees, bearingDegrees(segment.a, segment.b))
                score += minOf(delta, 180.0 - delta) * 0.9
                if (preferFeature != null && segment.featureId != preferFeature && distance < 180.0) score += 35.0
            }
            if (score < bestScore) { bestScore = score; best = SegmentProjection(segment, t, distance) }
        }
        return best
    }

    private fun sameUndirectedEdge(a: RailSegment, b: RailSegment): Boolean =
        (a.aKey == b.aKey && a.bKey == b.bKey) || (a.aKey == b.bKey && a.bKey == b.aKey)

    private data class Projection(val alongMeters: Double, val distanceMeters: Double, val bearingDegrees: Double)

    private fun projectOntoRoute(point: GeoPoint, paths: List<List<GeoPoint>>): Projection {
        var pathOffset = 0.0
        var bestDistance = Double.MAX_VALUE
        var bestAlong = 0.0
        var bestBearing = 0.0
        for (path in paths) {
            var alongInPath = 0.0
            for (i in 0 until path.size - 1) {
                val a = path[i]; val b = path[i + 1]
                val segmentLength = haversineMeters(a.latitude, a.longitude, b.latitude, b.longitude)
                if (segmentLength < 0.01) continue
                val latScale = 111_320.0
                val lonScale = 111_320.0 * cos(Math.toRadians(point.latitude)).coerceAtLeast(0.01)
                val ax = (a.longitude - point.longitude) * lonScale
                val ay = (a.latitude - point.latitude) * latScale
                val bx = (b.longitude - point.longitude) * lonScale
                val by = (b.latitude - point.latitude) * latScale
                val dx = bx - ax; val dy = by - ay
                val denom = dx * dx + dy * dy
                val t = if (denom == 0.0) 0.0 else ((-(ax * dx + ay * dy) / denom).coerceIn(0.0, 1.0))
                val px = ax + t * dx; val py = ay + t * dy
                val dist = hypot(px, py)
                if (dist < bestDistance) {
                    bestDistance = dist
                    bestAlong = pathOffset + alongInPath + segmentLength * t
                    bestBearing = bearingDegrees(a, b)
                }
                alongInPath += segmentLength
            }
            pathOffset += alongInPath
        }
        return Projection(bestAlong, bestDistance, bestBearing)
    }

    private fun bearingDegrees(a: GeoPoint, b: GeoPoint): Double {
        val lat1 = Math.toRadians(a.latitude)
        val lat2 = Math.toRadians(b.latitude)
        val dLon = Math.toRadians(b.longitude - a.longitude)
        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    private fun angularDifference(a: Double, b: Double): Double {
        val difference = abs((a - b + 540.0) % 360.0 - 180.0)
        return difference
    }

    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6_371_000.0
        val dLat = Math.toRadians(lat2 - lat1); val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return r * 2 * atan2(sqrt(a), sqrt((1 - a).coerceAtLeast(0.0)))
    }
}
