package br.com.alertageografico

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Atalho nas configurações rápidas: toca para iniciar um destino único (viagem rápida). Com o
 * monitoramento ativo o atalho aparece ligado e, ao tocar, pede a confirmação para parar.
 */
class QuickTripTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        val monitoring = DestinationStore.monitoringActive(this)
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (monitoring) intent.putExtra(LocationMonitorService.EXTRA_CONFIRM_STOP, true)
        else intent.action = MainActivity.ACTION_QUICK_TRIP
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 11, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            )
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val monitoring = DestinationStore.monitoringActive(this)
        tile.label = "Destino único"
        tile.state = if (monitoring) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= 29) tile.subtitle = if (monitoring) "Monitorando" else "Viagem rápida"
        tile.updateTile()
    }
}
