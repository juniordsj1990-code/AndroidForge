package br.com.alertageografico

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Posição gerada pelo simulador. */
data class SimFix(val latitude: Double, val longitude: Double, val speedMps: Float, val bearingDeg: Float, val finished: Boolean)

/**
 * Simulador de trajeto para testes sem sair de casa. Percorre em linha reta a sequência de pontos
 * informada, começando [startOffsetMeters] antes do primeiro, a uma velocidade constante.
 * Não depende de Android, então é testável em JVM.
 */
class TripSimulator(
    waypoints: List<Pair<Double, Double>>,
    private val speedMps: Double,
    startOffsetMeters: Double = DEFAULT_START_OFFSET_METERS
) {
    private val path: List<Pair<Double, Double>>
    private val cumulative: DoubleArray
    private var travelled = 0.0

    init {
        require(waypoints.isNotEmpty()) { "O simulador precisa de ao menos um ponto" }
        val first = waypoints.first()
        // Ponto de partida: antes do primeiro destino, para o trajeto "chegar" a ele.
        val start = if (waypoints.size >= 2) {
            val second = waypoints[1]
            // Mesmo rumo do trecho first -> second, para a viagem seguir em frente ao passar pelo primeiro ponto.
            val heading = bearing(first.first, first.second, second.first, second.second)
            offset(first.first, first.second, heading, startOffsetMeters)
        } else {
            offset(first.first, first.second, DEFAULT_APPROACH_BEARING, startOffsetMeters)
        }
        path = listOf(start) + waypoints
        cumulative = DoubleArray(path.size)
        for (i in 1 until path.size) {
            cumulative[i] = cumulative[i - 1] + distance(path[i - 1], path[i])
        }
    }

    val totalMeters: Double get() = cumulative.last()

    /** Avança [dtSeconds] e devolve a nova posição. */
    fun step(dtSeconds: Double): SimFix {
        travelled = min(totalMeters, travelled + max(0.0, speedMps * dtSeconds))
        var seg = 1
        while (seg < path.size - 1 && cumulative[seg] < travelled) seg++
        val a = path[seg - 1]
        val b = path[seg]
        val segLen = cumulative[seg] - cumulative[seg - 1]
        val f = if (segLen <= 0.0) 1.0 else ((travelled - cumulative[seg - 1]) / segLen).coerceIn(0.0, 1.0)
        val lat = a.first + (b.first - a.first) * f
        val lon = a.second + (b.second - a.second) * f
        return SimFix(lat, lon, speedMps.toFloat(), bearing(a.first, a.second, b.first, b.second).toFloat(), travelled >= totalMeters)
    }

    companion object {
        const val DEFAULT_START_OFFSET_METERS = 1_500.0
        private const val DEFAULT_APPROACH_BEARING = 200.0 // anda rumo a sul-sudoeste (vem de nor-nordeste)
        private const val EARTH_RADIUS = 6_371_000.0

        fun distance(a: Pair<Double, Double>, b: Pair<Double, Double>): Double {
            val dLat = Math.toRadians(b.first - a.first)
            val dLon = Math.toRadians(b.second - a.second)
            val h = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(a.first)) * cos(Math.toRadians(b.first)) * sin(dLon / 2) * sin(dLon / 2)
            return 2 * EARTH_RADIUS * atan2(sqrt(h), sqrt(1 - h))
        }

        fun bearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
            val p1 = Math.toRadians(lat1)
            val p2 = Math.toRadians(lat2)
            val dl = Math.toRadians(lon2 - lon1)
            val y = sin(dl) * cos(p2)
            val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
            return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
        }

        /** Ponto a [meters] metros de (lat, lon), "atrás" de quem anda com o rumo [bearingDeg]. */
        fun offset(lat: Double, lon: Double, bearingDeg: Double, meters: Double): Pair<Double, Double> {
            val back = Math.toRadians((bearingDeg + 180.0) % 360.0)
            val ang = meters / EARTH_RADIUS
            val p1 = Math.toRadians(lat)
            val l1 = Math.toRadians(lon)
            val p2 = Math.asin(sin(p1) * cos(ang) + cos(p1) * sin(ang) * cos(back))
            val l2 = l1 + atan2(sin(back) * sin(ang) * cos(p1), cos(ang) - sin(p1) * sin(p2))
            return Math.toDegrees(p2) to Math.toDegrees(l2)
        }
    }
}
