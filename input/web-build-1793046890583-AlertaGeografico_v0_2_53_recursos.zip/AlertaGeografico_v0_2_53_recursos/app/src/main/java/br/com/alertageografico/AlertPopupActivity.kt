package br.com.alertageografico

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import br.com.alertageografico.ui.AgIcon
import br.com.alertageografico.ui.AgTheme

/**
 * Alerta em janela (alternativa à notificação): aparece em primeiro plano, inclusive sobre a tela
 * bloqueada, e oferece as mesmas ações da notificação: OK, Soneca 5 min e abrir o app.
 * Visual: ícone grande, cor por tipo de transporte e a distância que falta até o destino.
 */
class AlertPopupActivity : ComponentActivity() {
    private var title by mutableStateOf("")
    private var message by mutableStateOf("")
    private var transport by mutableStateOf(TransportType.TRAIN)
    private var distanceMeters by mutableStateOf(-1)
    private var arrival by mutableStateOf(true)
    private var isFinal by mutableStateOf(false)
    private var notificationId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        readIntent(intent)
        setContent {
            AgTheme {
                // Voltar equivale a OK: confirma o alerta e para o som.
                BackHandler { confirm() }
                val isBus = transport == TransportType.BUS
                // Cor por tipo: azul para trem/metrô, laranja para ônibus.
                val accent = if (isBus) Color(0xFFE65100) else Color(0xFF1558B0)
                val headline = when {
                    isFinal && arrival -> "Chegada ao destino final"
                    arrival -> "Chegando à parada"
                    else -> "Aproximando-se do destino"
                }
                Box(
                    Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)).padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        shape = RoundedCornerShape(28.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Column(
                                Modifier.fillMaxWidth().background(accent).padding(horizontal = 24.dp, vertical = 28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    Modifier.size(88.dp).background(Color.White.copy(alpha = 0.2f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AgIcon(
                                        if (isBus) R.drawable.ic_pick_bus else R.drawable.ic_pick_train,
                                        size = 52.dp, tint = Color.White
                                    )
                                }
                                Text(headline, style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = 0.9f))
                                Text(
                                    title, style = MaterialTheme.typography.headlineSmall, color = Color.White,
                                    textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold
                                )
                                if (isFinal) {
                                    Surface(shape = RoundedCornerShape(50), color = Color.White.copy(alpha = 0.22f)) {
                                        Text(
                                            "PARADA FINAL", style = MaterialTheme.typography.labelMedium, color = Color.White,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text(message, style = MaterialTheme.typography.bodyLarge)
                                if (distanceMeters >= 0) {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = accent.copy(alpha = 0.12f),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            AgIcon(R.drawable.ic_ui_ruler, size = 20.dp, tint = accent)
                                            Text(
                                                if (distanceMeters < 15) "Você está no destino" else "Faltam cerca de ${formatDistance(distanceMeters)}",
                                                style = MaterialTheme.typography.titleSmall, color = accent
                                            )
                                        }
                                    }
                                }
                                Button(
                                    onClick = { confirm() },
                                    colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.White),
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("OK") }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    OutlinedButton(onClick = { snooze() }, modifier = Modifier.weight(1f)) { Text("Soneca 5 min") }
                                    TextButton(onClick = { openApp() }, modifier = Modifier.weight(1f)) { Text("Abrir app") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    private fun readIntent(intent: Intent?) {
        title = intent?.getStringExtra(EXTRA_TITLE).orEmpty()
        message = intent?.getStringExtra(EXTRA_MESSAGE).orEmpty()
        notificationId = intent?.getIntExtra(EXTRA_NOTIFICATION_ID, -1) ?: -1
        transport = TransportType.normalize(intent?.getStringExtra(EXTRA_TRANSPORT))
        distanceMeters = intent?.getIntExtra(EXTRA_DISTANCE_METERS, -1) ?: -1
        arrival = intent?.getBooleanExtra(EXTRA_ARRIVAL, true) ?: true
        isFinal = intent?.getBooleanExtra(EXTRA_FINAL, false) ?: false
    }

    private fun formatDistance(meters: Int): String =
        if (meters >= 1000) String.format(java.util.Locale("pt", "BR"), "%.1f km", meters / 1000.0) else "$meters m"

    // A confirmação passa pelo mesmo receptor da notificação (para o som e remove a notificação).
    private fun confirm() {
        sendBroadcast(Intent(this, AlertDismissReceiver::class.java).putExtra("notification_id", notificationId))
        finish()
    }

    private fun snooze() {
        sendBroadcast(
            Intent(this, AlertDismissReceiver::class.java).setAction(AlertDismissReceiver.ACTION_SNOOZE)
                .putExtra("notification_id", notificationId).putExtra("minutes", 5)
        )
        finish()
    }

    private fun openApp() {
        sendBroadcast(Intent(this, AlertDismissReceiver::class.java).putExtra("notification_id", notificationId))
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }

    companion object {
        const val EXTRA_TITLE = "br.com.alertageografico.extra.POPUP_TITLE"
        const val EXTRA_MESSAGE = "br.com.alertageografico.extra.POPUP_MESSAGE"
        const val EXTRA_NOTIFICATION_ID = "br.com.alertageografico.extra.POPUP_NOTIFICATION_ID"
        const val EXTRA_TRANSPORT = "br.com.alertageografico.extra.POPUP_TRANSPORT"
        const val EXTRA_DISTANCE_METERS = "br.com.alertageografico.extra.POPUP_DISTANCE"
        const val EXTRA_ARRIVAL = "br.com.alertageografico.extra.POPUP_ARRIVAL"
        const val EXTRA_FINAL = "br.com.alertageografico.extra.POPUP_FINAL"
    }
}
