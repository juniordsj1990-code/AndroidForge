package br.com.alertageografico

import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Leitura de posição independente de Android, para permitir testes de unidade. */
data class Fix(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    val timeMillis: Long = 0L
)

data class ProximityResult(
    /** Destinos cujo alerta deve ser disparado agora. */
    val triggered: List<Destination>,
    /** Menor distância até a borda de um raio ativo (0 se estiver dentro de algum). Null sem destinos ativos. */
    val nearestEdgeMeters: Double?,
    /** Verdadeiro se a leitura foi descartada por baixa precisão (para qualquer destino). */
    val lowAccuracy: Boolean
)

/**
 * Decide quando alertar. Regras:
 *  - leituras com precisão pior que min(maxAccuracy, max(raio, 50 m)) não podem disparar nem rearmar;
 *  - são necessárias [confirmFixes] leituras consecutivas dentro do raio (1 se a precisão for excelente);
 *  - rearma após sair do raio × [rearmFactor] + [rearmExtraMeters];
 *  - estado de destinos removidos é descartado.
 */
class ProximityEngine(
    private val maxAccuracyMeters: Float = 150f,
    private val confirmFixes: Int = 2,
    private val strongAccuracyMeters: Float = 25f,
    private val rearmFactor: Double = 1.15,
    private val rearmExtraMeters: Double = 15.0
) {
    private val inside = mutableMapOf<String, Boolean>()
    private val streak = mutableMapOf<String, Int>()

    fun process(fix: Fix, destinations: List<Destination>): ProximityResult {
        val active = destinations.filter { it.enabled }
        val activeIds = active.mapTo(HashSet()) { it.id }
        inside.keys.retainAll(activeIds)
        streak.keys.retainAll(activeIds)

        val triggered = mutableListOf<Destination>()
        var nearestEdge: Double? = null
        var anyLowAccuracy = false

        for (d in active) {
            val distance = distanceMeters(fix.latitude, fix.longitude, d.latitude, d.longitude)
            val edge = max(0.0, distance - d.radiusMeters)
            nearestEdge = nearestEdge?.let { min(it, edge) } ?: edge

            val gate = min(maxAccuracyMeters, max(d.radiusMeters.toFloat(), 50f))
            if (fix.accuracyMeters > gate) {
                anyLowAccuracy = true
                continue // leitura pouco confiável: não altera estado
            }

            val wasInside = inside[d.id] ?: false
            if (distance <= d.radiusMeters) {
                if (!wasInside) {
                    val count = (streak[d.id] ?: 0) + 1
                    streak[d.id] = count
                    val needed = if (fix.accuracyMeters <= strongAccuracyMeters) 1 else confirmFixes
                    if (count >= needed) {
                        inside[d.id] = true
                        streak[d.id] = 0
                        triggered += d
                    }
                }
            } else {
                streak[d.id] = 0
                if (wasInside && distance > d.radiusMeters * rearmFactor + rearmExtraMeters) {
                    inside[d.id] = false
                }
            }
        }
        return ProximityResult(triggered, nearestEdge, anyLowAccuracy)
    }

    fun reset() { inside.clear(); streak.clear() }

    companion object {
        private const val EARTH_RADIUS_M = 6_371_000.0
        private const val ASSUMED_MAX_SPEED_MPS = 30.0 // ~108 km/h
        const val MIN_INTERVAL_MS = 3_000L
        const val MAX_INTERVAL_MS = 60_000L

        fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
            val p1 = Math.toRadians(lat1)
            val p2 = Math.toRadians(lat2)
            val dp = p2 - p1
            val dl = Math.toRadians(lon2 - lon1)
            val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
            return 2 * EARTH_RADIUS_M * asin(min(1.0, sqrt(a)))
        }

        /**
         * Intervalo de atualização seguro: no máximo 1/3 do tempo que levaria para alcançar a borda
         * do raio na velocidade assumida, limitado a 3–60 s. Sem destinos ativos, usa o máximo.
         */
        fun recommendedIntervalMs(nearestEdgeMeters: Double?): Long {
            if (nearestEdgeMeters == null) return MAX_INTERVAL_MS
            val ms = nearestEdgeMeters / ASSUMED_MAX_SPEED_MPS * 1000.0 / 3.0
            return ms.toLong().coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)
        }
    }
}
