package br.com.alertageografico

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONArray

/** Mapa baseado em dados OpenStreetMap usando o serviço de tiles OpenFreeMap,
 * sem solicitar tiles ao servidor público tile.openstreetmap.org. */
class MapActivity : Activity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Preferência por ids (evita estourar o limite de ~1 MB de uma Intent com muitos destinos).
        // O JSON continua aceito para prévias de destinos ainda não salvos.
        val ids = intent.getStringArrayListExtra(EXTRA_DESTINATION_IDS)
        val destinations = if (ids != null) {
            val byId = DestinationStore.load(this).associateBy { it.id }
            ids.mapNotNull { byId[it] }
        } else {
            val raw = intent.getStringExtra(EXTRA_DESTINATIONS) ?: "[]"
            runCatching {
                val array = JSONArray(raw)
                (0 until array.length()).map { Destination.fromJson(array.getJSONObject(it)) }
            }.getOrDefault(emptyList())
        }
        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = object : WebViewClient() {
            // Links de atribuição (OpenStreetMap/OpenFreeMap) abrem no navegador, não dentro do mapa.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.isForMainFrame && request.url.scheme in listOf("http", "https")) {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                    return true
                }
                return false
            }
        }
        val selecting = intent.getBooleanExtra(EXTRA_SELECT_POINT, false)
        // No Android 15 o app é desenhado sob as barras do sistema: aplica as margens ao contêiner.
        val container = FrameLayout(this)
        container.addView(webView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        container.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            }
            insets
        }
        setContentView(container)
        if (selecting) {
            webView.addJavascriptInterface(object {
                @JavascriptInterface fun selected(lat: Double, lon: Double) {
                    runOnUiThread {
                        setResult(Activity.RESULT_OK, Intent().putExtra(EXTRA_SELECTED_LAT, lat).putExtra(EXTRA_SELECTED_LON, lon))
                        finish()
                    }
                }
            }, "AndroidBridge")
        } else {
            webView.addJavascriptInterface(object {
                @JavascriptInterface fun layerVisibilityChanged(showLines: Boolean, showStations: Boolean) {
                    getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE).edit()
                        .putBoolean(PREF_SHOW_RAIL_LINES, showLines)
                        .putBoolean(PREF_SHOW_RAIL_STATIONS, showStations)
                        .apply()
                }
            }, "AndroidBridge")
        }
        val json = JSONArray().apply { destinations.forEach { put(it.toJson()) } }.toString().replace("<", "\\u003c")
        // Dados ferroviários importados são lidos do armazenamento local e enviados ao mapa como GeoJSON.
        val railStationsJson = runCatching { StationNavigationStore.stationsGeoJsonForMap(this).optJSONArray("features") ?: JSONArray() }
            .getOrDefault(JSONArray()).let { JSONArray(it.toString()) }.toString().replace("<", "\\u003c")
        val railRoutesJson = runCatching { StationNavigationStore.routesGeoJsonForMap(this).optJSONArray("features") ?: JSONArray() }
            .getOrDefault(JSONArray()).let { JSONArray(it.toString()) }.toString().replace("<", "\\u003c")
        val railStationCount = runCatching { JSONArray(railStationsJson).length() }.getOrDefault(0)
        val railRouteCount = runCatching { JSONArray(railRoutesJson).length() }.getOrDefault(0)
        val prefs = getSharedPreferences(DestinationStore.PREFS, MODE_PRIVATE)
        val showRailLinesInitially = prefs.getBoolean(PREF_SHOW_RAIL_LINES, true)
        val showRailStationsInitially = prefs.getBoolean(PREF_SHOW_RAIL_STATIONS, true)
        val lastLat = prefs.getString(DestinationStore.KEY_LAST_LATITUDE, null)?.toDoubleOrNull()
        val lastLon = prefs.getString(DestinationStore.KEY_LAST_LONGITUDE, null)?.toDoubleOrNull()
        val currentLocationJson = if (lastLat != null && lastLon != null && lastLat in -90.0..90.0 && lastLon in -180.0..180.0) {
            "{lat:$lastLat,lon:$lastLon}"
        } else "null"
        val html = """
            <!doctype html><html lang="pt-br"><head><meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
            <link href="https://unpkg.com/maplibre-gl@5.6.1/dist/maplibre-gl.css" rel="stylesheet">
            <style>
              html,body,#map{height:100%;width:100%;margin:0;padding:0}
              .selectBtn{position:absolute;z-index:20;bottom:32px;left:50%;transform:translateX(-50%);padding:14px 20px;border:0;border-radius:24px;background:#166534;color:white;font-size:16px;box-shadow:0 2px 8px #555}
              .hint{position:absolute;z-index:20;top:12px;left:50%;transform:translateX(-50%);padding:8px 12px;background:white;border-radius:8px;font:14px sans-serif;box-shadow:0 1px 6px #555;white-space:nowrap}
              .attribution{position:absolute;bottom:4px;right:5px;z-index:10;background:#fff;padding:3px 6px;font:11px sans-serif;border-radius:3px}
              .rail-controls{position:absolute;z-index:15;top:12px;left:12px;background:#fff;color:#172033;padding:10px 12px;border-radius:10px;box-shadow:0 1px 7px #555;font:14px sans-serif;max-width:220px}
              .rail-controls strong{display:block;margin-bottom:7px;font-size:13px}
              .rail-controls label{display:flex;align-items:center;gap:7px;margin:7px 0;cursor:pointer}
              .rail-controls input{width:18px;height:18px;accent-color:#2563eb}
            </style></head><body><div id="map"></div>
            ${if (selecting) "<div class=\"hint\">Toque no mapa para escolher o ponto</div><button class=\"selectBtn\" onclick=\"confirmPoint()\">Usar este ponto</button>" else ""}
            ${if (!selecting && (railStationCount > 0 || railRouteCount > 0)) """<div class="rail-controls"><strong>Camadas ferroviárias</strong>${if (railRouteCount > 0) "<label><input id='toggle-rail-lines' type='checkbox' ${if (showRailLinesInitially) "checked" else ""}> Linhas ferroviárias</label>" else ""}${if (railStationCount > 0) "<label><input id='toggle-rail-stations' type='checkbox' ${if (showRailStationsInitially) "checked" else ""}> Estações</label>" else ""}</div>""" else ""}
            <div class="attribution">© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a> · Tiles <a href="https://openfreemap.org/">OpenFreeMap</a></div>
            <script src="https://unpkg.com/maplibre-gl@5.6.1/dist/maplibre-gl.js"></script><script>
              const destinations = $json;
              const currentLocation = $currentLocationJson;
              const railStations = $railStationsJson;
              const railRoutes = $railRoutesJson;
              const styleUrl = 'https://tiles.openfreemap.org/styles/liberty';
              const map = new maplibregl.Map({container:'map',style:styleUrl,center:[-51.9253,-14.235],zoom:4, attributionControl:false});
              map.addControl(new maplibregl.NavigationControl(), 'top-right');
              let selectedPoint = null; let selectionMarker = null;
              function confirmPoint(){ if(!selectedPoint){alert('Toque no mapa para escolher um ponto.');return;} if(window.AndroidBridge) AndroidBridge.selected(selectedPoint.lat,selectedPoint.lng); }
              ${if (selecting) "map.on('click',e=>{selectedPoint=e.lngLat; if(selectionMarker)selectionMarker.remove(); selectionMarker=new maplibregl.Marker({color:'#16a34a'}).setLngLat(e.lngLat).addTo(map);});" else ""}
              const escapeHtml = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
              function circleFeature(lon,lat,radius){
                const coords=[]; const earth=6378137; const latRad=lat*Math.PI/180;
                for(let i=0;i<=96;i++){const a=i*2*Math.PI/96;const dy=radius*Math.sin(a)/earth;const dx=radius*Math.cos(a)/(earth*Math.cos(latRad));coords.push([lon+dx*180/Math.PI,lat+dy*180/Math.PI]);}
                return {type:'Feature',properties:{},geometry:{type:'Polygon',coordinates:[coords]}};
              }
              map.on('load',()=>{
                const features=destinations.filter(d=>Number.isFinite(Number(d.latitude))&&Number.isFinite(Number(d.longitude))).map(d=>circleFeature(Number(d.longitude),Number(d.latitude),Math.max(1,Number(d.radiusMeters)||300)));
                map.addSource('alert-radii',{type:'geojson',data:{type:'FeatureCollection',features}});
                map.addLayer({id:'alert-radii-fill',type:'fill',source:'alert-radii',paint:{'fill-color':'#fb7185','fill-opacity':0.2}});
                map.addLayer({id:'alert-radii-line',type:'line',source:'alert-radii',paint:{'line-color':'#e11d48','line-width':2}});
                const coords=[]; const boundsCoords=[];
                destinations.forEach((d,i)=>{
                  const lat=Number(d.latitude),lon=Number(d.longitude); if(!Number.isFinite(lat)||!Number.isFinite(lon))return;
                  coords.push([lon,lat]); boundsCoords.push([lon,lat]);
                  const el=document.createElement('div'); el.style.cssText='width:18px;height:18px;background:#e11d48;border:3px solid white;border-radius:50%;box-shadow:0 1px 5px #555';
                  new maplibregl.Marker({element:el}).setLngLat([lon,lat]).setPopup(new maplibregl.Popup({offset:18}).setHTML('<b>'+escapeHtml(d.name||'Destino')+'</b><br>Raio: '+(Number(d.radiusMeters)||300)+' m')).addTo(map);
                });
                if(coords.length>1){map.addSource('route-line',{type:'geojson',data:{type:'Feature',properties:{},geometry:{type:'LineString',coordinates:coords}}});map.addLayer({id:'route-line-layer',type:'line',source:'route-line',paint:{'line-color':'#2563eb','line-width':3,'line-dasharray':[2,2]}});}
                if(currentLocation && Number.isFinite(currentLocation.lat) && Number.isFinite(currentLocation.lon)){
                  const here=[currentLocation.lon,currentLocation.lat]; boundsCoords.push(here);
                  const el=document.createElement('div'); el.style.cssText='width:18px;height:18px;background:#2563eb;border:3px solid white;border-radius:50%;box-shadow:0 1px 6px #555';
                  new maplibregl.Marker({element:el}).setLngLat(here).setPopup(new maplibregl.Popup({offset:18}).setText('Última posição GPS recebida')).addTo(map);
                }

                // Camada de linhas: cada rota recebe uma cor estável e pode ser ocultada no painel.
                const validRailRoutes = railRoutes.filter(f => f && f.geometry && f.geometry.type === 'LineString' && Array.isArray(f.geometry.coordinates) && f.geometry.coordinates.length >= 2);
                if(validRailRoutes.length){
                  map.addSource('rail-routes-source',{type:'geojson',data:{type:'FeatureCollection',features:validRailRoutes}});
                  const palette=['#2563eb','#dc2626','#16a34a','#9333ea','#ea580c','#0891b2','#be123c','#4f46e5','#65a30d','#a16207'];
                  const ids=[...new Set(validRailRoutes.map(f=>String(f.properties?.routeId||f.properties?.name||'rail')))];
                  const colorExpression=['match',['get','routeId']];
                  ids.forEach((id,i)=>{colorExpression.push(id,palette[i%palette.length]);});
                  colorExpression.push('#64748b');
                  map.addLayer({id:'rail-routes-layer',type:'line',source:'rail-routes-source',layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':colorExpression,'line-width':3.5,'line-opacity':0.88}});
                }

                // Camada de estações: círculos clicáveis com nome, operadora e referência de linha.
                const validStations=railStations.filter(f=>f && f.geometry && f.geometry.type==='Point' && Array.isArray(f.geometry.coordinates) && f.geometry.coordinates.length>=2);
                if(validStations.length){
                  map.addSource('rail-stations-source',{type:'geojson',data:{type:'FeatureCollection',features:validStations}});
                  map.addLayer({id:'rail-stations-layer',type:'circle',source:'rail-stations-source',paint:{'circle-radius':['interpolate',['linear'],['zoom'],5,3.5,12,6,16,8],'circle-color':'#f59e0b','circle-stroke-color':'#ffffff','circle-stroke-width':1.7,'circle-opacity':0.98}});
                  map.on('click','rail-stations-layer',e=>{
                    const feature=e.features&&e.features[0]; if(!feature)return;
                    const props=feature.properties||{}; const name=props.name||'Estação sem nome';
                    const details=[]; if(props.operator)details.push(escapeHtml(props.operator)); if(props.lineHint)details.push('Linha: '+escapeHtml(props.lineHint));
                    new maplibregl.Popup({offset:10}).setLngLat(e.lngLat).setHTML('<div style="font:14px sans-serif;min-width:140px"><strong>'+escapeHtml(name)+'</strong>'+(details.length?'<br>'+details.join('<br>'):'')+'</div>').addTo(map);
                  });
                  map.on('mouseenter','rail-stations-layer',()=>map.getCanvas().style.cursor='pointer');
                  map.on('mouseleave','rail-stations-layer',()=>map.getCanvas().style.cursor='');
                }

                const linesToggle=document.getElementById('toggle-rail-lines');
                const stationsToggle=document.getElementById('toggle-rail-stations');
                if(linesToggle && map.getLayer('rail-routes-layer')) map.setLayoutProperty('rail-routes-layer','visibility',linesToggle.checked?'visible':'none');
                if(stationsToggle && map.getLayer('rail-stations-layer')) map.setLayoutProperty('rail-stations-layer','visibility',stationsToggle.checked?'visible':'none');
                function saveLayerPreferences(){
                  if(window.AndroidBridge && AndroidBridge.layerVisibilityChanged){
                    AndroidBridge.layerVisibilityChanged(linesToggle ? linesToggle.checked : ${showRailLinesInitially}, stationsToggle ? stationsToggle.checked : ${showRailStationsInitially});
                  }
                }
                if(linesToggle)linesToggle.addEventListener('change',()=>{if(map.getLayer('rail-routes-layer'))map.setLayoutProperty('rail-routes-layer','visibility',linesToggle.checked?'visible':'none');saveLayerPreferences();});
                if(stationsToggle)stationsToggle.addEventListener('change',()=>{if(map.getLayer('rail-stations-layer'))map.setLayoutProperty('rail-stations-layer','visibility',stationsToggle.checked?'visible':'none');saveLayerPreferences();});

                // Se não houver destinos/posição GPS, enquadra automaticamente a área coberta pelos dados ferroviários.
                if(boundsCoords.length===0){
                  const railBounds=new maplibregl.LngLatBounds(); let railPointCount=0;
                  validStations.forEach(f=>{railBounds.extend(f.geometry.coordinates);railPointCount++;});
                  validRailRoutes.forEach(f=>f.geometry.coordinates.forEach(c=>{railBounds.extend(c);railPointCount++;}));
                  if(railPointCount>0){if(railPointCount===1)map.jumpTo({center:railBounds.getCenter(),zoom:13});else map.fitBounds(railBounds,{padding:45,maxZoom:13});}
                }
                if(boundsCoords.length===1){const d=destinations.find(x=>Number(x.latitude)===boundsCoords[0][1]&&Number(x.longitude)===boundsCoords[0][0]);const radius=Math.max(1,Number(d?.radiusMeters)||300);const zoom=Math.max(10,Math.min(17,Math.log2(40075016/(radius*2))-1));map.jumpTo({center:boundsCoords[0],zoom});}
                else if(boundsCoords.length>1){const b=new maplibregl.LngLatBounds();boundsCoords.forEach(c=>b.extend(c));map.fitBounds(b,{padding:55,maxZoom:15});}
              });
            </script></body></html>
        """.trimIndent()
        webView.loadDataWithBaseURL("https://openfreemap.org/", html, "text/html", "UTF-8", null)
    }

    companion object {
        const val EXTRA_DESTINATIONS = "destinations_json"
        const val EXTRA_DESTINATION_IDS = "destination_ids"
        const val EXTRA_SELECT_POINT = "select_point"
        const val EXTRA_SELECTED_LAT = "selected_lat"
        const val EXTRA_SELECTED_LON = "selected_lon"
        const val PREF_SHOW_RAIL_LINES = "map_show_rail_lines"
        const val PREF_SHOW_RAIL_STATIONS = "map_show_rail_stations"
    }
}
