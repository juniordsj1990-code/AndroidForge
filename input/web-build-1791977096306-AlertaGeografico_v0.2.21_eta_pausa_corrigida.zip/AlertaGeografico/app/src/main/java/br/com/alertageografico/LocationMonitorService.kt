package br.com.alertageografico

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

/**
 * Monitora a posição e dispara alertas.
 *  - A decisão de alertar fica em [ProximityEngine] (testável).
 *  - O intervalo do GPS é definido pelo usuário e pode ser alterado durante o monitoramento.
 *  - O estado "ativo" é gravado em [DestinationStore] e o serviço é reiniciado pelo sistema (START_STICKY)
 *    caso seja encerrado para liberar memória.
 */
private fun formatEtaDuration(totalMinutes: Int): String {
    if (totalMinutes < 60) return "$totalMinutes min"
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return if (minutes == 0) "$hours h" else "$hours h $minutes min"
}

class LocationMonitorService : Service() {
    private lateinit var client: FusedLocationProviderClient
    private lateinit var callback: LocationCallback
    private val engine = ProximityEngine()
    private val etaEstimator = OfflineEtaEstimator()
    private var etaTargetId: String? = null
    private var destinations: List<Destination> = emptyList()
    private var updating = false
    private var currentRequestIntervalMs = -1L
    private var currentRequestPriority = -1
    private var lastLocationForPolicy: android.location.Location? = null
    private var stationaryUpdates = 0

    private val monitorChannelId = "geo_monitor"
    private val alertChannelId = "geo_alerts_routed"

    // Mantém referência forte: o SharedPreferences guarda o listener em WeakReference.
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            DestinationStore.KEY -> destinations = DestinationStore.load(this)
            DestinationStore.KEY_LOCATION_INTERVAL_SECONDS, DestinationStore.KEY_BATTERY_PROFILE -> {
                if (updating) {
                    try {
                        reconfigureLocationUpdates()
                    } catch (_: SecurityException) {
                        stopSelf()
                    }
                }
            }
        }
    }

    private fun dismissPendingIntent(notificationId: Int): PendingIntent {
        val intent = Intent(this, AlertDismissReceiver::class.java).putExtra("notification_id", notificationId)
        return PendingIntent.getBroadcast(
            this, notificationId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
        client = LocationServices.getFusedLocationProviderClient(this)
        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                if (result.locations.isEmpty()) return
                onLocations(result.locations)
            }
        }
        try {
            startForeground(1001, buildStatusNotification())
        } catch (e: Exception) {
            // Ex.: início em segundo plano não permitido após reinício pelo sistema.
            Log.w(TAG, "Não foi possível entrar em primeiro plano", e)
            DestinationStore.setMonitoringActive(this, false)
            stopSelf()
            return
        }
        destinations = DestinationStore.load(this)
        getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
            .registerOnSharedPreferenceChangeListener(prefsListener)
        DestinationStore.setMonitoringActive(this, true)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!updating) {
            try {
                reconfigureLocationUpdates(force = true)
            } catch (_: SecurityException) {
                DestinationStore.setMonitoringActive(this, false)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun requestUpdates(intervalMs: Long, highAccuracy: Boolean, force: Boolean = false) {
        val priority = if (highAccuracy) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        if (!force && updating && currentRequestIntervalMs == intervalMs && currentRequestPriority == priority) return
        if (updating) client.removeLocationUpdates(callback)
        val request = LocationRequest.Builder(priority, intervalMs)
            .setMinUpdateIntervalMillis(intervalMs)
            .setWaitForAccurateLocation(false)
            .build()
        client.requestLocationUpdates(request, callback, mainLooper)
        currentRequestIntervalMs = intervalMs
        currentRequestPriority = priority
        updating = true
    }

    /** Escolhe a frequência e a precisão conforme o perfil, movimento e proximidade do destino. */
    private fun reconfigureLocationUpdates(force: Boolean = false) {
        val configuredMs = DestinationStore.locationIntervalSeconds(this) * 1_000L
        val profile = DestinationStore.batteryProfile(this)
        val location = lastLocationForPolicy
        val activeTargets = when (DestinationStore.monitorMode(this)) {
            "route" -> destinations.filter { it.itineraryName == DestinationStore.activeItinerary(this) && it.enabled }
                .getOrNull(DestinationStore.itineraryIndex(this))?.let(::listOf).orEmpty()
            else -> destinations.filter { it.id == DestinationStore.selectedDestinationId(this) && it.enabled }
        }
        val nearTarget = location != null && activeTargets.any {
            ProximityEngine.distanceMeters(location.latitude, location.longitude, it.latitude, it.longitude) <= 1_000
        }
        val moving = location?.let { (it.hasSpeed() && it.speed >= 1.2f) || stationaryUpdates < 3 } ?: true

        val intervalMs: Long
        val highAccuracy: Boolean
        val railNavigationAvailable = StationNavigationStore.hasStations(this) && StationNavigationStore.hasRoutes(this)
        when (profile) {
            "precision" -> {
                // Durante navegação ferroviária, manter atualização responsiva mesmo se o
                // intervalo geral configurado for maior; fora disso, respeitar a preferência.
                intervalMs = if (railNavigationAvailable && moving) minOf(configuredMs, 5_000L) else configuredMs
                highAccuracy = true
            }
            "economy" -> {
                if (nearTarget) {
                    // Aumenta a responsividade ao se aproximar de uma parada.
                    intervalMs = minOf(configuredMs, 10_000L).coerceAtLeast(5_000L)
                    highAccuracy = true
                } else if (moving && railNavigationAvailable) {
                    intervalMs = minOf(configuredMs, 10_000L).coerceAtLeast(5_000L)
                    highAccuracy = true
                } else if (moving) {
                    intervalMs = maxOf(configuredMs, 20_000L)
                    highAccuracy = false
                } else {
                    intervalMs = maxOf(configuredMs, 120_000L)
                    highAccuracy = false
                }
            }
            else -> { // equilibrado
                if (nearTarget) {
                    intervalMs = minOf(configuredMs, 5_000L).coerceAtLeast(5_000L)
                    highAccuracy = true
                } else if (railNavigationAvailable && moving) {
                    intervalMs = minOf(configuredMs, 8_000L).coerceAtLeast(5_000L)
                    highAccuracy = true
                } else {
                    intervalMs = maxOf(configuredMs, 15_000L)
                    highAccuracy = false
                }
            }
        }
        requestUpdates(intervalMs, highAccuracy, force)
    }

    private fun onLocations(locations: List<android.location.Location>) {
        for (loc in locations) {
            val previousPolicyLocation = lastLocationForPolicy
            if (previousPolicyLocation != null && loc.accuracyOrDefault() <= 50f && previousPolicyLocation.accuracyOrDefault() <= 50f) {
                val movedMeters = ProximityEngine.distanceMeters(
                    previousPolicyLocation.latitude, previousPolicyLocation.longitude, loc.latitude, loc.longitude
                )
                if ((loc.hasSpeed() && loc.speed >= 1.2f) || movedMeters >= 30.0) stationaryUpdates = 0
                else if ((!loc.hasSpeed() || loc.speed < 0.8f) && movedMeters < 25.0) stationaryUpdates++
            }
            lastLocationForPolicy = loc
            DestinationStore.saveLastLocation(this, loc.latitude, loc.longitude)
            // A cada posição do monitoramento, reposiciona a sequência ferroviária a partir do GPS atual.
            // Assim, iniciar no meio do trajeto não depende de contar estações desde o início do serviço.
            val stationResult = runCatching { StationNavigationStore.locate(this, loc) }.getOrNull()
            DestinationStore.saveStationNavigation(this, stationResult)
            if (DestinationStore.snoozed(this)) engine.reset()
            val activeRoute = DestinationStore.activeItinerary(this)
            val monitored = when (DestinationStore.monitorMode(this)) {
                "route" -> {
                    val stops = destinations.filter { it.itineraryName == activeRoute && it.enabled }
                    listOfNotNull(stops.getOrNull(DestinationStore.itineraryIndex(this)))
                }
                else -> destinations.filter { it.id == DestinationStore.selectedDestinationId(this) && it.enabled }
            }
            val result = engine.process(
                Fix(loc.latitude, loc.longitude, if (loc.hasAccuracy()) loc.accuracy else 9999f, loc.time),
                monitored
            )
            if (!DestinationStore.snoozed(this)) {
                result.triggered.forEach { destination ->
                    alert(destination)
                    if (!activeRoute.isNullOrBlank() && destination.itineraryName == activeRoute) {
                        DestinationStore.setItineraryIndex(this, DestinationStore.itineraryIndex(this) + 1)
                        engine.reset()
                    }
                }
            }

            val target = monitored.firstOrNull()
            val railDistanceToTarget = target?.let {
                StationNavigationStore.distanceAlongRailMeters(this, loc.latitude, loc.longitude, it.latitude, it.longitude)
            }
            val etaEstimate = if (target != null) {
                if (etaTargetId != target.id) {
                    etaEstimator.reset()
                    etaTargetId = target.id
                }
                val straightDistance = ProximityEngine.distanceMeters(
                    loc.latitude, loc.longitude, target.latitude, target.longitude
                )
                val distanceForEta = railDistanceToTarget?.toDouble() ?: straightDistance
                // O raio é geográfico; não o subtraímos da distância medida ao longo dos trilhos.
                etaEstimator.update(loc, distanceForEta, if (railDistanceToTarget != null) 0 else target.radiusMeters)
            } else {
                etaEstimator.reset()
                etaTargetId = null
                null
            }

            // O alerta antecipado usa a velocidade filtrada. A lógica de proximidade permanece independente.
            if (!DestinationStore.snoozed(this)) {
                val leadMinutes = DestinationStore.etaAlertMinutes(this)
                val alertSpeed = etaEstimate
                    ?.takeIf { it.confidence == EtaConfidence.NORMAL }
                    ?.filteredSpeedMps
                if (leadMinutes > 0 && alertSpeed != null && alertSpeed >= 1.5) {
                    val route = DestinationStore.activeItinerary(this)
                    val candidates = if (route.isNullOrBlank()) monitored else monitored.filter { it.itineraryName == route }
                    candidates.forEach { d ->
                        val geographicDistance = ProximityEngine.distanceMeters(loc.latitude, loc.longitude, d.latitude, d.longitude)
                        val distance = if (d.id == target?.id && railDistanceToTarget != null) railDistanceToTarget.toDouble()
                            else geographicDistance
                        val etaSeconds = distance / alertSpeed
                        val key = "eta_alerted_${d.id}"
                        val prefs = getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
                        if (geographicDistance > d.radiusMeters && etaSeconds <= leadMinutes * 60 && !prefs.getBoolean(key, false)) {
                            prefs.edit().putBoolean(key, true).apply()
                            alert(d.copy(message = "Tempo estimado até ${d.name}: cerca de ${formatEtaDuration((etaSeconds / 60).toInt().coerceAtLeast(1))}"))
                        } else if (distance > leadMinutes * 60.0 * alertSpeed * 1.5) {
                            prefs.edit().putBoolean(key, false).apply()
                        }
                    }
                }
            }

            val routeMode = DestinationStore.monitorMode(this) == "route"
            val routeStops = if (routeMode) {
                destinations.filter { it.itineraryName == activeRoute && it.enabled }
            } else emptyList()
            val finalDestinationName = if (routeMode) {
                routeStops.lastOrNull()?.name ?: "Roteiro sem paradas ativas"
            } else target?.name ?: "Aguardando destino"
            // O índice aponta para a próxima parada ainda pendente. Não somar 1:
            // isso pulava a parada que o monitoramento está acompanhando no momento.
            val nextStopName = if (routeMode) {
                routeStops.getOrNull(DestinationStore.itineraryIndex(this))?.name
                    ?: if (routeStops.isNotEmpty()) "Roteiro concluído" else "Nenhuma parada disponível"
            } else "—"

            if (routeMode) {
                if (target != null && etaEstimate != null) {
                    val etaMin = etaEstimate.minMinutes
                    val etaMax = etaEstimate.maxMinutes
                    val etaMiddle = if (etaMin >= 0 && etaMax >= 0) (etaMin + etaMax) / 2 else -1
                    DestinationStore.saveDashboard(
                        this,
                        finalDestinationName,
                        nextStopName,
                        etaEstimate.distanceMeters,
                        etaMiddle,
                        etaMin,
                        etaMax,
                        etaEstimate.confidence.storageValue,
                        if (railDistanceToTarget != null) "rail" else "straight"
                    )
                } else {
                    // Continua mostrando o destino final mesmo quando todas as paradas foram concluídas.
                    DestinationStore.saveDashboard(
                        this, finalDestinationName, nextStopName, -1, -1, -1, -1, "unavailable"
                    )
                }
            } else if (target != null && etaEstimate != null) {
                val etaMin = etaEstimate.minMinutes
                val etaMax = etaEstimate.maxMinutes
                val etaMiddle = if (etaMin >= 0 && etaMax >= 0) (etaMin + etaMax) / 2 else -1
                DestinationStore.saveDashboard(
                    this,
                    target.name,
                    nextStopName,
                    etaEstimate.distanceMeters,
                    etaMiddle,
                    etaMin,
                    etaMax,
                    etaEstimate.confidence.storageValue,
                    if (railDistanceToTarget != null) "rail" else "straight"
                )
            }
            // Só altera a requisição quando o perfil realmente muda de faixa.
            try { reconfigureLocationUpdates() } catch (_: SecurityException) { stopSelf() }
        }
    }

    private fun android.location.Location.accuracyOrDefault(): Float = if (hasAccuracy()) accuracy else 9999f

    private fun alert(destination: Destination) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationId = destination.id.hashCode()
        val dismiss = dismissPendingIntent(notificationId)
        val snoozeIntent = Intent(this, AlertDismissReceiver::class.java).setAction(AlertDismissReceiver.ACTION_SNOOZE)
            .putExtra("notification_id", notificationId).putExtra("minutes", 5)
        val snooze = PendingIntent.getBroadcast(this, notificationId + 100000, snoozeIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = NotificationCompat.Builder(this, alertChannelId)
            .setSmallIcon(android.R.drawable.ic_dialog_map)
            .setContentTitle(destination.name)
            .setContentText(destination.message)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDeleteIntent(dismiss) // deslizar para dispensar também interrompe o som
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "OK", dismiss)
            .addAction(android.R.drawable.ic_lock_idle_alarm, "Soneca 5 min", snooze)
        manager.notify(notificationId, builder.build())

        // O toque é reproduzido separadamente para respeitar a saída escolhida pelo usuário.
        RoutedAlertSound.play(this)

        if (DestinationStore.vibrationEnabled(this)) {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(500)
            }
        }

        if (destination.oneShot) disableAfterAlert(destination.id)
    }

    /** Alerta único: desativa o destino. Relê a lista salva para não sobrescrever edições recentes. */
    private fun disableAfterAlert(id: String) {
        val latest = DestinationStore.load(this)
        val updated = latest.map { if (it.id == id) it.copy(enabled = false) else it }
        DestinationStore.save(this, updated)
        destinations = updated
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(monitorChannelId, "Monitoramento", NotificationManager.IMPORTANCE_LOW)
            )
            val alerts = NotificationChannel(alertChannelId, "Alertas de proximidade", NotificationManager.IMPORTANCE_HIGH)
            alerts.description = "Alertas sonoros direcionados conforme as preferências"
            // O som do canal fica desativado porque RoutedAlertSound reproduz o toque na saída escolhida.
            alerts.setSound(null, null)
            manager.createNotificationChannel(alerts)
        }
    }

    private fun buildStatusNotification(): Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val openApp = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, LocationMonitorService::class.java).setAction(ACTION_STOP), flags
        )
        return NotificationCompat.Builder(this, monitorChannelId)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Alerta Geográfico ativo")
            .setContentText("Monitorando destinos habilitados")
            .setOngoing(true)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar", stop)
            .build()
    }

    override fun onDestroy() {
        if (::client.isInitialized && ::callback.isInitialized) client.removeLocationUpdates(callback)
        getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
            .unregisterOnSharedPreferenceChangeListener(prefsListener)
        // Parada normal (usuário ou stopSelf): marca como inativo. Se o processo for morto pelo sistema,
        // onDestroy não roda, o flag continua verdadeiro e o START_STICKY reinicia o serviço.
        DestinationStore.setMonitoringActive(this, false)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "LocationMonitor"
        const val ACTION_STOP = "br.com.alertageografico.action.STOP"
    }
}
