package com.docfotopro.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
