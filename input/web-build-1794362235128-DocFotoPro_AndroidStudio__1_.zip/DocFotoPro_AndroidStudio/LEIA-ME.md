# DocFoto Pro — projeto para Android Studio (Capacitor 8)

O app é uma página web (`www/index.html`) dentro de um aplicativo Capacitor.
Plugins usados: Camera, Filesystem, Geolocation e Share.
Pacote: `com.docfotopro.app`. Os ícones e a tela de abertura são os do APK original.

## O que instalar (uma vez)
- Node.js 22 ou superior
- Android Studio Otter (2025.2.1) ou mais novo, com JDK 21 (já vem com ele)

## Passo a passo
1. Abra um terminal nesta pasta e rode:

       node scripts/setup.mjs

   O script instala as dependências, cria a pasta `android/`, copia ícone/splash,
   confere as permissões (câmera, localização, armazenamento) e sincroniza o `www/`.
2. No Android Studio: **File > Open** e escolha a pasta `android/`.
3. Aguarde o Gradle sincronizar e use **Run** (celular ligado) ou
   **Build > Build APK(s)**. Para publicar/instalar fora do Studio, use
   **Build > Generate Signed App Bundle / APK**.

## Depois de editar o app
Toda a interface está em `www/index.html`. Após editar, rode `npx cap sync android`
e gere o APK de novo.

## Observações
- O código nativo do APK original é o modelo padrão do Capacitor (MainActivity +
  plugins), por isso foi recriado em vez de copiado.
- O botão "Exportar ZIP" baixa a biblioteca JSZip da internet na hora do uso
  (comportamento original, não alterado).
- Para compilar pelo AndroidForge, rode o passo 1 e envie esta pasta inteira
  em .zip (com `android/` dentro).
