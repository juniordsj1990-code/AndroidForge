// Gera o projeto Android (pasta "android/") a partir do app web em "www/".
// Uso:  node scripts/setup.mjs        (ou: npm run setup)
import { execSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync, cpSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');

// Permissões que o APK original declarava
export const PERMISSOES = [
  'android.permission.INTERNET',
  'android.permission.ACCESS_NETWORK_STATE',
  'android.permission.CAMERA',
  'android.permission.ACCESS_FINE_LOCATION',
  'android.permission.ACCESS_COARSE_LOCATION',
  'android.permission.READ_MEDIA_IMAGES',
  'android.permission.READ_EXTERNAL_STORAGE',
  'android.permission.WRITE_EXTERNAL_STORAGE',
];
export const RECURSOS = [
  'android.hardware.camera',
  'android.hardware.location.gps',
];

export function patchManifest(xml) {
  let add = '';
  for (const p of PERMISSOES) {
    if (!xml.includes(`"${p}"`)) add += `    <uses-permission android:name="${p}" />\n`;
  }
  for (const f of RECURSOS) {
    if (!xml.includes(`"${f}"`)) add += `    <uses-feature android:name="${f}" android:required="false" />\n`;
  }
  if (!add) return xml;
  if (!xml.includes('</manifest>')) throw new Error('AndroidManifest.xml inesperado (sem </manifest>)');
  return xml.replace('</manifest>', `\n    <!-- DocFoto Pro: permissões do app original -->\n${add}</manifest>`);
}

function run(cmd) {
  console.log(`\n> ${cmd}`);
  execSync(cmd, { cwd: ROOT, stdio: 'inherit', shell: true });
}

function main() {
  const major = parseInt(process.versions.node.split('.')[0], 10);
  if (major < 22) {
    console.error(`Node ${process.versions.node} é antigo. O Capacitor 8 exige Node 22 ou superior (https://nodejs.org).`);
    process.exit(1);
  }

  run('npm install');

  if (!existsSync(join(ROOT, 'android'))) run('npx cap add android');
  else console.log('\nPasta "android" já existe — mantendo.');

  // ícone e tela de abertura originais
  cpSync(join(ROOT, 'resources', 'android-res'), join(ROOT, 'android', 'app', 'src', 'main', 'res'), { recursive: true });
  console.log('Ícones e splash do app copiados.');

  // permissões
  const mf = join(ROOT, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
  writeFileSync(mf, patchManifest(readFileSync(mf, 'utf8')));
  console.log('Permissões conferidas no AndroidManifest.xml.');

  run('npx cap sync android');

  console.log('\nPronto! Abra a pasta "android" no Android Studio (File > Open),');
  console.log('ou rode:  npx cap open android');
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) main();
