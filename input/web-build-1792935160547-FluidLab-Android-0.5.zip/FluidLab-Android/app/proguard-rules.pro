# Métodos expostos ao JavaScript pela ponte AndroidBridge não podem ser renomeados nem removidos.
-keepattributes *Annotation*
-keepclassmembers class com.fluidlab.android.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
