package com.fluidlab.android

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream

/**
 * Casca nativa do FluidLab: uma WebView que serve o simulador a partir dos assets, com
 * salvar/abrir pelo seletor de arquivos do sistema (SAF) e extensão própria ".fluidlab".
 */
class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private var pageReady = false
    private var pendingViewUri: Uri? = null
    private var pendingSaveJson: String? = null

    private val touchScript: String? by lazy {
        try {
            assets.open("android-touch.js").bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: IOException) {
            Log.w(TAG, "android-touch.js não encontrado", e)
            null
        }
    }

    // O MIME genérico faz o sistema respeitar a extensão do nome sugerido (sem anexar ".bin").
    private val saveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument(PROJECT_MIME)) { uri ->
            writePendingProject(uri)
        }

    // Extensão própria não tem MIME registrado, então o seletor precisa aceitar qualquer tipo.
    private val openLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) toast(R.string.open_cancelled) else readProject(uri)
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // DevTools só em build de debug.
        val debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        WebView.setWebContentsDebuggingEnabled(debuggable)

        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setOnLongClickListener { true }
        }
        setContentView(webView)

        webView.settings.apply {
            setJavaScriptEnabled(true)
            setDomStorageEnabled(true)
            setAllowFileAccess(false)
            setAllowContentAccess(false)
            setSupportZoom(false)
            setBuiltInZoomControls(false)
            setDisplayZoomControls(false)
            setUseWideViewPort(true)
            setLoadWithOverviewMode(false)
            setGeolocationEnabled(false)
            setCacheMode(WebSettings.LOAD_NO_CACHE)
            setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW)
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = AppClient(assetLoader)
        webView.addJavascriptInterface(AndroidBridge(), BRIDGE_NAME)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = confirmExit()
        })

        pendingViewUri = viewUriFrom(intent)
        webView.loadUrl(START_URL)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val uri = viewUriFrom(intent) ?: return
        pendingViewUri = uri
        if (pageReady) flushPendingView()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onDestroy() {
        webView.stopLoading()
        webView.removeJavascriptInterface(BRIDGE_NAME)
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }

    // --- WebView ----------------------------------------------------------------------------

    private inner class AppClient(private val loader: WebViewAssetLoader) : WebViewClient() {

        override fun shouldInterceptRequest(
            view: WebView?,
            request: WebResourceRequest?,
        ): WebResourceResponse? = request?.url?.let { loader.shouldInterceptRequest(it) }

        // O app não navega para fora do próprio conteúdo.
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
            request?.url?.toString()?.startsWith(ORIGIN) != true

        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            if (url == null || !url.startsWith(ORIGIN)) return
            touchScript?.let { webView.evaluateJavascript(it, null) }
            pageReady = true
            flushPendingView()
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?,
        ) {
            if (request?.isForMainFrame == true) {
                Log.e(TAG, "erro ao carregar a página: ${error?.description}")
                toast(R.string.load_error, long = true)
            }
        }
    }

    /** Ponte JS → nativo. Só responde enquanto a página exibida é a do próprio app. */
    private inner class AndroidBridge {

        @JavascriptInterface
        fun saveProject(json: String, suggestedName: String) {
            runOnUiThread {
                if (!isAppPage()) return@runOnUiThread
                if (json.length > MAX_PROJECT_BYTES) {
                    toast(R.string.save_too_large)
                    return@runOnUiThread
                }
                pendingSaveJson = json
                saveLauncher.launch(sanitizeFilename(suggestedName))
            }
        }

        @JavascriptInterface
        fun openProject() {
            runOnUiThread {
                if (!isAppPage()) return@runOnUiThread
                openLauncher.launch(arrayOf("*/*"))
            }
        }
    }

    private fun isAppPage(): Boolean = webView.url?.startsWith(ORIGIN) == true

    // --- Arquivos de projeto ----------------------------------------------------------------

    private fun writePendingProject(uri: Uri?) {
        val json = pendingSaveJson ?: return
        pendingSaveJson = null
        if (uri == null) {
            toast(R.string.save_cancelled)
            return
        }
        try {
            // "wt" trunca: no modo padrão ("w") alguns provedores mantêm o resto de um arquivo
            // maior e o JSON fica corrompido ao sobrescrever.
            val out = contentResolver.openOutputStream(uri, "wt")
                ?: throw IOException("openOutputStream retornou null")
            out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            toast(R.string.saved)
        } catch (e: Exception) {
            Log.e(TAG, "falha ao salvar o projeto", e)
            toast(R.string.save_failed, long = true)
        }
    }

    private fun readProject(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri) ?: throw IOException("openInputStream retornou null")
            val bytes = input.use { readLimited(it, MAX_PROJECT_BYTES) }
            val json = String(bytes, Charsets.UTF_8).removePrefix("\uFEFF")
            val name = displayName(uri) ?: DEFAULT_NAME
            webView.evaluateJavascript(
                "window.FluidLabAndroidOpen(${JSONObject.quote(json)}, ${JSONObject.quote(name)})",
                null,
            )
        } catch (e: FileTooLargeException) {
            toast(R.string.open_too_large, long = true)
        } catch (e: Exception) {
            Log.e(TAG, "falha ao abrir o projeto", e)
            toast(R.string.open_failed, long = true)
        }
    }

    private fun flushPendingView() {
        val uri = pendingViewUri ?: return
        pendingViewUri = null
        readProject(uri)
    }

    private fun viewUriFrom(intent: Intent?): Uri? =
        if (intent?.action == Intent.ACTION_VIEW) intent.data else null

    private fun displayName(uri: Uri): String? {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val name = c.getString(0)
                    if (!name.isNullOrBlank()) return name
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "não foi possível ler o nome do arquivo", e)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private class FileTooLargeException : IOException("Arquivo grande demais")

    private fun readLimited(input: InputStream, max: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            total += n
            if (total > max) throw FileTooLargeException()
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }

    /** Remove caracteres inválidos e garante a extensão .fluidlab (aceita .json antigo). */
    private fun sanitizeFilename(raw: String): String {
        var name = raw.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim()
        name = name.replace(Regex("\\.(fluidlab|json)$", RegexOption.IGNORE_CASE), "").trim()
        if (name.isEmpty()) name = "Esquema"
        if (name.length > 80) name = name.substring(0, 80).trim()
        return name + PROJECT_EXT
    }

    // --- Interface --------------------------------------------------------------------------

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setTitle(R.string.exit_title)
            .setMessage(R.string.exit_message)
            .setPositiveButton(R.string.exit_yes) { _, _ -> finish() }
            .setNegativeButton(R.string.exit_no, null)
            .show()
    }

    private fun toast(@StringRes id: Int, long: Boolean = false) {
        Toast.makeText(this, id, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val TAG = "FluidLab"
        const val BRIDGE_NAME = "AndroidBridge"
        const val ORIGIN = "https://appassets.androidplatform.net/"
        const val START_URL = ORIGIN + "assets/fluidlab/index.html"
        const val PROJECT_EXT = ".fluidlab"
        const val PROJECT_MIME = "application/octet-stream"
        const val DEFAULT_NAME = "Esquema" + PROJECT_EXT
        const val MAX_PROJECT_BYTES = 20 * 1024 * 1024
    }
}
