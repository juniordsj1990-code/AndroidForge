(() => {
  'use strict';

  // The native side injects this on every page load; without a guard a reload would stack
  // a second set of listeners and apply every pinch twice.
  if (window.__fluidLabTouchBridge) return;
  window.__fluidLabTouchBridge = true;

  // FluidLab Android touch bridge.
  // The desktop FluidLab already uses Pointer Events. This bridge deliberately
  // leaves one-finger pointer events intact and only adds mobile viewport rules
  // plus two-finger pan/pinch behavior.

  const active = new Map();
  let lastDistance = 0;
  let lastCenter = null;
  let gestureTarget = null;

  const root = document.documentElement;
  const body = document.body;
  root.style.touchAction = 'none';
  body.style.touchAction = 'none';
  body.style.overscrollBehavior = 'none';
  body.style.webkitUserSelect = 'none';
  body.style.userSelect = 'none';
  body.style.webkitTouchCallout = 'none';

  const centerAndDistance = () => {
    const pts = [...active.values()];
    if (pts.length < 2) return null;
    const a = pts[0], b = pts[1];
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    return {
      distance: Math.hypot(dx, dy),
      center: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }
    };
  };

  const sendWheel = (target, dx, dy, ctrlKey) => {
    if (!target) return;
    target.dispatchEvent(new WheelEvent('wheel', {
      deltaX: dx,
      deltaY: dy,
      deltaMode: WheelEvent.DOM_DELTA_PIXEL,
      ctrlKey: !!ctrlKey,
      bubbles: true,
      cancelable: true,
      clientX: lastCenter?.x || 0,
      clientY: lastCenter?.y || 0
    }));
  };

  document.addEventListener('pointerdown', e => {
    if (e.pointerType !== 'touch') return;
    active.set(e.pointerId, { x: e.clientX, y: e.clientY });
    gestureTarget = e.target;

    try {
      if (e.target?.setPointerCapture) e.target.setPointerCapture(e.pointerId);
    } catch (_) {}

    if (active.size === 2) {
      const g = centerAndDistance();
      lastDistance = g?.distance || 0;
      lastCenter = g?.center || null;
    }
  }, { capture: true, passive: false });

  document.addEventListener('pointermove', e => {
    if (e.pointerType !== 'touch' || !active.has(e.pointerId)) return;
    active.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (active.size < 2) return;
    e.preventDefault();

    const g = centerAndDistance();
    if (!g) return;

    if (lastDistance > 0) {
      const scale = g.distance / lastDistance;
      const delta = Math.log(Math.max(0.2, Math.min(5, scale))) * -420;
      sendWheel(gestureTarget, 0, delta, true);
    }

    if (lastCenter) {
      sendWheel(
        gestureTarget,
        (lastCenter.x - g.center.x) * 1.35,
        (lastCenter.y - g.center.y) * 1.35,
        false
      );
    }

    lastDistance = g.distance;
    lastCenter = g.center;
  }, { capture: true, passive: false });

  const end = e => {
    if (e.pointerType !== 'touch') return;
    active.delete(e.pointerId);

    try {
      if (e.target?.releasePointerCapture && e.target.hasPointerCapture(e.pointerId)) {
        e.target.releasePointerCapture(e.pointerId);
      }
    } catch (_) {}

    if (active.size < 2) {
      lastDistance = 0;
      lastCenter = null;
      gestureTarget = null;
    }
  };

  document.addEventListener('pointerup', end, { capture: true, passive: false });
  document.addEventListener('pointercancel', end, { capture: true, passive: false });

  document.addEventListener('contextmenu', e => e.preventDefault(), { capture: true });

  let meta = document.querySelector('meta[name="viewport"]');
  if (!meta) {
    meta = document.createElement('meta');
    meta.name = 'viewport';
    document.head.appendChild(meta);
  }
  meta.content = 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover';
})();
