// Correctness gate — untrusted project files and HTML output.
//
// A .fluidlab/.json file can come from anywhere. These tests assert two things: that the
// loader coerces every field to the type the model expects, and that no template which ends
// up in innerHTML interpolates user-controlled text without escaping it.
//
// Run headless:  node tests/run.js

import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Circuit, LIMITS } from '../src/circuit.js';
import { Grafcet } from '../src/grafcet.js';
import { esc } from '../src/symbols.js';

export const tests = [];
const test = (name, fn) => tests.push({ name, fn });
const assert = (cond, msg) => { if (!cond) throw new Error(msg); };

const here = dirname(fileURLToPath(import.meta.url));
const PAYLOAD = '"><img src=x onerror=alert(1)>';

test('Segurança: esc() neutraliza aspas, apóstrofo e colchetes', () => {
  const out = esc(`${PAYLOAD}'&`);
  assert(!/[<>"']/.test(out), `caracteres perigosos sobraram: ${out}`);
  assert(out.includes('&amp;'), '& precisa virar &amp;');
  assert(esc(null) === '' && esc(undefined) === '', 'null/undefined viram texto vazio');
  return { saida: out };
});

test('Segurança: Circuit.fromJSON converte cada campo para o tipo esperado', () => {
  const c = Circuit.fromJSON({
    instances: [
      null, 'lixo', { type: 'inexistente', x: 1 },
      {
        id: 'a', type: 'cyl_double', x: 'abc', y: Infinity, rot: 1e9,
        params: {
          tag: PAYLOAD.repeat(20), bore: 'não é número', stroke: 1e9,
          __proto__: { x: 1 }, desconhecido: 'x',
        },
        faults: { 'a b': true, ok_1: true, ruim: 'sim', [`x${'y'.repeat(40)}`]: true },
      },
    ],
    wires: [null, {}, { from: {}, to: null }],
  });
  assert(c.instances.length === 1, `esperava 1 instância válida, veio ${c.instances.length}`);
  const i = c.instances[0];
  assert(i.x === 0 && i.y === 0, 'coordenadas não numéricas devem virar 0');
  assert([0, 90, 180, 270].includes(i.rot), `rotação fora de 0/90/180/270: ${i.rot}`);
  assert(typeof i.params.tag.value === 'string' && i.params.tag.value.length <= LIMITS.text,
    'texto precisa ser string e respeitar o limite');
  assert(i.params.bore.value !== 'não é número', 'range não pode aceitar texto');
  assert(i.params.stroke.value <= i.params.stroke.max, 'range precisa respeitar o máximo');
  assert(!('desconhecido' in i.params), 'parâmetro desconhecido não pode entrar');
  assert(Object.keys(i.faults).length === 1 && i.faults.ok_1 === true, 'só falhas booleanas com chave válida');
  return { instancias: c.instances.length, tag_len: i.params.tag.value.length };
});

test('Segurança: limites de tamanho e entrada inválida', () => {
  const many = Array.from({ length: LIMITS.instances + 500 }, (_, k) => ({ id: k, type: 'supply', x: k, y: 0 }));
  const c = Circuit.fromJSON({ instances: many });
  assert(c.instances.length === LIMITS.instances, `limite de instâncias não aplicado: ${c.instances.length}`);
  for (const bad of [null, 42, 'texto']) {
    let threw = false;
    try { Circuit.fromJSON(bad); } catch { threw = true; }
    assert(threw, `fromJSON(${JSON.stringify(bad)}) deveria rejeitar`);
  }
  return { limite: LIMITS.instances };
});

test('Segurança: Grafcet.fromJSON limpa nomes, ações e condições', () => {
  const g = Grafcet.fromJSON({
    steps: [
      null,
      { id: 's1', name: PAYLOAD.repeat(10), initial: 'sim', x: 'a', y: NaN,
        actions: [null, { kind: 'xyz', target: PAYLOAD, value: 'talvez' }, { kind: 'stored', target: 'M1', value: false }] },
    ],
    transitions: [{ from: ['s1', 'fantasma'], to: ['s1'], receptivity: 5, x: {}, y: [] }, 7],
  });
  const s = [...g.steps.values()][0];
  assert(s.name.length <= 32, `nome da etapa passou do limite: ${s.name.length}`);
  assert(s.initial === false, '"initial" só aceita true booleano');
  assert(s.x === 0 && s.y === 0, 'coordenadas inválidas devem virar 0');
  assert(s.actions.length === 2, `ações inválidas deveriam sair: ${s.actions.length}`);
  assert(s.actions[0].kind === 'continuous' && !('value' in s.actions[0]), 'tipo desconhecido vira contínuo, sem value');
  assert(s.actions[1].kind === 'stored' && s.actions[1].value === false, 'ação armazenada válida precisa ficar intacta');
  const t = [...g.transitions.values()][0];
  assert(typeof t.receptivity === 'string', 'receptividade precisa ser texto');
  assert(t.from.length === 1, 'referência a etapa inexistente deve cair');
  return { etapa: s.name.length, acoes: s.actions.length };
});

test('Segurança: nenhum template HTML interpola texto do usuário sem esc()', () => {
  // Expressions that carry text a project file can control.
  const risky = /(tag\??\.value|probe\.label|\bch\.label|\bit\.text|\bi\.text|\br\.spec|\br\.tags|\bs\.name|\ba\.target|\bp\.value ?\?\?|\bt\.receptivity|steps\.get\([^)]*\)\??\.name|\bact\.join)/;
  // Lines that write through textContent/toast/SVG <title> are not HTML sinks.
  const exempt = /toast\(|textContent|\.title\b|out\.push\(|issues\.push\(|\blabel\.|querySelector|dataset|\.map\(\(\[?[a-z]+\]?\) => \[|Set\(|Map\(|\.get\(/;
  const bad = [];
  for (const file of ['main.js', 'diagram.js', 'scope.js', 'partslist.js', 'panels.js']) {
    const lines = readFileSync(join(here, '..', 'src', file), 'utf8').split('\n');
    lines.forEach((line, n) => {
      if (exempt.test(line)) return;
      for (const m of line.matchAll(/\$\{([^}]*)\}/g)) {
        if (risky.test(m[1]) && !/esc\(/.test(m[1])) bad.push(`${file}:${n + 1}  ${line.trim().slice(0, 90)}`);
      }
    });
  }
  assert(bad.length === 0, `interpolação sem escape:\n  ${bad.join('\n  ')}`);
  return { arquivos: 5, violacoes: 0 };
});
