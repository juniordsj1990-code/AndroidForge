# Avisos e licenças

**FluidLab** — © Alexander Hahn, licenciado sob **PolyForm Noncommercial 1.0.0**
(`web/fluidlab/LICENSE`). Uso comercial (serviço pago, produto, ferramenta de empresa com fins
lucrativos) exige licença do autor. A tradução para português e a casca Android são obras derivadas
e herdam essa restrição.

**Fontes embutidas** — Inter (© The Inter Project Authors) e JetBrains Mono (© The JetBrains Mono
Project Authors), SIL Open Font License 1.1: `web/fluidlab/fonts/LICENSE-*.txt`.

**Bibliotecas Android** — AndroidX (core-ktx, activity-ktx, webkit), Apache License 2.0.
