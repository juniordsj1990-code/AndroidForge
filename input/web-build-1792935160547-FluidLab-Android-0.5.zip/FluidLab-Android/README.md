# FluidLab Android 0.5

Projeto Android Studio (Kotlin) que embute o simulador **FluidLab** (pneumática, eletropneumática,
hidráulica, eletrônica, GRAFCET e CLP) numa WebView, 100% offline e sem permissões.

## Abrir e rodar

1. Android Studio **Ladybug (2024.2.1)** ou mais novo, JDK 17.
2. *File → Open* nesta pasta e aguarde o sync do Gradle (usa o wrapper 8.9; precisa de internet na primeira vez).
3. Rode no dispositivo ou emulador (minSdk 26, targetSdk 35). A tela fica em paisagem.

## Gerar release assinado

Copie `keystore.properties.example` para `keystore.properties`, preencha e rode
`./gradlew assembleRelease` (APK) ou `./gradlew bundleRelease` (AAB). Sem esse arquivo o release sai sem assinatura.
O release usa R8 e `debuggable=false`; o DevTools da WebView só liga em build de debug.

## Arquivo de projeto: `.fluidlab`

Salvar usa o seletor do sistema (SAF) e grava `Nome.fluidlab` (conteúdo JSON). Abrir aceita `.fluidlab`
e os `.json` antigos. Tocar num `.fluidlab` no gerenciador de arquivos oferece abrir no FluidLab
(depende do gerenciador respeitar os filtros de caminho do manifest).
O salvamento usa o modo `wt` (trunca), então sobrescrever um projeto maior por um menor não corrompe o arquivo.

## Estrutura

```
web/fluidlab/        simulador (HTML/JS/CSS, fontes locais, testes e docs)
web/android-touch.js ponte de toque: pinça e arrasto com dois dedos
app/                 casca Kotlin: MainActivity, manifest, recursos
```

Só o que o app executa vai para o APK: a tarefa `stageWebAssets<Variante>` copia `web/` sem
`tests/`, `docs/`, `*.md`, `serve.py` e `package.json`.

## Testes do simulador

```
cd web/fluidlab
node tests/run.js        # 97 testes (inclui tests/gate-security.js)
```

## O que mudou em relação à 0.4

- Tradução completa para português (mensagens do parser ST, GRAFCET, I/O, interface) e testes atualizados.
- Texto vindo do arquivo de projeto passa por `esc()` antes de ir ao HTML; `fromJSON` valida tipos e tamanhos.
  Um teste varre os templates e falha se surgir interpolação sem escape.
- Fontes Inter e JetBrains Mono embutidas (o app não tem permissão de internet).
- Ponte de toque idempotente; WebView sem acesso a `file://`/`content://`, sem navegação externa,
  e a ponte JS só responde na página do app.
- Back pede confirmação para sair; limite de 20 MB ao abrir; erros são registrados no logcat.

Veja `NOTICE.md` sobre a licença do FluidLab antes de qualquer uso comercial.
