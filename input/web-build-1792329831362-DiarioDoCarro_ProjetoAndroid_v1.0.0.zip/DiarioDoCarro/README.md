# Diário do Carro — projeto Android inicial

Projeto Kotlin + Jetpack Compose com tema escuro, ícone vetorial, tela de abertura nativa e histórico local SQLite.

Inclui:
- Cadastro de manutenções, defeitos/diagnósticos, peças, documentos/fotos, modificações e lembretes.
- Histórico com pesquisa e exclusão de registros.
- Quilometragem como referência técnica, sem controle de abastecimento.
- Interface em grafite e laranja.

## Abrir
Extraia o ZIP e abra a pasta `DiarioDoCarro` no Android Studio. Aguarde a sincronização do Gradle e execute em dispositivo ou emulador.
Requer Android Studio com suporte a Android Gradle Plugin 8.11.1 e Gradle 8.13.

## Próximas melhorias
Esta é uma base inicial. Notificações programadas, seleção real de fotos/arquivos, backup/restauração, edição de registros e persistência da ficha do veículo ainda precisam ser implementadas.
