package br.com.diariodocarro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0C0E)
private val Panel = Color(0xFF17191D)
private val Orange = Color(0xFFFF7900)
private val Muted = Color(0xFF9A9DA3)
private val categories = listOf("Manutenção preventiva", "Defeito / diagnóstico", "Peça / componente", "Documento / foto", "Modificação", "Lembrete")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent { DiaryApp(CarDatabase(this)) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiaryApp(db: CarDatabase) {
    var tab by remember { mutableStateOf("Início") }
    var records by remember { mutableStateOf(db.all()) }
    var showNew by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf(categories[0]) }
    var search by remember { mutableStateOf("") }
    var carName by remember { mutableStateOf("Meu veículo") }
    var km by remember { mutableStateOf("") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Orange, onPrimary = Color.Black, background = Bg, surface = Panel, onSurface = Color.White, secondary = Orange)) {
        Scaffold(
            containerColor = Bg,
            topBar = { TopAppBar(title = { Column { Text("DIÁRIO DO CARRO", fontWeight = FontWeight.Bold, fontSize = 17.sp); Text("Seu veículo, sua história.", color = Muted, fontSize = 11.sp) } }, actions = { IconButton(onClick = { showNew = true }) { Icon(Icons.Default.Add, "Novo registro", tint = Orange) } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg, titleContentColor = Color.White)) },
            bottomBar = { NavigationBar(containerColor = Panel) {
                listOf("Início", "Histórico", "Manutenção", "Arquivos", "Mais").forEach { t ->
                    val ico = when(t) { "Início" -> Icons.Default.Home; "Histórico" -> Icons.Default.History; "Manutenção" -> Icons.Default.Build; "Arquivos" -> Icons.Default.Folder; else -> Icons.Default.MoreHoriz }
                    NavigationBarItem(selected = tab == t, onClick = { tab = t }, icon = { Icon(ico, t) }, label = { Text(t, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Orange, selectedTextColor = Orange, indicatorColor = Color(0xFF3A2415)))
                }
            } },
            floatingActionButton = { FloatingActionButton(onClick = { showNew = true }, containerColor = Orange, contentColor = Color.Black) { Icon(Icons.Default.Add, "Registrar") } }
        ) { pad ->
            when(tab) {
                "Início" -> Home(Modifier.padding(pad), carName, { carName = it }, km, { km = it }, records, { tab = "Histórico" }, { showNew = true })
                "Histórico" -> RecordList(Modifier.padding(pad), records, search, { search = it }, { id -> db.delete(id); records = db.all() })
                "Manutenção" -> RecordList(Modifier.padding(pad), records.filter { it.category == categories[0] || it.category == categories[2] || it.category == categories[5] }, search, { search = it }, { id -> db.delete(id); records = db.all() })
                "Arquivos" -> RecordList(Modifier.padding(pad), records.filter { it.category == categories[3] }, search, { search = it }, { id -> db.delete(id); records = db.all() })
                else -> More(Modifier.padding(pad), carName, { carName = it }, km, { km = it })
            }
            if(showNew) NewRecord(category, { category = it }, { showNew = false }, { r -> db.add(r); records = db.all(); showNew = false })
        }
    }
}

@Composable
private fun Home(modifier: Modifier, name: String, onName: (String)->Unit, km: String, onKm: (String)->Unit, records: List<CarRecord>, onHistory: ()->Unit, onNew: ()->Unit) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("VEÍCULO", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(name, onName, label = { Text("Nome / modelo") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(km, onKm, label = { Text("Quilometragem atual (km)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("A quilometragem serve para o histórico e os lembretes, sem controle de abastecimento.", color = Muted, fontSize = 11.sp)
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Summary("Registros", records.size.toString(), Icons.Default.History, Modifier.weight(1f)); Summary("Lembretes", records.count { it.category == categories[5] }.toString(), Icons.Default.Notifications, Modifier.weight(1f)) } }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Últimos registros", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); TextButton(onClick = onHistory) { Text("Ver todos", color = Orange) } } }
        if(records.isEmpty()) item { Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Book, null, tint = Orange, modifier = Modifier.size(38.dp)); Spacer(Modifier.height(8.dp)); Text("Seu diário começa aqui", fontWeight = FontWeight.SemiBold); Text("Registre uma manutenção, defeito ou peça.", color = Muted); Button(onClick = onNew, colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) { Text("Criar registro") } } } }
        else items(records.take(5), key = { it.id }) { RecordCard(it) {} }
    }
}

@Composable
private fun Summary(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(icon, null, tint = Orange); Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 12.sp) } }
}

@Composable
private fun RecordList(modifier: Modifier, records: List<CarRecord>, search: String, onSearch: (String)->Unit, onDelete: (Long)->Unit) {
    val filtered = records.filter { it.title.contains(search, true) || it.details.contains(search, true) || it.category.contains(search, true) }
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(search, onSearch, modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), singleLine = true, label = { Text("Buscar no histórico") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        if(filtered.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nenhum registro encontrado", color = Muted) }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) { items(filtered, key = { it.id }) { r -> RecordCard(r) { onDelete(r.id) } } }
    }
}

@Composable
private fun RecordCard(r: CarRecord, onDelete: ()->Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.size(42.dp).background(Color(0xFF332114), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(when(r.category) { categories[0] -> Icons.Default.Build; categories[1] -> Icons.Default.Warning; categories[2] -> Icons.Default.Settings; categories[3] -> Icons.Default.Description; categories[4] -> Icons.Default.DirectionsCar; else -> Icons.Default.Notifications }, null, tint = Orange) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(r.title, fontWeight = FontWeight.SemiBold); Text(r.category, color = Orange, fontSize = 11.sp)
                Text("${r.date}${if(r.mileage.isNotBlank()) " • ${r.mileage} km" else ""}", color = Muted, fontSize = 12.sp)
                if(r.details.isNotBlank()) Text(r.details, color = Color(0xFFD0D2D5), fontSize = 13.sp, maxLines = 4)
                if(r.reminderDate.isNotBlank() || r.reminderKm.isNotBlank()) Text("Lembrete: ${r.reminderDate.ifBlank { "sem data" }}${if(r.reminderKm.isNotBlank()) " • ${r.reminderKm} km" else ""}", color = Orange, fontSize = 11.sp)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, "Excluir", tint = Muted) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewRecord(category: String, onCategory: (String)->Unit, onDismiss: ()->Unit, onSave: (CarRecord)->Unit) {
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale("pt", "BR")).format(java.util.Date())) }
    var km by remember { mutableStateOf("") }; var details by remember { mutableStateOf("") }
    var reminderDate by remember { mutableStateOf("") }; var reminderKm by remember { mutableStateOf("") }; var expanded by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Novo registro") }, text = {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 500.dp)) {
            item { ExposedDropdownMenuBox(expanded, { expanded = it }) {
                OutlinedTextField(category, {}, readOnly = true, label = { Text("Categoria") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded, { expanded = false }) { categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { onCategory(c); expanded = false }) } }
            } }
            item { OutlinedTextField(title, { title = it }, label = { Text("Título / serviço") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(date, { date = it }, label = { Text("Data (dd/mm/aaaa)") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(km, { km = it }, label = { Text("Quilometragem (opcional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(details, { details = it }, label = { Text("Detalhes, sintomas, peças, solução...") }, minLines = 3, modifier = Modifier.fillMaxWidth()) }
            item { Text("Lembrete opcional", color = Orange, fontWeight = FontWeight.SemiBold) }
            item { OutlinedTextField(reminderDate, { reminderDate = it }, label = { Text("Data do lembrete") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(reminderKm, { reminderKm = it }, label = { Text("Quilometragem do lembrete") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth()) }
        }
    }, confirmButton = { Button(enabled = title.isNotBlank(), onClick = { onSave(CarRecord(category=category, title=title.trim(), date=date.trim(), mileage=km.trim(), details=details.trim(), reminderDate=reminderDate.trim(), reminderKm=reminderKm.trim())) }, colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) { Text("Salvar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }, containerColor = Panel)
}

@Composable
private fun More(modifier: Modifier, name: String, onName: (String)->Unit, km: String, onKm: (String)->Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Mais opções", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item { Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { Text("Ficha do veículo", fontWeight = FontWeight.Bold, color = Orange); OutlinedTextField(name, onName, label = { Text("Nome / modelo") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(km, onKm, label = { Text("Quilometragem atual") }, modifier = Modifier.fillMaxWidth()) } } }
        item { Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp)) { Text("Sobre o Diário do Carro", fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text("Um diário técnico para preservar a história do veículo: manutenções, defeitos, peças, documentos e modificações.", color = Muted); Spacer(Modifier.height(8.dp)); Text("Versão 1.0.0 • Funciona offline", color = Orange, fontSize = 12.sp) } } }
    }
}
