package br.com.diariodocarro

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class CarRecord(val id: Long = 0, val category: String, val title: String, val date: String, val mileage: String, val details: String, val reminderDate: String = "", val reminderKm: String = "")

class CarDatabase(context: Context) : SQLiteOpenHelper(context, "diario_do_carro.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE records (id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, title TEXT NOT NULL, date TEXT NOT NULL, mileage TEXT NOT NULL DEFAULT '', details TEXT NOT NULL DEFAULT '', reminderDate TEXT NOT NULL DEFAULT '', reminderKm TEXT NOT NULL DEFAULT '')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(r: CarRecord) {
        val v = ContentValues().apply {
            put("category", r.category); put("title", r.title); put("date", r.date)
            put("mileage", r.mileage); put("details", r.details)
            put("reminderDate", r.reminderDate); put("reminderKm", r.reminderKm)
        }
        writableDatabase.insert("records", null, v)
    }
    fun all(): List<CarRecord> {
        val out = mutableListOf<CarRecord>()
        readableDatabase.rawQuery("SELECT id,category,title,date,mileage,details,reminderDate,reminderKm FROM records ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out += CarRecord(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getString(6), c.getString(7))
        }
        return out
    }
    fun delete(id: Long) { writableDatabase.delete("records", "id=?", arrayOf(id.toString())) }
}
