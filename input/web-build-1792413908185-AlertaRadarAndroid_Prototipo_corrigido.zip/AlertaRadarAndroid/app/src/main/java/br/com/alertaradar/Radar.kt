package br.com.alertaradar

import android.content.Context
import org.json.JSONObject

data class Radar(
    val id: String,
    val lat: Double,
    val lon: Double,
    val type: String = "Radar",
    val speedLimit: Int? = null,
    val road: String = "",
    val direction: Double? = null
)

object RadarRepository {
    fun load(context: Context): List<Radar> {
        val raw = context.assets.open("radares.json").bufferedReader().use { it.readText() }
        val root = JSONObject(raw)
        val arr = root.optJSONArray("radars") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val lat = o.optDouble("lat", Double.NaN)
            val lon = o.optDouble("lon", Double.NaN)
            if (!lat.isFinite() || !lon.isFinite() || lat !in -90.0..90.0 || lon !in -180.0..180.0) return@mapNotNull null
            Radar(
                id = o.optString("id", "radar-$i"),
                lat = lat, lon = lon,
                type = o.optString("type", "Radar"),
                speedLimit = if (o.has("speedLimit") && !o.isNull("speedLimit")) o.optInt("speedLimit") else null,
                road = o.optString("road", ""),
                direction = if (o.has("direction") && !o.isNull("direction")) o.optDouble("direction") else null
            )
        }
    }
}
