package br.com.alertaradar

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RadarScreen() }
    }

    @Composable
    private fun RadarScreen() {
        var running by remember { mutableStateOf(false) }
        var floating by remember { mutableStateOf(false) }
        var voice by remember { mutableStateOf(true) }
        var distance by remember { mutableFloatStateOf(500f) }
        val radarCount = remember { RadarRepository.load(this).size }

        MaterialTheme(colorScheme = darkColorScheme()) {
            Surface(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Text("ALERTA RADAR", style = MaterialTheme.typography.headlineMedium)
                    Text("Monitor independente • sem roteirizador", color = MaterialTheme.colorScheme.secondary)
                    Card {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(if (running) "Monitoramento ativo" else "Monitoramento parado", style = MaterialTheme.typography.titleLarge)
                            Text("Base local: $radarCount radares")
                            Text("A base oficial do DER-SP ainda precisa ser importada. Este protótipo não contém coordenadas reais pré-carregadas.")
                            Button(
                                onClick = { if (running) stopMonitor() else startMonitor(distance, voice, floating); running = !running },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(if (running) "Parar monitoramento" else "Iniciar monitoramento") }
                        }
                    }
                    Text("Distância do alerta: ${distance.toInt()} m", style = MaterialTheme.typography.titleMedium)
                    Slider(value = distance, onValueChange = { distance = it }, valueRange = 200f..1500f, steps = 12)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1)) {
                            Text("Alertas por voz", style = MaterialTheme.typography.titleMedium)
                            Text("Anuncia distância e limite quando disponível", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = voice, onCheckedChange = { voice = it })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1)) {
                            Text("Janela flutuante", style = MaterialTheme.typography.titleMedium)
                            Text("Exibe aviso sobre outros aplicativos", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = floating, onCheckedChange = {
                            floating = it
                            if (it && !Settings.canDrawOverlays(this@MainActivity)) {
                                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                            }
                        })
                    }
                    OutlinedButton(onClick = {
                        locationPermission.launch(buildList {
                            add(Manifest.permission.ACCESS_FINE_LOCATION)
                            add(Manifest.permission.ACCESS_COARSE_LOCATION)
                            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
                        }.toTypedArray())
                    }, modifier = Modifier.fillMaxWidth()) { Text("Conceder permissões de localização") }
                    OutlinedButton(onClick = {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://dadosabertos.sp.gov.br/dataset/radar")))
                    }, modifier = Modifier.fillMaxWidth()) { Text("Abrir fonte oficial de radares DER-SP") }
                    Text("Protótipo técnico: teste em local seguro, com o veículo parado. A precisão depende da base e do GPS.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                }
            }
        }
    }

    private fun startMonitor(distance: Float, voice: Boolean, floating: Boolean) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            return
        }
        val intent = Intent(this, RadarMonitorService::class.java)
            .putExtra("distance", distance).putExtra("voice", voice).putExtra("floating", floating)
        ContextCompat.startForegroundService(this, intent)
    }
    private fun stopMonitor() {
        stopService(Intent(this, RadarMonitorService::class.java))
        stopService(Intent(this, FloatingAlertService::class.java))
    }
}
