package br.com.alertaradar

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import java.util.Locale
import kotlin.math.*

class RadarMonitorService : Service(), TextToSpeech.OnInitListener {
    private lateinit var fused: FusedLocationProviderClient
    private var tts: TextToSpeech? = null
    private var radars: List<Radar> = emptyList()
    private var lastAlertId: String? = null
    private var lastAlertAt = 0L
    private var alertDistance = 500f
    private var voiceEnabled = true
    private var floatingEnabled = true

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val location = result.lastLocation ?: return
            checkRadars(location)
        }
    }

    override fun onCreate() {
        super.onCreate()
        radars = RadarRepository.load(this)
        fused = LocationServices.getFusedLocationProviderClient(this)
        tts = TextToSpeech(this, this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        alertDistance = intent?.getFloatExtra("distance", 500f) ?: 500f
        voiceEnabled = intent?.getBooleanExtra("voice", true) ?: true
        floatingEnabled = intent?.getBooleanExtra("floating", true) ?: true
        val notification = NotificationCompat.Builder(this, "radar_monitor")
            .setSmallIcon(android.R.drawable.ic_dialog_map)
            .setContentTitle("Alerta Radar ativo")
            .setContentText("Monitoramento de localização em andamento")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(101, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else startForeground(101, notification)

        try {
            val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 2000L)
                .setMinUpdateDistanceMeters(8f).build()
            fused.requestLocationUpdates(request, callback, mainLooper)
        } catch (_: SecurityException) {
            stopSelf()
        }
        return START_STICKY
    }

    private fun checkRadars(current: Location) {
        if (radars.isEmpty()) return
        val nearest = radars.map { radar ->
            val target = Location("radar").apply { latitude = radar.lat; longitude = radar.lon }
            radar to current.distanceTo(target)
        }.filter { it.second <= alertDistance }
            .minByOrNull { it.second } ?: return
        val (radar, distance) = nearest
        val now = System.currentTimeMillis()
        if (radar.id == lastAlertId && now - lastAlertAt < 45000L) return
        lastAlertId = radar.id
        lastAlertAt = now
        val dist = (distance / 50).roundToInt() * 50
        val speed = radar.speedLimit?.let { " Limite de $it quilômetros por hora." } ?: ""
        val message = "${radar.type} a aproximadamente $dist metros.$speed"
        if (voiceEnabled) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, radar.id)
        if (floatingEnabled) {
            startService(Intent(this, FloatingAlertService::class.java).putExtra("message", message))
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("radar_monitor", "Monitoramento de radares", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        fused.removeLocationUpdates(callback)
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
