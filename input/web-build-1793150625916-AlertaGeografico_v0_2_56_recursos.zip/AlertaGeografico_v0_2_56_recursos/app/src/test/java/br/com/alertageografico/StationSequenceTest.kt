package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class StationSequenceTest {
    private val alongs = doubleArrayOf(0.0, 2000.0, 4000.0)

    private fun w(nearest: Int, dist: Double, along: Double, dir: Boolean?, slow: Boolean = false) =
        StationSequence.resolve(alongs, nearest, dist, along, dir, slow)

    @Test fun atPlatformIsCurrent() {
        val r = w(1, 60.0, 2010.0, false, slow = true)
        assertEquals(1, r.currentIndex); assertEquals(0, r.previousIndex); assertEquals(2, r.nextIndex)
    }

    @Test fun approachingWithin150mIsCurrent() {
        val r = w(1, 120.0, 1880.0, false)
        assertEquals(1, r.currentIndex); assertEquals(2, r.nextIndex)
    }

    @Test fun justLeftStationIsNoLongerCurrentEvenWithin150m() {
        // 100 m depois da estação 1, em movimento: já saiu
        val r = w(1, 100.0, 2100.0, false)
        assertNull(r.currentIndex); assertEquals(1, r.previousIndex); assertEquals(2, r.nextIndex)
    }

    @Test fun betweenStationsShowsPreviousAndNext() {
        val r = w(1, 800.0, 1200.0, false)
        assertNull(r.currentIndex); assertEquals(0, r.previousIndex); assertEquals(1, r.nextIndex)
    }

    @Test fun reverseDirectionMirrorsTheSequence() {
        // indo contra a geometria, 100 m "depois" (em sentido de viagem) da estação 1
        val left = w(1, 100.0, 1900.0, true)
        assertNull(left.currentIndex); assertEquals(1, left.previousIndex); assertEquals(0, left.nextIndex)
        val between = w(1, 800.0, 2800.0, true)
        assertNull(between.currentIndex); assertEquals(2, between.previousIndex); assertEquals(1, between.nextIndex)
    }

    @Test fun beforeFirstAndAfterLastStationHaveNoNeighbour() {
        val start = w(0, 700.0, -700.0, false)
        assertNull(start.currentIndex); assertEquals(-1, start.previousIndex); assertEquals(0, start.nextIndex)
        val end = w(2, 700.0, 4700.0, false)
        assertEquals(2, end.previousIndex); assertEquals(3, end.nextIndex) // fora da lista = "não há"
    }

    @Test fun slowDriftOf200mStillCountsAsPlatform() {
        assertEquals(1, w(1, 200.0, 2000.0, false, slow = true).currentIndex)
    }

    @Test fun unknownDirectionKeepsNearestAsCurrent() {
        val r = w(1, 600.0, 1700.0, null)
        assertEquals(1, r.currentIndex)
    }
}
