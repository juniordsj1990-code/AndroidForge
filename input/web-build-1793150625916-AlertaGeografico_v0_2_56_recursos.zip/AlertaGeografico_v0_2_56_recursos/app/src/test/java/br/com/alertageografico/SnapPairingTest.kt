package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SnapPairingTest {
    private data class C(val comp: Int, val score: Double)
    private fun pick(a: List<C>, b: List<C>) = SnapPairing.bestConnectedPair(a, b, { it.comp }, { it.score })

    @Test fun picksTheSameTrackWhenTheNearestOnesDiffer() {
        // Usuário mais perto da via 1 (erro lateral), mas o alvo só tem via 2 próxima do usuário: usa a via comum
        val users = listOf(C(1, 5.0), C(2, 12.0))
        val targets = listOf(C(2, 3.0), C(1, 9.0))
        val r = pick(users, targets)!!
        // custos: (1,1)=5+9=14, (2,2)=12+3=15 -> via 1
        assertEquals(1, r.first.comp)
        assertEquals(1, r.second.comp)
    }

    @Test fun usesTheOnlyConnectedPair() {
        val r = pick(listOf(C(1, 4.0)), listOf(C(2, 1.0), C(1, 40.0)))!!
        assertEquals(1, r.second.comp)
        assertEquals(40.0, r.second.score, 0.0)
    }

    @Test fun noCommonComponentMeansNoPath() {
        assertNull(pick(listOf(C(1, 2.0), C(3, 5.0)), listOf(C(2, 1.0))))
    }

    @Test fun emptyListsMeanNoPath() {
        assertNull(pick(emptyList(), listOf(C(1, 1.0))))
        assertNull(pick(listOf(C(1, 1.0)), emptyList()))
    }
}
