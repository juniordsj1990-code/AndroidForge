package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Test

class DeadReckoningTest {
    @Test fun gapThresholdFollowsObservedIntervalWithinBounds() {
        assertEquals(8_000L, DeadReckoning.gapThresholdMs(1_000L))
        assertEquals(15_000L, DeadReckoning.gapThresholdMs(5_000L))
        assertEquals(20_000L, DeadReckoning.gapThresholdMs(60_000L))
    }

    @Test fun alertIsAnticipatedByTheEffectiveRadiusTime() {
        // chegada ao centro em t=100 s; raio efetivo 375 m a 15 m/s => 25 s antes
        assertEquals(75_000L, DeadReckoning.alertAtMs(100_000L, 375.0, 0, 15.0))
        // janela já medida até a borda do raio (300 m): só falta a diferença (375 − 300) / 15 = 5 s
        assertEquals(95_000L, DeadReckoning.alertAtMs(100_000L, 375.0, 300, 15.0))
        // raio efetivo igual ao já descontado: sem recuo
        assertEquals(100_000L, DeadReckoning.alertAtMs(100_000L, 300.0, 300, 15.0))
    }
}
