package br.com.alertageografico

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Leitura bruta entregue ao filtro (independente de Android). */
data class FilterInput(
    val timeMs: Long,
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Double,
    val speedMps: Double? = null,
    val bearingDeg: Double? = null,
    val speedAccuracyMps: Double? = null
)

data class FilteredFix(
    val latitude: Double,
    val longitude: Double,
    /** Incerteza (1σ) da posição filtrada. */
    val accuracyMeters: Float,
    val speedMps: Double,
    /** Rumo do vetor velocidade filtrado; null quando praticamente parado. */
    val bearingDeg: Double?,
    val timeMs: Long,
    /** Verdadeiro se a leitura foi descartada como salto e a posição é só a previsão do filtro. */
    val rejected: Boolean = false
)

/**
 * Filtro de Kalman de velocidade constante, um por eixo (leste/norte), em metros locais.
 *  - ruído de medição vem do `accuracy` reportado;
 *  - a velocidade Doppler (e o rumo) entra como segunda medição, e velocidade ~0 com boa
 *    precisão trava a posição em paradas (evita "andar" parado);
 *  - leituras muito fora da previsão (distância de Mahalanobis) são descartadas; após
 *    [maxConsecutiveRejects] descartes seguidos, ou após uma lacuna longa, o filtro recomeça.
 */
class PositionFilter(
    private val accelSigma: Double = 1.5,
    private val gateChi2: Double = 16.0,
    private val maxConsecutiveRejects: Int = 3,
    private val resetGapMs: Long = 120_000L
) {
    private var initialized = false
    private var lat0 = 0.0
    private var lon0 = 0.0
    private var lastT = 0L
    private var rejects = 0

    // estado por eixo: posição, velocidade e covariância [p00 p01; p01 p11]
    private val x = DoubleArray(2)
    private val v = DoubleArray(2)
    private val p00 = DoubleArray(2)
    private val p01 = DoubleArray(2)
    private val p11 = DoubleArray(2)

    fun reset() { initialized = false; rejects = 0 }

    private fun mPerDegLat() = EARTH_RADIUS_M * PI / 180.0
    private fun mPerDegLon() = mPerDegLat() * cos(Math.toRadians(lat0))

    private fun start(input: FilterInput) {
        lat0 = input.latitude
        lon0 = input.longitude
        val sp = input.speedMps
        val br = input.bearingDeg
        val hasVel = sp != null && br != null && sp >= 1.0
        val velSigma = (input.speedAccuracyMps ?: 3.0).coerceAtLeast(0.5)
        val r = max(input.accuracyMeters, 3.0)
        for (a in 0..1) {
            x[a] = 0.0
            v[a] = if (hasVel) (if (a == 0) sp!! * sin(Math.toRadians(br!!)) else sp!! * cos(Math.toRadians(br!!))) else 0.0
            p00[a] = r * r
            p01[a] = 0.0
            p11[a] = if (hasVel) velSigma * velSigma + (sp!! * 0.1) * (sp * 0.1) else 15.0 * 15.0
        }
        lastT = input.timeMs
        rejects = 0
        initialized = true
    }

    private fun predict(dtSeconds: Double) {
        if (dtSeconds <= 0.0) return
        val q = accelSigma * accelSigma
        val dt2 = dtSeconds * dtSeconds
        for (a in 0..1) {
            x[a] += v[a] * dtSeconds
            // Aceleração como ruído branco contínuo: a incerteza cresce ~dt³ (e não dt⁴),
            // sem explodir em lacunas de dezenas de segundos.
            val n00 = p00[a] + 2 * dtSeconds * p01[a] + dt2 * p11[a] + q * dt2 * dtSeconds / 3.0
            val n01 = p01[a] + dtSeconds * p11[a] + q * dt2 / 2.0
            val n11 = p11[a] + q * dtSeconds
            p00[a] = n00; p01[a] = n01; p11[a] = n11
        }
    }

    private fun velocityUpdate(axis: Int, z: Double, sigma: Double) {
        val s = p11[axis] + sigma * sigma
        val k0 = p01[axis] / s
        val k1 = p11[axis] / s
        val innovation = z - v[axis]
        x[axis] += k0 * innovation
        v[axis] += k1 * innovation
        val old01 = p01[axis]
        val old11 = p11[axis]
        p00[axis] -= k0 * old01
        p01[axis] -= k0 * old11
        p11[axis] -= k1 * old11
    }

    fun update(input: FilterInput): FilteredFix {
        val gap = input.timeMs - lastT
        if (!initialized || gap > resetGapMs || gap < -5_000L) start(input)
        else {
            predict(gap.coerceAtLeast(0L) / 1000.0)
            lastT = max(lastT, input.timeMs)
            val r = max(input.accuracyMeters, 3.0)
            val mx = (input.longitude - lon0) * mPerDegLon()
            val my = (input.latitude - lat0) * mPerDegLat()
            val yx = mx - x[0]
            val yy = my - x[1]
            val sx = p00[0] + r * r
            val sy = p00[1] + r * r
            val d2 = yx * yx / sx + yy * yy / sy
            if (d2 > gateChi2) {
                rejects++
                if (rejects >= maxConsecutiveRejects) { start(input) }
                else return output(input.timeMs, rejected = true)
            } else {
                rejects = 0
                val meas = doubleArrayOf(mx, my)
                for (a in 0..1) {
                    val s = p00[a] + r * r
                    val k0 = p00[a] / s
                    val k1 = p01[a] / s
                    val y = meas[a] - x[a]
                    x[a] += k0 * y
                    v[a] += k1 * y
                    val o00 = p00[a]; val o01 = p01[a]
                    p00[a] = (1 - k0) * o00
                    p01[a] = (1 - k0) * o01
                    p11[a] -= k1 * o01
                }
                val sp = input.speedMps
                val br = input.bearingDeg
                val spAcc = input.speedAccuracyMps
                if (sp != null && br != null && sp >= 1.0 && sp < 70.0) {
                    val sigma = (spAcc ?: 1.5).coerceAtLeast(0.4)
                    val rad = Math.toRadians(br)
                    val dirNoise = sp * 0.1
                    val sg = sqrt(sigma * sigma + dirNoise * dirNoise)
                    val zx = sp * sin(rad)
                    val zy = sp * cos(rad)
                    if (hypot(zx - v[0], zy - v[1]) < 20.0) {
                        velocityUpdate(0, zx, sg)
                        velocityUpdate(1, zy, sg)
                    }
                } else if (sp != null && sp < 0.3 && spAcc != null && spAcc <= 1.0) {
                    // Velocidade ~0 medida com confiança: trava a posição (parada em estação/semáforo).
                    val sg = spAcc.coerceAtLeast(0.3)
                    velocityUpdate(0, 0.0, sg)
                    velocityUpdate(1, 0.0, sg)
                }
            }
        }
        return output(input.timeMs, rejected = false)
    }

    private fun output(timeMs: Long, rejected: Boolean): FilteredFix {
        val lat = lat0 + x[1] / mPerDegLat()
        val lon = lon0 + x[0] / mPerDegLon()
        val speed = hypot(v[0], v[1])
        val bearing = if (speed >= 1.0) (Math.toDegrees(atan2(v[0], v[1])) + 360.0) % 360.0 else null
        val sigma = sqrt(max(p00[0], p00[1])).coerceAtLeast(2.0)
        return FilteredFix(lat, lon, sigma.toFloat(), speed, bearing, timeMs, rejected)
    }

    private companion object {
        const val EARTH_RADIUS_M = 6_371_000.0
    }
}
