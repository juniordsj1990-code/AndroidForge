package br.com.alertageografico

/**
 * Escolha do par de encaixes (usuário, alvo) para medir a distância pelos trilhos.
 * Só pares da mesma componente conectada têm caminho; entre eles vale o de menor custo
 * (pontuação do encaixe do usuário + pontuação do encaixe do alvo).
 */
object SnapPairing {
    fun <T> bestConnectedPair(
        starts: List<T>,
        finishes: List<T>,
        component: (T) -> Int,
        score: (T) -> Double
    ): Pair<T, T>? {
        var best: Pair<T, T>? = null
        var bestCost = Double.POSITIVE_INFINITY
        for (s in starts) for (f in finishes) {
            if (component(s) != component(f)) continue
            val cost = score(s) + score(f)
            if (cost < bestCost) { bestCost = cost; best = s to f }
        }
        return best
    }
}
