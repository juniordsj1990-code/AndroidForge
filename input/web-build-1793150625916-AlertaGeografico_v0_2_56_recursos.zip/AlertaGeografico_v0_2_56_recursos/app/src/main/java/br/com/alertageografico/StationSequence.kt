package br.com.alertageografico

/**
 * Decide, a partir da posição ao longo da linha, qual é a estação atual (na plataforma) e quais são
 * a anterior e a próxima. Lógica pura, separada de [StationNavigationStore.locate] para teste.
 */
object StationSequence {
    /** [currentIndex] é null entre estações; os índices podem cair fora da lista (= "não há"). */
    data class Window(val currentIndex: Int?, val previousIndex: Int, val nextIndex: Int)

    private const val PLATFORM_RADIUS_MOVING_M = 150.0
    private const val PLATFORM_RADIUS_SLOW_M = 220.0
    private const val DEPARTED_MARGIN_M = 40.0

    /**
     * @param alongs posição de cada estação ao longo da geometria, em ordem crescente
     * @param direction sentido da viagem: false = a favor da ordem da geometria, true = contra, null = desconhecido
     * @param slow parado ou quase (a velocidade não permite concluir que saiu da estação)
     */
    fun resolve(
        alongs: DoubleArray,
        nearestIndex: Int,
        nearestDistanceMeters: Double,
        userAlongMeters: Double,
        direction: Boolean?,
        slow: Boolean
    ): Window {
        val reverse = direction == true
        // Saiu da estação: em movimento, com a mais próxima já ficando para trás. Antes, a estação
        // deixada seguia como "atual" até a plataforma seguinte entrar nos 150 m.
        val behindBy = if (reverse) alongs[nearestIndex] - userAlongMeters else userAlongMeters - alongs[nearestIndex]
        val nearestIsBehind = direction != null && !slow && behindBy > DEPARTED_MARGIN_M
        val platformRadius = if (slow) PLATFORM_RADIUS_SLOW_M else PLATFORM_RADIUS_MOVING_M
        val atStation = nearestDistanceMeters <= platformRadius && !nearestIsBehind
        if (atStation || direction == null) {
            return Window(
                nearestIndex,
                if (reverse) nearestIndex + 1 else nearestIndex - 1,
                if (reverse) nearestIndex - 1 else nearestIndex + 1
            )
        }
        return if (!reverse) {
            val passed = alongs.indices.lastOrNull { alongs[it] <= userAlongMeters } ?: -1
            Window(null, passed, passed + 1)
        } else {
            val passed = alongs.indices.firstOrNull { alongs[it] >= userAlongMeters } ?: alongs.size
            Window(null, passed, passed - 1)
        }
    }
}
