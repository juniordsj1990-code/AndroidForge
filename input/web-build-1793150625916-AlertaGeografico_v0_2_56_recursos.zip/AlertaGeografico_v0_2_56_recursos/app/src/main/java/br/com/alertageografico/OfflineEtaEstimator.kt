package br.com.alertageografico

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Estado de confiança da estimativa offline de chegada. */
enum class EtaConfidence(val storageValue: String) {
    NORMAL("normal"),
    PAUSED("paused"),
    LOW("low_confidence"),
    /** Sem GPS (túnel/subsolo): a faixa continua contando pelo movimento anterior. */
    NO_GPS("no_gps"),
    UNAVAILABLE("unavailable")
}

/** Trem/metrô usam velocidade de cruzeiro; ônibus, velocidade média incluindo as paradas. */
enum class EtaMode(val key: String) { RAIL("rail"), BUS("bus") }

/** Leitura de posição no formato que o estimador consome (sem depender de Android). */
data class EtaFix(
    /** Tempo monotônico (elapsedRealtime, ms). */
    val elapsedMs: Long,
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float?,
    val speedMps: Double?,
    val speedAccuracyMps: Double?
)

data class EtaEstimate(
    val distanceMeters: Int,
    val minMinutes: Int,
    val maxMinutes: Int,
    val confidence: EtaConfidence,
    val filteredSpeedMps: Double?,
    /** Instante (elapsedRealtime, ms) em que a estimativa foi montada. */
    val updatedAtMillis: Long,
    /** Tempo restante central (s), antes de aplicar a faixa; -1 se indisponível. */
    val midSeconds: Double = -1.0,
    /** Limites da faixa (s restantes em [updatedAtMillis]); -1 se indisponível. */
    val minSeconds: Double = -1.0,
    val maxSeconds: Double = -1.0
)

/**
 * Estimativa offline com validação temporal, filtro robusto de velocidade,
 * retenção temporária durante pausas e suavização do tempo restante.
 *
 *  - A chegada é guardada como janela de horários absolutos (monotônicos): em perda de GPS a faixa
 *    continua contando; em parada operacional (estação) a janela é empurrada, mantendo o tempo.
 *  - O suavizador desconta o tempo decorrido entre leituras antes de misturar a nova medida, para
 *    não carregar viés para cima.
 *  - A faixa min–max vem de erros reais registrados em [calibrator] (previsto × real); sem amostras,
 *    de uma faixa a priori que cresce com o horizonte e com a variação de velocidade.
 * Não participa da decisão de proximidade/alerta.
 */
class OfflineEtaEstimator(private val calibrator: EtaCalibrator? = null) {
    private data class SpeedSample(val timestamp: Long, val speedMps: Double)
    private data class PositionSample(val timestamp: Long, val latitude: Double, val longitude: Double)
    private data class Snapshot(val atMs: Long, val midSeconds: Double)

    private val speedSamples = ArrayDeque<SpeedSample>()
    private val busSamples = ArrayDeque<SpeedSample>()
    private var previousPosition: PositionSample? = null
    private var pauseStartedAt: Long? = null
    private var smoothedSpeed: Double? = null
    private var smoothedMidSeconds: Double? = null
    private var smoothedAtMs = 0L
    private var arrivalMinAt = 0L
    private var arrivalMaxAt = 0L
    private var lastValidEstimate: EtaEstimate? = null
    private var lastTickAt = 0L
    private var cruiseSpeed: Double? = null
    private var cruiseUpdatedAt: Long = 0L
    private val snapshots = ArrayDeque<Snapshot>()
    private var arrivalResolved = false

    /**
     * Troca de destino (ex.: próxima parada do roteiro): descarta apenas a estimativa anterior,
     * que pertencia a outra distância, e mantém o histórico de velocidade.
     */
    fun resetTarget() {
        smoothedMidSeconds = null
        lastValidEstimate = null
        snapshots.clear()
        arrivalResolved = false
    }

    fun reset() {
        cruiseSpeed = null
        cruiseUpdatedAt = 0L
        speedSamples.clear()
        busSamples.clear()
        previousPosition = null
        pauseStartedAt = null
        smoothedSpeed = null
        lastTickAt = 0L
        resetTarget()
    }

    fun update(
        fix: EtaFix,
        nowElapsedMs: Long,
        distanceToCenterMeters: Double,
        radiusMeters: Int,
        mode: EtaMode = EtaMode.RAIL,
        extraDwellSeconds: Double = 0.0
    ): EtaEstimate {
        val now = nowElapsedMs
        val tickDt = if (lastTickAt > 0L) max(0L, now - lastTickAt) else 0L
        lastTickAt = now
        val remaining = max(0.0, distanceToCenterMeters - radiusMeters).toInt()
        val stale = fix.elapsedMs <= 0L || now - fix.elapsedMs > MAX_FIX_AGE_MS || fix.elapsedMs - now > FUTURE_FIX_TOLERANCE_MS
        val accuracy = fix.accuracyMeters ?: Float.POSITIVE_INFINITY
        val positionUsable = !stale && accuracy <= MAX_HORIZONTAL_ACCURACY_M

        if (!positionUsable) return retainedEstimate(remaining, now, tickDt, EtaConfidence.LOW, frozen = false)
        pruneSamples(fix.elapsedMs)

        if (remaining <= ARRIVAL_TOLERANCE_M) resolveSnapshots(fix.elapsedMs, mode)

        // A distância dentro do raio do destino significa chegada, mesmo se o usuário estiver parado.
        if (remaining == 0) {
            val arrived = EtaEstimate(0, 0, 0, EtaConfidence.NORMAL, smoothedSpeed, now, 0.0, 0.0, 0.0)
            lastValidEstimate = arrived
            smoothedMidSeconds = 0.0
            smoothedAtMs = fix.elapsedMs
            arrivalMinAt = fix.elapsedMs
            arrivalMaxAt = fix.elapsedMs
            previousPosition = PositionSample(fix.elapsedMs, fix.latitude, fix.longitude)
            return arrived
        }

        val currentPosition = PositionSample(fix.elapsedMs, fix.latitude, fix.longitude)
        val priorPosition = previousPosition
        var displacementSpeed: Double? = null
        if (priorPosition != null) {
            val elapsed = (currentPosition.timestamp - priorPosition.timestamp) / 1000.0
            if (elapsed >= MIN_POSITION_DELTA_SECONDS && elapsed <= MAX_POSITION_DELTA_SECONDS) {
                val traveled = ProximityEngine.distanceMeters(
                    priorPosition.latitude, priorPosition.longitude,
                    currentPosition.latitude, currentPosition.longitude
                )
                val derived = traveled / elapsed
                // Um salto incompatível é tratado como posição suspeita, não como movimento real.
                if (derived <= MAX_PLAUSIBLE_SPEED_MPS) displacementSpeed = derived
            }
        }
        previousPosition = currentPosition

        val reportedSpeed = fix.speedMps
        val speedAccuracyOk = fix.speedAccuracyMps == null || fix.speedAccuracyMps <= MAX_SPEED_ACCURACY_MPS
        var candidate = when {
            reportedSpeed != null && reportedSpeed.isFinite() && reportedSpeed in 0.0..MAX_PLAUSIBLE_SPEED_MPS && speedAccuracyOk -> reportedSpeed
            displacementSpeed != null -> displacementSpeed
            else -> null
        }

        if (mode == EtaMode.BUS) return updateBus(fix, now, tickDt, remaining, candidate, extraDwellSeconds)

        val medianBefore = median(speedSamples.map { it.speedMps })
        if (candidate != null && medianBefore != null && candidate > PAUSE_SPEED_MPS) {
            val allowedDeviation = max(OUTLIER_ABSOLUTE_DEVIATION_MPS, medianBefore * OUTLIER_RELATIVE_FACTOR)
            if (abs(candidate - medianBefore) > allowedDeviation) candidate = null
        }

        val isPaused = candidate != null && candidate <= PAUSE_SPEED_MPS &&
            (displacementSpeed == null || displacementSpeed <= PAUSE_DISPLACEMENT_SPEED_MPS)
        if (isPaused) {
            if (pauseStartedAt == null) pauseStartedAt = fix.elapsedMs
            val pausedFor = now - (pauseStartedAt ?: now)
            val status = if (pausedFor <= PAUSE_HOLD_MS) EtaConfidence.PAUSED else EtaConfidence.LOW
            // Parado (estação, semáforo): o tempo restante não corre; empurra a janela de chegada.
            return retainedEstimate(remaining, now, tickDt, status, frozen = true)
        }

        if (candidate == null || candidate <= PAUSE_SPEED_MPS) {
            return retainedEstimate(remaining, now, tickDt, EtaConfidence.LOW, frozen = false)
        }

        pauseStartedAt = null
        val sampleTime = fix.elapsedMs
        pruneSamples(sampleTime)
        speedSamples.addLast(SpeedSample(sampleTime, candidate))
        while (speedSamples.size > MAX_SPEED_SAMPLES) speedSamples.removeFirst()

        // Memória de velocidade de cruzeiro: evita que frenagem, chegada em estação ou arranque
        // lento (velocidades baixas e passageiras) projetem o tempo restante inteiro nessa velocidade.
        if (candidate >= CRUISE_MIN_SPEED_MPS) {
            val previousCruise = cruiseSpeed
            val expired = previousCruise == null || sampleTime - cruiseUpdatedAt > CRUISE_MEMORY_MS
            cruiseSpeed = if (expired) candidate else previousCruise!! + CRUISE_ALPHA * (candidate - previousCruise)
            cruiseUpdatedAt = sampleTime
        }
        val cruise = cruiseSpeed?.takeIf { sampleTime - cruiseUpdatedAt <= CRUISE_MEMORY_MS }
        val cruiseFloor = cruise?.let { it * CRUISE_FLOOR_FACTOR } ?: 0.0

        val medianSpeed = median(speedSamples.map { it.speedMps }) ?: candidate
        val oldSmoothedSpeed = smoothedSpeed
        val filteredSpeed = if (oldSmoothedSpeed == null) medianSpeed
            else oldSmoothedSpeed + SPEED_SMOOTHING_ALPHA * (medianSpeed - oldSmoothedSpeed)
        smoothedSpeed = filteredSpeed
        val effectiveSpeed = max(max(filteredSpeed, cruiseFloor), MIN_ESTIMATION_SPEED_MPS)

        val values = speedSamples.map { it.speedMps }.sorted()
        val p20 = percentile(values, 0.20) ?: effectiveSpeed * 0.9
        val p80 = percentile(values, 0.80) ?: effectiveSpeed * 1.1
        val spread = ((p80 - p20) / (2.0 * max(effectiveSpeed, 1.0))).coerceIn(0.0, 0.5)
        return finish(fix, now, remaining, effectiveSpeed, spread, mode, extraDwellSeconds)
    }

    /**
     * Ônibus: o tempo restante usa a velocidade média da janela recente INCLUINDO as paradas
     * (semáforo, trânsito, pontos), sem piso de cruzeiro; assim o congestionamento aparece no ETA.
     */
    private fun updateBus(fix: EtaFix, now: Long, tickDt: Long, remaining: Int, candidate: Double?, extraDwell: Double): EtaEstimate {
        if (candidate == null) return retainedEstimate(remaining, now, tickDt, EtaConfidence.LOW, frozen = false)
        busSamples.addLast(SpeedSample(fix.elapsedMs, candidate))
        while (busSamples.isNotEmpty() && fix.elapsedMs - busSamples.first().timestamp > BUS_WINDOW_MS) busSamples.removeFirst()
        val avg = timeWeightedMean(busSamples)
            ?: return retainedEstimate(remaining, now, tickDt, EtaConfidence.LOW, frozen = false)
        smoothedSpeed = avg
        val values = busSamples.map { it.speedMps }
        val mean = values.average()
        val variance = values.sumOf { (it - mean) * (it - mean) } / values.size
        val spread = if (mean > 0.5) (sqrt(variance) / mean * 0.5).coerceIn(0.0, 0.5) else 0.5
        return finish(fix, now, remaining, max(avg, MIN_BUS_SPEED_MPS), spread, EtaMode.BUS, extraDwell)
    }

    private fun finish(fix: EtaFix, now: Long, remaining: Int, speed: Double, spread: Double, mode: EtaMode, extraDwell: Double): EtaEstimate {
        val midRaw = remaining / speed + extraDwell
        if (midRaw > MAX_MID_SECONDS) return unavailable(remaining, now)

        // O tempo restante já correu desde a última leitura: desconta antes de misturar,
        // senão o EMA fica sempre atrasado em relação à realidade (viés para cima).
        val previous = smoothedMidSeconds
        val elapsedSincePrev = fix.elapsedMs - smoothedAtMs
        val advanced = if (previous != null && elapsedSincePrev in 0..SMOOTH_MAX_GAP_MS) previous - elapsedSincePrev / 1000.0 else null
        val mid = if (advanced == null || advanced <= 0.0) midRaw else advanced + ETA_SMOOTHING_ALPHA * (midRaw - advanced)
        smoothedMidSeconds = mid
        smoothedAtMs = fix.elapsedMs

        val (lowMul, highMul) = calibrator?.multipliers(mode.key, mid) ?: priorMultipliers(mid, spread)
        arrivalMinAt = fix.elapsedMs + (mid * lowMul * 1000.0).toLong()
        arrivalMaxAt = fix.elapsedMs + (mid * highMul * 1000.0).toLong()

        if (snapshots.isEmpty() || fix.elapsedMs - snapshots.last().atMs >= SNAPSHOT_EVERY_MS) {
            snapshots.addLast(Snapshot(fix.elapsedMs, mid))
            while (snapshots.size > MAX_SNAPSHOTS) snapshots.removeFirst()
        }

        val estimate = windowEstimate(remaining, now, EtaConfidence.NORMAL, speed, mid)
        lastValidEstimate = estimate
        return estimate
    }

    /** Faixa a priori: ±4% perto, até ±14% a 20 min, alargada de leve pela variação de velocidade; atrasos pesam um pouco mais. A calibração por viagens reais assume depois. */
    private fun priorMultipliers(midSeconds: Double, spread: Double): Pair<Double, Double> {
        val horizon = 0.04 + 0.10 * min(1.0, midSeconds / 1200.0)
        val speedPart = spread * 0.35
        val w = min(0.3, sqrt(horizon * horizon + speedPart * speedPart))
        return (1.0 - w) to (1.0 + 1.25 * w)
    }

    /** Monta a estimativa a partir da janela de chegada absoluta, contada até [now]. */
    private fun windowEstimate(remaining: Int, now: Long, confidence: EtaConfidence, speed: Double?, mid: Double): EtaEstimate {
        val minS = (arrivalMinAt - now) / 1000.0
        val maxS = (arrivalMaxAt - now) / 1000.0
        if (maxS < -OVERDUE_SECONDS) return unavailable(remaining, now)
        // Arredonda ao minuto mais próximo (floor no mínimo + ceil no máximo inflava a faixa em até 2 min).
        val minMinutes = Math.round(max(minS, 0.0) / 60.0).toInt().coerceAtLeast(1)
        val maxMinutes = Math.round(max(maxS, 0.0) / 60.0).toInt().coerceAtLeast(minMinutes)
        return EtaEstimate(remaining, minMinutes, maxMinutes, confidence, speed, now, mid, max(minS, 0.0), max(maxS, 0.0))
    }

    private fun unavailable(remaining: Int, now: Long) =
        EtaEstimate(remaining, -1, -1, EtaConfidence.UNAVAILABLE, null, now)

    private fun retainedEstimate(remaining: Int, now: Long, tickDt: Long, status: EtaConfidence, frozen: Boolean): EtaEstimate {
        val previous = lastValidEstimate ?: return unavailable(remaining, now)
        // Em estações, túneis e paradas operacionais o GPS pode ficar sem movimento por vários
        // minutos. Preserva a última estimativa por esse período, em vez de trocar para "aguardando GPS".
        if (now - previous.updatedAtMillis > MAX_RETAINED_ESTIMATE_AGE_MS) return unavailable(remaining, now)
        if (frozen) {
            arrivalMinAt += tickDt
            arrivalMaxAt += tickDt
            if (smoothedMidSeconds != null) smoothedAtMs += tickDt
        }
        return windowEstimate(remaining, now, status, previous.filteredSpeedMps, previous.midSeconds)
    }

    /**
     * Estimativa sem leitura nova (GPS ausente): a janela de chegada segue contando em tempo real.
     * [distanceMeters] é a distância estimada por dead-reckoning, calculada pelo chamador.
     */
    fun peek(nowElapsedMs: Long, distanceMeters: Int): EtaEstimate {
        val previous = lastValidEstimate ?: return unavailable(distanceMeters, nowElapsedMs)
        if (nowElapsedMs - previous.updatedAtMillis > MAX_RETAINED_ESTIMATE_AGE_MS) return unavailable(distanceMeters, nowElapsedMs)
        return windowEstimate(distanceMeters, nowElapsedMs, EtaConfidence.NO_GPS, previous.filteredSpeedMps, previous.midSeconds)
    }

    /**
     * Janela de chegada absoluta (mais cedo, mais tarde; ms monotônicos) da última estimativa válida,
     * ou null se não há. Base do alerta estimado sem GPS.
     */
    fun arrivalWindow(): Pair<Long, Long>? = if (lastValidEstimate == null) null else arrivalMinAt to arrivalMaxAt

    private fun resolveSnapshots(arrivedAtMs: Long, mode: EtaMode) {
        if (arrivalResolved) return
        arrivalResolved = true
        val c = calibrator
        if (c != null) for (s in snapshots) c.record(mode.key, s.midSeconds, (arrivedAtMs - s.atMs) / 1000.0)
        snapshots.clear()
    }

    private fun timeWeightedMean(samples: ArrayDeque<SpeedSample>): Double? {
        if (samples.size < 2) return null
        var weighted = 0.0
        var span = 0.0
        var prev = samples.first()
        for (i in 1 until samples.size) {
            val cur = samples[i]
            val dt = min((cur.timestamp - prev.timestamp) / 1000.0, MAX_SAMPLE_GAP_S)
            if (dt > 0) { weighted += dt * (cur.speedMps + prev.speedMps) / 2.0; span += dt }
            prev = cur
        }
        return if (span >= MIN_BUS_SPAN_S) weighted / span else null
    }

    private fun pruneSamples(now: Long) {
        while (speedSamples.isNotEmpty() && now - speedSamples.first().timestamp > SPEED_HISTORY_MS) speedSamples.removeFirst()
    }

    private fun median(values: List<Double>): Double? {
        if (values.isEmpty()) return null
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[middle - 1] + sorted[middle]) / 2.0 else sorted[middle]
    }

    private fun percentile(sortedValues: List<Double>, percentile: Double): Double? {
        if (sortedValues.isEmpty()) return null
        val index = ((sortedValues.size - 1) * percentile).toInt().coerceIn(0, sortedValues.lastIndex)
        return sortedValues[index]
    }

    companion object {
        private const val CRUISE_MIN_SPEED_MPS = 4.0
        private const val CRUISE_ALPHA = 0.2
        private const val CRUISE_MEMORY_MS = 4 * 60_000L
        private const val CRUISE_FLOOR_FACTOR = 0.55
        private const val MAX_FIX_AGE_MS = 30_000L
        private const val FUTURE_FIX_TOLERANCE_MS = 5_000L
        private const val MAX_HORIZONTAL_ACCURACY_M = 50f
        private const val MAX_SPEED_ACCURACY_MPS = 5.0
        private const val MAX_PLAUSIBLE_SPEED_MPS = 70.0
        private const val MIN_POSITION_DELTA_SECONDS = 0.5
        private const val MAX_POSITION_DELTA_SECONDS = 60.0
        private const val PAUSE_SPEED_MPS = 0.5
        private const val PAUSE_DISPLACEMENT_SPEED_MPS = 1.0
        private const val PAUSE_HOLD_MS = 10_000L
        private const val MAX_RETAINED_ESTIMATE_AGE_MS = 10 * 60_000L
        private const val SPEED_HISTORY_MS = 30_000L
        private const val MAX_SPEED_SAMPLES = 9
        private const val OUTLIER_ABSOLUTE_DEVIATION_MPS = 8.0
        private const val OUTLIER_RELATIVE_FACTOR = 2.5
        private const val SPEED_SMOOTHING_ALPHA = 0.35
        private const val ETA_SMOOTHING_ALPHA = 0.35
        private const val SMOOTH_MAX_GAP_MS = 60_000L
        private const val MIN_ESTIMATION_SPEED_MPS = 0.5
        private const val MIN_BUS_SPEED_MPS = 0.8
        private const val BUS_WINDOW_MS = 240_000L
        private const val MIN_BUS_SPAN_S = 20.0
        private const val MAX_SAMPLE_GAP_S = 30.0
        private const val MAX_MID_SECONDS = 6 * 3600.0
        private const val OVERDUE_SECONDS = 90.0
        private const val ARRIVAL_TOLERANCE_M = 40
        private const val SNAPSHOT_EVERY_MS = 20_000L
        private const val MAX_SNAPSHOTS = 80
    }
}
