package br.com.alertageografico

import kotlin.math.max

/**
 * Regras (puras) do alerta estimado quando não há GPS utilizável (túnel, subsolo, estação coberta).
 * O horário do alerta sai da janela absoluta de chegada do estimador de ETA, que já embute paradas
 * em estações (dwell) e a variação de velocidade; aqui só se decide quando considerar "sem GPS" e
 * quando disparar, com a mesma antecedência do raio efetivo.
 */
object DeadReckoning {
    /** Leitura só conta como sinal se tiver erro até este valor (m)... */
    const val USABLE_ACCURACY_M = 100f
    /** ...e não for velha (o provedor às vezes reentrega a última posição conhecida). */
    const val MAX_FIX_AGE_MS = 15_000L
    const val MIN_SPEED_MPS = 3.0

    /** Tempo sem leitura utilizável para declarar "sem GPS": ~3 intervalos observados, entre 8 e 20 s. */
    fun gapThresholdMs(observedIntervalMs: Long): Long = (observedIntervalMs * 3).coerceIn(8_000L, 20_000L)

    /**
     * Horário (ms monotônico) do alerta estimado. A janela de chegada vale até o centro da parada
     * (trilhos/trilha) ou até a borda do raio (linha reta, [radiusUsedMeters] > 0). O alerta deve
     * ocorrer ao alcançar o raio efetivo, então recua (raio efetivo − raio já descontado) ÷ velocidade
     * a partir da chegada MAIS CEDO plausível: em dúvida, avisa antes e não depois de descer.
     */
    fun alertAtMs(arrivalEarliestMs: Long, effectiveRadiusMeters: Double, radiusUsedMeters: Int, speedMps: Double): Long {
        val metersBefore = max(0.0, effectiveRadiusMeters - radiusUsedMeters)
        return arrivalEarliestMs - (metersBefore / max(speedMps, MIN_SPEED_MPS) * 1000.0).toLong()
    }
}
