@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pdfpro.app

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var mergeList by remember { mutableStateOf<List<Uri>?>(null) }
    var camList by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var camPending by remember { mutableStateOf<Uri?>(null) }
    var camDialog by remember { mutableStateOf(false) }

    val openPdf = rememberLauncherForActivityResult(OpenPdfContract()) { uri ->
        if (uri != null) vm.open(uri)
    }
    val mergePick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l ->
        if (l.size >= 2) mergeList = l else if (l.isNotEmpty()) vm.message = "Escolha pelo menos 2 PDFs"
    }
    val imgPick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { l ->
        if (l.isNotEmpty()) vm.imagesToPdf(l)
    }
    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) camPending?.let { camList = camList + it }
        if (camList.isNotEmpty()) camDialog = true
    }

    fun shoot() {
        val dir = File(ctx.cacheDir, "cam").apply { mkdirs() }
        val f = File(dir, "foto_${System.nanoTime()}.jpg")
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        camPending = uri
        camLauncher.launch(uri)
    }

    Scaffold(topBar = { TopAppBar(title = { Text("PDF Pro") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeCard(Icons.Default.FolderOpen, "Abrir PDF", Modifier.weight(1f)) {
                    openPdf.launch(arrayOf("application/pdf"))
                }
                HomeCard(Icons.Default.Layers, "Mesclar PDFs", Modifier.weight(1f)) {
                    mergePick.launch(arrayOf("application/pdf"))
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeCard(Icons.Default.Image, "Imagens → PDF", Modifier.weight(1f)) {
                    imgPick.launch("image/*")
                }
                HomeCard(Icons.Default.PhotoCamera, "Foto → PDF", Modifier.weight(1f)) {
                    camList = emptyList()
                    shoot()
                }
            }
            Text(
                "Recentes",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
            )
            if (vm.recents.isEmpty()) {
                Text("Nenhum arquivo recente.")
            } else {
                LazyColumn {
                    items(vm.recents, key = { it.uri }) { r ->
                        ListItem(
                            headlineContent = { Text(r.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            supportingContent = { Text("parou na página ${r.page + 1}") },
                            leadingContent = { Icon(Icons.Default.PictureAsPdf, null) },
                            trailingContent = {
                                IconButton(onClick = { vm.removeRecent(r.uri) }) {
                                    Icon(Icons.Default.Close, "Remover")
                                }
                            },
                            modifier = Modifier.clickable { vm.open(Uri.parse(r.uri)) }
                        )
                    }
                }
            }
        }
    }

    mergeList?.let { MergeDialog(vm, it) { mergeList = null } }

    if (camDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { camDialog = false; camList = emptyList() },
            title = { Text("${camList.size} foto(s) adicionada(s)") },
            text = { Text("Quer fotografar mais páginas ou criar o PDF agora?") },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    camDialog = false
                    val l = camList
                    camList = emptyList()
                    vm.imagesToPdf(l)
                }) { Text("Criar PDF") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = {
                    camDialog = false
                    shoot()
                }) { Text("Outra foto") }
            }
        )
    }
}

@Composable
private fun HomeCard(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier) {
        Column(
            Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, null, Modifier.size(32.dp))
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}
