# QuadroDoc – projeto Android Studio

App Android (Kotlin) que embute o QuadroDoc.html original num WebView, mantendo todas as funções,
com adaptações nativas:

- Nova Foto: galeria ou câmera.
- Salvar/Abrir Projeto (.json), Exportar PNG e Exportar PDF: abrem o "Salvar como" do Android.
- alert / confirm / prompt: diálogos nativos.
- Arrastar marcadores com o dedo (o HTML original só tratava mouse).
- Dados (fotos, marcadores, templates) salvos em arquivos do app, sem o limite de ~5 MB do localStorage.
- Compartilhar PDF / PNG / projeto direto pelo WhatsApp, e-mail, Drive etc.
- Fotos grandes: o projeto guarda uma versão reduzida (2000 px) para trabalhar; o original fica em arquivo no aparelho e é usado nas exportações PNG/PDF (até 4096 px). O .json leva só a versão reduzida.
- Barra de botões rolável e fixa no topo.
- Zoom por pinça na foto (1 dedo move a foto ampliada; afaste/aproxime 2 dedos de 1x a 6x).
- Botão voltar fecha os modais abertos.

## Como abrir
1. Android Studio (Koala 2024.1 ou mais novo) > File > Open > pasta QuadroDoc.
2. Aguarde o Gradle sincronizar (baixa o Gradle 8.7 automaticamente) e clique em Run.
3. APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Offline
Na primeira compilação o Gradle baixa jsPDF e html2canvas para app/src/main/assets/libs/ (precisa de internet nessa hora) e eles vão dentro do APK; depois o PDF funciona sem internet. Veja LEIA-ME.txt na pasta se o download falhar.

## Onde editar
O app web fica em app/src/main/assets/index.html; ajustes nativos em MainActivity.kt e android-shim.js.
