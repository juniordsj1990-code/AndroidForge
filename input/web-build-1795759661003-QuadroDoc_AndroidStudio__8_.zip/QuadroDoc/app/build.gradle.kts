import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.quadrodoc.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.quadrodoc.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
}

// Baixa jsPDF e html2canvas para assets/libs (uma vez) e embute no APK -> PDF funciona offline
val jsLibs = mapOf(
    "jspdf.umd.min.js" to "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js",
    "html2canvas.min.js" to "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"
)
val downloadJsLibs by tasks.registering {
    val libsDir = layout.projectDirectory.dir("src/main/assets/libs").asFile
    doLast {
        libsDir.mkdirs()
        jsLibs.forEach { (name, url) ->
            val f = File(libsDir, name)
            if (!f.exists() || f.length() < 1000L) {
                try {
                    logger.lifecycle("Baixando $name ...")
                    URL(url).openStream().use { input -> f.outputStream().use { input.copyTo(it) } }
                } catch (e: Exception) {
                    f.delete()
                    logger.warn("AVISO: não foi possível baixar $name (${e.message}). Coloque o arquivo manualmente em ${libsDir.path}; sem ele o PDF exigirá internet.")
                }
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadJsLibs) }
