package com.quadrodoc.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.widget.EditText
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private var pendingBytes: ByteArray? = null

    // Resultado do seletor de arquivos (galeria / câmera / projeto .json)
    private val chooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = filePathCallback
            filePathCallback = null
            if (cb != null) {
                var uris: Array<Uri>? = null
                if (result.resultCode == Activity.RESULT_OK) {
                    uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
                    val cam = cameraUri
                    if (uris == null && cam != null) uris = arrayOf(cam)
                }
                cb.onReceiveValue(uris)
            }
            cameraUri = null
        }

    // Resultado do "Salvar como" (JSON, PNG, PDF)
    private val saveLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val bytes = pendingBytes
            pendingBytes = null
            val uri = result.data?.data
            if (result.resultCode == Activity.RESULT_OK && uri != null && bytes != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    toast("Arquivo salvo")
                } catch (e: Exception) {
                    toast("Erro ao salvar: " + e.message)
                }
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain(APP_HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/photos/", WebViewAssetLoader.PathHandler { path -> photoResponse(path) })
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            builtInZoomControls = false
            textZoom = 100
        }

        webView.addJavascriptInterface(Bridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                localLibrary(request.url)?.let { return it }
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                if (request.url.host == APP_HOST) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (e: ActivityNotFoundException) {
                    // sem app para abrir o link
                }
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback

                val wantsImage = params.acceptTypes.any { it.startsWith("image") }
                val content = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = if (wantsImage) "image/*" else "*/*"
                }
                val chooser = Intent.createChooser(content, "Selecionar arquivo")
                if (wantsImage) {
                    createCameraIntent()?.let {
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(it))
                    }
                }
                return try {
                    chooserLauncher.launch(chooser)
                    true
                } catch (e: ActivityNotFoundException) {
                    filePathCallback = null
                    callback.onReceiveValue(null)
                    false
                }
            }

            // alert() / confirm() / prompt() precisam de implementação nativa no WebView
            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.app_name)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.app_name)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: JsPromptResult
            ): Boolean {
                val input = EditText(this@MainActivity).apply {
                    setText(defaultValue ?: "")
                    setSelection(text.length)
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(message)
                    .setView(input)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }

        // Botão voltar: fecha modais abertos; se não houver, sai do app
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val js = "(function(){" +
                    "var a=document.getElementById('markerModalBg');" +
                    "var b=document.getElementById('tplModalBg');" +
                    "var c=document.getElementById('shareModalBg');" +
                    "var d=document.getElementById('pdfPreviewBg');" +
                    "if(d&&d.classList.contains('show')){closePdfPreview();return true;}" +
                    "if(a&&a.classList.contains('show')){closeMarkerModal();return true;}" +
                    "if(b&&b.classList.contains('show')){closeTemplatesModal();return true;}" +
                    "if(c&&c.classList.contains('show')){closeShareModal();return true;}" +
                    "return false;})()"
                webView.evaluateJavascript(js) { value ->
                    if (value != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        webView.loadUrl("https://$APP_HOST/assets/index.html")
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    /** Serve jsPDF/html2canvas de assets/libs/ (uso offline) se os arquivos existirem. */
    private fun localLibrary(uri: Uri): WebResourceResponse? {
        if (uri.host != "cdnjs.cloudflare.com") return null
        val name = uri.lastPathSegment ?: return null
        return try {
            WebResourceResponse("application/javascript", "UTF-8", assets.open("libs/$name"))
        } catch (e: IOException) {
            null
        }
    }

    private fun createCameraIntent(): Intent? {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) == null) return null
        return try {
            val dir = File(cacheDir, "camera").apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(dir, "IMG_$stamp.jpg")
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            cameraUri = uri
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
            intent
        } catch (e: Exception) {
            null
        }
    }

    /** Fotos originais (resolução total) guardadas em filesDir/photos/<id>. */
    private fun photoFile(id: String): File? {
        if (!Regex("[A-Za-z0-9_-]{1,64}").matches(id)) return null
        return File(File(filesDir, "photos").apply { mkdirs() }, id)
    }

    private fun photoResponse(path: String): WebResourceResponse? {
        val f = photoFile(path) ?: return null
        if (!f.exists()) return null
        val head = ByteArray(12)
        f.inputStream().use { it.read(head) }
        val mime = when {
            head[0] == 0x89.toByte() && head[1] == 0x50.toByte() -> "image/png"
            head[0] == 'R'.code.toByte() && head[8] == 'W'.code.toByte() -> "image/webp"
            head[0] == 'G'.code.toByte() && head[1] == 'I'.code.toByte() -> "image/gif"
            else -> "image/jpeg"
        }
        return WebResourceResponse(mime, null, f.inputStream())
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun storageFile(key: String): File {
        val dir = File(filesDir, "storage").apply { mkdirs() }
        return File(dir, key.replace(Regex("[^A-Za-z0-9_]"), "_") + ".json")
    }

    /** Ponte JS <-> Android (usada por assets/android-shim.js). */
    private inner class Bridge {

        // Substitui o localStorage para as chaves quadrodoc_* (sem limite de ~5 MB)
        @JavascriptInterface
        fun getItem(key: String): String? {
            val f = storageFile(key)
            if (!f.exists()) return null
            val text = f.readText()
            return if (text.isEmpty()) null else text
        }

        @JavascriptInterface
        fun setItem(key: String, value: String) {
            val f = storageFile(key)
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(value)
            if (!tmp.renameTo(f)) {
                f.delete()
                tmp.renameTo(f)
            }
        }

        // Foto original em resolução total (o projeto guarda só a versão reduzida)
        @JavascriptInterface
        fun savePhoto(id: String, base64: String): Boolean {
            return try {
                val f = photoFile(id) ?: return false
                f.writeBytes(Base64.decode(base64, Base64.DEFAULT))
                true
            } catch (e: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun deletePhoto(id: String) {
            photoFile(id)?.delete()
        }

        // Compartilhar (WhatsApp, e-mail, Drive...): grava em cache e abre a folha de compartilhamento
        @JavascriptInterface
        fun shareFile(name: String, mime: String, base64: String) {
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val dir = File(cacheDir, "shared").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val file = File(dir, safe)
                file.writeBytes(bytes)
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, name)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread {
                    try {
                        startActivity(Intent.createChooser(send, "Compartilhar"))
                    } catch (e: ActivityNotFoundException) {
                        toast("Nenhum app disponível para compartilhar")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Erro ao compartilhar: " + e.message) }
            }
        }

        // Substitui os downloads (<a download>): abre o "Salvar como" do Android
        @JavascriptInterface
        fun saveFile(name: String, mime: String, base64: String) {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            runOnUiThread {
                pendingBytes = bytes
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = mime
                    putExtra(Intent.EXTRA_TITLE, name)
                }
                try {
                    saveLauncher.launch(intent)
                } catch (e: ActivityNotFoundException) {
                    pendingBytes = null
                    toast("Nenhum app disponível para salvar arquivos")
                }
            }
        }
    }

    companion object {
        private const val APP_HOST = "appassets.androidplatform.net"
    }
}
