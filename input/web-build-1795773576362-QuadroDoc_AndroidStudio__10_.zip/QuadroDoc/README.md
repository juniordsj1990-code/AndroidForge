# QuadroDoc – projeto Android Studio

App Android (Kotlin) que embute o QuadroDoc.html original num WebView, mantendo todas as funções,
com adaptações nativas:

- Nova Foto: galeria ou câmera.
- Salvar/Abrir Projeto (.json), Exportar PNG e Exportar PDF: abrem o "Salvar como" do Android.
- alert / confirm / prompt: diálogos nativos.
- Arrastar marcadores com o dedo (o HTML original só tratava mouse).
- Dados (fotos, marcadores, templates) salvos em arquivos do app, sem o limite de ~5 MB do localStorage.
- Compartilhar PDF / PNG / projeto direto pelo WhatsApp, e-mail, Drive etc.
- Fotos grandes: o projeto guarda uma versão reduzida (2000 px) para trabalhar; o original fica em arquivo no aparelho e é usado nas exportações PNG/PDF (até 4096 px). O .json leva só a versão reduzida.
- Barra de botões rolável e fixa no topo.
- Zoom por pinça na foto (1 dedo move a foto ampliada; afaste/aproxime 2 dedos de 1x a 6x).
- Botão voltar fecha os modais abertos.
- ✂️ Recortar detalhe: selecione uma área da foto (arraste; ajuste pelos cantos ou mova) e o app cria uma NOVA foto só com esse pedaço, logo após a foto de origem, com identificação/descrição próprias e entrando no PDF. O recorte sai do original em alta resolução quando existir. Se houver marcadores dentro da área, o app pergunta se deseja copiá-los (renumerados a partir de 01, posições recalculadas); a foto original não muda.
- Pré-visualização do PDF: ao tocar em PDF (ou Compartilhar > Relatório em PDF) o app gera as páginas e mostra uma pré-visualização rolável (toque numa página para ampliar); só depois você escolhe Salvar PDF, Compartilhar ou Cancelar. O botão voltar fecha a pré-visualização.
- PDF paginado: cada página do relatório é A4 sem esticar/achatar nada. Se foto + identificação não cabem juntas, a foto ocupa a largura toda (proporção original) e os itens de identificação continuam nas páginas seguintes; a descrição dos componentes também quebra em quantas páginas forem necessárias, sem cortar item ao meio.

## Como abrir
1. Android Studio (Koala 2024.1 ou mais novo) > File > Open > pasta QuadroDoc.
2. Aguarde o Gradle sincronizar (baixa o Gradle 8.7 automaticamente) e clique em Run.
3. APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Offline
Na primeira compilação o Gradle baixa jsPDF e html2canvas para app/src/main/assets/libs/ (precisa de internet nessa hora) e eles vão dentro do APK; depois o PDF funciona sem internet. Veja LEIA-ME.txt na pasta se o download falhar.

## Onde editar
O app web fica em app/src/main/assets/index.html; ajustes nativos em MainActivity.kt e android-shim.js.
