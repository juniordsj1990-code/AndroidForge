package br.com.alertageografico.ui

import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import java.util.Locale
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Slider
import androidx.compose.material3.RadioButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import br.com.alertageografico.R

/** Ícone vetorial do app (res/drawable/ic_ui_*), tingido pela cor de conteúdo atual. */
@Composable
fun AgIcon(
    @DrawableRes id: Int,
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    tint: Color = LocalContentColor.current,
    contentDescription: String? = null
) {
    Icon(painterResource(id), contentDescription, modifier.size(size), tint)
}

/** Título de grupo de configurações (substitui os títulos em caixa alta soltos). */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier = modifier.padding(top = 10.dp, bottom = 2.dp),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary
    )
}

/** Texto de apoio longo recolhido em 2 linhas, com "Mostrar mais". Evita paredes de texto nas telas de configuração. */
@Composable
fun ExpandableHelp(text: String, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Column(modifier.animateContentSize()) {
        Text(
            text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = if (expanded) Int.MAX_VALUE else 2,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            if (expanded) "Mostrar menos" else "Mostrar mais",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .clickable { expanded = !expanded }
                .padding(vertical = 4.dp)
        )
    }
}

/** Pílula de estado: verde pulsante quando monitorando, neutra em espera. */
@Composable
fun StatusPill(active: Boolean, modifier: Modifier = Modifier) {
    val container = if (active) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh
    val content = if (active) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
    val transition = rememberInfiniteTransition(label = "statusPill")
    val dotAlpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "statusDot"
    )
    Surface(modifier = modifier, shape = CircleShape, color = container) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                Modifier
                    .size(7.dp)
                    .alpha(if (active) dotAlpha else 1f)
                    .background(content, CircleShape)
            )
            Text(if (active) "Monitorando" else "Em espera", style = MaterialTheme.typography.labelMedium, color = content)
        }
    }
}

/** Cartão principal da tela Início: próxima parada, distância, tempo e botão iniciar/parar. */
@Composable
fun MonitoringHero(
    monitoring: Boolean,
    overline: String,
    title: String,
    distanceValue: String,
    distanceUnit: String,
    distanceCaption: String,
    etaValue: String,
    etaCaption: String,
    progress: Float?,
    progressCaption: String?,
    finalStop: String? = null,
    finalStopDetail: String? = null,
    distanceMeters: Int? = null,
    etaArrival: String? = null,
    helper: String?,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    // Distância "rola" até o novo valor em vez de saltar; o progresso do roteiro desliza.
    val animatedMeters by animateIntAsState(targetValue = distanceMeters ?: 0, animationSpec = tween(800, easing = FastOutSlowInEasing), label = "heroDistance")
    val animatedProgress by animateFloatAsState(targetValue = progress ?: 0f, animationSpec = tween(600, easing = FastOutSlowInEasing), label = "heroProgress")
    // Toque no tempo estimado alterna entre "daqui a X min" e o horário previsto de chegada.
    var showArrival by rememberSaveable { mutableStateOf(false) }
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.fillMaxWidth().animateContentSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    overline.uppercase(),
                    modifier = Modifier.weight(1f).padding(end = 8.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                StatusPill(active = monitoring)
            }
            Text(title, style = MaterialTheme.typography.headlineSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (!finalStop.isNullOrBlank()) {
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AgIcon(R.drawable.ic_ui_pin, size = 16.dp, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 2.dp))
                    Column {
                        Text(
                            "Parada final: $finalStop",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (!finalStopDetail.isNullOrBlank()) {
                            Text(finalStopDetail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }
            // Sem monitoramento não há distância nem tempo a mostrar: o cartão fica enxuto.
            if (monitoring) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                Column(Modifier.weight(1f)) {
                    val useMeters = distanceMeters != null && distanceMeters >= 0
                    val shownValue = if (!useMeters) distanceValue
                        else if (animatedMeters >= 1000) String.format(Locale.getDefault(), "%.1f", animatedMeters / 1000.0)
                        else "$animatedMeters"
                    val shownUnit = if (!useMeters) distanceUnit else if (animatedMeters >= 1000) "km" else "m"
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            shownValue,
                            style = MaterialTheme.typography.displayMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        if (shownUnit.isNotEmpty()) {
                            Text(
                                shownUnit,
                                modifier = Modifier.padding(start = 4.dp, bottom = 6.dp),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Text(distanceCaption, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                val arrivalVisible = showArrival && etaArrival != null
                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(enabled = etaArrival != null) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            showArrival = !showArrival
                        }
                        .padding(vertical = 2.dp)
                ) {
                    AnimatedContent(
                        targetState = if (arrivalVisible) etaArrival.orEmpty() else etaValue,
                        transitionSpec = {
                            (fadeIn(tween(220)) + slideInVertically(tween(220)) { it / 3 }) togetherWith
                                (fadeOut(tween(160)) + slideOutVertically(tween(160)) { -it / 3 })
                        },
                        label = "heroEta"
                    ) { value -> Text(value, style = MaterialTheme.typography.titleLarge) }
                    val caption = if (arrivalVisible) "chegada prevista" else etaCaption
                    if (caption.isNotEmpty()) {
                        Text(caption, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (progress != null) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                        color = MaterialTheme.colorScheme.secondary,
                        trackColor = MaterialTheme.colorScheme.outlineVariant
                    )
                    if (progressCaption != null) {
                        Text(progressCaption, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (!helper.isNullOrBlank()) ExpandableHelp(helper)
            Button(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onToggle()
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = if (monitoring) ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                ) else ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                AgIcon(if (monitoring) R.drawable.ic_ui_stop else R.drawable.ic_ui_play, size = 20.dp)
                Spacer(Modifier.width(8.dp))
                Text(if (monitoring) "Parar monitoramento" else "Iniciar monitoramento", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

/** Linha do tempo vertical: estação anterior, atual (estimada) e próxima. */
@Composable
fun StationTimelineCard(
    title: String,
    subtitle: String?,
    previous: String?,
    current: String?,
    next: String?,
    message: String?,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AgIcon(R.drawable.ic_ui_train, tint = MaterialTheme.colorScheme.primary)
                Column {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    if (!subtitle.isNullOrBlank()) {
                        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (message != null) {
                Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Column {
                    TimelineRow("Anterior", previous ?: "Não identificada", MaterialTheme.colorScheme.outline, false, true)
                    TimelineRow(if (current != null) "Atual (estimada)" else "Em trânsito", current ?: "Entre as estações", MaterialTheme.colorScheme.primary, true, true)
                    TimelineRow("Próxima", next ?: "Não identificada", MaterialTheme.colorScheme.secondary, false, false)
                }
                Text(
                    "Estimativa por GPS; pode variar em linhas paralelas, ramificações ou túneis.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun TimelineRow(label: String, name: String, dot: Color, highlight: Boolean, lineBelow: Boolean) {
    // Ponto muda de cor/tamanho com transição e o ponto atual pulsa de leve.
    val dotColor by animateColorAsState(dot, tween(400), label = "timelineDotColor")
    val dotSize by animateDpAsState(if (highlight) 14.dp else 10.dp, tween(400), label = "timelineDotSize")
    val pulse = rememberInfiniteTransition(label = "timelinePulse")
    val pulseScale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "timelinePulseScale"
    )
    Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(Modifier.fillMaxHeight().width(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(4.dp))
            Box(Modifier.size(dotSize).scale(if (highlight) pulseScale else 1f).background(dotColor, CircleShape))
            if (lineBelow) Box(Modifier.width(2.dp).weight(1f).background(MaterialTheme.colorScheme.outlineVariant))
        }
        Column(Modifier.padding(bottom = if (lineBelow) 14.dp else 0.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            // Troca de estação: o nome antigo sobe e o novo entra por baixo.
            AnimatedContent(
                targetState = name,
                transitionSpec = {
                    (fadeIn(tween(260)) + slideInVertically(tween(260)) { it / 2 }) togetherWith
                        (fadeOut(tween(160)) + slideOutVertically(tween(160)) { -it / 2 })
                },
                label = "timelineName"
            ) { value ->
                Text(
                    value,
                    style = if (highlight) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}

/** Bloco de métrica compacto: ícone + valor + rótulo. */
@Composable
fun StatTile(@DrawableRes icon: Int, value: String, label: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AgIcon(icon, size = 20.dp, tint = MaterialTheme.colorScheme.primary)
            Column {
                Text(value, style = MaterialTheme.typography.titleLarge)
                Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** Atalho para o mapa. */
@Composable
fun MapShortcutCard(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f), modifier = Modifier.size(44.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    AgIcon(R.drawable.ic_ui_map, tint = MaterialTheme.colorScheme.primary)
                }
            }
            Column(Modifier.weight(1f)) {
                Text("Mapa e malha ferroviária", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text("Destinos, raios de alerta, estações e linhas", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
            }
            AgIcon(R.drawable.ic_ui_arrow_right, tint = MaterialTheme.colorScheme.onPrimaryContainer)
        }
    }
}

/** Cabeçalho do menu lateral com o logotipo do app. */
@Composable
fun DrawerHeader(versionName: String, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 28.dp, bottom = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF0D1B33)),
            contentAlignment = Alignment.Center
        ) {
            Image(painterResource(R.drawable.ic_launcher_foreground), contentDescription = null, modifier = Modifier.size(64.dp))
        }
        Column {
            Text("Alerta Geográfico", style = MaterialTheme.typography.titleMedium)
            Text("Versão $versionName", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Tela de abertura animada: logotipo com ondas de sinal (mesma linguagem visual do ícone). */
@Composable
fun IntroScreen(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "intro")
    val wave1 by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing)),
        label = "wave1"
    )
    val wave2 by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), initialStartOffset = StartOffset(750)),
        label = "wave2"
    )
    val breathe by transition.animateFloat(
        initialValue = 0.97f, targetValue = 1.03f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe"
    )
    val ringColor = MaterialTheme.colorScheme.tertiary
    Box(modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    listOf(wave1, wave2).forEach { p ->
                        drawCircle(
                            color = ringColor.copy(alpha = (1f - p) * 0.35f),
                            radius = size.minDimension / 2f * (0.3f + 0.7f * p),
                            style = Stroke(width = 2.5.dp.toPx())
                        )
                    }
                }
                Image(
                    painterResource(R.drawable.ic_launcher_foreground),
                    contentDescription = null,
                    modifier = Modifier.size(170.dp).scale(breathe)
                )
            }
            Spacer(Modifier.height(8.dp))
            Text("Alerta Geográfico", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text(
                "Sua próxima parada, no momento certo.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

/** Cartão de configurações que pode ser recolhido tocando no cabeçalho. O estado sobrevive a rotação e rolagem. */
@Composable
fun CollapsibleCard(
    title: String,
    modifier: Modifier = Modifier,
    defaultExpanded: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by rememberSaveable(title) { mutableStateOf(defaultExpanded) }
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                AgIcon(
                    if (expanded) R.drawable.ic_ui_chevron_up else R.drawable.ic_ui_chevron_down,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            AnimatedVisibility(visible = expanded) {
                Column(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    content = content
                )
            }
        }
    }
}


// ---------------------------------------------------------------------------------------------
// Componentes de configurações (estilo "Configurações" do Android): grupos em cartão, linhas com
// título + valor, interruptores e escolhas em diálogo.
// ---------------------------------------------------------------------------------------------

/** Grupo de configurações: título pequeno acima de um cartão com linhas separadas por divisórias. */
@Composable
fun SettingsGroup(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 16.dp, top = 4.dp)
        )
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
        ) {
            Column(Modifier.fillMaxWidth(), content = content)
        }
    }
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 16.dp),
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
    )
}

/** Linha com interruptor: tocar em qualquer parte da linha alterna. */
@Composable
fun SettingsSwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    subtitle: String? = null,
    enabled: Boolean = true,
    showDivider: Boolean = true
) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(enabled = enabled) { onCheckedChange(!checked) }
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.bodyLarge)
                if (subtitle != null) {
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Switch(checked = checked, onCheckedChange = null, enabled = enabled)
        }
        if (showDivider) SettingsDivider()
    }
}

/** Linha tocável: título, valor atual em destaque, texto de apoio e seta (ou um botão à direita). */
@Composable
fun SettingsValueRow(
    title: String,
    onClick: () -> Unit,
    value: String? = null,
    subtitle: String? = null,
    trailing: (@Composable () -> Unit)? = null,
    @DrawableRes leadingIcon: Int? = null,
    showDivider: Boolean = true
) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (leadingIcon != null) {
                AgIcon(leadingIcon, size = 24.dp, tint = MaterialTheme.colorScheme.primary)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.bodyLarge)
                if (value != null) Text(value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                if (subtitle != null) {
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (trailing != null) trailing()
            else AgIcon(R.drawable.ic_ui_arrow_right, size = 18.dp, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (showDivider) SettingsDivider()
    }
}

/** Linha com controle deslizante (ex.: volume). */
@Composable
fun SettingsSliderRow(
    title: String,
    valueLabel: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    enabled: Boolean = true,
    showDivider: Boolean = true
) {
    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, style = MaterialTheme.typography.bodyLarge)
                Text(valueLabel, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
            }
            Slider(
                value = value,
                onValueChange = onValueChange,
                onValueChangeFinished = onValueChangeFinished,
                valueRange = 0f..1f,
                enabled = enabled
            )
        }
        if (showDivider) SettingsDivider()
    }
}

/** Diálogo de escolha única, com botões de opção. */
@Composable
fun SettingsChoiceDialog(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit,
    message: String? = null
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                if (message != null) {
                    Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                options.forEach { (key, label) ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelect(key) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = key == selected, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(label, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}


/** Seletor de ícone de destino/roteiro: linha rolável de círculos com os ícones vetoriais. */
@Composable
fun IconPickerRow(
    selected: String?,
    onSelect: (String) -> Unit,
    fallback: String = AppIcons.DEFAULT_DESTINATION
) {
    val current = AppIcons.normalize(selected, fallback)
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
    ) {
        AppIcons.all.forEach { entry ->
            val isSelected = entry.key == current
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceContainerHigh
                    )
                    .clickable { onSelect(entry.key) },
                contentAlignment = Alignment.Center
            ) {
                AgIcon(
                    entry.res,
                    size = 24.dp,
                    tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    contentDescription = entry.label
                )
            }
        }
    }
}

/** Indicador de passos (1 Local, 2 Tipo e raio, 3 Alertas) com barra de progresso. */
@Composable
fun StepIndicator(current: Int, labels: List<String>) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            labels.forEachIndexed { index, label ->
                val done = index < current
                val active = index == current
                Column(
                    Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(
                                if (done || active) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceContainerHighest
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (done) {
                            AgIcon(R.drawable.ic_ui_check, size = 16.dp, tint = MaterialTheme.colorScheme.onPrimary)
                        } else {
                            Text(
                                "${index + 1}",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Text(
                        label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        LinearProgressIndicator(
            progress = { (current + 1).toFloat() / labels.size },
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50))
        )
    }
}

/** Versão em grade do seletor de ícones (para diálogos). */
@Composable
fun IconPickerGrid(
    selected: String?,
    onSelect: (String) -> Unit,
    columns: Int = 5,
    fallback: String = AppIcons.DEFAULT_ROUTE
) {
    val current = AppIcons.normalize(selected, fallback)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        AppIcons.all.chunked(columns).forEach { rowEntries ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                rowEntries.forEach { entry ->
                    val isSelected = entry.key == current
                    Box(
                        Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                            .clickable { onSelect(entry.key) },
                        contentAlignment = Alignment.Center
                    ) {
                        AgIcon(
                            entry.res,
                            size = 24.dp,
                            tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            contentDescription = entry.label
                        )
                    }
                }
            }
        }
    }
}
