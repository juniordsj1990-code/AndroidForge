package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProximityEngineTest {
    private val dest = Destination(id = "a", name = "A", latitude = -23.0, longitude = -46.0, radiusMeters = 200)

    // ~1 grau de latitude = 111,2 km → 0,001° ≈ 111 m
    private fun fixAt(dLat: Double, accuracy: Float = 10f) = Fix(dest.latitude + dLat, dest.longitude, accuracy)

    @Test fun triggersOnceWhenEntering() {
        val e = ProximityEngine()
        assertTrue(e.process(fixAt(0.01), listOf(dest)).triggered.isEmpty())
        assertEquals(1, e.process(fixAt(0.0005), listOf(dest)).triggered.size)
        assertTrue(e.process(fixAt(0.0004), listOf(dest)).triggered.isEmpty())
    }

    @Test fun rearmsOnlyAfterLeavingWithMargin() {
        val e = ProximityEngine()
        e.process(fixAt(0.0), listOf(dest))
        assertTrue(e.process(fixAt(0.0020), listOf(dest)).triggered.isEmpty()) // ~222 m: ainda na margem
        assertTrue(e.process(fixAt(0.0), listOf(dest)).triggered.isEmpty())    // não rearmou
        e.process(fixAt(0.01), listOf(dest))                                    // saiu de vez
        assertEquals(1, e.process(fixAt(0.0), listOf(dest)).triggered.size)
    }

    @Test fun poorAccuracyNeverTriggers() {
        val e = ProximityEngine()
        assertTrue(e.process(fixAt(0.0, accuracy = 400f), listOf(dest)).triggered.isEmpty())
        assertTrue(e.process(fixAt(0.0, accuracy = 400f), listOf(dest)).lowAccuracy)
    }

    @Test fun validFixInsideRadiusTriggersImmediatelyEvenWithMediocreAccuracy() {
        val e = ProximityEngine()
        assertEquals(1, e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.size)
        assertTrue(e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.isEmpty())
    }

    @Test fun reentryTriggersOnlyAfterLeavingRearmMargin() {
        val e = ProximityEngine()
        assertEquals(1, e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.size)
        assertTrue(e.process(fixAt(0.01, accuracy = 60f), listOf(dest)).triggered.isEmpty())
        assertEquals(1, e.process(fixAt(0.0, accuracy = 60f), listOf(dest)).triggered.size)
    }

    @Test fun disabledDestinationsAreIgnored() {
        val e = ProximityEngine()
        val r = e.process(fixAt(0.0), listOf(dest.copy(enabled = false)))
        assertTrue(r.triggered.isEmpty())
        assertNull(r.nearestEdgeMeters)
    }

    @Test fun nearestEdgeIsZeroInsideAndPositiveOutside() {
        val e = ProximityEngine()
        assertEquals(0.0, e.process(fixAt(0.0), listOf(dest)).nearestEdgeMeters!!, 0.001)
        val far = e.process(fixAt(0.01), listOf(dest)).nearestEdgeMeters
        assertNotNull(far)
        assertTrue(far!! in 880.0..920.0) // ~1112 m − 200 m
    }

    @Test fun intervalScalesWithDistance() {
        assertEquals(60_000L, ProximityEngine.recommendedIntervalMs(null))
        assertEquals(60_000L, ProximityEngine.recommendedIntervalMs(50_000.0))
        assertEquals(3_000L, ProximityEngine.recommendedIntervalMs(0.0))
        assertEquals(3_000L, ProximityEngine.recommendedIntervalMs(200.0))
        assertEquals(11_111L, ProximityEngine.recommendedIntervalMs(1_000.0))
    }
}
