package br.com.alertageografico

import org.json.JSONObject
import java.util.UUID

data class Destination(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val radiusMeters: Int = 300,
    val message: String = "Você está chegando ao destino",
    val enabled: Boolean = true,
    val itineraryName: String? = null,
    /** Se verdadeiro, o destino é desativado automaticamente após o primeiro alerta. */
    val oneShot: Boolean = false,
    /** Nome legível do local/endereço informado pelo usuário. */
    val locationLabel: String? = null,
    /** Emoji escolhido pelo usuário para identificar visualmente o destino. */
    val icon: String = "📍"
) {
    fun toJson() = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("latitude", latitude)
        put("longitude", longitude)
        put("radiusMeters", radiusMeters)
        put("message", message)
        put("enabled", enabled)
        put("itineraryName", itineraryName)
        put("oneShot", oneShot)
        put("locationLabel", locationLabel)
        put("icon", icon)
    }

    companion object {
        fun fromJson(o: JSONObject) = Destination(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.getString("name"),
            latitude = o.getDouble("latitude"),
            longitude = o.getDouble("longitude"),
            radiusMeters = o.optInt("radiusMeters", 300),
            message = o.optString("message", "Você está chegando ao destino"),
            enabled = o.optBoolean("enabled", true),
            itineraryName = o.optString("itineraryName", "").takeIf { it.isNotBlank() && it != "null" },
            oneShot = o.optBoolean("oneShot", false),
            locationLabel = o.optString("locationLabel", "").takeIf { it.isNotBlank() && it != "null" },
            icon = o.optString("icon", "📍").ifBlank { "📍" }
        )
    }
}
