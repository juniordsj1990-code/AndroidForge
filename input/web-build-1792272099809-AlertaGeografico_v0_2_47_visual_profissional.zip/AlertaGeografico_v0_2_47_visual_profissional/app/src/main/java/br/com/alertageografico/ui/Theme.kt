package br.com.alertageografico.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Identidade visual do Alerta Geográfico.
 *
 * - Fundo grafite-azulado escuro (conforto visual em ambientes pouco iluminados, como trens à noite).
 * - Turquesa = ação/identidade; âmbar = próxima parada e números de destaque;
 *   verde = monitoramento ativo; vermelho = somente alerta disparado ou parar.
 */
object AgColors {
    val Background = Color(0xFF0D1418)
    val Surface = Color(0xFF131C21)
    val SurfaceLow = Color(0xFF111A1F)
    val SurfaceMid = Color(0xFF16222A)
    val SurfaceHigh = Color(0xFF1C2A33)
    val SurfaceHighest = Color(0xFF233440)
    val Outline = Color(0xFF3A4C56)
    val OutlineVariant = Color(0xFF26343C)
    val OnSurface = Color(0xFFE3EAEE)
    val OnSurfaceVariant = Color(0xFF9FB3BD)

    val Teal = Color(0xFF78C7C8)
    val TealContainer = Color(0xFF173A40)
    val Amber = Color(0xFFF2C562)
    val AmberContainer = Color(0xFF3B3118)
    val Success = Color(0xFF3FD29B)
    val SuccessContainer = Color(0xFF12332C)
    val Danger = Color(0xFFFF8A90)
    val DangerContainer = Color(0xFF3A1F24)
}

private val AgColorScheme = darkColorScheme(
    primary = AgColors.Teal,
    onPrimary = Color(0xFF06282B),
    primaryContainer = AgColors.TealContainer,
    onPrimaryContainer = Color(0xFFCDEEEF),
    secondary = AgColors.Amber,
    onSecondary = Color(0xFF3A2C00),
    secondaryContainer = AgColors.AmberContainer,
    onSecondaryContainer = Color(0xFFFBE3A8),
    tertiary = AgColors.Success,
    onTertiary = Color(0xFF003827),
    tertiaryContainer = AgColors.SuccessContainer,
    onTertiaryContainer = Color(0xFF9BEBCB),
    background = AgColors.Background,
    onBackground = AgColors.OnSurface,
    surface = AgColors.Surface,
    onSurface = AgColors.OnSurface,
    surfaceVariant = AgColors.SurfaceHigh,
    onSurfaceVariant = AgColors.OnSurfaceVariant,
    surfaceTint = AgColors.Teal,
    error = AgColors.Danger,
    onError = Color(0xFF4A0A10),
    errorContainer = AgColors.DangerContainer,
    onErrorContainer = Color(0xFFFFB3B8),
    outline = AgColors.Outline,
    outlineVariant = AgColors.OutlineVariant,
    surfaceContainerLowest = Color(0xFF0A1013),
    surfaceContainerLow = AgColors.SurfaceLow,
    surfaceContainer = AgColors.SurfaceMid,
    surfaceContainerHigh = AgColors.SurfaceHigh,
    surfaceContainerHighest = AgColors.SurfaceHigh
)

private val Sans = FontFamily.SansSerif

/** Dígitos tabulares ("tnum") nos números grandes evitam que o valor "pule" a cada atualização do GPS. */
val AgTypography = Typography(
    displayMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 44.sp, lineHeight = 48.sp, letterSpacing = (-0.5).sp, fontFeatureSettings = "tnum"),
    headlineMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 28.sp, lineHeight = 34.sp, fontFeatureSettings = "tnum"),
    headlineSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 22.sp, lineHeight = 28.sp),
    titleLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 20.sp, lineHeight = 26.sp, fontFeatureSettings = "tnum"),
    titleMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 22.sp, letterSpacing = 0.1.sp),
    titleSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp),
    bodyLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp),
    labelMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.3.sp),
    labelSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 16.sp, letterSpacing = 0.8.sp)
)

private val AgShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun AgTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AgColorScheme,
        typography = AgTypography,
        shapes = AgShapes,
        content = content
    )
}
