package br.com.alertageografico

import android.location.Location
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Estado de confiança da estimativa offline de chegada. */
enum class EtaConfidence(val storageValue: String) {
    NORMAL("normal"),
    PAUSED("paused"),
    LOW("low_confidence"),
    UNAVAILABLE("unavailable")
}

data class EtaEstimate(
    val distanceMeters: Int,
    val minMinutes: Int,
    val maxMinutes: Int,
    val confidence: EtaConfidence,
    val filteredSpeedMps: Double?,
    val updatedAtMillis: Long
)

/**
 * Estimativa offline com validação temporal, filtro robusto de velocidade,
 * retenção temporária durante pausas e suavização do intervalo apresentado.
 * Não participa da decisão de proximidade/alerta.
 */
class OfflineEtaEstimator {
    private data class SpeedSample(val timestamp: Long, val speedMps: Double)
    private data class PositionSample(val timestamp: Long, val latitude: Double, val longitude: Double)

    private val speedSamples = ArrayDeque<SpeedSample>()
    private var previousPosition: PositionSample? = null
    private var pauseStartedAt: Long? = null
    private var smoothedSpeed: Double? = null
    private var smoothedMinSeconds: Double? = null
    private var smoothedMaxSeconds: Double? = null
    private var lastValidEstimate: EtaEstimate? = null

    fun reset() {
        speedSamples.clear()
        previousPosition = null
        pauseStartedAt = null
        smoothedSpeed = null
        smoothedMinSeconds = null
        smoothedMaxSeconds = null
        lastValidEstimate = null
    }

    fun update(
        location: Location,
        distanceToCenterMeters: Double,
        radiusMeters: Int,
        nowMillis: Long = System.currentTimeMillis()
    ): EtaEstimate {
        val remaining = max(0.0, distanceToCenterMeters - radiusMeters).toInt()
        val stale = location.time <= 0L || nowMillis - location.time > MAX_FIX_AGE_MS || location.time - nowMillis > FUTURE_FIX_TOLERANCE_MS
        val accuracy = if (location.hasAccuracy()) location.accuracy else Float.POSITIVE_INFINITY
        val positionUsable = !stale && accuracy <= MAX_HORIZONTAL_ACCURACY_M

        if (!positionUsable) return retainedEstimate(remaining, nowMillis, EtaConfidence.LOW)

        // A distância dentro do raio do destino significa chegada, mesmo se o usuário estiver parado.
        if (remaining == 0) {
            val arrived = EtaEstimate(0, 0, 0, EtaConfidence.NORMAL, smoothedSpeed, nowMillis)
            lastValidEstimate = arrived
            smoothedMinSeconds = 0.0
            smoothedMaxSeconds = 0.0
            previousPosition = PositionSample(location.time, location.latitude, location.longitude)
            return arrived
        }

        val currentPosition = PositionSample(location.time, location.latitude, location.longitude)
        val priorPosition = previousPosition
        var displacementSpeed: Double? = null
        if (priorPosition != null) {
            val elapsed = (currentPosition.timestamp - priorPosition.timestamp) / 1000.0
            if (elapsed >= MIN_POSITION_DELTA_SECONDS && elapsed <= MAX_POSITION_DELTA_SECONDS) {
                val traveled = ProximityEngine.distanceMeters(
                    priorPosition.latitude, priorPosition.longitude,
                    currentPosition.latitude, currentPosition.longitude
                )
                val derived = traveled / elapsed
                // Um salto incompatível é tratado como posição suspeita, não como movimento real.
                if (derived <= MAX_PLAUSIBLE_SPEED_MPS) displacementSpeed = derived
            }
        }
        previousPosition = currentPosition

        val reportedSpeed = if (location.hasSpeed()) location.speed.toDouble() else null
        val speedAccuracyOk = !location.hasSpeedAccuracy() || location.speedAccuracyMetersPerSecond <= MAX_SPEED_ACCURACY_MPS
        var candidate = when {
            reportedSpeed != null && reportedSpeed.isFinite() && reportedSpeed in 0.0..MAX_PLAUSIBLE_SPEED_MPS && speedAccuracyOk -> reportedSpeed
            displacementSpeed != null -> displacementSpeed
            else -> null
        }

        val medianBefore = median(speedSamples.map { it.speedMps })
        if (candidate != null && medianBefore != null && candidate > PAUSE_SPEED_MPS) {
            val allowedDeviation = max(OUTLIER_ABSOLUTE_DEVIATION_MPS, medianBefore * OUTLIER_RELATIVE_FACTOR)
            if (kotlin.math.abs(candidate - medianBefore) > allowedDeviation) candidate = null
        }

        val isPaused = candidate != null && candidate <= PAUSE_SPEED_MPS &&
            (displacementSpeed == null || displacementSpeed <= PAUSE_DISPLACEMENT_SPEED_MPS)
        if (isPaused) {
            if (pauseStartedAt == null) pauseStartedAt = location.time
            val pausedFor = nowMillis - (pauseStartedAt ?: nowMillis)
            val status = if (pausedFor <= PAUSE_HOLD_MS) EtaConfidence.PAUSED else EtaConfidence.LOW
            return retainedEstimate(remaining, nowMillis, status)
        }

        if (candidate == null || candidate <= PAUSE_SPEED_MPS) {
            return retainedEstimate(remaining, nowMillis, EtaConfidence.LOW)
        }

        pauseStartedAt = null
        val sampleTime = location.time
        pruneSamples(sampleTime)
        speedSamples.addLast(SpeedSample(sampleTime, candidate))
        while (speedSamples.size > MAX_SPEED_SAMPLES) speedSamples.removeFirst()

        val medianSpeed = median(speedSamples.map { it.speedMps }) ?: candidate
        val oldSmoothedSpeed = smoothedSpeed
        val filteredSpeed = if (oldSmoothedSpeed == null) medianSpeed
            else oldSmoothedSpeed + SPEED_SMOOTHING_ALPHA * (medianSpeed - oldSmoothedSpeed)
        smoothedSpeed = filteredSpeed

        val values = speedSamples.map { it.speedMps }.sorted()
        val p20 = percentile(values, 0.20) ?: filteredSpeed * 0.85
        val p80 = percentile(values, 0.80) ?: filteredSpeed * 1.15
        // Garante uma margem mínima para não sugerir precisão que o GPS não oferece.
        val slowerSpeed = min(p20, filteredSpeed * MIN_SPEED_MARGIN_FACTOR).coerceAtLeast(MIN_ESTIMATION_SPEED_MPS)
        val fasterSpeed = max(p80, filteredSpeed * MAX_SPEED_MARGIN_FACTOR).coerceAtLeast(slowerSpeed)
        val rawMinSeconds = remaining / fasterSpeed
        val rawMaxSeconds = remaining / slowerSpeed
        val smoothMin = smoothSeconds(smoothedMinSeconds, rawMinSeconds)
        val smoothMax = max(smoothMin, smoothSeconds(smoothedMaxSeconds, rawMaxSeconds))
        smoothedMinSeconds = smoothMin
        smoothedMaxSeconds = smoothMax

        val minMinutes = floor(smoothMin / 60.0).toInt().coerceAtLeast(1)
        val maxMinutes = ceil(smoothMax / 60.0).toInt().coerceAtLeast(minMinutes)
        val estimate = EtaEstimate(remaining, minMinutes, maxMinutes, EtaConfidence.NORMAL, filteredSpeed, nowMillis)
        lastValidEstimate = estimate
        return estimate
    }

    private fun retainedEstimate(remaining: Int, nowMillis: Long, status: EtaConfidence): EtaEstimate {
        val previous = lastValidEstimate
        if (previous == null) {
            return EtaEstimate(remaining, -1, -1, EtaConfidence.UNAVAILABLE, smoothedSpeed, nowMillis)
        }
        // Em estações, túneis e paradas operacionais o GPS pode ficar sem movimento
        // por vários minutos. Preserve a última ETA durante esse período, em vez de
        // trocar imediatamente para "aguardando GPS". A confiança sinaliza que ela
        // está congelada; a distância, porém, acompanha a leitura atual quando disponível.
        if (nowMillis - previous.updatedAtMillis > MAX_RETAINED_ESTIMATE_AGE_MS) {
            return EtaEstimate(remaining, -1, -1, EtaConfidence.UNAVAILABLE, null, nowMillis)
        }
        return previous.copy(distanceMeters = remaining, confidence = status)
    }

    private fun pruneSamples(now: Long) {
        while (speedSamples.isNotEmpty() && now - speedSamples.first().timestamp > SPEED_HISTORY_MS) speedSamples.removeFirst()
    }

    private fun smoothSeconds(previous: Double?, current: Double): Double =
        if (previous == null) current else previous + ETA_SMOOTHING_ALPHA * (current - previous)

    private fun median(values: List<Double>): Double? {
        if (values.isEmpty()) return null
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[middle - 1] + sorted[middle]) / 2.0 else sorted[middle]
    }

    private fun percentile(sortedValues: List<Double>, percentile: Double): Double? {
        if (sortedValues.isEmpty()) return null
        val index = ((sortedValues.size - 1) * percentile).toInt().coerceIn(0, sortedValues.lastIndex)
        return sortedValues[index]
    }

    companion object {
        private const val MAX_FIX_AGE_MS = 30_000L
        private const val FUTURE_FIX_TOLERANCE_MS = 5_000L
        private const val MAX_HORIZONTAL_ACCURACY_M = 50f
        private const val MAX_SPEED_ACCURACY_MPS = 5f
        private const val MAX_PLAUSIBLE_SPEED_MPS = 70.0
        private const val MIN_POSITION_DELTA_SECONDS = 0.5
        private const val MAX_POSITION_DELTA_SECONDS = 60.0
        private const val PAUSE_SPEED_MPS = 0.5
        private const val PAUSE_DISPLACEMENT_SPEED_MPS = 1.0
        private const val PAUSE_HOLD_MS = 10_000L
        private const val MAX_RETAINED_ESTIMATE_AGE_MS = 10 * 60_000L
        private const val SPEED_HISTORY_MS = 30_000L
        private const val MAX_SPEED_SAMPLES = 9
        private const val OUTLIER_ABSOLUTE_DEVIATION_MPS = 8.0
        private const val OUTLIER_RELATIVE_FACTOR = 2.5
        private const val SPEED_SMOOTHING_ALPHA = 0.35
        private const val ETA_SMOOTHING_ALPHA = 0.35
        private const val MIN_ESTIMATION_SPEED_MPS = 0.5
        private const val MIN_SPEED_MARGIN_FACTOR = 0.85
        private const val MAX_SPEED_MARGIN_FACTOR = 1.15
    }
}
