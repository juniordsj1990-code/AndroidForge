package br.com.alertageografico

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Confirma o alerta: remove a notificação e interrompe o som (importante no modo alarme). */
class AlertDismissReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        RoutedAlertSound.stop()
        if (intent.action == ACTION_SNOOZE) {
            val minutes = intent.getIntExtra("minutes", 5).coerceIn(1, 30)
            context.getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE).edit()
                .putLong(DestinationStore.KEY_SNOOZE_UNTIL, System.currentTimeMillis() + minutes * 60_000L).apply()
        }
        val id = intent.getIntExtra("notification_id", -1)
        if (id != -1) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.cancel(id)
        }
    }
    companion object { const val ACTION_SNOOZE = "br.com.alertageografico.action.SNOOZE" }
}
