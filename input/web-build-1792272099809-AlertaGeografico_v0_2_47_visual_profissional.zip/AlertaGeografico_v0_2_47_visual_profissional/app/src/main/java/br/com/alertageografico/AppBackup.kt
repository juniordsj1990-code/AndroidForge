package br.com.alertageografico

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.io.File

/** Exporta configurações, destinos, roteiros e dados ferroviários offline em um único arquivo JSON. */
object AppBackup {
    private const val FORMAT = "alerta-geografico-backup"
    private const val VERSION = 1
    private const val STATIONS_FILE = "osm_stations.geojson"
    private const val ROUTES_FILE = "osm_routes.geojson"

    fun create(context: Context): String {
        val prefs = context.getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
        val prefsJson = JSONObject()
        prefs.all.forEach { (key, value) ->
            val entry = JSONObject()
            when (value) {
                is String -> entry.put("type", "string").put("value", value)
                is Boolean -> entry.put("type", "boolean").put("value", value)
                is Int -> entry.put("type", "int").put("value", value)
                is Long -> entry.put("type", "long").put("value", value)
                is Float -> entry.put("type", "float").put("value", value.toDouble())
                is Set<*> -> entry.put("type", "string_set").put("value", org.json.JSONArray(value.filterIsInstance<String>()))
            }
            if (entry.has("type")) prefsJson.put(key, entry)
        }
        val files = JSONObject()
        listOf(STATIONS_FILE, ROUTES_FILE).forEach { name ->
            val file = File(context.filesDir, name)
            if (file.isFile) files.put(name, Base64.encodeToString(file.readBytes(), Base64.NO_WRAP))
        }
        return JSONObject()
            .put("format", FORMAT)
            .put("version", VERSION)
            .put("created_at", System.currentTimeMillis())
            .put("preferences", prefsJson)
            .put("offline_files_base64", files)
            .toString(2)
    }

    /** Valida o backup integralmente antes de modificar os dados locais. */
    fun validate(raw: String): JSONObject {
        val root = JSONObject(raw)
        require(root.optString("format") == FORMAT) { "Este arquivo não é um backup do Alerta Geográfico." }
        require(root.optInt("version", -1) in 1..VERSION) { "Versão de backup incompatível." }
        require(root.optJSONObject("preferences") != null) { "O backup não contém as configurações." }
        val files = root.optJSONObject("offline_files_base64") ?: JSONObject()
        listOf(STATIONS_FILE, ROUTES_FILE).forEach { name ->
            if (files.has(name)) Base64.decode(files.getString(name), Base64.DEFAULT)
        }
        return root
    }

    fun restore(context: Context, root: JSONObject) {
        val prefsJson = root.getJSONObject("preferences")
        val editor = context.getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE).edit().clear()
        val keys = prefsJson.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val entry = prefsJson.getJSONObject(key)
            when (entry.getString("type")) {
                "string" -> editor.putString(key, entry.getString("value"))
                "boolean" -> editor.putBoolean(key, entry.getBoolean("value"))
                "int" -> editor.putInt(key, entry.getInt("value"))
                "long" -> editor.putLong(key, entry.getLong("value"))
                "float" -> editor.putFloat(key, entry.getDouble("value").toFloat())
                "string_set" -> {
                    val array = entry.getJSONArray("value")
                    editor.putStringSet(key, (0 until array.length()).map { array.getString(it) }.toSet())
                }
            }
        }
        // Não retoma automaticamente um monitoramento que estava ativo no aparelho que gerou o backup.
        editor.putBoolean(DestinationStore.KEY_MONITORING, false)
        editor.apply()

        val files = root.optJSONObject("offline_files_base64") ?: JSONObject()
        listOf(STATIONS_FILE, ROUTES_FILE).forEach { name ->
            val file = File(context.filesDir, name)
            if (files.has(name)) {
                val bytes = Base64.decode(files.getString(name), Base64.DEFAULT)
                val temp = File(context.filesDir, "$name.restore.tmp")
                temp.writeBytes(bytes)
                if (!temp.renameTo(file)) {
                    file.writeBytes(bytes)
                    temp.delete()
                }
            } else {
                file.delete()
            }
        }
    }
}
