plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.com.radaralerta"
    compileSdk = 35

    defaultConfig {
        applicationId = "br.com.radaralerta"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4.0-dev"
    }
}
