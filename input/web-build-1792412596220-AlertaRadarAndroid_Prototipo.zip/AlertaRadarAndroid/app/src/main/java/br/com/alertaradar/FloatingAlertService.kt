package br.com.alertaradar

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface

class FloatingAlertService : Service() {
    private var windowManager: WindowManager? = null
    private var view: TextView? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        val message = intent?.getStringExtra("message") ?: "Radar próximo"
        if (view == null) {
            view = TextView(this).apply {
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.rgb(40, 45, 55))
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(28, 20, 28, 20)
                elevation = 12f
            }
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                       else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 100 }
            windowManager?.addView(view, params)
            view?.setOnClickListener { stopSelf() }
        }
        view?.text = "📷  $message\nToque para fechar"
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        view?.let { windowManager?.removeView(it) }
        view = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
