# Alerta Radar — protótipo Android nativo

Protótipo inicial em Kotlin/Jetpack Compose, com serviço de localização, leitura de base JSON offline, alertas por voz e janela flutuante.

## Importante sobre a base de radares
A base `app/src/main/assets/radares.json` está intencionalmente vazia. O conjunto oficial do DER-SP foi localizado:
https://dadosabertos.sp.gov.br/dataset/radar

O arquivo XLSX indicado pelo portal não pôde ser baixado automaticamente neste ambiente. Portanto, não incluí coordenadas inventadas nem afirmo que os radares do estado já estejam incorporados. Baixe o recurso XLSX no portal, confira os campos e converta os registros com coordenadas para o formato abaixo.

```json
{
  "source": "DER-SP / Dados Abertos SP",
  "source_url": "https://dadosabertos.sp.gov.br/dataset/radar",
  "updated_at": "AAAA-MM-DD",
  "radars": [
    {
      "id": "der-001",
      "lat": -23.5505,
      "lon": -46.6333,
      "type": "Radar fixo",
      "speedLimit": 60,
      "road": "Nome da rodovia",
      "direction": 90
    }
  ]
}
```
O ponto acima é apenas um exemplo de formato e NÃO é um radar real; não o utilize para alertas.

## Abrir o projeto
1. Instale Android Studio e um JDK compatível com a versão do Android Gradle Plugin.
2. Extraia o ZIP e abra a pasta `AlertaRadarAndroid` no Android Studio.
3. Aguarde a sincronização Gradle e instale em um aparelho Android físico para testar GPS e sobreposição.
4. Conceda permissões de localização e, para a janela flutuante, a permissão especial "Exibir sobre outros apps".

## Limitações do protótipo
- Não foi compilado nem testado em aparelho neste ambiente.
- Base oficial ainda não importada; portanto, a contagem inicial é zero e não haverá alertas reais.
- O serviço usa uma busca linear simples e serve apenas para uma primeira prova de conceito; precisa de índice espacial, filtro de sentido robusto e testes antes de uso real.
- A janela flutuante é um aviso simples e desaparece quando o serviço é encerrado.
- Requer ajustes adicionais de permissões e tratamento de restrições de bateria conforme versões e fabricantes.
- Não use durante a condução para testar. Faça testes com passageiro ou com o veículo parado.
