# Diário do Carro — projeto Android inicial

Projeto Kotlin + Jetpack Compose com tema escuro, ícone vetorial, tela de abertura nativa e histórico local SQLite.

Inclui:
- Cadastro de manutenções, defeitos/diagnósticos, peças, documentos/fotos, modificações e lembretes.
- Histórico com pesquisa e exclusão de registros.
- Quilometragem como referência técnica, sem controle de abastecimento.
- Interface em grafite e laranja.

## Abrir
Extraia o ZIP e abra a pasta `DiarioDoCarro` no Android Studio. Aguarde a sincronização do Gradle e execute em dispositivo ou emulador.
Compatibilidade ajustada para ambientes com Gradle 8.9: Android Gradle Plugin 8.7.3, Kotlin 2.1.20 e compileSdk 35. O Android SDK Platform 35 deve estar instalado. O projeto ainda não inclui os arquivos executáveis do Gradle Wrapper; no AndroidForge, utilize a versão Gradle 8.9 do ambiente.

## Compatibilidade da compilação

A configuração foi ajustada para evitar a falha inicial causada pelo Gradle 8.9 incompatível com AGP 8.11.1. Se o ambiente tiver uma versão de Gradle diferente, confira a matriz oficial de compatibilidade do Android Gradle Plugin antes de alterar as versões.

## Próximas melhorias
Esta é uma base inicial. Notificações programadas, seleção real de fotos/arquivos, backup/restauração, edição de registros e persistência da ficha do veículo ainda precisam ser implementadas.
