# ScanPro

App Android (Kotlin + Jetpack Compose) inspirado no CamScanner.

## Como abrir
1. Android Studio (Koala ou mais novo) > **Open** > pasta `ScanPro`
2. Aguarde o Gradle sincronizar (baixa CameraX, OpenCV e ML Kit)
3. Run no celular (Android 8.0+)

## Recursos
- Câmera (CameraX) com flash e modo em lote (várias páginas)
- Importar da galeria (várias imagens)
- Detecção automática das bordas (OpenCV) + ajuste manual dos 4 cantos + correção de perspectiva
- Filtros: Original, Mágico, P&B, Cinza, Brilho
- Girar páginas, assinatura à mão (carimbada na página)
- Pastas, renomear, excluir, buscar por nome
- Reordenar/excluir/reeditar páginas, adicionar páginas a documentos existentes
- OCR offline (ML Kit): copiar e compartilhar o texto
- Exportar PDF (com marca d'água opcional) ou JPG e compartilhar

## Estrutura (app/src/main/java/com/scanpro/app)
- `MainActivity.kt` entrada
- `AppVM.kt` estado e fluxo (captura -> recorte -> edição -> documento)
- `Ui.kt` todas as telas Compose
- `ImageProc.kt` OpenCV (bordas, perspectiva, filtros)
- `Util.kt` OCR, exportação de PDF/JPG, assinatura
- `Data.kt` armazenamento local (JSON + JPG em filesDir)
