package com.scanpro.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

data class Doc(
    val id: String,
    val name: String,
    val folder: String,
    val created: Long,
    val pages: List<String>
)

class Repo(ctx: Context) {
    private val root = File(ctx.filesDir, "docs").apply { mkdirs() }

    fun dir(id: String) = File(root, id)
    fun pageFile(d: Doc, i: Int) = File(dir(d.id), d.pages[i])

    fun list(): List<Doc> =
        root.listFiles()?.mapNotNull { load(it.name) }?.sortedByDescending { it.created } ?: emptyList()

    fun load(id: String): Doc? {
        val f = File(dir(id), "meta.json")
        if (!f.exists()) return null
        return try {
            val j = JSONObject(f.readText())
            val p = j.getJSONArray("pages")
            Doc(id, j.getString("name"), j.optString("folder", ""), j.getLong("created"),
                List(p.length()) { p.getString(it) })
        } catch (e: Exception) { null }
    }

    fun save(d: Doc) {
        dir(d.id).mkdirs()
        val j = JSONObject().put("name", d.name).put("folder", d.folder)
            .put("created", d.created).put("pages", JSONArray(d.pages))
        File(dir(d.id), "meta.json").writeText(j.toString())
    }

    private fun writePage(id: String, b: Bitmap): String {
        val name = "p_${System.nanoTime()}.jpg"
        FileOutputStream(File(dir(id), name)).use { b.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        return name
    }

    fun create(name: String, folder: String, bmps: List<Bitmap>): Doc {
        val id = UUID.randomUUID().toString()
        dir(id).mkdirs()
        val d = Doc(id, name, folder, System.currentTimeMillis(), bmps.map { writePage(id, it) })
        save(d); return d
    }

    fun addPages(d: Doc, bmps: List<Bitmap>): Doc {
        val n = d.copy(pages = d.pages + bmps.map { writePage(d.id, it) })
        save(n); return n
    }

    fun replacePage(d: Doc, i: Int, b: Bitmap): Doc {
        val old = pageFile(d, i)
        val list = d.pages.toMutableList()
        list[i] = writePage(d.id, b)
        old.delete()
        val n = d.copy(pages = list); save(n); return n
    }

    fun deletePage(d: Doc, i: Int): Doc {
        pageFile(d, i).delete()
        val n = d.copy(pages = d.pages.filterIndexed { k, _ -> k != i }); save(n); return n
    }

    fun movePage(d: Doc, from: Int, to: Int): Doc {
        if (to !in d.pages.indices) return d
        val list = d.pages.toMutableList()
        list.add(to, list.removeAt(from))
        val n = d.copy(pages = list); save(n); return n
    }

    fun delete(id: String) { dir(id).deleteRecursively() }

    fun loadBmp(f: File): Bitmap? = BitmapFactory.decodeFile(f.path)
}
