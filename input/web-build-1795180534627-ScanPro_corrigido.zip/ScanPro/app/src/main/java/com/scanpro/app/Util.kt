package com.scanpro.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.compose.ui.geometry.Offset
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume

object Util {
    fun limit(b: Bitmap, max: Int = 2400): Bitmap {
        val s = max.toFloat() / maxOf(b.width, b.height)
        if (s >= 1f) return b
        return Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
    }

    fun rotate(b: Bitmap, deg: Int): Bitmap {
        if (deg % 360 == 0) return b
        val m = Matrix().apply { postRotate(deg.toFloat()) }
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    fun fix(b: Bitmap, deg: Int) = limit(rotate(b, deg))

    fun decodeUri(ctx: Context, uri: Uri): Bitmap? {
        val cr = ctx.contentResolver
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > 4800) s *= 2
        val b = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        } ?: return null
        val ori = cr.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val deg = when (ori) { 6 -> 90; 3 -> 180; 8 -> 270; else -> 0 }
        return fix(b, deg)
    }

    /** Carimba a assinatura no canto inferior direito da página. */
    fun stamp(page: Bitmap, sig: Bitmap): Bitmap {
        val out = page.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val w = out.width * 0.35f
        val h = w * sig.height / sig.width
        val l = out.width - w - out.width * 0.06f
        val t = out.height - h - out.height * 0.06f
        c.drawBitmap(sig, null, RectF(l, t, l + w, t + h), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    fun renderSig(strokes: List<List<Offset>>, w: Int, h: Int): Bitmap {
        val full = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(full)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK; strokeWidth = 5f; strokeCap = Paint.Cap.ROUND
        }
        strokes.forEach { s -> for (i in 1 until s.size) c.drawLine(s[i - 1].x, s[i - 1].y, s[i].x, s[i].y, p) }
        val pts = strokes.flatten()
        val pad = 12
        val l = (pts.minOf { it.x }.toInt() - pad).coerceIn(0, w - 1)
        val t = (pts.minOf { it.y }.toInt() - pad).coerceIn(0, h - 1)
        val r = (pts.maxOf { it.x }.toInt() + pad).coerceIn(l + 1, w)
        val b = (pts.maxOf { it.y }.toInt() + pad).coerceIn(t + 1, h)
        return Bitmap.createBitmap(full, l, t, r - l, b - t)
    }
}

object Ocr {
    private suspend fun full(bmp: Bitmap): com.google.mlkit.vision.text.Text? =
        suspendCancellableCoroutine { cont ->
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
                .addOnFailureListener { if (cont.isActive) cont.resume(null) }
        }

    suspend fun read(bmp: Bitmap): String = full(bmp)?.text ?: ""

    /** Linhas reconhecidas com a caixa delimitadora (em pixels do bitmap). */
    suspend fun lines(bmp: Bitmap): List<Pair<String, Rect>> =
        full(bmp)?.textBlocks?.flatMap { it.lines }?.mapNotNull { l ->
            l.boundingBox?.let { l.text to it }
        } ?: emptyList()
}

object Exporter {
    private fun outDir(ctx: Context) = File(ctx.cacheDir, "exports").apply { mkdirs() }
    private fun safe(n: String) = n.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").ifBlank { "documento" }

    suspend fun pdf(ctx: Context, repo: Repo, d: Doc, watermark: String?, searchable: Boolean = false): File {
        outDir(ctx).listFiles()?.forEach { it.delete() }
        val pdf = PdfDocument()
        for (i in d.pages.indices) {
            val bmp = repo.loadBmp(repo.pageFile(d, i)) ?: continue
            val w = 595
            val h = (bmp.height * 595f / bmp.width).toInt().coerceAtLeast(1)
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(w, h, i + 1).create())
            val c = page.canvas
            c.drawBitmap(bmp, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
            if (searchable) {
                // camada de texto quase invisível sobre a imagem, para busca e seleção
                val k = w.toFloat() / bmp.width
                val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = 1 }
                for ((text, r) in Ocr.lines(bmp)) {
                    if (text.isBlank() || r.width() <= 0 || r.height() <= 0) continue
                    tp.textSize = r.height() * k * 0.85f
                    val mw = tp.measureText(text)
                    tp.textScaleX = if (mw > 0f) (r.width() * k / mw).coerceIn(0.2f, 5f) else 1f
                    c.drawText(text, r.left * k, r.bottom * k - r.height() * k * 0.2f, tp)
                }
            }
            if (!watermark.isNullOrBlank()) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.GRAY; alpha = 90
                    textSize = w / 9f; textAlign = Paint.Align.CENTER
                }
                c.save(); c.rotate(-30f, w / 2f, h / 2f)
                c.drawText(watermark, w / 2f, h / 2f, p); c.restore()
            }
            pdf.finishPage(page)
        }
        val f = File(outDir(ctx), safe(d.name) + ".pdf")
        FileOutputStream(f).use { pdf.writeTo(it) }
        pdf.close()
        return f
    }

    fun jpgs(ctx: Context, repo: Repo, d: Doc): List<File> {
        outDir(ctx).listFiles()?.forEach { it.delete() }
        return d.pages.indices.map { i ->
            val f = File(outDir(ctx), "${safe(d.name)}_${i + 1}.jpg")
            repo.pageFile(d, i).copyTo(f, true); f
        }
    }

    fun share(ctx: Context, files: List<File>, mime: String) {
        val uris = ArrayList(files.map { FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", it) })
        val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        i.type = mime
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, null))
    }
}
