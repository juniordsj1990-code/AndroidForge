package com.scanpro.app

import android.graphics.Bitmap
import android.graphics.PointF
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.hypot

enum class Filter(val label: String) {
    ORIGINAL("Original"), MAGIC("Mágico"), BW("P&B"), GRAY("Cinza"), BRIGHT("Brilho")
}

object ImageProc {
    private var ready = false
    fun init() { if (!ready) ready = OpenCVLoader.initLocal() }

    /** Detecta os 4 cantos do documento (TL, TR, BR, BL) em coordenadas do bitmap. */
    fun detect(src: Bitmap): List<PointF> {
        init()
        val w = src.width.toFloat()
        val h = src.height.toFloat()
        val fallback = listOf(
            PointF(w * .05f, h * .05f), PointF(w * .95f, h * .05f),
            PointF(w * .95f, h * .95f), PointF(w * .05f, h * .95f)
        )
        try {
            val scale = 500.0 / maxOf(src.width, src.height)
            val rgba = Mat(); Utils.bitmapToMat(src, rgba)
            val small = Mat(); Imgproc.resize(rgba, small, Size(), scale, scale)
            val gray = Mat(); Imgproc.cvtColor(small, gray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.GaussianBlur(gray, gray, Size(5.0, 5.0), 0.0)
            val edges = Mat(); Imgproc.Canny(gray, edges, 60.0, 180.0)
            Imgproc.dilate(edges, edges, Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0)))
            val contours = ArrayList<MatOfPoint>()
            Imgproc.findContours(edges, contours, Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE)
            val minArea = small.width() * small.height() * 0.2
            for (c in contours.sortedByDescending { Imgproc.contourArea(it) }.take(6)) {
                val c2 = MatOfPoint2f(*c.toArray())
                val peri = Imgproc.arcLength(c2, true)
                val ap = MatOfPoint2f()
                Imgproc.approxPolyDP(c2, ap, 0.02 * peri, true)
                if (ap.total() == 4L && Imgproc.contourArea(ap) > minArea &&
                    Imgproc.isContourConvex(MatOfPoint(*ap.toArray()))
                ) {
                    return order(ap.toArray().map { PointF((it.x / scale).toFloat(), (it.y / scale).toFloat()) })
                }
            }
        } catch (e: Throwable) { /* usa o fallback */ }
        return fallback
    }

    private fun order(p: List<PointF>): List<PointF> {
        val tl = p.minBy { it.x + it.y }
        val br = p.maxBy { it.x + it.y }
        val tr = p.minBy { it.y - it.x }
        val bl = p.maxBy { it.y - it.x }
        return listOf(tl, tr, br, bl)
    }

    private fun dist(a: PointF, b: PointF) = hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble())

    /** Corrige a perspectiva a partir dos 4 cantos. */
    fun warp(src: Bitmap, c: List<PointF>): Bitmap {
        init()
        val (tl, tr, br, bl) = c
        val w = maxOf(dist(tl, tr), dist(bl, br)).toInt().coerceAtLeast(1)
        val h = maxOf(dist(tl, bl), dist(tr, br)).toInt().coerceAtLeast(1)
        val s = MatOfPoint2f(
            Point(tl.x.toDouble(), tl.y.toDouble()), Point(tr.x.toDouble(), tr.y.toDouble()),
            Point(br.x.toDouble(), br.y.toDouble()), Point(bl.x.toDouble(), bl.y.toDouble())
        )
        val d = MatOfPoint2f(
            Point(0.0, 0.0), Point(w - 1.0, 0.0), Point(w - 1.0, h - 1.0), Point(0.0, h - 1.0)
        )
        val m = Imgproc.getPerspectiveTransform(s, d)
        val inMat = Mat(); Utils.bitmapToMat(src, inMat)
        val out = Mat()
        Imgproc.warpPerspective(inMat, out, m, Size(w.toDouble(), h.toDouble()))
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(out, bmp)
        return bmp
    }

    fun filter(src: Bitmap, f: Filter): Bitmap {
        if (f == Filter.ORIGINAL) return src
        init()
        val m = Mat(); Utils.bitmapToMat(src, m)
        val out = Mat()
        when (f) {
            Filter.GRAY -> Imgproc.cvtColor(m, out, Imgproc.COLOR_RGBA2GRAY)
            Filter.BW -> {
                val g = Mat(); Imgproc.cvtColor(m, g, Imgproc.COLOR_RGBA2GRAY)
                Imgproc.GaussianBlur(g, g, Size(3.0, 3.0), 0.0)
                Imgproc.adaptiveThreshold(g, out, 255.0, Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C,
                    Imgproc.THRESH_BINARY, 31, 15.0)
            }
            Filter.MAGIC -> {
                val g = Mat(); Imgproc.cvtColor(m, g, Imgproc.COLOR_RGBA2GRAY)
                val bg = Mat(); Imgproc.GaussianBlur(g, bg, Size(0.0, 0.0), 25.0)
                Core.divide(g, bg, out, 255.0)
            }
            else -> m.convertTo(out, -1, 1.25, 15.0)
        }
        val res = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(out, res)
        return res
    }
}
