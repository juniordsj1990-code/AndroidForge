@file:OptIn(ExperimentalMaterial3Api::class)

package com.scanpro.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TextSnippet
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

@Composable
fun App(vm: AppVM) {
    BackHandler(vm.screen != Screen.Home) { vm.back() }
    when (vm.screen) {
        Screen.Home -> HomeScreen(vm)
        Screen.Camera -> CameraScreen(vm)
        Screen.Crop -> CropScreen(vm)
        Screen.Edit -> EditScreen(vm)
        is Screen.Detail -> DetailScreen(vm)
    }
}

// ============================ HOME ============================

@Composable
fun HomeScreen(vm: AppVM) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) vm.importUris(uris, null)
    }
    val folders = vm.docs.map { it.folder }.filter { it.isNotBlank() }.distinct().sorted()
    val shown = vm.docs.filter {
        (vm.folder == null || it.folder == vm.folder) &&
            (vm.query.isBlank() || it.name.contains(vm.query, ignoreCase = true))
    }
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("ScanPro") }, actions = {
                IconButton({ picker.launch("image/*") }) { Icon(Icons.Default.ImageIcon, "Importar") }
            })
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { vm.startScan(null) },
                icon = { Icon(Icons.Default.CameraAlt, null) },
                text = { Text("Escanear") })
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = vm.query, onValueChange = { vm.query = it },
                placeholder = { Text("Buscar documentos") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp))
            if (folders.isNotEmpty()) {
                LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = vm.folder == null, onClick = { vm.folder = null }, label = { Text("Todos") }) }
                    items(folders) { f ->
                        FilterChip(selected = vm.folder == f, onClick = { vm.folder = f }, label = { Text(f) })
                    }
                }
            }
            if (vm.busy) CircularProgressIndicator(Modifier.padding(16.dp))
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nenhum documento ainda") }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp, 8.dp, 12.dp, 88.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) { items(shown, key = { it.id }) { d -> DocRow(vm, d) } }
            }
        }
    }
}

@Composable
fun DocRow(vm: AppVM, d: Doc) {
    var menu by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf("") }
    Card(Modifier.fillMaxWidth().clickable { vm.openDoc(d.id) }) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = File(vm.repo.dir(d.id), d.pages.firstOrNull() ?: ""),
                contentDescription = null,
                modifier = Modifier.size(60.dp, 76.dp).clip(RoundedCornerShape(6.dp)),
                contentScale = ContentScale.Crop)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(d.name, maxLines = 1, style = MaterialTheme.typography.titleMedium)
                val date = DateFormat.getDateInstance(DateFormat.SHORT).format(Date(d.created))
                Text(
                    "${d.pages.size} pág. · $date" + if (d.folder.isNotBlank()) " · ${d.folder}" else "",
                    style = MaterialTheme.typography.bodySmall)
            }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, null) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Renomear") }, onClick = { menu = false; dlg = "rename" })
                    DropdownMenuItem(text = { Text("Mover para pasta") }, onClick = { menu = false; dlg = "folder" })
                    DropdownMenuItem(text = { Text("Excluir") }, onClick = { menu = false; dlg = "delete" })
                }
            }
        }
    }
    when (dlg) {
        "rename" -> TextDialog("Renomear", d.name, "Nome", { dlg = "" }) {
            vm.update(d.copy(name = it.ifBlank { d.name })); dlg = ""
        }
        "folder" -> TextDialog("Pasta (vazio = sem pasta)", d.folder, "Pasta", { dlg = "" }) {
            vm.update(d.copy(folder = it)); dlg = ""
        }
        "delete" -> AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("Excluir documento?") },
            text = { Text(d.name) },
            confirmButton = { TextButton({ vm.deleteDoc(d); dlg = "" }) { Text("Excluir") } },
            dismissButton = { TextButton({ dlg = "" }) { Text("Cancelar") } })
    }
}

@Composable
fun TextDialog(title: String, initial: String, label: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton({ onOk(t.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } })
}

// ============================ CÂMERA ============================

@Composable
fun CameraScreen(vm: AppVM) {
    val ctx = LocalContext.current
    val owner = ctx as LifecycleOwner
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val req = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) req.launch(Manifest.permission.CAMERA) }
    if (!granted) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Button({ req.launch(Manifest.permission.CAMERA) }) { Text("Permitir câmera") }
        }
        return
    }
    val capture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build() }
    var flash by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                PreviewView(c).also { pv ->
                    val fut = ProcessCameraProvider.getInstance(c)
                    fut.addListener({
                        val provider = fut.get()
                        val prev = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                        provider.unbindAll()
                        provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, prev, capture)
                    }, ContextCompat.getMainExecutor(c))
                }
            })
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton({ vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
            IconButton({ flash = !flash }) {
                Icon(if (flash) Icons.Default.FlashOn else Icons.Default.FlashOff, null, tint = Color.White)
            }
        }
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(24.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Text(if (vm.session.isEmpty()) "" else "${vm.session.size} pág.", color = Color.White, modifier = Modifier.size(70.dp, 24.dp))
            Box(
                Modifier.size(72.dp).clip(CircleShape).background(Color.White).clickable {
                    capture.flashMode = if (flash) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
                    capture.takePicture(ContextCompat.getMainExecutor(ctx), object : ImageCapture.OnImageCapturedCallback() {
                        override fun onCaptureSuccess(image: ImageProxy) {
                            val rot = image.imageInfo.rotationDegrees
                            val b = image.toBitmap()
                            image.close()
                            vm.onCaptured(Util.fix(b, rot))
                        }
                        override fun onError(exception: ImageCaptureException) {
                            Toast.makeText(ctx, "Falha ao capturar", Toast.LENGTH_SHORT).show()
                        }
                    })
                })
            if (vm.session.isNotEmpty()) TextButton({ vm.saveSession() }) { Text("Concluir", color = Color.White) }
            else Box(Modifier.size(70.dp, 24.dp))
        }
    }
}

// ============================ RECORTE ============================

@Composable
fun CropScreen(vm: AppVM) {
    val bmp = vm.raw ?: return
    var box by remember { mutableStateOf(IntSize.Zero) }
    var active by remember { mutableStateOf(-1) }
    val corners = vm.corners
    val s = if (box.width == 0) 1f else minOf(box.width.toFloat() / bmp.width, box.height.toFloat() / bmp.height)
    val ox = (box.width - bmp.width * s) / 2f
    val oy = (box.height - bmp.height * s) / 2f
    fun toS(o: Offset) = Offset(o.x * s + ox, o.y * s + oy)

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Box(
            Modifier.weight(1f).fillMaxWidth().onSizeChanged { box = it }
                .pointerInput(s, box) {
                    detectDragGestures(
                        onDragStart = { p ->
                            val i = corners.indices.minByOrNull { (toS(corners[it]) - p).getDistance() }
                            active = if (i != null && (toS(corners[i]) - p).getDistance() < 140f) i else -1
                        },
                        onDragEnd = { active = -1 },
                        onDragCancel = { active = -1 },
                        onDrag = { ch, d ->
                            ch.consume()
                            if (active in corners.indices) {
                                val c = corners[active]
                                corners[active] = Offset(
                                    (c.x + d.x / s).coerceIn(0f, bmp.width.toFloat()),
                                    (c.y + d.y / s).coerceIn(0f, bmp.height.toFloat()))
                            }
                        })
                }
        ) {
            Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            if (corners.size == 4) {
                Canvas(Modifier.fillMaxSize()) {
                    val pts = corners.map { toS(it) }
                    for (i in 0 until 4) drawLine(Color(0xFF4FC3F7), pts[i], pts[(i + 1) % 4], 5f)
                    pts.forEachIndexed { i, p ->
                        drawCircle(if (i == active) Color.Yellow else Color(0xFF4FC3F7), 22f, p)
                    }
                }
            } else CircularProgressIndicator(Modifier.align(Alignment.Center))
            if (vm.busy) CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton({ vm.cancelCrop() }) { Text("Cancelar", color = Color.White) }
            TextButton({ vm.resetCorners(false) }) { Text("Auto", color = Color.White) }
            TextButton({ vm.resetCorners(true) }) { Text("Tudo", color = Color.White) }
            Button({ vm.confirmCrop() }, enabled = corners.size == 4 && !vm.busy) { Text("Continuar") }
        }
    }
}

// ============================ EDIÇÃO ============================

@Composable
fun EditScreen(vm: AppVM) {
    var sign by remember { mutableStateOf(false) }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Editar página") },
            navigationIcon = { IconButton({ vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                vm.editPreview?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize().padding(8.dp)) }
                if (vm.busy) CircularProgressIndicator()
            }
            LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Filter.values().toList()) { f ->
                    FilterChip(selected = vm.filter == f, onClick = { vm.selectFilter(f) }, label = { Text(f.label) })
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton({ vm.rotate(-90) }) { Icon(Icons.Default.RotateLeft, "Girar à esquerda") }
                IconButton({ vm.rotate(90) }) { Icon(Icons.Default.RotateRight, "Girar à direita") }
                TextButton({ sign = true }) {
                    Icon(Icons.Default.Edit, null); Text(" Assinar")
                }
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (vm.isEditingExisting) {
                    Button({ vm.finishPage(false) }, Modifier.weight(1f), enabled = vm.editPreview != null) { Text("Salvar") }
                } else {
                    OutlinedButton({ vm.finishPage(true) }, Modifier.weight(1f), enabled = vm.editPreview != null) { Text("+ Página") }
                    Button({ vm.finishPage(false) }, Modifier.weight(1f), enabled = vm.editPreview != null) { Text("Concluir") }
                }
            }
        }
    }
    if (sign) SignDialog({ sign = false }) { vm.stamp(it); sign = false }
}

@Composable
fun SignDialog(onDismiss: () -> Unit, onDone: (android.graphics.Bitmap) -> Unit) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var cur by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Assinatura") },
        text = {
            Canvas(
                Modifier.fillMaxWidth().height(180.dp).background(Color(0xFFF2F2F2))
                    .onSizeChanged { size = it }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { cur = listOf(it) },
                            onDragEnd = { strokes.add(cur); cur = emptyList() },
                            onDragCancel = { cur = emptyList() },
                            onDrag = { ch, _ -> ch.consume(); cur = cur + ch.position })
                    }
            ) {
                (strokes.toList() + listOf(cur)).forEach { pts ->
                    for (i in 1 until pts.size) drawLine(Color.Black, pts[i - 1], pts[i], 5f, StrokeCap.Round)
                }
            }
        },
        confirmButton = {
            TextButton({
                val all = strokes.filter { it.size > 1 }
                if (all.isNotEmpty() && size.width > 0) onDone(Util.renderSig(all, size.width, size.height))
            }) { Text("Aplicar") }
        },
        dismissButton = {
            Row {
                TextButton({ strokes.clear() }) { Text("Limpar") }
                TextButton(onDismiss) { Text("Cancelar") }
            }
        })
}

// ============================ DOCUMENTO ============================

@Composable
fun DetailScreen(vm: AppVM) {
    val d = vm.current
    if (d == null) { Box(Modifier.fillMaxSize()) { CircularProgressIndicator(Modifier.align(Alignment.Center)) }; return }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) vm.importUris(uris, d.id)
    }
    var menu by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var ocrText by remember { mutableStateOf<String?>(null) }

    fun export(kind: String, wm: String?) {
        scope.launch {
            working = true
            val files = withContext(Dispatchers.IO) {
                when (kind) {
                    "pdf" -> listOf(Exporter.pdf(ctx, vm.repo, d, wm))
                    "pdf_ocr" -> listOf(Exporter.pdf(ctx, vm.repo, d, wm, searchable = true))
                    else -> Exporter.jpgs(ctx, vm.repo, d)
                }
            }
            working = false
            Exporter.share(ctx, files, if (kind.startsWith("pdf")) "application/pdf" else "image/jpeg")
        }
    }

    fun runOcr() {
        scope.launch {
            working = true
            val text = buildString {
                for (i in d.pages.indices) {
                    val b = withContext(Dispatchers.IO) { vm.repo.loadBmp(vm.repo.pageFile(d, i)) } ?: continue
                    append(Ocr.read(b)).append("\n\n")
                }
            }
            working = false
            ocrText = text.trim().ifBlank { "Nenhum texto encontrado." }
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(d.name, maxLines = 1) },
            navigationIcon = { IconButton({ vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
            actions = {
                IconButton({ vm.startScan(d.id) }) { Icon(Icons.Default.CameraAlt, "Adicionar com câmera") }
                IconButton({ picker.launch("image/*") }) { Icon(Icons.Default.ImageIcon, "Adicionar da galeria") }
                IconButton({ runOcr() }) { Icon(Icons.Default.TextSnippet, "Extrair texto (OCR)") }
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, null) }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem(text = { Text("Compartilhar PDF") }, onClick = { menu = false; export("pdf", null) })
                        DropdownMenuItem(text = { Text("PDF pesquisável (OCR)") }, onClick = { menu = false; export("pdf_ocr", null) })
                        DropdownMenuItem(text = { Text("PDF com marca d'água") }, onClick = { menu = false; dlg = "wm" })
                        DropdownMenuItem(text = { Text("Compartilhar imagens JPG") }, onClick = { menu = false; export("jpg", null) })
                        DropdownMenuItem(text = { Text("Renomear") }, onClick = { menu = false; dlg = "rename" })
                    }
                }
            })
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(d.pages, key = { _, n -> n }) { i, name ->
                    Card {
                        Column {
                            AsyncImage(
                                model = File(vm.repo.dir(d.id), name), contentDescription = null,
                                modifier = Modifier.fillMaxWidth().aspectRatio(0.72f).clickable { vm.editPage(i) },
                                contentScale = ContentScale.Fit)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically) {
                                IconButton({ vm.movePage(i, -1) }, enabled = i > 0) { Icon(Icons.Default.ChevronLeft, null) }
                                Text("${i + 1}")
                                IconButton({ vm.deletePage(i) }) { Icon(Icons.Default.Delete, null) }
                                IconButton({ vm.movePage(i, 1) }, enabled = i < d.pages.size - 1) { Icon(Icons.Default.ChevronRight, null) }
                            }
                        }
                    }
                }
            }
            if (working || vm.busy) CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
    }

    when (dlg) {
        "wm" -> TextDialog("Texto da marca d'água", "CONFIDENCIAL", "Texto", { dlg = "" }) {
            dlg = ""; if (it.isNotBlank()) export("pdf", it)
        }
        "rename" -> TextDialog("Renomear", d.name, "Nome", { dlg = "" }) {
            vm.update(d.copy(name = it.ifBlank { d.name })); dlg = ""
        }
    }

    ocrText?.let { t ->
        AlertDialog(
            onDismissRequest = { ocrText = null },
            title = { Text("Texto extraído") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(t) } },
            confirmButton = {
                TextButton({
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t)
                    ctx.startActivity(Intent.createChooser(i, null))
                }) { Text("Compartilhar") }
            },
            dismissButton = {
                Row {
                    TextButton({ clip.setText(AnnotatedString(t)); Toast.makeText(ctx, "Copiado", Toast.LENGTH_SHORT).show() }) { Text("Copiar") }
                    TextButton({ ocrText = null }) { Text("Fechar") }
                }
            })
    }
}
