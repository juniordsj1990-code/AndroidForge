package com.scanpro.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.PointF
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

sealed class Screen {
    object Home : Screen()
    object Camera : Screen()
    object Crop : Screen()
    object Edit : Screen()
    data class Detail(val id: String) : Screen()
}

class AppVM(app: Application) : AndroidViewModel(app) {
    val repo = Repo(app)

    var screen by mutableStateOf<Screen>(Screen.Home)
    var docs by mutableStateOf<List<Doc>>(emptyList())
    var current by mutableStateOf<Doc?>(null)
    var query by mutableStateOf("")
    var folder by mutableStateOf<String?>(null)

    var raw by mutableStateOf<Bitmap?>(null)
    val corners = mutableStateListOf<Offset>()
    var editBase by mutableStateOf<Bitmap?>(null)
    var editPreview by mutableStateOf<Bitmap?>(null)
    var filter by mutableStateOf(Filter.MAGIC)
    var busy by mutableStateOf(false)

    val session = mutableStateListOf<Bitmap>()
    private val queue = ArrayDeque<Bitmap>()
    private var editing: Pair<String, Int>? = null
    private var appendTo: String? = null
    private var fromCamera = true
    val isEditingExisting get() = editing != null

    init { refresh() }

    fun refresh() { docs = repo.list() }

    // ---------- fluxo de captura ----------
    fun startScan(target: String?) {
        session.clear(); queue.clear(); appendTo = target; fromCamera = true
        screen = Screen.Camera
    }

    fun importUris(uris: List<Uri>, target: String?) {
        session.clear(); queue.clear(); appendTo = target; fromCamera = false
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            uris.forEach { u -> Util.decodeUri(getApplication(), u)?.let { queue.addLast(it) } }
            withContext(Dispatchers.Main) {
                busy = false
                if (queue.isEmpty()) leave() else updateRaw(queue.removeFirst())
            }
        }
    }

    fun onCaptured(b: Bitmap) { fromCamera = true; updateRaw(b) }

    private fun updateRaw(b: Bitmap) {
        raw = b; corners.clear(); screen = Screen.Crop
        viewModelScope.launch(Dispatchers.Default) {
            val pts: List<PointF> = ImageProc.detect(b)
            withContext(Dispatchers.Main) {
                if (raw === b) { corners.clear(); corners.addAll(pts.map { Offset(it.x, it.y) }) }
            }
        }
    }

    fun resetCorners(full: Boolean) {
        val b = raw ?: return
        if (full) {
            corners.clear()
            corners.addAll(listOf(Offset(0f, 0f), Offset(b.width.toFloat(), 0f),
                Offset(b.width.toFloat(), b.height.toFloat()), Offset(0f, b.height.toFloat())))
        } else updateRaw(b)
    }

    fun confirmCrop() {
        val b = raw ?: return
        if (corners.size < 4) return
        val pts = corners.map { PointF(it.x, it.y) }
        busy = true
        viewModelScope.launch(Dispatchers.Default) {
            val w = ImageProc.warp(b, pts)
            withContext(Dispatchers.Main) { startEdit(w, null) }
        }
    }

    fun cancelCrop() {
        raw = null
        when {
            fromCamera -> screen = Screen.Camera
            queue.isNotEmpty() -> updateRaw(queue.removeFirst())
            session.isNotEmpty() -> saveSession()
            else -> leave()
        }
    }

    // ---------- edição ----------
    private fun startEdit(base: Bitmap, ex: Pair<String, Int>?) {
        editBase = base; editing = ex
        filter = if (ex == null) Filter.MAGIC else Filter.ORIGINAL
        screen = Screen.Edit
        applyFilter()
    }

    private fun applyFilter() {
        val b = editBase ?: return
        val f = filter
        busy = true
        viewModelScope.launch(Dispatchers.Default) {
            val r = ImageProc.filter(b, f)
            withContext(Dispatchers.Main) {
                if (editBase === b && filter == f) { editPreview = r; busy = false }
            }
        }
    }

    fun selectFilter(f: Filter) { filter = f; applyFilter() }
    fun rotate(deg: Int) { editBase = editBase?.let { Util.rotate(it, deg) }; applyFilter() }
    fun stamp(sig: Bitmap) { editBase = editBase?.let { Util.stamp(it, sig) }; applyFilter() }

    fun finishPage(more: Boolean) {
        val bmp = editPreview ?: return
        val ex = editing
        if (ex != null) {
            viewModelScope.launch(Dispatchers.IO) {
                val d = repo.load(ex.first)?.let { repo.replacePage(it, ex.second, bmp) }
                refresh()
                withContext(Dispatchers.Main) {
                    editing = null; current = d; screen = Screen.Detail(ex.first)
                }
            }
            return
        }
        session.add(bmp)
        if (more) {
            if (queue.isNotEmpty()) updateRaw(queue.removeFirst()) else { fromCamera = true; screen = Screen.Camera }
        } else saveSession()
    }

    fun saveSession() {
        val pages = session.toList()
        val target = appendTo
        session.clear(); queue.clear(); appendTo = null
        if (pages.isEmpty()) { leaveTo(target); return }
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            val name = SimpleDateFormat("'Scan' dd-MM-yyyy HH.mm", Locale.getDefault()).format(System.currentTimeMillis())
            val doc = if (target != null) repo.load(target)?.let { repo.addPages(it, pages) }
            else repo.create(name, "", pages)
            refresh()
            withContext(Dispatchers.Main) {
                busy = false
                if (doc != null) { current = doc; screen = Screen.Detail(doc.id) } else screen = Screen.Home
            }
        }
    }

    private fun leave() { val t = appendTo; appendTo = null; session.clear(); queue.clear(); leaveTo(t) }
    private fun leaveTo(t: String?) { if (t != null) openDoc(t) else { refresh(); screen = Screen.Home } }

    fun back() {
        when (screen) {
            Screen.Camera -> if (session.isNotEmpty()) saveSession() else leave()
            Screen.Crop -> cancelCrop()
            Screen.Edit -> { val ex = editing; if (ex != null) { editing = null; openDoc(ex.first) } else screen = Screen.Crop }
            is Screen.Detail -> { refresh(); screen = Screen.Home }
            Screen.Home -> {}
        }
    }

    // ---------- documentos ----------
    fun openDoc(id: String) { current = repo.load(id); screen = Screen.Detail(id) }

    fun update(d: Doc) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.save(d); refresh()
            withContext(Dispatchers.Main) { if (current?.id == d.id) current = d }
        }
    }

    fun deleteDoc(d: Doc) {
        viewModelScope.launch(Dispatchers.IO) { repo.delete(d.id); refresh() }
    }

    private fun mutate(block: (Doc) -> Doc?) {
        val d = current ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val n = block(d)
            refresh()
            withContext(Dispatchers.Main) {
                if (n == null) { current = null; screen = Screen.Home } else current = n
            }
        }
    }

    fun movePage(i: Int, delta: Int) = mutate { repo.movePage(it, i, i + delta) }
    fun deletePage(i: Int) = mutate {
        if (it.pages.size <= 1) { repo.delete(it.id); null } else repo.deletePage(it, i)
    }

    fun editPage(i: Int) {
        val d = current ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val b = repo.loadBmp(repo.pageFile(d, i))
            withContext(Dispatchers.Main) { if (b != null) startEdit(b, Pair(d.id, i)) }
        }
    }
}
