package com.ladderlab.simulator

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var loadingScreen: View? = null
    private var loadingHidden = false
    @Volatile private var ready = false
    private val main = Handler(Looper.getMainLooper())
    private var printView: WebView? = null
    private var pendingSave = ""
    private var pendingOpen: String? = null

    private fun readIntent(i: Intent?): String? {
        val uri = i?.data ?: return null
        if (i.action != Intent.ACTION_VIEW) return null
        return contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) }
    }

    private fun deliver(view: WebView?, txt: String) {
        view?.evaluateJavascript("ldImportText(" + JSONObject.quote(txt) + ")", null)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        readIntent(intent)?.let { deliver(web, it) }
    }

    // Salvar/abrir programas em arquivo (seletor de arquivos do sistema)
    private val saveLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-ladderlab")) { uri ->
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { it.write(pendingSave.toByteArray(Charsets.UTF_8)) }
            web.evaluateJavascript("toast('Programa salvo.')", null)
        }
    }
    private val openLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val txt = contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
            web.evaluateJavascript("ldImportText(" + JSONObject.quote(txt) + ")", null)
        }
    }

    inner class FileBridge {
        @JavascriptInterface
        fun save(name: String, json: String) {
            pendingSave = json
            runOnUiThread { saveLauncher.launch(name) }
        }

        @JavascriptInterface
        fun open() {
            runOnUiThread { openLauncher.launch(arrayOf("*/*")) }
        }
    }

    /** Ponte JS -> Android: abre o diálogo de impressão do sistema (impressora ou "Salvar como PDF"). */
    inner class PrintBridge {
        @JavascriptInterface
        fun print(html: String, name: String) {
            runOnUiThread {
                val w = WebView(this@MainActivity)
                printView = w
                var done = false
                w.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        if (done) return
                        done = true
                        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                        pm.print(name, view.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
                    }
                }
                w.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createLoadingScreen(): View {
        val background = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(7, 15, 31), Color.rgb(12, 28, 51), Color.rgb(5, 10, 22))
            )
            isClickable = true
            isFocusable = true
        }

        // Linhas de destaque discretas, com aparência de equipamento técnico.
        val accent = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(0, 220, 190), Color.rgb(48, 130, 255), Color.TRANSPARENT)
            )
        }
        background.addView(accent, FrameLayout.LayoutParams(dp(150), dp(3), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(54)
        })

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(30), dp(24), dp(30), dp(24))
        }
        val iconFrame = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(28).toFloat()
                setColor(Color.rgb(19, 37, 62))
                setStroke(dp(1), Color.rgb(45, 77, 105))
            }
            elevation = dp(10).toFloat()
        }
        val icon = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher_foreground)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(13), dp(13), dp(13), dp(13))
        }
        iconFrame.addView(icon, FrameLayout.LayoutParams(dp(100), dp(100), Gravity.CENTER))
        content.addView(iconFrame, LinearLayout.LayoutParams(dp(124), dp(124)).apply {
            bottomMargin = dp(30)
        })

        val title = TextView(this).apply {
            text = "LADDER LAB"
            setTextColor(Color.rgb(245, 249, 255))
            textSize = 29f
            letterSpacing = 0.14f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        content.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val subtitle = TextView(this).apply {
            text = "SIMULADOR DE LÓGICA PROGRAMÁVEL"
            setTextColor(Color.rgb(124, 164, 194))
            textSize = 10.5f
            letterSpacing = 0.12f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        content.addView(subtitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        })

        val divider = View(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(2).toFloat()
                setColor(Color.rgb(0, 211, 181))
            }
        }
        content.addView(divider, LinearLayout.LayoutParams(dp(42), dp(3)).apply {
            topMargin = dp(28)
            bottomMargin = dp(25)
        })

        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(0, 220, 190))
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.rgb(0, 220, 190))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(34, 54, 76))
        }
        content.addView(progress, LinearLayout.LayoutParams(dp(180), dp(3)))

        val status = TextView(this).apply {
            text = "Preparando ambiente..."
            setTextColor(Color.rgb(164, 188, 208))
            textSize = 12f
            letterSpacing = 0.03f
            gravity = Gravity.CENTER
        }
        content.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(15)
        })

        val footer = TextView(this).apply {
            text = "AUTOMAÇÃO   •   CONTROLE   •   PRÁTICA"
            setTextColor(Color.rgb(91, 122, 151))
            textSize = 9f
            letterSpacing = 0.08f
            gravity = Gravity.CENTER
        }
        background.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        background.addView(footer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            leftMargin = dp(16)
            rightMargin = dp(16)
            bottomMargin = dp(34)
        })
        return background
    }

    private fun hideLoadingScreen() {
        if (loadingHidden) return
        loadingHidden = true
        ready = true
        val overlay = loadingScreen ?: return
        overlay.animate().alpha(0f).setDuration(350).withEndAction {
            root.removeView(overlay)
            loadingScreen = null
        }.start()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        // A splash nativa dá lugar à tela personalizada enquanto o simulador é preparado.
        main.postDelayed({ hideLoadingScreen() }, 5000)

        web = WebView(this).apply {
            setBackgroundColor(0xFF000308.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    main.postDelayed({ hideLoadingScreen() }, 650)
                    pendingOpen?.let { deliver(view, it); pendingOpen = null }
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url ?: return false
                    if (url.toString().startsWith("file:///android_asset")) return false
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url.toString())))
                    return true
                }
            }
        }
        web.addJavascriptInterface(PrintBridge(), "AndroidPrint")
        web.addJavascriptInterface(FileBridge(), "AndroidFiles")
        root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        loadingScreen = createLoadingScreen()
        root.addView(loadingScreen, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)

        // Voltar fecha primeiro a janela do Programador/Monitor; depois sai do app.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript(
                    "(function(){var o=document.getElementById('workspaceOverlay');" +
                        "if(o&&o.classList.contains('open')){closeWorkspace();return 1}return 0})()"
                ) { r ->
                    if (r != "1") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        pendingOpen = readIntent(intent)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }
}
