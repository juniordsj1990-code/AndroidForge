# DocFoto Pro — Projeto Android Studio

Projeto Android autocontido (Capacitor 8). Não precisa de Node nem de `node_modules`.

## Como abrir e gerar o APK
1. Android Studio (Narwhal/Otter ou mais novo, com JDK 21 — o JBR embutido serve).
2. **File > Open** e escolha esta pasta (`DocFotoPro`).
3. Aguarde o Gradle Sync (baixa o Gradle 8.14.3 e o SDK 36 se faltar).
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   Linha de comando: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`.

## Onde editar o app
O HTML/JS do app fica em `app/src/main/assets/public/` (index.html).
Os plugins nativos (câmera, arquivos, GPS, compartilhar) estão nas pastas `capacitor-*`.
