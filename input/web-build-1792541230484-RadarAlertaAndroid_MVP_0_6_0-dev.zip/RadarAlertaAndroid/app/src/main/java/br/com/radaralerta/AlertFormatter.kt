package br.com.radaralerta

import android.content.SharedPreferences
import java.util.Locale
import kotlin.math.roundToInt

/** Monta o texto falado e as linhas da janela flutuante conforme as preferências do usuário. */
object AlertFormatter {
    fun voiceMessage(prefs: SharedPreferences, radar: Radar, distanceMeters: Float): String {
        val head = mutableListOf<String>()
        val prefix = (prefs.getString("voice_prefix", "Atenção") ?: "").trim()
        if (prefix.isNotEmpty()) head.add(prefix)
        if (prefs.getBoolean("voice_type", true)) head.add(radar.spokenName)
        if (prefs.getBoolean("voice_road", false)) {
            val road = listOfNotNull(radar.highway?.let { spokenHighway(it) }, radar.km?.let { "quilômetro " + spokenNumber(it) }).joinToString(" ")
            if (road.isNotBlank()) head.add(road)
        }
        if (prefs.getBoolean("voice_city", false)) radar.cityDisplay?.let { head.add(it) }
        val sentences = mutableListOf<String>()
        if (head.isNotEmpty()) sentences.add(head.joinToString(", "))
        if (prefs.getBoolean("voice_speed", true)) radar.speedLimit?.let { sentences.add("Limite de $it quilômetros por hora") }
        if (prefs.getBoolean("voice_distance", true)) sentences.add("Aproximadamente " + spokenDistance(distanceMeters))
        return if (sentences.isEmpty()) "Radar à frente" else sentences.joinToString(". ")
    }

    fun overlayLines(prefs: SharedPreferences, radar: Radar): List<String> {
        val lines = mutableListOf<String>()
        if (prefs.getBoolean("overlay_show_type", true)) lines.add(listOfNotNull(radar.code?.takeIf { radar.source != "OpenStreetMap" }, radar.typeLabel).joinToString(" • "))
        if (prefs.getBoolean("overlay_show_road", true) && radar.roadLine.isNotBlank()) lines.add(radar.roadLine)
        if (prefs.getBoolean("overlay_show_city", false)) radar.cityDisplay?.let { lines.add(it) }
        if (prefs.getBoolean("overlay_show_speed", true)) radar.speedLimit?.let { lines.add("Limite $it km/h") }
        return lines
    }

    /** "SP 008" -> "S P 8" para o leitor de voz soletrar a sigla. */
    fun spokenHighway(raw: String): String {
        val m = Regex("^([A-Za-z]+)[\\s-]*0*(\\d+)").find(raw.trim()) ?: return raw
        return m.groupValues[1].uppercase(Locale.ROOT).toCharArray().joinToString(" ") + " " + m.groupValues[2]
    }

    private fun spokenNumber(value: Double): String =
        String.format(Radar.PT_BR, "%.1f", value).removeSuffix(",0")

    private fun spokenDistance(meters: Float): String =
        if (meters >= 1000f) String.format(Radar.PT_BR, "%.1f quilômetros", meters / 1000f) else "${(meters / 10f).roundToInt() * 10} metros"
}
