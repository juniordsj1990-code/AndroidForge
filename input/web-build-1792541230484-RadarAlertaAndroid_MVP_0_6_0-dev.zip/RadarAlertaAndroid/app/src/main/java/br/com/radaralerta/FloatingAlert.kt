package br.com.radaralerta

import android.content.Context
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

object AlertOptions {
    val POSITIONS = listOf("Topo", "Centro", "Base")
    val SIZES = listOf("Pequena", "Média", "Grande")
    val OPACITY_LABELS = listOf("50%", "70%", "85%", "100%")
    val OPACITY_VALUES = listOf(50, 70, 85, 100)
    val HIDE_LABELS = listOf("3 s", "6 s", "10 s", "20 s")
    val HIDE_SECONDS = listOf(3, 6, 10, 20)
}

/** Janela flutuante com a distância ao vivo; reaproveitada pelo serviço e pela pré-visualização. */
class FloatingAlert(context: Context) {
    private val app = context.applicationContext
    private var root: LinearLayout? = null
    private var distanceView: TextView? = null
    private var detailView: TextView? = null
    private var signature = ""
    var onDismiss: (() -> Unit)? = null
    val isShowing: Boolean get() = root != null

    fun update(prefs: SharedPreferences, distanceMeters: Float, lines: List<String>) {
        try {
            val pos = prefs.getInt("overlay_pos", 0)
            val size = prefs.getInt("overlay_size", 1)
            val opacity = AlertOptions.OPACITY_VALUES.getOrElse(prefs.getInt("overlay_opacity", 2)) { 85 }
            val sig = "$pos/$size/$opacity"
            if (root != null && sig != signature) hide()
            if (root == null) create(pos, size, opacity, sig)
            distanceView?.text = Text.distance(distanceMeters)
            detailView?.text = lines.joinToString("\n")
            detailView?.visibility = if (lines.isEmpty()) View.GONE else View.VISIBLE
        } catch (_: Exception) {
            hide()
        }
    }

    private fun create(pos: Int, size: Int, opacity: Int, sig: String) {
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(app.dp(22), app.dp(12), app.dp(22), app.dp(14))
            elevation = app.dp(10).toFloat()
            background = GradientDrawable().apply {
                setColor(((opacity * 255 / 100) shl 24) or 0x00C62828)
                cornerRadius = app.dp(20).toFloat()
            }
            setOnClickListener { hide(); onDismiss?.invoke() }
        }
        box.addView(TextView(app).apply { text = "RADAR À FRENTE"; textSize = 11f; setTextColor(0xCCFFFFFF.toInt()); letterSpacing = 0.12f; gravity = Gravity.CENTER })
        val distance = TextView(app).apply {
            textSize = listOf(26f, 34f, 44f).getOrElse(size) { 34f }
            setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val detail = TextView(app).apply {
            textSize = listOf(13f, 15f, 18f).getOrElse(size) { 15f }
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        box.addView(distance)
        box.addView(detail)
        box.addView(TextView(app).apply { text = "Toque para fechar"; textSize = 10f; setTextColor(0x99FFFFFF.toInt()); gravity = Gravity.CENTER; setPadding(0, app.dp(4), 0, 0) })
        val width = (app.resources.displayMetrics.widthPixels * 0.9f).toInt()
        val params = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        when (pos) {
            0 -> { params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; params.y = app.dp(28) }
            1 -> params.gravity = Gravity.CENTER
            else -> { params.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; params.y = app.dp(96) }
        }
        wm.addView(box, params)
        root = box
        distanceView = distance
        detailView = detail
        signature = sig
    }

    fun hide() {
        val v = root ?: return
        try { (app.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Exception) { }
        root = null
        distanceView = null
        detailView = null
    }
}
