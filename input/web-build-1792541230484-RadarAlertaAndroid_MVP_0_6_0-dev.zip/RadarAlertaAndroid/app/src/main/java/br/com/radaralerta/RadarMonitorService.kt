package br.com.radaralerta

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioAttributes
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class RadarMonitorService : Service(), LocationListener, TextToSpeech.OnInitListener {
    private lateinit var locationManager: LocationManager
    private lateinit var alertOverlay: FloatingAlert
    private val prefs: SharedPreferences by lazy { getSharedPreferences("radar_alerta", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wakeLock: PowerManager.WakeLock? = null
    private val lastAlertAt = mutableMapOf<String, Long>()

    private var startedElapsed = 0L
    private var lastFixElapsed = 0L
    private var lastGpsElapsed = 0L
    private var lastAccuracy = -1f
    private var lastNotifElapsed = 0L
    private var lastRegisterElapsed = 0L
    private var lastCandidateElapsed = 0L
    private var candidateRadar: Radar? = null
    private var candidateDistance = 0f
    private var nearest: Radar? = null
    private var nearestDistance = Float.MAX_VALUE
    private var overlayKey: String? = null
    private var dismissedKey: String? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        tts = TextToSpeech(this, this)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        alertOverlay = FloatingAlert(this)
        alertOverlay.onDismiss = { dismissedKey = overlayKey }
        startedElapsed = SystemClock.elapsedRealtime()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startForeground(NOTIFICATION_ID, buildNotification("Radar Alerta ativo", "Aguardando sinal de GPS…", null, false))
        } catch (_: Exception) {
            stopSelf(); return START_NOT_STICKY
        }
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) { stopSelf(); return START_NOT_STICKY }
        acquireWakeLock()
        registerLocationUpdates()
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    // ------------------------------------------------------------------ localização

    @SuppressLint("MissingPermission")
    private fun registerLocationUpdates() {
        lastRegisterElapsed = SystemClock.elapsedRealtime()
        try { locationManager.removeUpdates(this) } catch (_: Exception) { }
        try { if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this) } catch (_: Exception) { }
        try { if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 0f, this) } catch (_: Exception) { }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        try {
            wakeLock = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "radaralerta:monitor").apply {
                setReferenceCounted(false)
                acquire(12L * 60 * 60 * 1000)
            }
        } catch (_: Exception) { }
    }

    override fun onLocationChanged(location: Location) {
        val now = SystemClock.elapsedRealtime()
        // A rede só serve de reserva: com GPS recente, ignora fixes menos precisos.
        if (location.provider == LocationManager.NETWORK_PROVIDER && now - lastGpsElapsed < 15000L) return
        if (location.provider == LocationManager.GPS_PROVIDER) lastGpsElapsed = now
        lastFixElapsed = now
        lastAccuracy = if (location.hasAccuracy()) location.accuracy else -1f

        val radars = RadarStore.all(this)
        if (radars.isEmpty()) { nearest = null; refreshNotification(true); return }
        val distanceLimit = listOf(100, 200, 300, 500, 800, 1000).getOrElse(prefs.getInt("distance", 2)) { 300 }
        val useDirection = prefs.getBoolean("direction", true)
        var bestNear: Radar? = null
        var bestNearDistance = Float.MAX_VALUE
        var candidate: Radar? = null
        var candidateD = Float.MAX_VALUE
        val result = FloatArray(1)
        for (radar in radars) {
            Location.distanceBetween(location.latitude, location.longitude, radar.latitude, radar.longitude, result)
            val d = result[0]
            if (d < bestNearDistance) { bestNear = radar; bestNearDistance = d }
            if (d <= distanceLimit && d < candidateD && RadarDirectionMatcher.shouldAlert(radar, location, d, useDirection)) {
                candidate = radar; candidateD = d
            }
        }
        nearest = bestNear
        nearestDistance = bestNearDistance
        if (candidate != null) {
            lastCandidateElapsed = now
            candidateRadar = candidate
            candidateDistance = candidateD
            maybeAlert(candidate, candidateD, location)
            updateOverlay(candidate, candidateD)
        }
        refreshNotification(candidate != null)
    }

    // ------------------------------------------------------------------ vigia (roda a cada 1,5 s)

    private val tick = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            val reference = if (lastFixElapsed != 0L) lastFixElapsed else startedElapsed
            // Sem nenhum fix por 45 s: registra os provedores de novo (recupera de falhas silenciosas).
            if (now - reference > 45000L && now - lastRegisterElapsed > 30000L) registerLocationUpdates()
            val hideAfter = (AlertOptions.HIDE_SECONDS.getOrElse(prefs.getInt("overlay_hide", 1)) { 6 }) * 1000L
            if (alertOverlay.isShowing && now - lastCandidateElapsed > hideAfter) { alertOverlay.hide(); overlayKey = null }
            if (lastCandidateElapsed != 0L && now - lastCandidateElapsed > hideAfter) dismissedKey = null
            refreshNotification(false)
            handler.postDelayed(this, 1500L)
        }
    }

    // ------------------------------------------------------------------ alertas

    private fun keyOf(radar: Radar) = radar.code ?: "${radar.latitude},${radar.longitude}"

    private fun maybeAlert(radar: Radar, distance: Float, location: Location) {
        if (location.hasAccuracy() && location.accuracy > 65f) return
        val key = keyOf(radar)
        val now = System.currentTimeMillis()
        if (now - (lastAlertAt[key] ?: 0L) < 45000L) return
        lastAlertAt[key] = now
        if (prefs.getBoolean("voice", true) && ttsReady) {
            tts?.speak(AlertFormatter.voiceMessage(prefs, radar, distance), TextToSpeech.QUEUE_FLUSH, null, "radar_$now")
        }
        if (prefs.getBoolean("vibrate", false)) {
            try {
                val vibrator = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
                vibrator.vibrate(android.os.VibrationEffect.createOneShot(250, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } catch (_: Exception) { }
        }
        if (prefs.getBoolean("sound", true)) {
            val alert = NotificationCompat.Builder(this, ALERT_CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_radar)
                .setColor(0xFFD93025.toInt())
                .setContentTitle("Radar a ${Text.distance(distance)}")
                .setContentText(listOfNotNull(radar.typeLabel, radar.roadLine.ifBlank { null }).joinToString(" • "))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(openAppIntent())
                .setAutoCancel(true)
                .build()
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(key.hashCode() and 0x7fffffff, alert)
        }
    }

    private fun updateOverlay(radar: Radar, distance: Float) {
        if (!prefs.getBoolean("overlay", true) || !Settings.canDrawOverlays(this)) return
        val key = keyOf(radar)
        if (key == dismissedKey) return
        overlayKey = key
        alertOverlay.update(prefs, distance, AlertFormatter.overlayLines(prefs, radar))
    }

    // ------------------------------------------------------------------ notificação dinâmica

    private fun refreshNotification(force: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastNotifElapsed < 1000L) return
        lastNotifElapsed = now
        val age = if (lastFixElapsed == 0L) -1L else (now - lastFixElapsed) / 1000L
        val gps = when {
            age < 0 -> "Aguardando sinal de GPS…"
            age > 10 -> "Sem sinal de GPS há ${age}s"
            lastAccuracy >= 0 -> "GPS ±${lastAccuracy.toInt()} m"
            else -> "GPS ativo"
        }
        val alerting = candidateRadar != null && now - lastCandidateElapsed < 3000L
        val near = nearest
        val title: String
        val text: String
        if (alerting) {
            val r = candidateRadar!!
            title = "Radar a ${Text.distance(candidateDistance)}"
            text = listOfNotNull(r.typeLabel, r.roadLine.ifBlank { null }).joinToString(" • ")
        } else {
            title = "Radar Alerta ativo"
            text = if (near != null && age in 0..30) {
                "Mais próximo: ${Text.distance(nearestDistance)} • " + listOfNotNull(near.code?.takeIf { near.source != "OpenStreetMap" } ?: near.type, near.roadLine.ifBlank { null }).joinToString(" • ")
            } else gps
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildNotification(title, text, gps, alerting))
    }

    private fun buildNotification(title: String, text: String, sub: String?, alerting: Boolean): Notification =
        NotificationCompat.Builder(this, STATUS_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_radar)
            .setColor(if (alerting) 0xFFD93025.toInt() else 0xFF1456D6.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setSubText(sub)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setWhen(System.currentTimeMillis())
            .setShowWhen(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent())
            .addAction(0, "Parar", stopIntent())
            .build()

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun stopIntent(): PendingIntent = PendingIntent.getService(
        this, 1, Intent(this, RadarMonitorService::class.java).setAction(ACTION_STOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(STATUS_CHANNEL, "Monitoramento em andamento", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Notificação permanente com o radar mais próximo, atualizada ao vivo"
        })
        manager.createNotificationChannel(NotificationChannel(ALERT_CHANNEL, "Alertas de radar", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Avisos quando você se aproxima de um radar"
        })
    }

    // ------------------------------------------------------------------ voz e ciclo de vida

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (!ttsReady) return
        tts?.language = Locale("pt", "BR")
        // Fala como instrução de navegação: reduz o volume da música em vez de competir com ela.
        tts?.setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
        )
    }

    override fun onProviderEnabled(provider: String) { registerLocationUpdates() }
    override fun onProviderDisabled(provider: String) { refreshNotification(true) }
    @Deprecated("Deprecated by Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { locationManager.removeUpdates(this) } catch (_: Exception) { }
        alertOverlay.hide()
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) { }
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "br.com.radaralerta.STOP"
        private const val NOTIFICATION_ID = 42
        private const val STATUS_CHANNEL = "radar_status"
        private const val ALERT_CHANNEL = "radar_alert"
    }
}
