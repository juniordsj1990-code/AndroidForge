package br.com.radaralerta

import android.content.Context
import android.location.Geocoder
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Endereço a partir de coordenadas (geocodificação reversa). Usa o Geocoder do aparelho e, se ele não
 * estiver disponível, o Nominatim do OpenStreetMap. Resultados ficam em cache para não repetir consultas
 * (a política do Nominatim pede no máximo 1 consulta por segundo e identificação do app).
 */
object AddressLookup {
    private val memory = HashMap<String, String>()
    private val failedAt = HashMap<String, Long>()
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var lastRequestAt = 0L

    private fun key(lat: Double, lon: Double) = String.format(Locale.ROOT, "%.4f,%.4f", lat, lon)

    /** Chame na thread principal; [onResult] também é chamado na thread principal (null = indisponível). */
    fun lookup(context: Context, lat: Double, lon: Double, onResult: (String?) -> Unit) {
        val app = context.applicationContext
        val k = key(lat, lon)
        val prefs = app.getSharedPreferences("address_cache", Context.MODE_PRIVATE)
        val cached = memory[k] ?: prefs.getString(k, null)
        if (cached != null) { memory[k] = cached; onResult(cached); return }
        val failed = failedAt[k]
        if (failed != null && System.currentTimeMillis() - failed < 60_000L) { onResult(null); return }
        executor.execute {
            val result = fromGeocoder(app, lat, lon) ?: fromNominatim(app, lat, lon)
            main.post {
                if (result != null) { memory[k] = result; prefs.edit().putString(k, result).apply() } else failedAt[k] = System.currentTimeMillis()
                onResult(result)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun fromGeocoder(context: Context, lat: Double, lon: Double): String? = try {
        if (!Geocoder.isPresent()) null else {
            val a = Geocoder(context, Locale("pt", "BR")).getFromLocation(lat, lon, 1)?.firstOrNull()
            a?.let {
                val street = it.thoroughfare?.let { t -> t + (it.subThoroughfare?.let { n -> ", $n" } ?: "") }
                listOfNotNull(street, it.subLocality, it.locality, it.adminArea).filter { s -> s.isNotBlank() }.joinToString(", ").ifBlank { null }
            }
        }
    } catch (_: Exception) { null }

    private fun fromNominatim(context: Context, lat: Double, lon: Double): String? {
        var conn: HttpURLConnection? = null
        return try {
            val wait = lastRequestAt + 1100L - System.currentTimeMillis()
            if (wait > 0) Thread.sleep(wait)
            lastRequestAt = System.currentTimeMillis()
            val url = URL(String.format(Locale.ROOT, "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1&accept-language=pt-BR&lat=%.6f&lon=%.6f", lat, lon))
            conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 8000
                setRequestProperty("User-Agent", "RadarAlerta/0.6 (Android; ${context.packageName})")
                setRequestProperty("Accept-Language", "pt-BR")
            }
            if (conn.responseCode != 200) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            val a = json.optJSONObject("address")
            val parts = if (a != null) {
                val city = listOf("city", "town", "village", "municipality").map { a.optString(it, "") }.firstOrNull { it.isNotBlank() } ?: ""
                listOf(a.optString("road", ""), a.optString("suburb", a.optString("neighbourhood", "")), city, a.optString("state", ""))
            } else emptyList()
            parts.filter { it.isNotBlank() }.joinToString(", ").ifBlank { json.optString("display_name", "").ifBlank { null } }
        } catch (_: Exception) { null } finally { conn?.disconnect() }
    }
}
