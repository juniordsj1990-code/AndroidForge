package br.com.radaralerta

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipInputStream

object RadarStore {
    private const val PREFS = "radar_alerta"
    private const val KEY_DATA = "radars_json"
    private const val KEY_UPDATED = "updated_at"

    // Faixa geográfica aceita (Brasil + margem). Coordenadas fora dela são tratadas como inválidas
    // (ex.: longitude sem o sinal negativo cai no Oceano Índico).
    private val LAT_RANGE = -34.0..6.0
    private val LON_RANGE = -75.0..-28.0

    @Volatile private var cache: List<Radar>? = null

    // ---------------------------------------------------------------- persistência

    fun all(context: Context): List<Radar> {
        cache?.let { return it }
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_DATA, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = (0 until arr.length()).mapNotNull { i -> runCatching { fromJson(arr.getJSONObject(i)) }.getOrNull() }
        cache = list
        return list
    }

    fun save(context: Context, radars: List<Radar>) {
        val snapshot = radars.toList()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_DATA, toJsonArray(snapshot).toString())
            .putString(KEY_UPDATED, SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())).apply()
        cache = snapshot
    }

    fun updatedAt(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_UPDATED, "Nunca") ?: "Nunca"

    fun exportJson(context: Context): String = toJsonArray(all(context)).toString(2)

    private fun toJsonArray(radars: List<Radar>): JSONArray {
        val arr = JSONArray()
        radars.forEach { r ->
            arr.put(
                JSONObject().put("latitude", r.latitude).put("longitude", r.longitude).put("type", r.type)
                    .put("speedLimit", r.speedLimit ?: JSONObject.NULL).put("direction", r.direction ?: "").put("source", r.source)
                    .put("code", r.code ?: "").put("highway", r.highway ?: "").put("highwayType", r.highwayType ?: "")
                    .put("km", r.km ?: JSONObject.NULL).put("lanes", r.lanes ?: "").put("city", r.city ?: "")
                    .put("model", r.model ?: "").put("operatorName", r.operatorName ?: "").put("startDate", r.startDate ?: "")
            )
        }
        return arr
    }

    private fun fromJson(o: JSONObject): Radar {
        fun str(key: String): String? = o.optString(key, "").takeIf { it.isNotBlank() }
        return Radar(
            latitude = o.getDouble("latitude"),
            longitude = o.getDouble("longitude"),
            type = o.optString("type", "Radar fixo").ifBlank { "Radar fixo" },
            speedLimit = if (o.isNull("speedLimit")) null else o.optInt("speedLimit"),
            direction = str("direction"),
            source = o.optString("source", "Importado"),
            code = str("code"),
            highway = str("highway"),
            highwayType = str("highwayType"),
            km = if (o.isNull("km") || !o.has("km")) null else o.optDouble("km").takeIf { it.isFinite() },
            lanes = str("lanes"),
            city = str("city"),
            model = str("model"),
            operatorName = str("operatorName"),
            startDate = str("startDate")
        )
    }

    fun upsert(context: Context, radar: Radar, editIndex: Int? = null) {
        val list = all(context).toMutableList()
        if (editIndex != null && editIndex in list.indices) list[editIndex] = radar else list.add(radar)
        save(context, list)
    }

    fun replace(context: Context, old: Radar, new: Radar) {
        val list = all(context).toMutableList()
        val index = list.indexOf(old)
        if (index >= 0) list[index] = new else list.add(new)
        save(context, list)
    }

    fun remove(context: Context, radar: Radar) {
        val list = all(context).toMutableList()
        if (list.remove(radar)) save(context, list)
    }

    // ---------------------------------------------------------------- importação

    fun preview(input: java.io.InputStream, filename: String): ImportPreview {
        val lower = filename.lowercase(Locale.ROOT)
        val bytes = input.readBytes()
        val isZip = bytes.size > 3 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
        if (lower.endsWith(".xlsx") || lower.endsWith(".xlsm") || isZip) {
            val rows = parseXlsx(bytes)
            if (rows.isEmpty()) throw IllegalArgumentException("A planilha Excel está vazia ou não contém uma primeira aba legível.")
            return parseTabularRows(rows)
        }
        if (lower.endsWith(".xls")) throw IllegalArgumentException("O formato Excel antigo .xls não é suportado. Abra a planilha no Excel e salve como Pasta de Trabalho do Excel (*.xlsx), ou exporte como CSV.")
        val text = String(bytes, Charsets.UTF_8).removePrefix("\uFEFF")
        val trimmed = text.trimStart()
        if (trimmed.startsWith("{")) return parseJsonObject(trimmed)
        if (lower.endsWith(".json") || lower.endsWith(".geojson") || trimmed.startsWith("[")) {
            val count = JSONArray(trimmed).length()
            val parsedJson = parseJson(trimmed)
            return ImportPreview(count, parsedJson, (count - parsedJson.size).coerceAtLeast(0))
        }
        val linesRead = (text.lines().count { it.isNotBlank() } - 1).coerceAtLeast(0)
        if (linesRead == 0) throw IllegalArgumentException("O arquivo não tem nenhum registro (só cabeçalho ou vazio). Se veio do Overpass Turbo, a consulta não retornou resultados: confira em Ajustes > Como obter radares.")
        val parsed = parseCsv(text)
        return ImportPreview(linesRead, parsed, (linesRead - parsed.size).coerceAtLeast(0))
    }

    fun commitImport(context: Context, preview: ImportPreview, replace: Boolean): ImportResult {
        require(preview.radars.isNotEmpty()) { "O arquivo não contém radares válidos; a base não foi alterada." }
        val existing = if (replace) mutableListOf() else all(context).toMutableList()
        val byCode = HashMap<String, Int>()
        existing.forEachIndexed { i, r -> r.code?.let { byCode[it] = i } }
        var added = 0
        var updated = 0
        var duplicates = 0
        preview.radars.forEach { r ->
            val code = r.code
            if (code != null) {
                val at = byCode[code]
                if (at != null) {
                    // Mesmo código: atualiza o cadastro existente (na substituição, é um código repetido no arquivo).
                    existing[at] = r
                    if (replace) duplicates++ else updated++
                } else {
                    existing.add(r); byCode[code] = existing.lastIndex; added++
                }
            } else if (existing.any { it.code == null && distanceMeters(it, r) < 25.0 }) {
                duplicates++
            } else {
                existing.add(r); added++
            }
        }
        save(context, existing)
        val history = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val oldHistory = JSONArray(history.getString("import_history", "[]") ?: "[]")
        val entry = JSONObject().put("date", updatedAt(context)).put("mode", if (replace) "Substituição" else "Mesclagem")
            .put("read", preview.read).put("added", added).put("updated", updated).put("duplicates", duplicates)
            .put("invalid", preview.invalid).put("cancelled", preview.cancelled)
        val newHistory = JSONArray().put(entry)
        for (i in 0 until minOf(oldHistory.length(), 9)) newHistory.put(oldHistory.get(i))
        history.edit().putString("import_history", newHistory.toString()).apply()
        return ImportResult(preview.read, added, duplicates, preview.invalid, updated, preview.cancelled)
    }

    fun importHistory(context: Context): List<String> {
        val arr = JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("import_history", "[]") ?: "[]")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            "${o.optString("date")} • ${o.optString("mode")}\nLidas: ${o.optInt("read")} | novas: ${o.optInt("added")} | atualizadas: ${o.optInt("updated")} | duplicadas: ${o.optInt("duplicates")} | inválidas: ${o.optInt("invalid")} | canceladas: ${o.optInt("cancelled")}"
        }
    }

    // ---------------------------------------------------------------- leitura de .xlsx (offline)

    /** Lê a primeira aba da pasta de trabalho, na ordem em que o Excel a exibe. */
    private fun parseXlsx(bytes: ByteArray): List<List<String>> {
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(bytes.inputStream()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val name = entry.name
                if (!entry.isDirectory && (name == "xl/sharedStrings.xml" || name == "xl/workbook.xml" || name == "xl/_rels/workbook.xml.rels" || SHEET_NAME.matches(name))) {
                    entries[name] = zip.readBytes()
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        val sheetPath = firstSheetPath(entries) ?: throw IllegalArgumentException("Não encontrei a primeira planilha dentro do arquivo .xlsx.")
        val sheet = entries[sheetPath] ?: throw IllegalArgumentException("Não encontrei a primeira planilha dentro do arquivo .xlsx.")
        val shared = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val parser = newXmlParser(sheet)
        val rows = mutableListOf<List<String>>()
        var row: MutableMap<Int, String>? = null
        var cellRef = ""
        var cellType = ""
        var cellValue = ""
        var inCell = false
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            when (parser.eventType) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> row = sortedMapOf<Int, String>()
                    "c" -> { inCell = true; cellRef = parser.getAttributeValue(null, "r") ?: "A1"; cellType = parser.getAttributeValue(null, "t") ?: ""; cellValue = "" }
                    "v", "t" -> if (inCell) cellValue += parser.nextText()
                }
                XmlPullParser.END_TAG -> when (parser.name) {
                    "c" -> {
                        val idx = columnIndex(cellRef)
                        val value = if (cellType == "s") shared.getOrNull(cellValue.toIntOrNull() ?: -1) ?: "" else cellValue
                        row?.put(idx, value)
                        inCell = false
                    }
                    "row" -> {
                        val current = row
                        if (current != null) {
                            val max = current.keys.maxOrNull() ?: -1
                            rows.add((0..max).map { current[it] ?: "" })
                        }
                        row = null
                    }
                }
            }
            parser.next()
        }
        return rows.filter { it.any(String::isNotBlank) }
    }

    private val SHEET_NAME = Regex("xl/worksheets/sheet\\d+\\.xml")

    private fun firstSheetPath(entries: Map<String, ByteArray>): String? {
        val workbook = entries["xl/workbook.xml"]
        val rels = entries["xl/_rels/workbook.xml.rels"]
        if (workbook != null && rels != null) {
            var rid: String? = null
            val wb = newXmlParser(workbook)
            while (wb.eventType != XmlPullParser.END_DOCUMENT && rid == null) {
                if (wb.eventType == XmlPullParser.START_TAG && wb.name == "sheet") {
                    for (i in 0 until wb.attributeCount) {
                        val attr = wb.getAttributeName(i)
                        if (attr == "r:id" || attr.endsWith(":id")) rid = wb.getAttributeValue(i)
                    }
                }
                wb.next()
            }
            if (rid != null) {
                val rp = newXmlParser(rels)
                while (rp.eventType != XmlPullParser.END_DOCUMENT) {
                    if (rp.eventType == XmlPullParser.START_TAG && rp.name == "Relationship" && rp.getAttributeValue(null, "Id") == rid) {
                        val target = (rp.getAttributeValue(null, "Target") ?: "").removePrefix("/")
                        val path = if (target.startsWith("xl/")) target else "xl/$target"
                        if (entries.containsKey(path)) return path
                    }
                    rp.next()
                }
            }
        }
        return entries.keys.filter { SHEET_NAME.matches(it) }
            .minByOrNull { it.filter(Char::isDigit).toIntOrNull() ?: Int.MAX_VALUE }
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val parser = newXmlParser(bytes)
        val result = mutableListOf<String>()
        var current = StringBuilder()
        var inString = false
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            when (parser.eventType) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "si" -> { current = StringBuilder(); inString = true }
                    "t" -> if (inString) current.append(parser.nextText())
                }
                XmlPullParser.END_TAG -> if (parser.name == "si") { result.add(current.toString()); inString = false }
            }
            parser.next()
        }
        return result
    }

    private fun newXmlParser(bytes: ByteArray): XmlPullParser = XmlPullParserFactory.newInstance().newPullParser().apply {
        setInput(bytes.inputStream(), "UTF-8")
    }

    private fun columnIndex(ref: String): Int {
        var value = 0
        for (ch in ref.takeWhile { it.isLetter() }.uppercase(Locale.ROOT)) value = value * 26 + (ch - 'A' + 1)
        return (value - 1).coerceAtLeast(0)
    }

    // ---------------------------------------------------------------- interpretação das linhas

    private val LAT_NAMES = setOf("latitude", "lat", "y", "@lat")
    private val LON_NAMES = setOf("longitude", "lon", "lng", "long", "x", "@lon")
    private val COORD_NAMES = setOf("coordenadas", "coordenada", "coordinates", "coords", "coord", "latlon", "latlng", "lat/lon", "lat,lon", "localizacao")
    private val NUMBER = Regex("-?\\d+(?:[.,]\\d+)?")

    /**
     * Interpreta uma planilha tabular. Aceita colunas separadas de latitude/longitude OU uma única coluna
     * "Coordenadas" (ex.: "-22.910293, -46.546438"), além de Tipo, Código, Rodovia, Km, Faixas, Município,
     * Marca/Modelo, Operadora, Início Operação e Cancelamento (formato DER/ARTESP).
     */
    private fun parseTabularRows(rows: List<List<String>>): ImportPreview {
        val headerRow = (0 until minOf(rows.size, 10)).firstOrNull { i ->
            val h = rows[i].map { Text.normalize(it) }
            (h.any { it in LAT_NAMES } && h.any { it in LON_NAMES }) || h.any { it in COORD_NAMES }
        } ?: throw IllegalArgumentException("Não encontrei colunas de coordenadas na planilha. Use \"Coordenadas\" ou \"Latitude\" e \"Longitude\" no cabeçalho.")
        val headers = rows[headerRow].map { Text.normalize(it) }
        fun col(vararg names: String): Int = headers.indexOfFirst { it in names }

        val latIndex = headers.indexOfFirst { it in LAT_NAMES }
        val lonIndex = headers.indexOfFirst { it in LON_NAMES }
        val coordIndex = headers.indexOfFirst { it in COORD_NAMES }
        val typeIndex = col("tipo", "type", "equipamento")
        val speedIndex = col("velocidade", "speed", "limite", "speedlimit", "velocidade (km/h)")
        val dirIndex = col("direcao", "direction", "sentido")
        val sourceIndex = col("origem", "source", "fonte")
        val codeIndex = col("codigo", "code", "cod", "id")
        val highwayIndex = col("rodovia", "highway", "via")
        val highwayTypeIndex = col("tipo da rodovia", "tipo de rodovia")
        val kmIndex = col("km", "quilometro")
        val lanesIndex = col("faixas", "faixa", "lanes")
        val cityIndex = col("municipio", "cidade", "city")
        val modelIndex = col("marca/modelo", "modelo", "marca", "model")
        val operatorIndex = col("operadora", "operator", "empresa", "concessionaria")
        val startIndex = col("inicio operacao", "inicio de operacao", "inicio", "data de inicio")
        val cancelIndex = col("cancelamento", "cancelado", "data de cancelamento")

        fun cell(cols: List<String>, index: Int): String? = if (index < 0) null else cols.getOrNull(index)?.trim()?.takeIf { it.isNotEmpty() }

        val radars = mutableListOf<Radar>()
        var invalid = 0
        var cancelled = 0
        val dataRows = rows.drop(headerRow + 1).filter { it.any(String::isNotBlank) }
        for (cols in dataRows) {
            val cancelRaw = cell(cols, cancelIndex)
            if (cancelRaw != null && isCancelled(cancelRaw)) { cancelled++; continue }

            val coords: Pair<Double, Double>? = if (latIndex >= 0 && lonIndex >= 0) {
                val la = cell(cols, latIndex)?.replace(',', '.')?.toDoubleOrNull()
                val lo = cell(cols, lonIndex)?.replace(',', '.')?.toDoubleOrNull()
                if (la != null && lo != null) la to lo else null
            } else {
                cell(cols, coordIndex)?.let { parseCoordinates(it) }
            }
            if (coords == null || !validCoordinates(coords.first, coords.second)) { invalid++; continue }

            val lanes = cell(cols, lanesIndex)
            val direction = cell(cols, dirIndex) ?: lanes?.let { lanesToDirection(it) }
            val speedValue = cell(cols, speedIndex)?.replace(',', '.')?.toDoubleOrNull()?.toInt()?.takeIf { it > 0 }
            val startRaw = cell(cols, startIndex)
            radars.add(
                Radar(
                    latitude = coords.first,
                    longitude = coords.second,
                    type = cell(cols, typeIndex)?.uppercase(Locale.ROOT) ?: "Radar fixo",
                    speedLimit = speedValue,
                    direction = direction,
                    source = cell(cols, sourceIndex) ?: "Importado",
                    code = cell(cols, codeIndex),
                    highway = cell(cols, highwayIndex),
                    highwayType = cell(cols, highwayTypeIndex),
                    km = cell(cols, kmIndex)?.replace(',', '.')?.toDoubleOrNull(),
                    lanes = lanes,
                    city = cell(cols, cityIndex),
                    model = cell(cols, modelIndex),
                    operatorName = cell(cols, operatorIndex),
                    startDate = startRaw?.let { dateMillis(it)?.let(::formatDate) ?: it }
                )
            )
        }
        return ImportPreview(dataRows.size, radars, invalid, cancelled)
    }

    private fun parseCoordinates(raw: String): Pair<Double, Double>? {
        val numbers = NUMBER.findAll(raw.replace('\u2212', '-')).mapNotNull { it.value.replace(',', '.').toDoubleOrNull() }.toList()
        return if (numbers.size >= 2) numbers[0] to numbers[1] else null
    }

    /** "N-1, S-1" -> "N, S" ; "L-1, L-2, O-1" -> "L, O". */
    private fun lanesToDirection(lanes: String): String? {
        val letters = Regex("([A-Za-z]{1,2})\\s*-").findAll(lanes).map { it.groupValues[1].uppercase(Locale.ROOT) }.distinct().toList()
        return letters.takeIf { it.isNotEmpty() }?.joinToString(", ")
    }

    private fun validCoordinates(lat: Double, lon: Double): Boolean =
        lat.isFinite() && lon.isFinite() && lat in LAT_RANGE && lon in LON_RANGE

    /** Radar com data de cancelamento já passada (ou texto que não seja data) não deve alertar. */
    private fun isCancelled(raw: String): Boolean {
        val millis = dateMillis(raw)
        if (millis != null) return millis <= System.currentTimeMillis()
        return Text.normalize(raw) !in setOf("-", "--", "n/a", "na", "nao", "null", "0")
    }

    private fun dateMillis(raw: String): Long? {
        val v = raw.trim()
        val serial = v.toDoubleOrNull()
        if (serial != null) {
            // Datas do Excel são números de série (dias desde 30/12/1899).
            return if (serial in 20000.0..80000.0) ((serial - 25569.0) * 86400000.0).toLong() else null
        }
        for (pattern in listOf("dd/MM/yyyy", "yyyy-MM-dd")) {
            try {
                val f = SimpleDateFormat(pattern, Locale.ROOT)
                f.timeZone = TimeZone.getTimeZone("UTC")
                f.isLenient = false
                val parsed = f.parse(v.take(10))
                if (parsed != null) return parsed.time
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun formatDate(millis: Long): String {
        val f = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date(millis))
    }

    // ---------------------------------------------------------------- GeoJSON / Overpass JSON

    /** Aceita GeoJSON (FeatureCollection ou Feature) e o JSON bruto do Overpass ("elements"). */
    private fun parseJsonObject(text: String): ImportPreview {
        val root = JSONObject(text)
        val items = mutableListOf<Radar?>()
        when {
            root.has("features") -> {
                val arr = root.getJSONArray("features")
                for (i in 0 until arr.length()) items.add(runCatching { featureToRadar(arr.getJSONObject(i)) }.getOrNull())
            }
            root.has("elements") -> {
                val arr = root.getJSONArray("elements")
                for (i in 0 until arr.length()) items.add(runCatching { elementToRadar(arr.getJSONObject(i)) }.getOrNull())
            }
            root.optString("type") == "Feature" -> items.add(runCatching { featureToRadar(root) }.getOrNull())
            else -> throw IllegalArgumentException("Não reconheci esse JSON. Use GeoJSON (FeatureCollection), o JSON do Overpass ou uma lista de radares.")
        }
        if (items.isEmpty()) {
            throw IllegalArgumentException("O arquivo não contém nenhum ponto (0 itens). Se foi exportado do Overpass Turbo, a consulta não retornou resultados: confira a região e a consulta em Ajustes > Como obter radares.")
        }
        val radars = items.filterNotNull()
        return ImportPreview(items.size, radars, items.size - radars.size)
    }

    private fun featureToRadar(feature: JSONObject): Radar? {
        val geometry = feature.optJSONObject("geometry") ?: return null
        val coords = mutableListOf<DoubleArray>()
        collectCoordinates(geometry.opt("coordinates"), coords)
        if (coords.isEmpty()) return null
        // GeoJSON usa [longitude, latitude]; linhas e polígonos viram o ponto médio.
        val lon = coords.map { it[0] }.average()
        val lat = coords.map { it[1] }.average()
        val props = feature.optJSONObject("properties") ?: JSONObject()
        val id = feature.opt("id")?.toString()?.takeIf { it.isNotBlank() } ?: props.optString("@id", "").takeIf { it.isNotBlank() }
        return osmRadar(lat, lon, props, id)
    }

    private fun elementToRadar(element: JSONObject): Radar? {
        val center = element.optJSONObject("center")
        val lat = if (element.has("lat")) element.optDouble("lat") else center?.optDouble("lat") ?: Double.NaN
        val lon = if (element.has("lon")) element.optDouble("lon") else center?.optDouble("lon") ?: Double.NaN
        val id = element.optString("type", "").let { t -> if (t.isNotBlank() && element.has("id")) "$t/${element.opt("id")}" else null }
        return osmRadar(lat, lon, element.optJSONObject("tags") ?: JSONObject(), id)
    }

    private fun collectCoordinates(node: Any?, out: MutableList<DoubleArray>) {
        if (node !is JSONArray) return
        if (node.length() >= 2 && node.opt(0) is Number && node.opt(1) is Number) {
            out.add(doubleArrayOf(node.getDouble(0), node.getDouble(1)))
        } else {
            for (i in 0 until node.length()) collectCoordinates(node.opt(i), out)
        }
    }

    /** Converte as tags do OpenStreetMap (highway=speed_camera, maxspeed, direction, operator...) em um Radar. */
    private fun osmRadar(lat: Double, lon: Double, props: JSONObject, id: String?): Radar? {
        if (!validCoordinates(lat, lon)) return null
        fun tag(vararg keys: String): String? {
            for (k in keys) { val v = props.optString(k, "").trim(); if (v.isNotEmpty() && v != "null") return v }
            return null
        }
        val speed = tag("maxspeed", "speedLimit", "velocidade")?.let { Regex("\\d+").find(it)?.value?.toIntOrNull() }?.takeIf { it in 1..250 }
        // Só aproveita sentidos que o app entende (N, S, L, O...). Valores como "forward" ou graus são ambíguos e ignorados.
        val direction = tag("sentido", "direction")?.takeIf { RadarDirectionMatcher.declaredHeadings(it) != null }
        return Radar(
            latitude = lat,
            longitude = lon,
            type = tag("tipo") ?: "Radar fixo",
            speedLimit = speed,
            direction = direction,
            source = "OpenStreetMap",
            code = tag("ref", "codigo", "code") ?: id,
            highway = tag("name", "nome"),
            city = tag("addr:city"),
            operatorName = tag("operator", "operador"),
            startDate = tag("start_date")
        )
    }

    // ---------------------------------------------------------------- JSON / CSV

    private fun parseJson(text: String): List<Radar> {
        val arr = JSONArray(text)
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val lat = o.optDouble("latitude", o.optDouble("lat", Double.NaN))
            val lon = o.optDouble("longitude", o.optDouble("lon", o.optDouble("lng", Double.NaN)))
            if (!validCoordinates(lat, lon)) return@mapNotNull null
            val base = runCatching { fromJson(JSONObject(o.toString()).put("latitude", lat).put("longitude", lon)) }.getOrNull() ?: return@mapNotNull null
            base.copy(
                type = o.optString("type", o.optString("tipo", base.type)).ifBlank { "Radar fixo" },
                speedLimit = o.optInt("speedLimit", o.optInt("velocidade", -1)).takeIf { it > 0 },
                direction = o.optString("direction", o.optString("direcao", "")).takeIf { it.isNotBlank() },
                source = o.optString("source", "Importado").ifBlank { "Importado" }
            )
        }
    }

    private fun parseCsv(text: String): List<Radar> {
        val lines = text.lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        val first = lines.first()
        val delimiter = when {
            first.count { it == '\t' } > maxOf(first.count { it == ';' }, first.count { it == ',' }) -> '\t'
            first.count { it == ';' } > first.count { it == ',' } -> ';'
            else -> ','
        }
        val headers = lines.first().split(delimiter).map { Text.normalize(it) }
        val latIndex = headers.indexOfFirst { it in LAT_NAMES }
        val lonIndex = headers.indexOfFirst { it in LON_NAMES }
        if (latIndex < 0 || lonIndex < 0) throw IllegalArgumentException("Não encontrei colunas de latitude e longitude no CSV.")
        val typeIndex = headers.indexOfFirst { it in listOf("tipo", "type", "equipamento") }
        val speedIndex = headers.indexOfFirst { it in listOf("velocidade", "speed", "limite", "speedlimit", "maxspeed") }
        val dirIndex = headers.indexOfFirst { it in listOf("direcao", "direction", "sentido") }
        val sourceIndex = headers.indexOfFirst { it in listOf("origem", "source", "fonte") }
        return lines.drop(1).mapNotNull { line ->
            val cols = line.split(delimiter).map { it.trim().trim('"') }
            val lat = cols.getOrNull(latIndex)?.replace(',', '.')?.toDoubleOrNull() ?: return@mapNotNull null
            val lon = cols.getOrNull(lonIndex)?.replace(',', '.')?.toDoubleOrNull() ?: return@mapNotNull null
            if (!validCoordinates(lat, lon)) return@mapNotNull null
            Radar(
                latitude = lat,
                longitude = lon,
                type = cols.getOrNull(typeIndex)?.ifBlank { null } ?: "Radar fixo",
                speedLimit = cols.getOrNull(speedIndex)?.let { Regex("\\d+").find(it)?.value?.toIntOrNull() }?.takeIf { it in 1..250 },
                direction = cols.getOrNull(dirIndex)?.takeIf { RadarDirectionMatcher.declaredHeadings(it) != null },
                source = cols.getOrNull(sourceIndex)?.ifBlank { null } ?: "Importado"
            )
        }
    }

    fun distanceMeters(a: Radar, b: Radar): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(b.latitude - a.latitude)
        val dLon = Math.toRadians(b.longitude - a.longitude)
        val x = kotlin.math.sin(dLat / 2).let { it * it } +
            kotlin.math.cos(Math.toRadians(a.latitude)) * kotlin.math.cos(Math.toRadians(b.latitude)) * kotlin.math.sin(dLon / 2).let { it * it }
        return 2 * r * kotlin.math.asin(kotlin.math.sqrt(x.coerceIn(0.0, 1.0)))
    }
}

data class ImportPreview(val read: Int, val radars: List<Radar>, val invalid: Int, val cancelled: Int = 0) {
    val typeCounts: Map<String, Int> get() = radars.groupingBy { it.type }.eachCount()
}

data class ImportResult(val read: Int, val added: Int, val duplicates: Int, val invalid: Int, val updated: Int = 0, val cancelled: Int = 0)
