# Radar Alerta — projeto Android nativo (MVP 0.5.0-dev)

Projeto inicial Android Studio em Kotlin, sem roteirizador. Foi estruturado para monitorar radares localmente e permitir importar/gerenciar a base offline.

## Novidades da 0.5.0
- Interface redesenhada: navegação por abas (Início, Mapa, Radares, Ajustes), cartões, ícone do app e notificações próprias.
- Mapa interno com OpenStreetMap (osmdroid): todos os radares coloridos por tipo, filtro por tipo, toque para ver detalhes, localização atual e zoom. Os tiles precisam de internet e ficam em cache no aparelho.
- Importação do formato de planilha com colunas Tipo, Código, Rodovia, Tipo da Rodovia, Km, Faixas, Município, Marca/Modelo, Operadora, Início Operação, Cancelamento e Coordenadas ("lat, lon" na mesma célula). O sentido (N/S/L/O) vem de Faixas; cancelados são ignorados; radares com o mesmo código são atualizados ao mesclar; coordenadas fora do Brasil são inválidas.
- Lista com busca por código, rodovia, município, modelo ou operadora.

## O que está implementado
- Tela inicial de monitoramento e navegação entre seções.
- Configurações para voz, som, vibração, janela flutuante e distância de aviso.
- Importação local de Excel `.xlsx`, CSV e JSON via seletor de arquivos do Android. O `.xlsx` é lido offline pela primeira aba da pasta de trabalho.
- Validação básica de latitude/longitude, contagem de registros inválidos e deduplicação aproximada por distância (25 m).
- Exportação da base em JSON.
- Lista local de radares.
- Serviço em primeiro plano usando GPS, notificação persistente, voz (TextToSpeech), vibração e sobreposição flutuante mediante permissão.
- Dados armazenados localmente no dispositivo; não há servidor ou roteirizador.

## Abrir no Android Studio
1. Extraia o ZIP.
2. Abra a pasta `RadarAlertaAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle e instale o SDK Android 35, se solicitado.
4. Execute em um aparelho Android físico para testar GPS e sobreposição.

## Formato Excel (.xlsx)
A primeira aba deve conter uma linha de cabeçalho com colunas `latitude` e `longitude` (também aceita `lat` e `lon`). São opcionais `tipo`, `velocidade`, `direcao` e `origem`. Exemplo de cabeçalho: `latitude | longitude | tipo | velocidade | direcao | origem`. A importação de `.xlsx` é offline e não exige biblioteca ou serviço externo. O formato legado `.xls` não é suportado diretamente: abra-o no Excel e salve como `.xlsx` ou CSV.

## Formato CSV
Cabeçalhos aceitos incluem `latitude,longitude,tipo,velocidade,direcao` ou `lat;lon;tipo;velocidade;direcao`. A importação tenta detectar vírgula ou ponto e vírgula como separador. Arquivos CSV com campos entre aspas contendo o próprio separador precisam ser normalizados antes da importação.

## Formato JSON
Uma lista de objetos, por exemplo:

```json
[
  {"latitude": -23.5505, "longitude": -46.6333, "type": "Radar fixo", "speedLimit": 50, "direction": "Norte"}
]
```

Também aceita as chaves `lat`, `lon`, `lng`, `tipo`, `velocidade` e `direcao`.

## Importante — limitações do MVP
- A base inicial está vazia: o projeto não distribui coordenadas de radares reais. Importe dados de origem confiável e confira licença, data e cobertura.
- O filtro por direção ainda não faz inferência automática da via/sentido; o campo é preservado como metadado.
- O mecanismo de alerta é por proximidade GPS, não usa mapa de ruas nem roteirização. Isso pode gerar avisos de radares em vias paralelas, sentidos opostos ou acessos próximos.
- A deduplicação usa distância aproximada de 25 m e pode exigir revisão manual.
- O app pede permissões em tempo de execução; no Android recente, o usuário deve conceder manualmente acesso à localização em segundo plano conforme a versão do sistema e autorizar “Exibir sobre outros apps” para a janela flutuante.
- Teste em ambiente seguro. O projeto ainda não foi compilado neste ambiente e não foi validado em aparelhos físicos. Trate como MVP de desenvolvimento, não como versão pronta para distribuição pública.
- O APK enviado anteriormente não inclui o código-fonte original. Este é um projeto Android nativo novo, criado com base nos requisitos descritos; não é uma reconstrução exata do código interno do APK.

## Próximas melhorias recomendadas
1. Trocar armazenamento simples por Room/SQLite e índice espacial para bases grandes.
2. Implementar importador CSV robusto e mapeamento de colunas configurável.
3. Adicionar tela de pré-visualização e seleção de estratégia: mesclar ou substituir a base.
4. Adicionar edição manual de radares e histórico das importações.
5. Melhorar a direção de deslocamento e filtragem por via para reduzir falsos alertas.
6. Criar testes instrumentados, política de privacidade e fluxo de distribuição.

## Atualização de gerenciamento (0.2.0-dev)
- Prévia do arquivo antes de gravar a base.
- Escolha entre mesclar e substituir a base local.
- Bloqueio para impedir que um arquivo sem radares válidos apague a base.
- Cadastro manual e edição/exclusão de radares.
- Histórico local das últimas 10 importações, com modo e contagens.
- Campo de origem preservado quando informado no CSV/JSON.
- A tela de base lista até 300 radares para evitar uma tela excessivamente pesada.

Esta atualização ainda requer compilação e testes no Android Studio/aparelho físico. A importação CSV é simples e não suporta todos os casos de CSV com separadores dentro de campos entre aspas.


## Versão 0.4.0-dev — precisão e tela bloqueada

### Filtro de direção e vias próximas
- Usa o rumo GPS do aparelho quando há movimento suficiente.
- Exige que o radar esteja aproximadamente à frente do deslocamento e próximo do corredor de movimento (filtro de distância lateral estimada).
- Quando a base contém uma direção cardinal reconhecida (Norte, Sul, Leste, Oeste e diagonais), compara-a com o rumo do veículo.
- Descarta posições GPS com precisão declarada pior que 65 m.
- Em velocidade muito baixa ou sem rumo GPS estável, só permite alerta muito próximo e sem direção explícita, para reduzir falsos positivos.

**Limitação importante:** este é um filtro geométrico baseado em GPS, não um mapa de geometria viária. Não consegue garantir que o radar está na mesma pista/estrada, sobretudo em vias paralelas, alças, curvas e cruzamentos. Para precisão de produção, a próxima etapa deve associar cada radar a uma via e geometria de sentido (por exemplo, dados OSM compatíveis com a licença) e validar em trajetos reais.

### Teste com tela bloqueada
1. Instale o APK de depuração em um aparelho Android.
2. Conceda localização precisa e, quando exigido pela versão do Android, localização em segundo plano.
3. Conceda notificações e permissão de sobreposição se desejar a janela flutuante.
4. Inicie o monitoramento, confirme a notificação persistente e bloqueie a tela por 5–10 minutos durante um teste seguro como passageiro.
5. Confirme se a notificação continua atualizando e se voz/alertas são emitidos ao passar por um ponto de teste conhecido.
6. Repita com economia de bateria desativada para o app; alguns fabricantes encerram ou limitam serviços em segundo plano.
7. Não teste manipulando o telefone enquanto dirige.

A continuidade com tela bloqueada depende de permissões, serviço em primeiro plano, configuração de bateria do fabricante e disponibilidade de GPS. Esta versão foi modificada no código-fonte, mas ainda precisa ser compilada e testada em aparelho físico; não declarar como validada até executar esses testes.
