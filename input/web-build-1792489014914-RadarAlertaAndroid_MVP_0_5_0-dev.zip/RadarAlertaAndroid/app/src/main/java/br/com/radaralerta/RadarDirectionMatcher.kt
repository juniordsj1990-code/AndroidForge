package br.com.radaralerta

import android.location.Location
import kotlin.math.abs
import kotlin.math.sin

/** Filtro conservador baseado apenas em GPS. Reduz alertas de vias paralelas/sentido oposto, mas não substitui a geometria da via. */
object RadarDirectionMatcher {
    private const val MAX_HEADING_TO_RADAR_DEG = 58f
    private const val MAX_CROSS_TRACK_METERS = 45f

    /** Vias rotuladas N/S/L/O costumam ser diagonais; por isso a tolerância é ampla. */
    private const val MAX_EXPLICIT_DIRECTION_DIFF_DEG = 75f
    private const val LOW_SPEED_MPS = 2.2f

    fun shouldAlert(radar: Radar, location: Location, distanceMeters: Float, useDeclaredDirection: Boolean = true): Boolean {
        if (location.hasAccuracy() && location.accuracy > 65f) return false
        val declared = if (useDeclaredDirection) declaredHeadings(radar.direction) else null

        // Em baixa velocidade o rumo do GPS é instável: só alerta muito perto e sem sentido declarado.
        if (!location.hasBearing() || location.speed < LOW_SPEED_MPS) {
            return distanceMeters <= 70f && declared == null
        }

        val distanceAndBearings = FloatArray(3)
        Location.distanceBetween(location.latitude, location.longitude, radar.latitude, radar.longitude, distanceAndBearings)
        val heading = normalizeAngle(location.bearing)
        val targetBearing = normalizeAngle(distanceAndBearings[1])
        val angleToRadar = angleDifference(heading, targetBearing)

        // O radar deve estar à frente, não em via paralela ou perpendicular.
        if (angleToRadar > MAX_HEADING_TO_RADAR_DEG) return false
        val crossTrack = distanceMeters * abs(sin(Math.toRadians(angleToRadar.toDouble())))
        if (crossTrack > MAX_CROSS_TRACK_METERS) return false

        // Sentido declarado (ex.: "N, S" vindo da coluna Faixas): vale qualquer um dos sentidos listados.
        if (declared != null && declared.none { angleDifference(heading, it) <= MAX_EXPLICIT_DIRECTION_DIFF_DEG }) return false
        return true
    }

    /** Converte "N, S", "Norte" ou "L-1, O-1" em rumos. Descrições desconhecidas retornam null (não são adivinhadas). */
    fun declaredHeadings(raw: String?): List<Float>? {
        if (raw.isNullOrBlank()) return null
        directionAngle(raw)?.let { return listOf(it) }
        val tokens = raw.split(Regex("[,;/\\s]+")).filter { it.isNotBlank() }
        if (tokens.isEmpty()) return null
        val angles = tokens.map { directionAngle(it) ?: return null }
        return angles.distinct()
    }

    private fun directionAngle(raw: String?): Float? {
        val value = raw?.trim()?.lowercase()?.replace('á', 'a')?.replace('ã', 'a')
            ?.replace('é', 'e')?.replace('í', 'i')?.replace('ó', 'o')?.replace('ú', 'u')
            ?.replace("º", "")?.replace("°", "") ?: return null
        return when {
            value in listOf("n", "norte", "north") || value.contains("sentido norte") -> 0f
            value in listOf("ne", "nordeste", "northeast") -> 45f
            value in listOf("l", "e", "leste", "este", "east") -> 90f
            value in listOf("se", "sudeste", "southeast") -> 135f
            value in listOf("s", "sul", "south") || value.contains("sentido sul") -> 180f
            value in listOf("so", "sudoeste", "southwest") -> 225f
            value in listOf("o", "w", "oeste", "west") -> 270f
            value in listOf("no", "noroeste", "northwest") -> 315f
            else -> null
        }
    }

    private fun normalizeAngle(value: Float): Float = ((value % 360f) + 360f) % 360f
    private fun angleDifference(a: Float, b: Float): Float {
        val diff = abs(normalizeAngle(a) - normalizeAngle(b))
        return minOf(diff, 360f - diff)
    }
}
