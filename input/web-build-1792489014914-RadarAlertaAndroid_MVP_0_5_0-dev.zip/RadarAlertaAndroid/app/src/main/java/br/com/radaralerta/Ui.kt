package br.com.radaralerta

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** Paleta do app. */
object Palette {
    val NAVY = 0xFF0B1F3A.toInt()
    val NAVY_LIGHT = 0xFF14407F.toInt()
    val PRIMARY = 0xFF1456D6.toInt()
    val BG = 0xFFF1F4F9.toInt()
    val SURFACE = 0xFFFFFFFF.toInt()
    val INK = 0xFF0F1B2D.toInt()
    val MUTED = 0xFF5B6B82.toInt()
    val LINE = 0xFFE3E8F0.toInt()
    val SUCCESS = 0xFF12A150.toInt()
    val DANGER = 0xFFD93025.toInt()
    val WARN = 0xFFF59E0B.toInt()
    val ON_DARK_MUTED = 0xFFB6C4DB.toInt()
}

fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

fun Context.rounded(color: Int, radiusDp: Int = 16, strokeColor: Int? = null): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
        if (strokeColor != null) setStroke(dp(1), strokeColor)
    }

/** Fundo arredondado com efeito de toque (ripple). */
fun Context.pressable(color: Int, radiusDp: Int = 14, strokeColor: Int? = null, rippleColor: Int = 0x33000000): Drawable =
    RippleDrawable(ColorStateList.valueOf(rippleColor), rounded(color, radiusDp, strokeColor), rounded(0xFFFFFFFF.toInt(), radiusDp))

fun Context.lp(
    width: Int = LinearLayout.LayoutParams.MATCH_PARENT,
    height: Int = LinearLayout.LayoutParams.WRAP_CONTENT,
    top: Int = 0, bottom: Int = 0, start: Int = 0, end: Int = 0, weight: Float = 0f
): LinearLayout.LayoutParams = LinearLayout.LayoutParams(width, height, weight).apply {
    setMargins(dp(start), dp(top), dp(end), dp(bottom))
}

fun Context.tv(value: CharSequence, size: Float = 14f, color: Int = Palette.INK, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }

fun Context.card(padding: Int = 16, color: Int = Palette.SURFACE): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(padding), dp(padding), dp(padding), dp(padding))
    background = rounded(color, 18, Palette.LINE)
    elevation = dp(1).toFloat()
}

fun Context.sectionTitle(value: String): TextView =
    tv(value.uppercase(), 12f, Palette.MUTED, true).apply {
        letterSpacing = 0.08f
        setPadding(dp(4), dp(20), 0, dp(8))
    }

fun Context.pill(value: String, background: Int, foreground: Int, sizeSp: Float = 11f): TextView =
    tv(value, sizeSp, foreground, true).apply {
        setPadding(dp(10), dp(4), dp(10), dp(4))
        this.background = rounded(background, 50)
        gravity = Gravity.CENTER
    }

fun Context.primaryButton(label: String, color: Int = Palette.PRIMARY, onClick: () -> Unit): TextView =
    tv(label, 15f, 0xFFFFFFFF.toInt(), true).apply {
        gravity = Gravity.CENTER
        minHeight = dp(52)
        setPadding(dp(18), dp(12), dp(18), dp(12))
        background = pressable(color, 14)
        isClickable = true
        setOnClickListener { onClick() }
    }

fun Context.secondaryButton(label: String, color: Int = Palette.PRIMARY, onClick: () -> Unit): TextView =
    tv(label, 15f, color, true).apply {
        gravity = Gravity.CENTER
        minHeight = dp(48)
        setPadding(dp(18), dp(10), dp(18), dp(10))
        background = pressable(Palette.SURFACE, 14, color, 0x22000000)
        isClickable = true
        setOnClickListener { onClick() }
    }

fun Context.chip(label: String, selected: Boolean, accent: Int = Palette.PRIMARY, onClick: () -> Unit): TextView =
    tv(label, 13f, if (selected) 0xFFFFFFFF.toInt() else Palette.INK, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = pressable(if (selected) accent else Palette.SURFACE, 50, if (selected) accent else Palette.LINE)
        isClickable = true
        setOnClickListener { onClick() }
    }

fun Context.divider(): View = View(this).apply {
    setBackgroundColor(Palette.LINE)
    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(12) }
}

/** Cabeçalho em degradê azul-marinho usado no topo das telas. */
fun Context.headerBackground(): GradientDrawable = GradientDrawable(
    GradientDrawable.Orientation.TL_BR, intArrayOf(Palette.NAVY, Palette.NAVY_LIGHT)
)
