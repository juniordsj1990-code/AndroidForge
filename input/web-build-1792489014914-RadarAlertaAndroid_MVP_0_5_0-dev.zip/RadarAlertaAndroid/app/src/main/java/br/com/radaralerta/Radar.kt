package br.com.radaralerta

import java.util.Locale

data class Radar(
    val latitude: Double,
    val longitude: Double,
    val type: String = "Radar fixo",
    val speedLimit: Int? = null,
    val direction: String? = null,
    val source: String = "Importado",
    val code: String? = null,
    val highway: String? = null,
    val highwayType: String? = null,
    val km: Double? = null,
    val lanes: String? = null,
    val city: String? = null,
    val model: String? = null,
    val operatorName: String? = null,
    val startDate: String? = null
) {
    /** Nome legível do tipo (ex.: CEV -> Controlador de velocidade). */
    val typeLabel: String get() = RadarTypes.label(type)

    /** Texto usado na fala do alerta. */
    val spokenName: String get() = RadarTypes.spoken(type)

    /** "SP 008 • km 96,86" (ou apenas o que estiver disponível). */
    val roadLine: String
        get() = listOfNotNull(highway, km?.let { "km " + String.format(PT_BR, "%.2f", it) }).joinToString(" • ")

    val cityDisplay: String? get() = city?.let { Text.titleCase(it) }

    /** Título curto para listas e notificações. */
    val title: String get() = code ?: typeLabel

    companion object {
        val PT_BR: Locale = Locale("pt", "BR")
    }
}

object RadarTypes {
    fun label(type: String): String = when (type.trim().uppercase(Locale.ROOT)) {
        "CEV" -> "Controlador de velocidade"
        "REV" -> "Redutor de velocidade"
        "CEC" -> "Controlador composto"
        "REC" -> "Redutor composto"
        "CEM" -> "Controlador misto"
        else -> type
    }

    fun spoken(type: String): String = when (type.trim().uppercase(Locale.ROOT)) {
        "CEV" -> "controlador de velocidade"
        "REV" -> "redutor de velocidade"
        "CEC" -> "controlador eletrônico composto"
        "REC" -> "redutor eletrônico composto"
        "CEM" -> "controlador eletrônico misto"
        else -> type
    }

    fun color(type: String): Int = when (type.trim().uppercase(Locale.ROOT)) {
        "CEV" -> 0xFF1456D6.toInt()
        "REV" -> 0xFF7C3AED.toInt()
        "CEC" -> 0xFFF59E0B.toInt()
        "REC" -> 0xFF0E9F9F.toInt()
        "CEM" -> 0xFFDB2777.toInt()
        else -> 0xFFD93025.toInt()
    }
}

object Text {
    private val smallWords = setOf("de", "da", "do", "das", "dos", "e")

    fun titleCase(raw: String): String = raw.trim().lowercase(Locale("pt", "BR")).split(' ')
        .filter { it.isNotEmpty() }
        .mapIndexed { i, w -> if (i > 0 && w in smallWords) w else w.replaceFirstChar { c -> c.titlecase(Locale("pt", "BR")) } }
        .joinToString(" ")

    fun distance(meters: Float): String =
        if (meters < 1000f) "${meters.toInt()} m" else String.format(Radar.PT_BR, "%.1f km", meters / 1000f)

    fun normalize(s: String): String =
        java.text.Normalizer.normalize(s.lowercase(Locale.ROOT).trim().replace("\"", ""), java.text.Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
}
