package br.com.radaralerta

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Point
import android.view.MotionEvent
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay

/**
 * Desenha todos os radares diretamente no canvas (leve mesmo com milhares de pontos) e trata o toque
 * para selecionar o radar mais próximo do dedo.
 */
class RadarMapOverlay(
    private val density: Float,
    private val onSelect: (Radar?) -> Unit
) : Overlay() {
    private var radars: List<Radar> = emptyList()
    private var visibleTypes: Set<String>? = null
    var selected: Radar? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFFFFFFF.toInt(); strokeWidth = 2f * density }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF0F1B2D.toInt(); strokeWidth = 3f * density }
    private val point = Point()
    private val geo = GeoPoint(0.0, 0.0)

    fun setData(list: List<Radar>, types: Set<String>?) {
        radars = list
        visibleTypes = types
    }

    fun setTypes(types: Set<String>?) {
        visibleTypes = types
    }

    private fun isVisible(radar: Radar): Boolean = visibleTypes?.contains(radar.type) ?: true

    private fun radiusFor(zoom: Double): Float = density * when {
        zoom < 8.0 -> 3.5f
        zoom < 11.0 -> 5.5f
        zoom < 14.0 -> 8f
        else -> 11f
    }

    override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
        if (shadow) return
        val projection = mapView.projection
        val box = mapView.boundingBox
        val radius = radiusFor(mapView.zoomLevelDouble)
        for (radar in radars) {
            if (!isVisible(radar) || !box.contains(radar.latitude, radar.longitude)) continue
            geo.setCoords(radar.latitude, radar.longitude)
            projection.toPixels(geo, point)
            fill.color = RadarTypes.color(radar.type)
            canvas.drawCircle(point.x.toFloat(), point.y.toFloat(), radius, fill)
            canvas.drawCircle(point.x.toFloat(), point.y.toFloat(), radius, ring)
        }
        selected?.let { s ->
            geo.setCoords(s.latitude, s.longitude)
            projection.toPixels(geo, point)
            fill.color = RadarTypes.color(s.type)
            canvas.drawCircle(point.x.toFloat(), point.y.toFloat(), radius + 5f * density, halo)
            canvas.drawCircle(point.x.toFloat(), point.y.toFloat(), radius + 1.5f * density, fill)
            canvas.drawCircle(point.x.toFloat(), point.y.toFloat(), radius + 1.5f * density, ring)
        }
    }

    override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
        val projection = mapView.projection
        val box = mapView.boundingBox
        val reach = 30f * density
        var best: Radar? = null
        var bestDist = Float.MAX_VALUE
        for (radar in radars) {
            if (!isVisible(radar) || !box.contains(radar.latitude, radar.longitude)) continue
            geo.setCoords(radar.latitude, radar.longitude)
            projection.toPixels(geo, point)
            val dx = point.x - e.x
            val dy = point.y - e.y
            val d = kotlin.math.sqrt(dx * dx + dy * dy)
            if (d < reach && d < bestDist) { best = radar; bestDist = d }
        }
        selected = best
        onSelect(best)
        mapView.invalidate()
        return best != null
    }
}
