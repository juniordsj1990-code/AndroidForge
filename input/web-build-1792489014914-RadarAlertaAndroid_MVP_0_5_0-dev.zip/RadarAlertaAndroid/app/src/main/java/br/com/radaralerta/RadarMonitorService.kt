package br.com.radaralerta

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class RadarMonitorService : Service(), LocationListener, TextToSpeech.OnInitListener {
    private lateinit var locationManager: LocationManager
    private var tts: TextToSpeech? = null
    private var overlay: TextView? = null
    private val lastAlertAt = mutableMapOf<String, Long>()
    private var ttsReady = false

    override fun onCreate() {
        super.onCreate()
        createChannels()
        tts = TextToSpeech(this, this)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, notification("Monitoramento ativo • aguardando GPS"))
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            stopSelf(); return START_NOT_STICKY
        }
        try { locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500L, 5f, this) }
        catch (_: Exception) { updateNotification("GPS indisponível. Verifique as permissões e o sinal.") }
        return START_STICKY
    }

    override fun onLocationChanged(location: Location) {
        val radars = RadarStore.all(this)
        if (radars.isEmpty()) { updateNotification("Monitoramento ativo • base sem radares"); return }
        val prefs = getSharedPreferences("radar_alerta", MODE_PRIVATE)
        val distanceLimit = listOf(100, 200, 300, 500, 800, 1000).getOrElse(prefs.getInt("distance", 2)) { 300 }
        val useDirection = prefs.getBoolean("direction", true)
        var nearest: Radar? = null
        var nearestDistance = Float.MAX_VALUE
        val result = FloatArray(1)
        for (radar in radars) {
            Location.distanceBetween(location.latitude, location.longitude, radar.latitude, radar.longitude, result)
            val d = result[0]
            if (d < nearestDistance) { nearest = radar; nearestDistance = d }
            if (d <= distanceLimit && RadarDirectionMatcher.shouldAlert(radar, location, d, useDirection)) {
                maybeAlert(radar, d, location)
            }
        }
        nearest?.let { r ->
            val detail = listOfNotNull(r.code ?: r.type, r.roadLine.ifBlank { null }).joinToString(" • ")
            updateNotification("Radar mais próximo: ${Text.distance(nearestDistance)} • $detail")
        }
    }

    private fun maybeAlert(radar: Radar, distance: Float, location: Location) {
        // Evita disparar alertas com fixes de baixa qualidade.
        if (location.hasAccuracy() && location.accuracy > 65f) return
        val key = radar.code ?: "${radar.latitude},${radar.longitude}"
        val now = System.currentTimeMillis()
        if (now - (lastAlertAt[key] ?: 0L) < 45000L) return
        lastAlertAt[key] = now
        val prefs = getSharedPreferences("radar_alerta", MODE_PRIVATE)
        val message = "Atenção, ${radar.spokenName}. ${radar.speedLimit?.let { "Limite de $it quilômetros por hora. " } ?: ""}Aproximadamente ${distance.toInt()} metros."
        if (prefs.getBoolean("voice", true) && ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "radar_$now")
        if (prefs.getBoolean("vibrate", false)) {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(android.os.VibrationEffect.createOneShot(250, android.os.VibrationEffect.DEFAULT_AMPLITUDE)) else vibrator.vibrate(250)
        }
        if (prefs.getBoolean("sound", true)) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val alert = NotificationCompat.Builder(this, ALERT_CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_radar)
                .setColor(0xFFD93025.toInt())
                .setContentTitle("Radar a ${distance.toInt()} m")
                .setContentText(listOfNotNull(radar.typeLabel, radar.roadLine.ifBlank { null }).joinToString(" • "))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(openAppIntent())
                .setAutoCancel(true)
                .build()
            manager.notify(key.hashCode() and 0x7fffffff, alert)
        }
        if (prefs.getBoolean("overlay", true) && Settings.canDrawOverlays(this)) {
            val detail = radar.speedLimit?.let { "$it km/h" } ?: listOfNotNull(radar.code ?: radar.typeLabel, radar.roadLine.ifBlank { null }).joinToString(" • ")
            showOverlay("RADAR • ${distance.toInt()} m\n$detail")
        }
    }

    private fun showOverlay(text: String) {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            if (overlay == null) {
                val view = TextView(this)
                view.setPadding(36, 22, 36, 22)
                view.textSize = 18f
                view.setTextColor(0xFFFFFFFF.toInt())
                view.gravity = Gravity.CENTER
                view.elevation = 12f
                view.background = android.graphics.drawable.GradientDrawable().apply { setColor(0xF0C62828.toInt()); cornerRadius = 36f }
                view.setOnClickListener {
                    try { wm.removeView(view) } catch (_: Exception) { }
                    overlay = null
                }
                val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
                val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
                params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                params.y = 100
                wm.addView(view, params)
                overlay = view
            }
            overlay?.text = "$text\nToque para fechar"
        } catch (_: Exception) { }
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun stopIntent(): PendingIntent = PendingIntent.getService(
        this, 1, Intent(this, RadarMonitorService::class.java).setAction(ACTION_STOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun notification(content: String): Notification = NotificationCompat.Builder(this, STATUS_CHANNEL)
        .setSmallIcon(R.drawable.ic_stat_radar)
        .setColor(0xFF1456D6.toInt())
        .setContentTitle("Radar Alerta ativo")
        .setContentText(content)
        .setStyle(NotificationCompat.BigTextStyle().bigText(content))
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setContentIntent(openAppIntent())
        .addAction(0, "Parar", stopIntent())
        .build()

    private fun updateNotification(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification(text))
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(STATUS_CHANNEL, "Monitoramento em andamento", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Notificação permanente enquanto o monitoramento está ativo"
        })
        manager.createNotificationChannel(NotificationChannel(ALERT_CHANNEL, "Alertas de radar", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Avisos quando você se aproxima de um radar"
        })
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("pt", "BR")
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) { updateNotification("GPS desligado") }
    @Deprecated("Deprecated by Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { locationManager.removeUpdates(this) } catch (_: Exception) { }
        try { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Exception) { }
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "br.com.radaralerta.STOP"
        private const val NOTIFICATION_ID = 42
        private const val STATUS_CHANNEL = "radar_status"
        private const val ALERT_CHANNEL = "radar_alert"
    }
}
