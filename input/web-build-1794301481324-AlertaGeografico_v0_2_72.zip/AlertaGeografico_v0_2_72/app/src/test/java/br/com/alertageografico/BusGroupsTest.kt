package br.com.alertageografico

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class BusGroupsTest {
    private fun bus(id: String, group: String = "", lines: List<String> = emptyList(), route: String? = null, enabled: Boolean = true) =
        Destination(id = id, name = "Ponto $id", latitude = -23.0, longitude = -46.0, radiusMeters = 60,
            transportType = TransportType.BUS, groupName = group, lines = lines, itineraryName = route, enabled = enabled)

    private fun train(id: String, group: String = "") =
        Destination(id = id, name = "Estação $id", latitude = -23.0, longitude = -46.0, groupName = group)

    private val noChoice = emptyMap<String, String>()
    private val noUsage = emptyMap<String, Int>()

    @Test fun listWithoutGroupsIsReturnedUntouched() {
        val stops = listOf(bus("a"), train("b"), bus("c"))
        assertSame(stops, BusGroups.collapse(stops, noChoice, noUsage, emptySet()))
    }

    @Test fun groupNameOnTrainIsIgnored() {
        assertNull(BusGroups.keyOf(train("t", group = "Casa")))
        val stops = listOf(train("t1", "Casa"), train("t2", "Casa"))
        assertSame(stops, BusGroups.collapse(stops, noChoice, noUsage, emptySet()))
    }

    @Test fun groupKeyIgnoresCaseAndSpaces() {
        assertEquals(BusGroups.keyOf(bus("a", "Casa da mãe")), BusGroups.keyOf(bus("b", "  casa da mãe ")))
    }

    @Test fun groupCollapsesToOneSlotAtFirstMemberPosition() {
        val stops = listOf(bus("x"), bus("a", "G"), bus("b", "G"), train("y"), bus("c", "G"))
        val out = BusGroups.collapse(stops, noChoice, noUsage, emptySet())
        assertEquals(listOf("x", "a", "y"), out.map { it.id })
    }

    @Test fun primaryPrefersChoiceThenUsageThenFirst() {
        val options = listOf(bus("a", "G"), bus("b", "G"), bus("c", "G"))
        assertEquals("a", BusGroups.pickPrimary(options, null, noUsage).id)
        assertEquals("c", BusGroups.pickPrimary(options, null, mapOf("b" to 1, "c" to 4)).id)
        assertEquals("b", BusGroups.pickPrimary(options, "b", mapOf("c" to 9)).id)
        // escolha que já não existe cai para a regra automática
        assertEquals("c", BusGroups.pickPrimary(options, "zzz", mapOf("c" to 2)).id)
    }

    @Test fun droppedOptionsLoseThePrimarySpotUnlessAllAreDropped() {
        val options = listOf(bus("a", "G"), bus("b", "G"))
        assertEquals("b", BusGroups.pickPrimary(options, null, mapOf("a" to 5), dropped = setOf("a")).id)
        assertEquals("a", BusGroups.pickPrimary(options, null, mapOf("a" to 5), dropped = setOf("a", "b")).id)
    }

    @Test fun explicitChoiceWinsEvenIfDropped() {
        val options = listOf(bus("a", "G"), bus("b", "G"))
        assertEquals("a", BusGroups.pickPrimary(options, "a", noUsage, dropped = setOf("a")).id)
    }

    @Test fun collapseUsesChoiceAndUsagePerGroup() {
        val stops = listOf(bus("a", "G1"), bus("b", "G1"), bus("c", "G2"), bus("d", "G2"))
        val out = BusGroups.collapse(stops, mapOf("g2" to "d"), mapOf("b" to 3), emptySet())
        assertEquals(listOf("b", "d"), out.map { it.id })
    }

    @Test fun optionsAreScopedToItineraryAndEnabled() {
        val all = listOf(bus("a", "G", route = "R1"), bus("b", "G", route = "R1"), bus("c", "G", route = "R2"),
            bus("d", "G", route = "R1", enabled = false), bus("e", "G"))
        assertEquals(listOf("a", "b"), BusGroups.optionsOf(all, all[0]).map { it.id })
        assertEquals(listOf("e"), BusGroups.optionsOf(all, all[4]).map { it.id })
    }

    @Test fun ungroupedDestinationHasOnlyItself() {
        val d = bus("a")
        assertEquals(listOf(d), BusGroups.optionsOf(listOf(d, bus("b")), d))
    }

    @Test fun parseLinesTrimsDedupesAndLimits() {
        assertEquals(listOf("472", "301", "8000-10"), BusGroups.parseLines(" 472, 301;8000-10 ,, 472 "))
        assertTrue(BusGroups.parseLines("  ").isEmpty())
        assertEquals(BusGroups.MAX_LINES, BusGroups.parseLines((1..30).joinToString(",")).size)
    }

    @Test fun destinationJsonRoundTripKeepsGroupAndLines() {
        val d = bus("a", "Casa da mãe", listOf("472", "301"))
        val back = Destination.fromJson(JSONObject(d.toJson().toString()))
        assertEquals("Casa da mãe", back.groupName)
        assertEquals(listOf("472", "301"), back.lines)
        assertEquals(d, back)
    }

    @Test fun legacyJsonWithoutNewFieldsStillLoads() {
        val legacy = JSONObject("""{"id":"x","name":"Velho","latitude":-23.0,"longitude":-46.0,"radiusMeters":60,"transportType":"bus"}""")
        val d = Destination.fromJson(legacy)
        assertEquals("", d.groupName)
        assertTrue(d.lines.isEmpty())
        assertNull(BusGroups.keyOf(d))
    }

    @Test fun menuShowsOneEntryPerGroupAndPrefersAnEnabledMember() {
        val list = listOf(bus("a", "G", enabled = false), bus("b", "G"), bus("z"), bus("c", "H"))
        assertEquals(listOf("b", "z", "c"), BusGroups.menuEntries(list).map { it.id })
        val plain = listOf(bus("x"), train("t"))
        assertSame(plain, BusGroups.menuEntries(plain))
    }

    @Test fun displayNameShowsGroupAndPointCount() {
        val list = listOf(bus("a", "Casa da mãe"), bus("b", "Casa da mãe"), bus("c", "Sozinho"), bus("d"))
        assertEquals("Casa da mãe · 2 pontos", BusGroups.displayName(list[0], list))
        assertEquals("Ponto c", BusGroups.displayName(list[2], list)) // grupo de um ponto só mostra o nome do ponto
        assertEquals("Ponto d", BusGroups.displayName(list[3], list))
    }
}
