package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AutoLineTrackerTest {
    // 0,001° de latitude ≈ 111 m
    private fun stop(id: String, dLat: Double) =
        Destination(id = id, name = id, latitude = -23.0 + dLat, longitude = -46.0, radiusMeters = 60,
            transportType = TransportType.BUS, groupName = "G")

    private fun fix(dLat: Double, t: Long, speed: Float? = 8f, acc: Float = 10f) =
        TrackFix(-23.0 + dLat, -46.0, acc, t, speed)

    @Test fun optionPassedAndLeftIsDropped() {
        val a = stop("a", 0.010)
        val tracker = AutoLineTracker()
        var t = 1_000L
        // aproxima de A (0,0095 → 0,0100) e se afasta (0,0125 ≈ 280 m além)
        val path = listOf(0.0080, 0.0095, 0.0100, 0.0110, 0.0125)
        val dropped = path.flatMap { tracker.observe(listOf(a), fix(it, t.also { t += 5_000 })).dropped }
        assertEquals(listOf("a"), dropped)
        assertTrue(tracker.isDropped("a"))
    }

    @Test fun optionNeverApproachedIsNotDropped() {
        val far = stop("far", 0.100) // ~11 km
        val tracker = AutoLineTracker()
        var t = 1_000L
        listOf(0.0, 0.005, 0.010, 0.020).forEach { tracker.observe(listOf(far), fix(it, t.also { t += 5_000 })) }
        assertFalse(tracker.isDropped("far"))
    }

    @Test fun movingAwayBeforeApproachingDoesNotDrop() {
        val a = stop("a", 0.050)
        val tracker = AutoLineTracker()
        var t = 1_000L
        // começa longe, se afasta um pouco (curva do trajeto) e depois se aproxima
        listOf(0.040, 0.030, 0.020, 0.030, 0.040, 0.049).forEach { tracker.observe(listOf(a), fix(it, t.also { t += 5_000 })) }
        assertFalse(tracker.isDropped("a"))
    }

    @Test fun lowAccuracyFixesAreIgnored() {
        val a = stop("a", 0.010)
        val tracker = AutoLineTracker()
        tracker.observe(listOf(a), fix(0.0100, 1_000L))
        val u = tracker.observe(listOf(a), fix(0.0300, 6_000L, acc = 120f))
        assertTrue(u.dropped.isEmpty())
        assertFalse(tracker.isDropped("a"))
    }

    @Test fun userWhoStaysStillAfterAlertIsConfirmed() {
        val a = stop("a", 0.010)
        val tracker = AutoLineTracker()
        tracker.beginPending(a, fix(0.0095, 1_000L))
        var confirmed: String? = null
        var t = 2_000L
        repeat(40) {
            val u = tracker.observe(listOf(a), fix(0.0100, t, speed = 1.0f))
            if (u.confirmedId != null && confirmed == null) confirmed = u.confirmedId
            t += 5_000
        }
        assertEquals("a", confirmed)
        assertNull(tracker.pendingId())
    }

    @Test fun confirmationNeedsTheFullStillWindow() {
        val a = stop("a", 0.010)
        val tracker = AutoLineTracker()
        tracker.beginPending(a, fix(0.0095, 1_000L))
        var t = 2_000L
        val confirmations = (1..10).mapNotNull { // 50 s parado: ainda não basta
            tracker.observe(listOf(a), fix(0.0100, t.also { t += 5_000 }, speed = 0.5f)).confirmedId
        }
        assertTrue(confirmations.isEmpty())
    }

    @Test fun movingFixRestartsTheStillWindow() {
        val a = stop("a", 0.010)
        val tracker = AutoLineTracker()
        tracker.beginPending(a, fix(0.0095, 1_000L))
        var t = 2_000L
        var confirmed: String? = null
        fun step(speed: Float) { tracker.observe(listOf(a), fix(0.0100, t, speed = speed)).confirmedId?.let { confirmed = it }; t += 5_000 }
        repeat(15) { step(0.5f) }   // 75 s parado
        step(6f)                     // ônibus arranca: recomeça
        repeat(15) { step(0.5f) }   // mais 75 s: ainda < 120 s desde o recomeço
        assertNull(confirmed)
        repeat(10) { step(0.5f) }   // agora passa de 120 s
        assertEquals("a", confirmed)
    }

    @Test fun busThatKeepsGoingDropsThePendingOption() {
        val a = stop("a", 0.010)
        val tracker = AutoLineTracker()
        tracker.beginPending(a, fix(0.0090, 1_000L))
        val u = tracker.observe(listOf(a), fix(0.0140, 6_000L, speed = 9f)) // ~440 m depois
        assertEquals(listOf("a"), u.dropped)
        assertNull(u.confirmedId)
        assertNull(tracker.pendingId())
    }

    @Test fun earlyAlertFarFromThePointDoesNotCountAsLeaving() {
        val a = stop("a", 0.010)
        val tracker = AutoLineTracker()
        tracker.beginPending(a, fix(0.0040, 1_000L)) // alerta a ~670 m do ponto (raio efetivo alto)
        val u = tracker.observe(listOf(a), fix(0.0060, 6_000L, speed = 12f))
        assertTrue(u.dropped.isEmpty())
        assertEquals("a", tracker.pendingId())
    }

    @Test fun resetClearsEverything() {
        val a = stop("a", 0.010)
        val tracker = AutoLineTracker()
        tracker.beginPending(a, fix(0.0095, 1_000L))
        tracker.reset()
        assertNull(tracker.pendingId())
        assertFalse(tracker.isDropped("a"))
    }
}
