package br.com.alertageografico

import android.content.Context
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Resolução de grupos de ônibus pelo DestinationStore (itinerário e destino único). */
class GroupResolutionTest {
    private fun bus(id: String, group: String = "", route: String? = null, lines: List<String> = emptyList()) =
        Destination(id = id, name = "P$id", latitude = -23.0, longitude = -46.0, radiusMeters = 60,
            transportType = TransportType.BUS, groupName = group, itineraryName = route, lines = lines)

    private val ctx = Context()

    private fun enableAll() {
        DestinationStore.setBusGroupsForRoute(ctx, "R", true)
        DestinationStore.setBusGroupsForIndividual(ctx, true)
    }

    @Test fun routeWithoutGroupsIsExactlyAsBefore() {
        val all = listOf(bus("a", route = "R"), bus("b", route = "R"), bus("c", route = "Outro"))
        assertEquals(listOf("a", "b"), DestinationStore.orderedItineraryStops(ctx, all, "R").map { it.id })
        DestinationStore.setRouteDirection(ctx, "volta")
        assertEquals(listOf("b", "a"), DestinationStore.orderedItineraryStops(ctx, all, "R").map { it.id })
    }

    @Test fun routeSlotFollowsChoiceUsageAndDropped() {
        enableAll()
        val all = listOf(bus("x", route = "R"), bus("a", "G", "R"), bus("b", "G", "R"), bus("y", route = "R"))
        assertEquals(listOf("x", "a", "y"), DestinationStore.orderedItineraryStops(ctx, all, "R").map { it.id })
        DestinationStore.bumpGroupUsage(ctx, "b")
        assertEquals(listOf("x", "b", "y"), DestinationStore.orderedItineraryStops(ctx, all, "R").map { it.id })
        DestinationStore.addGroupDropped(ctx, listOf("b"))
        assertEquals(listOf("x", "a", "y"), DestinationStore.orderedItineraryStops(ctx, all, "R").map { it.id })
        DestinationStore.setGroupChoice(ctx, "g", "b")
        assertEquals(listOf("x", "b", "y"), DestinationStore.orderedItineraryStops(ctx, all, "R").map { it.id })
        DestinationStore.setGroupChoice(ctx, "g", null)
        assertEquals(listOf("x", "a", "y"), DestinationStore.orderedItineraryStops(ctx, all, "R").map { it.id })
    }

    @Test fun individualTargetResolvesGroupFromAnyMember() {
        enableAll()
        val all = listOf(bus("a", "G"), bus("b", "G"), bus("z"))
        val prefs = ctx.getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(DestinationStore.KEY_SELECTED_DESTINATION, "b").apply()
        assertEquals(listOf("a"), DestinationStore.individualTargets(ctx, all).map { it.id })
        DestinationStore.setGroupChoice(ctx, "g", "b")
        assertEquals(listOf("b"), DestinationStore.individualTargets(ctx, all).map { it.id })
        prefs.edit().putString(DestinationStore.KEY_SELECTED_DESTINATION, "z").apply()
        assertEquals(listOf("z"), DestinationStore.individualTargets(ctx, all).map { it.id })
        prefs.edit().putString(DestinationStore.KEY_SELECTED_DESTINATION, "nao-existe").apply()
        assertTrue(DestinationStore.individualTargets(ctx, all).isEmpty())
    }

    @Test fun startingATripResetsChoicesAndDropped() {
        enableAll()
        DestinationStore.setGroupChoice(ctx, "g", "b")
        DestinationStore.addGroupDropped(ctx, listOf("a"))
        DestinationStore.bumpGroupUsage(ctx, "b")
        DestinationStore.setMonitorSelection(ctx, "individual", "a", null)
        assertTrue(DestinationStore.groupChoices(ctx).isEmpty())
        assertTrue(DestinationStore.groupDropped(ctx).isEmpty())
        assertEquals(1, DestinationStore.groupUsage(ctx)["b"])  // o histórico de uso permanece
    }

    @Test fun usageIsCappedAndCountsAccumulate() {
        repeat(3) { DestinationStore.bumpGroupUsage(ctx, "k") }
        assertEquals(3, DestinationStore.groupUsage(ctx)["k"])
        (1..250).forEach { DestinationStore.bumpGroupUsage(ctx, "id$it") }
        assertTrue(DestinationStore.groupUsage(ctx).size <= 200)
        assertEquals(3, DestinationStore.groupUsage(ctx)["k"]) // a mais usada sobrevive ao corte
    }

    @Test fun featureIsOffByDefaultAndLegacyBehaviorIsKept() {
        val all = listOf(bus("a", "G", "R"), bus("b", "G", "R"), bus("c", "G"), bus("d", "G"))
        // grupos cadastrados, mas a chave está desligada: cada ponto continua sendo uma parada/destino
        assertEquals(listOf("a", "b"), DestinationStore.orderedItineraryStops(ctx, all, "R").map { it.id })
        val prefs = ctx.getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(DestinationStore.KEY_SELECTED_DESTINATION, "d").apply()
        assertEquals(listOf("d"), DestinationStore.individualTargets(ctx, all).map { it.id })
        assertTrue(!DestinationStore.busGroupsActive(ctx))
    }

    @Test fun routeSwitchIsPerRouteAndIndependentFromIndividual() {
        val all = listOf(bus("a", "G", "R"), bus("b", "G", "R"), bus("c", "G", "R2"), bus("d", "G", "R2"))
        DestinationStore.setBusGroupsForRoute(ctx, "R", true)
        assertEquals(listOf("a"), DestinationStore.orderedItineraryStops(ctx, all, "R").map { it.id })
        assertEquals(listOf("c", "d"), DestinationStore.orderedItineraryStops(ctx, all, "R2").map { it.id })
        assertTrue(!DestinationStore.busGroupsForIndividual(ctx))
        DestinationStore.setBusGroupsForRoute(ctx, "R", false)
        assertEquals(listOf("a", "b"), DestinationStore.orderedItineraryStops(ctx, all, "R").map { it.id })
    }

    @Test fun renamingARouteKeepsItsSwitch() {
        DestinationStore.setBusGroupsForRoute(ctx, "Casa", true)
        DestinationStore.renameBusGroupsRoute(ctx, "Casa", "Trabalho")
        assertTrue(DestinationStore.busGroupsEnabledForRoute(ctx, "Trabalho"))
        assertTrue(!DestinationStore.busGroupsEnabledForRoute(ctx, "Casa"))
        DestinationStore.renameBusGroupsRoute(ctx, "Outro", "Novo") // sem chave ligada: nada acontece
        assertTrue(!DestinationStore.busGroupsEnabledForRoute(ctx, "Novo"))
    }

    @Test fun activeFollowsMonitorMode() {
        DestinationStore.setBusGroupsForRoute(ctx, "R", true)
        DestinationStore.setMonitorSelection(ctx, "route", null, "R")
        assertTrue(DestinationStore.busGroupsActive(ctx))
        DestinationStore.setMonitorSelection(ctx, "individual", "a", null)
        assertTrue(!DestinationStore.busGroupsActive(ctx))
        DestinationStore.setBusGroupsForIndividual(ctx, true)
        assertTrue(DestinationStore.busGroupsActive(ctx))
    }
}
