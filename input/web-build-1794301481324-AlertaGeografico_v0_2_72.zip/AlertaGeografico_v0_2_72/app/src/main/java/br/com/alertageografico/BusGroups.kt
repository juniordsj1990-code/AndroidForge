package br.com.alertageografico

/**
 * Destino de ônibus com várias opções de desembarque. Cada opção é um [Destination] comum (ponto,
 * raio e aviso próprios) que compartilha o mesmo [Destination.groupName] e lista as linhas que
 * descem ali. Sem Android, para permitir testes de unidade.
 *
 * Regra de ouro: quem não usa grupos não muda em nada. Destinos sem grupo (e todo trem/metrô)
 * passam por aqui sem alteração.
 */
object BusGroups {
    const val MAX_LINES = 12
    const val MAX_LINE_LENGTH = 12

    /** Chave do grupo; nula se o destino não é de ônibus ou não tem grupo. */
    fun keyOf(d: Destination): String? =
        if (d.isBus && d.groupName.isNotBlank()) d.groupName.trim().lowercase() else null

    /** Texto digitado ("472, 301; 8000-10") vira lista limpa, sem repetidas (ignora maiúsculas). */
    fun parseLines(raw: String): List<String> =
        raw.split(',', ';', '\n')
            .map { it.trim().take(MAX_LINE_LENGTH) }
            .filter { it.isNotEmpty() }
            .distinctBy { it.lowercase() }
            .take(MAX_LINES)

    fun linesLabel(d: Destination): String = d.lines.joinToString(" / ")

    /**
     * Opções do mesmo grupo de [d] (inclui o próprio [d]), na ordem da lista, só as ativas e só do
     * mesmo roteiro (ou todas fora de roteiro). Sem grupo, devolve só [d].
     */
    fun optionsOf(all: List<Destination>, d: Destination): List<Destination> {
        val key = keyOf(d) ?: return listOf(d)
        val members = all.filter { it.enabled && keyOf(it) == key && it.itineraryName == d.itineraryName }
        return if (members.any { it.id == d.id } || !d.enabled) members else members + d
    }

    /**
     * Opção principal do grupo, nesta ordem: a linha escolhida pelo usuário; senão a mais usada
     * (empate: a primeira da lista), ignorando as já descartadas por terem sido ultrapassadas.
     * Se todas foram descartadas, volta a considerar todas.
     */
    fun pickPrimary(
        options: List<Destination>,
        choiceId: String?,
        usage: Map<String, Int>,
        dropped: Set<String> = emptySet()
    ): Destination {
        options.firstOrNull { it.id == choiceId }?.let { return it }
        val pool = options.filter { it.id !in dropped }.ifEmpty { options }
        return pool.withIndex()
            .sortedWith(compareByDescending<IndexedValue<Destination>> { usage[it.value.id] ?: 0 }.thenBy { it.index })
            .first().value
    }

    /**
     * Reduz as paradas de um roteiro a uma por grupo: cada grupo ocupa a posição do seu primeiro
     * membro e é representado pela opção principal. Sem grupos, devolve a mesma lista, intacta.
     * [stops] já deve estar filtrada (só do roteiro, só ativas) e na ordem de percurso.
     */
    fun collapse(
        stops: List<Destination>,
        choices: Map<String, String>,
        usage: Map<String, Int>,
        dropped: Set<String>
    ): List<Destination> {
        if (stops.none { keyOf(it) != null }) return stops
        val seen = HashSet<String>()
        val out = ArrayList<Destination>(stops.size)
        for (stop in stops) {
            val key = keyOf(stop)
            if (key == null) { out += stop; continue }
            if (!seen.add(key)) continue
            val members = stops.filter { keyOf(it) == key }
            out += pickPrimary(members, choices[key], usage, dropped)
        }
        return out
    }

    /** Itens do menu de destino único: um por grupo (o primeiro ativo) e os demais como estão. */
    fun menuEntries(list: List<Destination>): List<Destination> {
        if (list.none { keyOf(it) != null }) return list
        val seen = HashSet<String>()
        val out = ArrayList<Destination>(list.size)
        for (d in list) {
            val key = keyOf(d)
            if (key == null) { out += d; continue }
            if (!seen.add(key)) continue
            out += list.firstOrNull { keyOf(it) == key && it.enabled } ?: d
        }
        return out
    }

    /** Nome mostrado na seleção: o do grupo (com a quantidade de pontos) ou o do próprio destino. */
    fun displayName(d: Destination, all: List<Destination>): String {
        val key = keyOf(d) ?: return d.name
        val count = all.count { keyOf(it) == key && it.itineraryName == d.itineraryName }
        return if (count > 1) "${d.groupName.trim()} · $count pontos" else d.name
    }

    /** Resumo curto de uma opção para listas: "Ponto — linhas 472 / 301". */
    fun optionLabel(d: Destination): String =
        if (d.lines.isEmpty()) d.name else "${d.name} — linhas ${linesLabel(d)}"
}
