package br.com.alertageografico

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object DestinationStore {
    const val PREFS = "alerta_geografico"
    const val KEY = "destinations"
    const val KEY_ITINERARY_ICONS = "itinerary_icons"
    const val KEY_MONITORING = "monitoring_active"
    const val KEY_LOCATION_INTERVAL_SECONDS = "location_interval_seconds"
    const val KEY_BATTERY_PROFILE = "battery_profile"
    const val KEY_ALARM_MODE = "alert_alarm_mode"
    const val KEY_ALERT_AUDIO_MODE = "alert_audio_mode"
    const val KEY_ALERT_MIX_MODE = "alert_mix_mode"
    const val KEY_ACTIVE_ITINERARY = "active_itinerary"
    const val KEY_ITINERARY_INDEX = "itinerary_index"
    const val KEY_ROUTE_DIRECTION = "route_direction"
    /** Ônibus com várias opções de desembarque: linha escolhida por grupo (JSON grupo → id). Ausente = automático. */
    const val KEY_GROUP_CHOICE = "bus_group_choice"
    /** Quantas vezes cada opção de desembarque foi usada (JSON id → contagem). Define a opção principal no automático. */
    const val KEY_GROUP_USAGE = "bus_group_usage"
    /** Opções já ultrapassadas na viagem atual (JSON array de ids). */
    const val KEY_GROUP_DROPPED = "bus_group_dropped"
    /** Roteiros com o recurso "várias linhas de ônibus" ligado (JSON array de nomes). Desligado por padrão. */
    const val KEY_GROUPS_ROUTES = "bus_groups_routes"
    /** Recurso "várias linhas de ônibus" para destino único. Desligado por padrão. */
    const val KEY_GROUPS_INDIVIDUAL = "bus_groups_individual"
    const val KEY_AUTO_SKIP_TO_LATER_STOP = "auto_skip_to_later_stop"
    const val KEY_SNOOZE_UNTIL = "alert_snooze_until"
    const val KEY_ETA_MINUTES = "eta_alert_minutes"
    const val KEY_MONITOR_MODE = "monitor_mode"
    const val KEY_SELECTED_DESTINATION = "selected_destination_id"
    const val KEY_DASH_TARGET = "dashboard_target"
    const val KEY_DASH_NEXT = "dashboard_next"
    const val KEY_DASH_DISTANCE = "dashboard_distance_m"
    const val KEY_DASH_ETA = "dashboard_eta_min"
    const val KEY_DASH_ETA_MIN = "dashboard_eta_min_range"
    const val KEY_DASH_ETA_MAX = "dashboard_eta_max_range"
    const val KEY_DASH_ETA_CONFIDENCE = "dashboard_eta_confidence"
    const val KEY_DASH_DISTANCE_MODE = "dashboard_distance_mode"
    const val KEY_DASH_UPDATED = "dashboard_updated"
    /** Segundos sem leitura de GPS (0 = sinal normal). Mostrado no painel e na notificação. */
    const val KEY_DASH_GAP_SECONDS = "dashboard_gap_seconds"
    const val KEY_DASH_ROUTE_PROGRESS = "dashboard_route_progress"
    const val KEY_DASH_TOTAL_DISTANCE = "dashboard_total_distance_m"
    const val KEY_DASH_TOTAL_ETA_MIN = "dashboard_total_eta_min"
    const val KEY_DASH_TOTAL_ETA_MAX = "dashboard_total_eta_max"
    const val KEY_ROUTE_START_LATITUDE = "route_start_latitude"
    const val KEY_ROUTE_START_LONGITUDE = "route_start_longitude"
    const val KEY_ROUTE_START_SET = "route_start_set"
    const val KEY_LAST_LATITUDE = "last_location_latitude"
    const val KEY_LAST_LONGITUDE = "last_location_longitude"
    const val KEY_LAST_LOCATION_UPDATED = "last_location_updated"
    const val KEY_STATION_ROUTE = "station_route_name"
    const val KEY_STATION_OPERATOR = "station_operator"
    const val KEY_STATION_PREVIOUS = "station_previous_name"
    const val KEY_STATION_CURRENT = "station_current_name"
    const val KEY_STATION_NEXT = "station_next_name"
    const val KEY_STATION_LINE_DISTANCE = "station_distance_to_line_m"
    const val KEY_STATION_CURRENT_DISTANCE = "station_distance_to_current_m"
    const val KEY_STATION_NEXT_DISTANCE = "station_distance_to_next_m"
    const val KEY_STATION_UPDATED = "station_navigation_updated"

    /** Intervalo configurado pelo usuário: 5 segundos a 5 minutos. */
    fun locationIntervalSeconds(context: Context): Int = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getInt(KEY_LOCATION_INTERVAL_SECONDS, 5).coerceIn(5, 300)

    fun setLocationIntervalSeconds(context: Context, seconds: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_LOCATION_INTERVAL_SECONDS, seconds.coerceIn(5, 300)).apply()
    }

    /** Perfis de consumo: precision, balanced ou economy. */
    fun batteryProfile(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_BATTERY_PROFILE, "balanced")?.takeIf { it in setOf("precision", "balanced", "economy") } ?: "balanced"

    fun setBatteryProfile(context: Context, profile: String) {
        val safeProfile = profile.takeIf { it in setOf("precision", "balanced", "economy") } ?: "balanced"
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_BATTERY_PROFILE, safeProfile).apply()
    }

    fun saveLastLocation(context: Context, latitude: Double, longitude: Double) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_LAST_LATITUDE, latitude.toString())
            .putString(KEY_LAST_LONGITUDE, longitude.toString())
            .putLong(KEY_LAST_LOCATION_UPDATED, System.currentTimeMillis())
            .apply()
    }

    /** Estado real do serviço: gravado pelo próprio serviço, sobrevive à recriação da Activity. */
    fun monitoringActive(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_MONITORING, false)

    fun setMonitoringActive(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_MONITORING, value).apply()
    }

    /** Modo alarme: toca em volume de alarme, repetindo até o usuário confirmar (ou 60 s). */
    fun alarmMode(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ALARM_MODE, false)

    fun setAlarmMode(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ALARM_MODE, value).apply()
    }

    /** Canal de áudio: mídia (volume de mídia) ou notificação (volume de notificações). */
    fun alertAudioMode(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_ALERT_AUDIO_MODE, "media")?.takeIf { it == "media" || it == "notification" } ?: "media"

    fun setAlertAudioMode(context: Context, value: String) {
        val safeValue = if (value == "notification") "notification" else "media"
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ALERT_AUDIO_MODE, safeValue).apply()
    }


    /** duck reduz temporariamente a música; overlap tenta tocar sem solicitar foco de áudio. */
    fun alertMixMode(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_ALERT_MIX_MODE, "duck")?.takeIf { it == "duck" || it == "overlap" } ?: "duck"

    fun setAlertMixMode(context: Context, value: String) {
        val safeValue = if (value == "overlap") "overlap" else "duck"
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ALERT_MIX_MODE, safeValue).apply()
    }

    fun load(context: Context): List<Destination> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { Destination.fromJson(array.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    /** Ícones dos roteiros são guardados separadamente para não alterar os dados de cada parada. */
    fun loadItineraryIcons(context: Context): Map<String, String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ITINERARY_ICONS, "{}") ?: "{}"
        return runCatching {
            val json = JSONObject(raw)
            buildMap {
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    put(key, br.com.alertageografico.ui.AppIcons.normalize(json.optString(key, ""), br.com.alertageografico.ui.AppIcons.DEFAULT_ROUTE))
                }
            }
        }.getOrDefault(emptyMap())
    }

    fun saveItineraryIcons(context: Context, icons: Map<String, String>) {
        val json = JSONObject()
        icons.forEach { (name, icon) -> json.put(name, icon) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_ITINERARY_ICONS, json.toString()).apply()
    }

    fun save(context: Context, destinations: List<Destination>) {
        val array = JSONArray()
        destinations.forEach { array.put(it.toJson()) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }

    fun monitorMode(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_MONITOR_MODE, "individual") ?: "individual"
    fun setMonitorSelection(context: Context, mode: String, destinationId: String? = null, itinerary: String? = null) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_MONITOR_MODE, mode).putString(KEY_SELECTED_DESTINATION, destinationId)
            .putString(KEY_ACTIVE_ITINERARY, itinerary).putInt(KEY_ITINERARY_INDEX, 0)
            .remove(KEY_GROUP_CHOICE).remove(KEY_GROUP_DROPPED) // cada viagem começa no automático
            .putBoolean(KEY_ROUTE_START_SET, false).putFloat(KEY_DASH_ROUTE_PROGRESS, 0f)
            .putInt(KEY_DASH_TOTAL_DISTANCE, -1).putInt(KEY_DASH_TOTAL_ETA_MIN, -1).putInt(KEY_DASH_TOTAL_ETA_MAX, -1).apply()
    }
    fun selectedDestinationId(context: Context): String? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SELECTED_DESTINATION, null)
    fun saveDashboard(
        context: Context,
        target: String,
        next: String,
        distanceMeters: Int,
        etaMinutes: Int,
        etaMinMinutes: Int = etaMinutes,
        etaMaxMinutes: Int = etaMinutes,
        etaConfidence: String = "normal",
        distanceMode: String = "straight",
        routeProgress: Float = 0f
    ) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_DASH_TARGET, target).putString(KEY_DASH_NEXT, next)
            .putInt(KEY_DASH_DISTANCE, distanceMeters).putInt(KEY_DASH_ETA, etaMinutes)
            .putInt(KEY_DASH_ETA_MIN, etaMinMinutes).putInt(KEY_DASH_ETA_MAX, etaMaxMinutes)
            .putString(KEY_DASH_ETA_CONFIDENCE, etaConfidence)
            .putString(KEY_DASH_DISTANCE_MODE, distanceMode)
            .putFloat(KEY_DASH_ROUTE_PROGRESS, routeProgress.coerceIn(0f, 1f))
            .putInt(KEY_DASH_GAP_SECONDS, 0)
            .putLong(KEY_DASH_UPDATED, System.currentTimeMillis()).apply()
    }
    /**
     * Sem GPS (túnel/subsolo): mantém alvo e próxima parada, mas atualiza distância e faixa de tempo
     * estimadas por dead-reckoning e marca a confiança como "no_gps" com os segundos sem sinal.
     */
    fun saveDashboardNoGps(context: Context, distanceMeters: Int, etaMinMinutes: Int, etaMaxMinutes: Int, gapSeconds: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_DASH_DISTANCE, distanceMeters)
            .putInt(KEY_DASH_ETA_MIN, etaMinMinutes).putInt(KEY_DASH_ETA_MAX, etaMaxMinutes)
            .putInt(KEY_DASH_ETA, if (etaMinMinutes >= 0 && etaMaxMinutes >= 0) (etaMinMinutes + etaMaxMinutes) / 2 else -1)
            .putString(KEY_DASH_ETA_CONFIDENCE, EtaConfidence.NO_GPS.storageValue)
            .putInt(KEY_DASH_GAP_SECONDS, gapSeconds.coerceAtLeast(1))
            .putLong(KEY_DASH_UPDATED, System.currentTimeMillis()).apply()
    }
    /** Distância e tempo aproximado restantes até a parada final do roteiro (-1 = indisponível). */
    fun saveRouteTotals(context: Context, remainingMeters: Int, etaMinMinutes: Int, etaMaxMinutes: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_DASH_TOTAL_DISTANCE, remainingMeters)
            .putInt(KEY_DASH_TOTAL_ETA_MIN, etaMinMinutes)
            .putInt(KEY_DASH_TOTAL_ETA_MAX, etaMaxMinutes).apply()
    }
    fun dashboard(context: Context): android.content.SharedPreferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Salva a estimativa local de navegação ferroviária para a Central de Monitoramento. */
    fun saveStationNavigation(context: Context, result: StationNavigationResult?) {
        val edit = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (result == null) {
            edit.remove(KEY_STATION_ROUTE)
                .remove(KEY_STATION_OPERATOR)
                .remove(KEY_STATION_PREVIOUS)
                .remove(KEY_STATION_CURRENT)
                .remove(KEY_STATION_NEXT)
                .remove(KEY_STATION_LINE_DISTANCE)
                .remove(KEY_STATION_CURRENT_DISTANCE)
                .remove(KEY_STATION_NEXT_DISTANCE)
        } else {
            edit.putString(KEY_STATION_ROUTE, result.routeName)
                .putString(KEY_STATION_OPERATOR, result.operator)
                .putString(KEY_STATION_PREVIOUS, result.previous?.name)
                .putString(KEY_STATION_NEXT, result.next?.name)
                .putInt(KEY_STATION_LINE_DISTANCE, result.distanceToLineMeters.toInt().coerceAtLeast(0))
            // Entre estações não há "atual": remove, em vez de manter a última que ficou para trás.
            if (result.current != null) {
                edit.putString(KEY_STATION_CURRENT, result.current.name)
                    .putInt(KEY_STATION_CURRENT_DISTANCE, result.distanceToCurrentMeters.toInt().coerceAtLeast(0))
            } else edit.remove(KEY_STATION_CURRENT).remove(KEY_STATION_CURRENT_DISTANCE)
            if (result.distanceToNextMeters != null) edit.putInt(KEY_STATION_NEXT_DISTANCE, result.distanceToNextMeters) else edit.remove(KEY_STATION_NEXT_DISTANCE)
        }
        edit.putLong(KEY_STATION_UPDATED, System.currentTimeMillis()).apply()
    }

    fun routeDirection(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ROUTE_DIRECTION, "ida") ?: "ida"
    fun setRouteDirection(context: Context, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_ROUTE_DIRECTION, if (value == "volta") "volta" else "ida")
            .putInt(KEY_ITINERARY_INDEX, 0).apply()
    }
    /** Retorna as paradas ativas na ordem escolhida sem alterar a lista original salva. */
    fun orderedItineraryStops(context: Context, destinations: List<Destination>, itinerary: String?): List<Destination> {
        val stops = destinations.filter { it.itineraryName == itinerary && it.enabled }
        val ordered = if (routeDirection(context) == "volta") stops.asReversed() else stops
        // Sem ônibus agrupado nada muda (e nem lê preferências): o caminho antigo segue idêntico.
        if (ordered.none { BusGroups.keyOf(it) != null } || !busGroupsEnabledForRoute(context, itinerary)) return ordered
        // Parada com várias opções de desembarque vira uma só (a linha escolhida ou a principal).
        return BusGroups.collapse(ordered, groupChoices(context), groupUsage(context), groupDropped(context))
    }

    /** Alvo do destino único: se for de um grupo de ônibus, a opção escolhida ou a principal do grupo. */
    fun individualTargets(context: Context, destinations: List<Destination>): List<Destination> {
        val selected = destinations.firstOrNull { it.id == selectedDestinationId(context) && it.enabled } ?: return emptyList()
        val key = BusGroups.keyOf(selected) ?: return listOf(selected)
        if (!busGroupsForIndividual(context)) return listOf(selected)
        val options = BusGroups.optionsOf(destinations, selected)
        return listOf(BusGroups.pickPrimary(options, groupChoices(context)[key], groupUsage(context), groupDropped(context)))
    }

    /** Nomes dos roteiros que têm o recurso de várias linhas ligado. */
    fun busGroupsRoutes(context: Context): Set<String> {
        val raw = readJson(context, KEY_GROUPS_ROUTES) ?: return emptySet()
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { array.getString(it) }.toSet()
        }.getOrDefault(emptySet())
    }

    fun busGroupsEnabledForRoute(context: Context, itinerary: String?): Boolean =
        !itinerary.isNullOrBlank() && itinerary in busGroupsRoutes(context)

    fun setBusGroupsForRoute(context: Context, itinerary: String, enabled: Boolean) {
        val name = itinerary.trim()
        if (name.isEmpty()) return
        val updated = if (enabled) busGroupsRoutes(context) + name else busGroupsRoutes(context) - name
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_GROUPS_ROUTES, JSONArray(updated.toList()).toString()).apply()
    }

    /** O roteiro foi renomeado: a chave acompanha o novo nome. */
    fun renameBusGroupsRoute(context: Context, oldName: String, newName: String) {
        if (oldName in busGroupsRoutes(context)) {
            setBusGroupsForRoute(context, oldName, false)
            setBusGroupsForRoute(context, newName, true)
        }
    }

    fun busGroupsForIndividual(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_GROUPS_INDIVIDUAL, false)

    fun setBusGroupsForIndividual(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_GROUPS_INDIVIDUAL, enabled).apply()
    }

    /** O recurso está ligado para o monitoramento atual (roteiro ativo ou destino único)? */
    fun busGroupsActive(context: Context): Boolean =
        if (monitorMode(context) == "route") busGroupsEnabledForRoute(context, activeItinerary(context))
        else busGroupsForIndividual(context)

    private fun readJson(context: Context, key: String): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key, null)

    fun groupChoices(context: Context): Map<String, String> {
        val raw = readJson(context, KEY_GROUP_CHOICE) ?: return emptyMap()
        return runCatching {
            val json = JSONObject(raw)
            buildMap<String, String> {
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next().toString()
                    val value = json.optString(key, "")
                    if (value.isNotBlank()) put(key, value)
                }
            }
        }.getOrDefault(emptyMap())
    }

    /** Escolhe a opção de um grupo; [destinationId] nulo volta ao automático. */
    fun setGroupChoice(context: Context, groupKey: String, destinationId: String?) {
        val current = JSONObject(groupChoices(context))
        if (destinationId == null) current.remove(groupKey) else current.put(groupKey, destinationId)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_GROUP_CHOICE, current.toString()).apply()
    }

    fun groupUsage(context: Context): Map<String, Int> {
        val raw = readJson(context, KEY_GROUP_USAGE) ?: return emptyMap()
        return runCatching {
            val json = JSONObject(raw)
            buildMap<String, Int> {
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next().toString()
                    val count = json.optInt(key, 0)
                    if (count > 0) put(key, count)
                }
            }
        }.getOrDefault(emptyMap())
    }

    fun bumpGroupUsage(context: Context, destinationId: String) {
        val usage = groupUsage(context).toMutableMap()
        usage[destinationId] = (usage[destinationId] ?: 0) + 1
        // Limite simples para o mapa não crescer sem fim com destinos apagados.
        val kept = if (usage.size > 200) usage.entries.sortedByDescending { it.value }.take(200).associate { it.key to it.value } else usage
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_GROUP_USAGE, JSONObject(kept as Map<*, *>).toString()).apply()
    }

    fun groupDropped(context: Context): Set<String> {
        val raw = readJson(context, KEY_GROUP_DROPPED) ?: return emptySet()
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { array.getString(it) }.toSet()
        }.getOrDefault(emptySet())
    }

    fun addGroupDropped(context: Context, ids: Collection<String>) {
        if (ids.isEmpty()) return
        val all = groupDropped(context) + ids
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_GROUP_DROPPED, JSONArray(all.toList()).toString()).apply()
    }

    fun activeItinerary(context: Context): String? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ACTIVE_ITINERARY, null)
    fun setActiveItinerary(context: Context, value: String?) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ACTIVE_ITINERARY, value).putInt(KEY_ITINERARY_INDEX, 0).apply() }
    fun autoSkipToLaterStopEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_AUTO_SKIP_TO_LATER_STOP, true)
    fun setAutoSkipToLaterStopEnabled(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_AUTO_SKIP_TO_LATER_STOP, value).apply()
    }
    fun itineraryIndex(context: Context): Int = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_ITINERARY_INDEX, 0)
    fun setItineraryIndex(context: Context, value: Int) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_ITINERARY_INDEX, value.coerceAtLeast(0)).apply() }
    fun etaAlertMinutes(context: Context): Int = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_ETA_MINUTES, 0).coerceIn(0, 30)
    fun setEtaAlertMinutes(context: Context, value: Int) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_ETA_MINUTES, value.coerceIn(0, 30)).apply() }
    fun snoozed(context: Context): Boolean = System.currentTimeMillis() < context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_SNOOZE_UNTIL, 0L)

    fun soundEnabled(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("sound", true)

    fun alertSoundUri(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("alert_sound_uri", null)

    fun setAlertSoundUri(context: Context, value: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("alert_sound_uri", value).apply()
    }

    private fun soundKey(kind: AlertKind) = when (kind) {
        AlertKind.TRAIN -> "alert_sound_uri_train"
        AlertKind.BUS_RADIUS -> "alert_sound_uri_bus_radius"
        AlertKind.BUS_DISTANCE -> "alert_sound_uri_bus_distance"
    }

    /** Valor gravado quando o usuário escolhe "Silencioso" para um tipo. */
    const val SOUND_SILENT = ""

    /** Som incluso no app para cada alerta (usado enquanto o usuário não escolher outro). */
    fun defaultSoundUri(context: Context, kind: AlertKind): String {
        val res = when (kind) {
            AlertKind.TRAIN, AlertKind.BUS_RADIUS -> R.raw.desembarque_proxima_parada
            AlertKind.BUS_DISTANCE -> R.raw.atencao_alerta_geografico
        }
        return "android.resource://${context.packageName}/$res"
    }

    /**
     * Som de cada alerta: a escolha do usuário; senão o som geral antigo (compatibilidade, se ele
     * chegou a escolher um); senão o áudio incluso no app.
     */
    fun alertSoundUri(context: Context, kind: AlertKind): String? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = soundKey(kind)
        if (prefs.contains(key)) return prefs.getString(key, null)
        return prefs.getString("alert_sound_uri", null) ?: defaultSoundUri(context, kind)
    }

    /** Volta os três alertas ao áudio incluso no app. */
    fun resetSoundsToDefault(context: Context) {
        val edit = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("alert_sound_uri")
        AlertKind.values().forEach { edit.remove(soundKey(it)) }
        edit.apply()
    }

    fun hasCustomSound(context: Context, kind: AlertKind): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(soundKey(kind))

    fun setAlertSoundUri(context: Context, kind: AlertKind, value: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(soundKey(kind), value ?: SOUND_SILENT).apply()
    }


    fun alertVolume(context: Context): Float =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat("alert_volume", 1.0f).coerceIn(0f, 1f)

    fun setAlertVolume(context: Context, value: Float) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat("alert_volume", value.coerceIn(0f, 1f)).apply()
    }

    fun alertAudioOutput(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("alert_audio_output", "headphones") ?: "headphones"

    fun setAlertAudioOutput(context: Context, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("alert_audio_output", value).apply()
    }

    // ----- Avançado: simulador de trajeto (testes sem sair de casa) -----
    fun simulationEnabled(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("simulation_enabled", false)

    fun setSimulationEnabled(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("simulation_enabled", value).apply()
    }

    /** Velocidade simulada em km/h (padrão 60). */
    fun simulationSpeedKmh(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("simulation_speed_kmh", 60).coerceIn(5, 400)

    fun setSimulationSpeedKmh(context: Context, value: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("simulation_speed_kmh", value).apply()
    }

    /** Áudio "percurso concluído", tocado depois do alerta da parada final. Ligado por padrão. */
    fun completionAudioEnabled(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("completion_audio", true)

    fun setCompletionAudioEnabled(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("completion_audio", value).apply()
    }

    /** Como mostrar o alerta: "notification" (notificação, como antes) ou "popup" (janela em primeiro plano). */
    const val DISPLAY_NOTIFICATION = "notification"
    const val DISPLAY_POPUP = "popup"

    fun alertDisplayMode(context: Context): String =
        if (context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("alert_display_mode", DISPLAY_NOTIFICATION) == DISPLAY_POPUP)
            DISPLAY_POPUP else DISPLAY_NOTIFICATION

    fun setAlertDisplayMode(context: Context, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("alert_display_mode", value).apply()
    }

    fun vibrationEnabled(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("vibration", true)

    fun setSoundEnabled(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("sound", value).apply()
    }

    fun setVibrationEnabled(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("vibration", value).apply()
    }
}
