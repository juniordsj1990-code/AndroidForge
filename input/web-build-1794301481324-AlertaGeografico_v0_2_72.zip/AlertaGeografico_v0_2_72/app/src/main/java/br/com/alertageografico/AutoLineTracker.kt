package br.com.alertageografico

import kotlin.math.max

/** Leitura de posição simplificada, sem Android, para o [AutoLineTracker]. */
data class TrackFix(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    /** Tempo monotônico (ms). Precisa ser maior que 0. */
    val timeMs: Long,
    val speedMps: Float? = null
)

/** Resultado de um [AutoLineTracker.observe]. */
data class AutoLineUpdate(
    /** Opções que acabaram de ser descartadas por terem sido ultrapassadas (o ônibus passou e se afastou). */
    val dropped: List<String> = emptyList(),
    /** Opção em que o usuário parece ter desembarcado (parado ou a pé por tempo suficiente). */
    val confirmedId: String? = null
)

/**
 * Modo automático de linha: o usuário não disse qual ônibus pegou, então todas as opções de
 * desembarque do grupo ficam armadas. Este rastreador só observa; quem alerta é o motor de proximidade.
 *
 *  - Descarta uma opção quando o trajeto passou perto dela e depois se afastou claramente. Isso só
 *    reduz a ambiguidade e escolhe a opção principal; a opção descartada continua armada e, se o
 *    ônibus voltar a ela, ainda alerta. Nunca se perde um alerta por causa do descarte.
 *  - Depois de um alerta ambíguo, confirma o desembarque se o aparelho fica parado ou a pé
 *    ([STILL_WINDOW_MS] seguidos, velocidade até [STILL_MAX_SPEED_MPS]). Se o ônibus segue viagem,
 *    descarta a opção e continua monitorando.
 */
class AutoLineTracker {
    private class State {
        var minDistance = Double.MAX_VALUE
        var approached = false
        var dropped = false
    }

    private val states = HashMap<String, State>()
    private var pendingId: String? = null
    private var pendingZone = 0.0
    private var stillSince = 0L
    private var stillFixes = 0

    fun reset() {
        states.clear()
        clearPending()
    }

    fun pendingId(): String? = pendingId

    fun clearPending() {
        pendingId = null
        pendingZone = 0.0
        stillSince = 0L
        stillFixes = 0
    }

    /** Chamado quando um alerta ambíguo foi emitido para [option]: passa a observar se o usuário desce ali. */
    fun beginPending(option: Destination, fix: TrackFix) {
        val distance = ProximityEngine.distanceMeters(fix.latitude, fix.longitude, option.latitude, option.longitude)
        pendingId = option.id
        // O alerta pode sair bem antes do ponto (raio efetivo cresce com a velocidade): a zona cobre isso.
        pendingZone = max(CONFIRM_ZONE_M, distance + 100.0)
        stillSince = 0L
        stillFixes = 0
    }

    fun observe(options: List<Destination>, fix: TrackFix): AutoLineUpdate {
        if (fix.accuracyMeters > MAX_ACCURACY_M) return AutoLineUpdate()
        val dropped = ArrayList<String>()
        val pending = pendingId
        for (option in options) {
            val state = states.getOrPut(option.id) { State() }
            if (state.dropped || option.id == pending) continue
            val distance = ProximityEngine.distanceMeters(fix.latitude, fix.longitude, option.latitude, option.longitude)
            if (distance < state.minDistance) state.minDistance = distance
            if (!state.approached && distance <= max(NEAR_MIN_M, option.radiusMeters * 3.0)) state.approached = true
            if (state.approached &&
                distance > state.minDistance + RECEDE_M &&
                distance > option.radiusMeters + RECEDE_M
            ) {
                state.dropped = true
                dropped += option.id
            }
        }

        var confirmed: String? = null
        if (pending != null) {
            val option = options.firstOrNull { it.id == pending }
            if (option == null) {
                clearPending()
            } else {
                val distance = ProximityEngine.distanceMeters(fix.latitude, fix.longitude, option.latitude, option.longitude)
                if (distance > pendingZone) {
                    // Passou direto: não era este o desembarque.
                    states.getOrPut(pending) { State() }.dropped = true
                    dropped += pending
                    clearPending()
                } else {
                    val speed = fix.speedMps
                    if (speed != null && speed.isFinite()) {
                        if (speed > STILL_MAX_SPEED_MPS) {
                            stillSince = 0L
                            stillFixes = 0
                        } else {
                            if (stillSince == 0L) stillSince = fix.timeMs
                            stillFixes++
                            if (stillFixes >= STILL_MIN_FIXES && fix.timeMs - stillSince >= STILL_WINDOW_MS) {
                                confirmed = pending
                                clearPending()
                            }
                        }
                    }
                }
            }
        }
        return AutoLineUpdate(dropped, confirmed)
    }

    fun isDropped(id: String): Boolean = states[id]?.dropped == true

    companion object {
        const val MAX_ACCURACY_M = 75f
        const val NEAR_MIN_M = 250.0
        const val RECEDE_M = 150.0
        const val CONFIRM_ZONE_M = 200.0
        const val STILL_MAX_SPEED_MPS = 3.0f
        const val STILL_WINDOW_MS = 120_000L
        const val STILL_MIN_FIXES = 4
    }
}
