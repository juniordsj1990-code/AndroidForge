package br.com.alertageografico

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/**
 * Cartão "Linha de ônibus" do painel Início. Aparece durante o monitoramento quando o alvo atual
 * (destino único ou parada do roteiro) tem várias opções de desembarque. Por padrão o app fica no
 * automático; tocar em "Trocar" permite dizer qual linha foi pega. A escolha vale até o fim da viagem.
 */
@Composable
fun BusLineChooser(
    destinations: List<Destination>,
    monitorMode: String,
    activeItinerary: String?
) {
    val context = LocalContext.current
    // Só serve para forçar nova leitura das preferências depois de uma escolha.
    var version by remember { mutableStateOf(0) }
    var dialogOpen by remember { mutableStateOf(false) }
    if (version < 0) return
    if (!DestinationStore.busGroupsActive(context)) return

    val currentOrNull: Destination? = if (monitorMode == "route") {
        DestinationStore.orderedItineraryStops(context, destinations, activeItinerary)
            .getOrNull(DestinationStore.itineraryIndex(context))
    } else {
        DestinationStore.individualTargets(context, destinations).firstOrNull()
    }
    val current: Destination = currentOrNull ?: return
    val key = BusGroups.keyOf(current) ?: return
    val options = BusGroups.optionsOf(destinations, current)
    if (options.size < 2) return

    val choiceId = DestinationStore.groupChoices(context)[key]
    val chosen = options.firstOrNull { it.id == choiceId }
    val primary = BusGroups.pickPrimary(
        options, null, DestinationStore.groupUsage(context), DestinationStore.groupDropped(context)
    )
    val summary = if (chosen != null) BusGroups.optionLabel(chosen) else "Automático · principal: ${BusGroups.optionLabel(primary)}"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Linha de ônibus · ${current.groupName}", style = MaterialTheme.typography.titleMedium)
            Text(summary, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { dialogOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("Trocar linha") }
        }
    }

    if (dialogOpen) {
        AlertDialog(
            onDismissRequest = { dialogOpen = false },
            title = { Text("Qual linha você pegou?") },
            text = {
                Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    ChoiceRow(
                        label = "Automático (o app decide)",
                        selected = chosen == null,
                        onClick = {
                            DestinationStore.setGroupChoice(context, key, null)
                            version++
                            dialogOpen = false
                        }
                    )
                    options.forEach { option ->
                        ChoiceRow(
                            label = BusGroups.optionLabel(option),
                            selected = chosen?.id == option.id,
                            onClick = {
                                DestinationStore.setGroupChoice(context, key, option.id)
                                version++
                                dialogOpen = false
                            }
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialogOpen = false }) { Text("Fechar") } }
        )
    }
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, modifier = Modifier.padding(start = 8.dp))
    }
}
