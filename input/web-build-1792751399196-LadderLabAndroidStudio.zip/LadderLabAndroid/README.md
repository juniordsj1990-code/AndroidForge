# Ladder Lab — Android Studio

Projeto Android nativo (Kotlin) que carrega o simulador HTML local em um WebView, sem depender de conexão com a internet. Inclui splash screen, ícone vetorial próprio e o simulador original em `app/src/main/assets/index.html`.

## Abrir e executar
1. Extraia o ZIP.
2. Abra a pasta `LadderLabAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle (JDK 17 recomendado).
4. Execute no emulador ou em um aparelho Android.

## Gerar APK
No Android Studio: **Build > Build APK(s)**. O APK de depuração normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Detalhes
- Application ID: `br.com.ladderlab`
- Versão: `1.0.0`
- Android mínimo: 6.0 (API 23)
- Interface e lógica do simulador são carregadas localmente; não há permissão de internet.
- O projeto não inclui um APK pré-compilado. O Android Studio fará a compilação na primeira execução.
