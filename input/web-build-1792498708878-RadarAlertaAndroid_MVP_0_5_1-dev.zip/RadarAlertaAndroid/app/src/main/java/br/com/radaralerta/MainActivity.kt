package br.com.radaralerta

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.io.File

class MainActivity : Activity() {
    private enum class Tab(val label: String, val icon: Int) {
        HOME("Início", R.drawable.ic_nav_home),
        MAP("Mapa", R.drawable.ic_nav_map),
        RADARS("Radares", R.drawable.ic_nav_list),
        SETTINGS("Ajustes", R.drawable.ic_nav_tune)
    }

    private class Screen(val root: View, val body: LinearLayout)

    private val prefs by lazy { getSharedPreferences("radar_alerta", MODE_PRIVATE) }
    private lateinit var rootLayout: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var navBar: LinearLayout
    private val navButtons = mutableMapOf<Tab, Pair<ImageView, TextView>>()
    private var currentTab = Tab.HOME

    // Estado do mapa
    private var mapView: MapView? = null
    private var locationOverlay: MyLocationNewOverlay? = null
    private var mapFocus: Radar? = null
    private var savedLat = 0.0
    private var savedLon = 0.0
    private var savedZoom = 0.0
    private var mapType: String? = null

    // Estado da lista
    private var listQuery = ""
    private var listType: String? = null

    private val importPicker = 7001
    private val exportRequest = 7002
    private var pendingExport: String? = null

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureOsmdroid()
        buildShell()
        show(Tab.HOME)
        requestBasicPermissions()
    }

    override fun onResume() {
        super.onResume()
        when (currentTab) {
            Tab.HOME, Tab.SETTINGS -> show(currentTab)
            Tab.MAP -> mapView?.onResume()
            Tab.RADARS -> {}
        }
    }

    override fun onPause() {
        mapView?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        leaveMap()
        super.onDestroy()
    }

    @Deprecated("Back handling kept simple for broad Android compatibility")
    override fun onBackPressed() {
        if (currentTab != Tab.HOME) show(Tab.HOME) else super.onBackPressed()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (currentTab != Tab.RADARS) show(currentTab)
    }

    private fun configureOsmdroid() {
        val config = Configuration.getInstance()
        config.load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
        config.userAgentValue = packageName
        val base = File(filesDir, "osmdroid").also { it.mkdirs() }
        config.osmdroidBasePath = base
        config.osmdroidTileCache = File(base, "tiles").also { it.mkdirs() }
        config.tileFileSystemCacheMaxBytes = 200L * 1024 * 1024
        config.tileFileSystemCacheTrimBytes = 150L * 1024 * 1024
    }

    // ------------------------------------------------------------------ estrutura (barra inferior)

    private fun buildShell() {
        rootLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Palette.NAVY) }
        content = FrameLayout(this).apply { setBackgroundColor(Palette.BG) }
        rootLayout.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Palette.SURFACE)
            elevation = dp(8).toFloat()
        }
        Tab.values().forEach { tab ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(9), 0, dp(9))
                background = pressable(Palette.SURFACE, 0, null, 0x22000000)
                isClickable = true
                setOnClickListener { show(tab) }
            }
            val icon = ImageView(this).apply { setImageResource(tab.icon) }
            val label = tv(tab.label, 11f, Palette.MUTED, true)
            item.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
            item.addView(label, lp(width = ViewGroup.LayoutParams.WRAP_CONTENT, top = 2))
            navButtons[tab] = icon to label
            navBar.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        rootLayout.addView(navBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(rootLayout)
        rootLayout.setOnApplyWindowInsetsListener { v, insets ->
            val i = readInsets(insets)
            val imeOpen = i[4] > 0
            v.setPadding(i[0], i[1], i[2], if (imeOpen) i[4] else 0)
            navBar.visibility = if (imeOpen) View.GONE else View.VISIBLE
            navBar.setPadding(0, 0, 0, i[3])
            insets
        }
        rootLayout.requestApplyInsets()
    }

    /** [esquerda, topo, direita, base das barras do sistema, altura do teclado] */
    @Suppress("DEPRECATION")
    private fun readInsets(insets: WindowInsets): IntArray {
        if (Build.VERSION.SDK_INT >= 30) {
            val sys = insets.getInsets(WindowInsets.Type.systemBars())
            val ime = insets.getInsets(WindowInsets.Type.ime())
            return intArrayOf(sys.left, sys.top, sys.right, sys.bottom, ime.bottom)
        }
        val ime = (insets.systemWindowInsetBottom - insets.stableInsetBottom).coerceAtLeast(0)
        return intArrayOf(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.stableInsetBottom, ime)
    }

    private fun show(tab: Tab) {
        leaveMap()
        currentTab = tab
        content.removeAllViews()
        Tab.values().forEach { t ->
            val (icon, label) = navButtons.getValue(t)
            val color = if (t == tab) Palette.PRIMARY else Palette.MUTED
            icon.setColorFilter(color)
            label.setTextColor(color)
        }
        val view = when (tab) {
            Tab.HOME -> homeScreen()
            Tab.MAP -> mapScreen()
            Tab.RADARS -> radarsScreen()
            Tab.SETTINGS -> settingsScreen()
        }
        content.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun header(title: String, subtitle: String?, trailing: View?): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = headerBackground()
            setPadding(dp(20), dp(18), dp(20), dp(18))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(tv(title, 24f, 0xFFFFFFFF.toInt(), true))
        if (subtitle != null) texts.addView(tv(subtitle, 13f, Palette.ON_DARK_MUTED), lp(top = 2))
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing != null) row.addView(trailing, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(12) })
        box.addView(row)
        return box
    }

    private fun screen(title: String, subtitle: String? = null, trailing: View? = null): Screen {
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(header(title, subtitle, trailing))
        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(24)) }
        scroll.addView(body)
        column.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return Screen(column, body)
    }

    // ------------------------------------------------------------------ início

    private fun homeScreen(): View {
        val running = isServiceRunning()
        val radars = RadarStore.all(this)
        val status = pill(if (running) "ATIVO" else "PARADO", if (running) Palette.SUCCESS else 0x33FFFFFF, 0xFFFFFFFF.toInt(), 12f)
        val s = screen("Radar Alerta", "Avisos de radar offline, sem depender de outro app", status)
        val body = s.body

        body.addView(card().apply {
            addView(tv(if (running) "Monitoramento ativo" else "Monitoramento parado", 18f, Palette.INK, true))
            addView(
                tv(
                    if (running) "O app está atento aos radares à frente. Você pode usar outro app de navegação ao mesmo tempo."
                    else "Inicie para receber avisos por voz, som e janela flutuante enquanto dirige.",
                    14f, Palette.MUTED
                ), lp(top = 4, bottom = 14)
            )
            addView(
                primaryButton(if (running) "Parar monitoramento" else "Iniciar monitoramento", if (running) Palette.DANGER else Palette.SUCCESS) {
                    if (running) stopMonitoring() else startMonitoring()
                }
            )
        }, lp(top = 8))

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val updated = RadarStore.updatedAt(this).substringBefore(' ').takeIf { it != "Nunca" } ?: "—"
        val distanceLabel = DISTANCE_OPTIONS.getOrElse(prefs.getInt("distance", 2)) { "300 m" }
        stats.addView(statCard(String.format(Radar.PT_BR, "%,d", radars.size), "Radares"), lp(width = 0, weight = 1f, end = 8))
        stats.addView(statCard(distanceLabel, "Aviso a"), lp(width = 0, weight = 1f, end = 8))
        stats.addView(statCard(updated, "Atualização"), lp(width = 0, weight = 1f))
        body.addView(stats, lp(top = 12))

        if (radars.isEmpty()) {
            body.addView(card().apply {
                addView(tv("Nenhum radar cadastrado", 17f, Palette.INK, true))
                addView(tv("Importe sua planilha (.xlsx), CSV ou JSON para começar. O app reconhece automaticamente colunas como Tipo, Rodovia, Km, Município e Coordenadas.", 14f, Palette.MUTED), lp(top = 4, bottom = 14))
                addView(primaryButton("Importar planilha") { openImportPicker() })
                addView(secondaryButton("Como obter radares") { showHowTo() }, lp(top = 8))
            }, lp(top = 12))
        } else {
            val loc = lastKnownLocation()
            body.addView(nearestCard(radars, loc), lp(top = 12))
            body.addView(card().apply {
                addView(tv("Atalhos", 16f, Palette.INK, true))
                addView(secondaryButton("Ver radares no mapa") { show(Tab.MAP) }, lp(top = 12))
                addView(secondaryButton("Importar ou atualizar base") { openImportPicker() }, lp(top = 8))
            }, lp(top = 12))
        }

        body.addView(
            tv("Use como apoio à direção. Respeite sempre a sinalização e os limites de velocidade; a precisão depende da base importada.", 12f, Palette.MUTED).apply { setPadding(dp(4), dp(16), dp(4), 0) }
        )
        return s.root
    }

    private fun statCard(value: String, caption: String): LinearLayout = card(12).apply {
        gravity = Gravity.CENTER_HORIZONTAL
        addView(tv(value, 18f, Palette.INK, true))
        addView(tv(caption, 11f, Palette.MUTED), lp(width = ViewGroup.LayoutParams.WRAP_CONTENT, top = 2))
    }

    private fun nearestCard(radars: List<Radar>, loc: Location?): View {
        val box = card()
        box.addView(tv("Radar mais próximo", 16f, Palette.INK, true))
        if (loc == null) {
            box.addView(tv("Ative o GPS e permita a localização para ver o radar mais próximo de você.", 14f, Palette.MUTED), lp(top = 6))
            return box
        }
        var best: Radar? = null
        var bestDist = Float.MAX_VALUE
        val out = FloatArray(1)
        for (r in radars) {
            Location.distanceBetween(loc.latitude, loc.longitude, r.latitude, r.longitude, out)
            if (out[0] < bestDist) { bestDist = out[0]; best = r }
        }
        val radar = best ?: return box
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(tv(Text.distance(bestDist), 28f, RadarTypes.color(radar.type), true))
        row.addView(pill(radar.type.take(12).uppercase(), RadarTypes.color(radar.type), 0xFFFFFFFF.toInt()), lp(width = ViewGroup.LayoutParams.WRAP_CONTENT, start = 12))
        box.addView(row, lp(top = 6))
        val detail = listOfNotNull(radar.code, radar.roadLine.ifBlank { null }, radar.cityDisplay).joinToString(" • ")
        box.addView(tv(detail, 14f, Palette.INK), lp(top = 4))
        box.addView(tv("Com base na última posição conhecida do aparelho.", 12f, Palette.MUTED), lp(top = 4, bottom = 12))
        box.addView(secondaryButton("Ver no mapa") { mapFocus = radar; show(Tab.MAP) })
        return box
    }

    // ------------------------------------------------------------------ mapa

    private fun mapScreen(): View {
        val radars = RadarStore.all(this)
        val frame = FrameLayout(this)
        val map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            isTilesScaledToDpi = true
            minZoomLevel = 4.0
            maxZoomLevel = 19.0
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        }
        frame.addView(map, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Cartão de detalhes (aparece ao tocar em um radar)
        val detail = card(16).apply { visibility = View.GONE }
        lateinit var overlay: RadarMapOverlay
        fun closeDetail() { detail.visibility = View.GONE; overlay.selected = null; map.invalidate() }
        fun openDetail(r: Radar) { fillDetail(detail, r) { closeDetail() }; detail.visibility = View.VISIBLE }
        overlay = RadarMapOverlay(resources.displayMetrics.density) { r -> if (r != null) openDetail(r) else closeDetail() }
        overlay.setData(radars, mapType?.let { setOf(it) })

        val me = MyLocationNewOverlay(GpsMyLocationProvider(this), map)
        if (hasLocationPermission()) me.enableMyLocation()
        map.overlays.add(me)
        map.overlays.add(overlay)
        locationOverlay = me
        mapView = map

        // Câmera inicial
        val focus = mapFocus
        mapFocus = null
        val loc = lastKnownLocation()
        when {
            focus != null -> {
                map.controller.setZoom(16.0)
                map.controller.setCenter(GeoPoint(focus.latitude, focus.longitude))
                overlay.selected = focus
                openDetail(focus)
            }
            savedZoom > 0.0 -> {
                map.controller.setZoom(savedZoom)
                map.controller.setCenter(GeoPoint(savedLat, savedLon))
            }
            loc != null && nearestDistance(radars, loc) < 80000f -> {
                map.controller.setZoom(12.0)
                map.controller.setCenter(GeoPoint(loc.latitude, loc.longitude))
            }
            radars.size >= 2 -> {
                val box = BoundingBox.fromGeoPoints(radars.map { GeoPoint(it.latitude, it.longitude) })
                map.post { map.zoomToBoundingBox(box, false, dp(48)) }
            }
            else -> {
                map.controller.setZoom(5.0)
                map.controller.setCenter(GeoPoint(-14.2, -51.9))
            }
        }

        // Filtros por tipo
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(10), dp(12), dp(10)) }
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) }
        val counts = radars.groupingBy { it.type }.eachCount().entries.sortedByDescending { it.value }
        fun renderChips() {
            chipRow.removeAllViews()
            chipRow.addView(chip("Todos (${radars.size})", mapType == null) {
                mapType = null; overlay.setTypes(null); map.invalidate(); renderChips()
            }, lp(width = ViewGroup.LayoutParams.WRAP_CONTENT, end = 8))
            counts.forEach { (type, count) ->
                chipRow.addView(chip("$type ($count)", mapType == type, RadarTypes.color(type)) {
                    mapType = type; overlay.setTypes(setOf(type)); map.invalidate(); renderChips()
                }, lp(width = ViewGroup.LayoutParams.WRAP_CONTENT, end = 8))
            }
        }
        renderChips()
        frame.addView(chipScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // Botões flutuantes
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        buttons.addView(mapButton(ImageView(this).apply { setImageResource(R.drawable.ic_locate); setColorFilter(Palette.PRIMARY) }) { centerOnMe(map, me) }, lp(width = dp(46), height = dp(46), bottom = 10))
        buttons.addView(mapButton(tv("+", 24f, Palette.INK, true)) { map.controller.zoomIn() }, lp(width = dp(46), height = dp(46), bottom = 10))
        buttons.addView(mapButton(tv("−", 24f, Palette.INK, true)) { map.controller.zoomOut() }, lp(width = dp(46), height = dp(46)))
        frame.addView(buttons, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply { topMargin = dp(70); marginEnd = dp(12) })

        frame.addView(detail, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply { setMargins(dp(12), 0, dp(12), dp(26)) })

        // Atribuição obrigatória do OpenStreetMap
        frame.addView(
            tv("© OpenStreetMap contributors", 10f, Palette.INK).apply {
                setPadding(dp(6), dp(2), dp(6), dp(2))
                background = rounded(0xCCFFFFFF.toInt(), 6)
            },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(8), 0, 0, dp(4)) }
        )
        map.onResume()
        return frame
    }

    private fun mapButton(inner: View, onClick: () -> Unit): FrameLayout = FrameLayout(this).apply {
        background = pressable(Palette.SURFACE, 23, Palette.LINE)
        elevation = dp(4).toFloat()
        isClickable = true
        setOnClickListener { onClick() }
        addView(inner, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    private fun centerOnMe(map: MapView, me: MyLocationNewOverlay) {
        if (!hasLocationPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 13)
            return
        }
        me.enableMyLocation()
        val point = me.myLocation
        if (point == null) { toast("Aguardando sinal de GPS…"); return }
        map.controller.setZoom(16.0)
        map.controller.animateTo(point)
    }

    private fun nearestDistance(radars: List<Radar>, loc: Location): Float {
        var best = Float.MAX_VALUE
        val out = FloatArray(1)
        for (r in radars) {
            Location.distanceBetween(loc.latitude, loc.longitude, r.latitude, r.longitude, out)
            if (out[0] < best) best = out[0]
        }
        return best
    }

    private fun fillDetail(box: LinearLayout, r: Radar, onClose: () -> Unit) {
        box.removeAllViews()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(pill(r.type.take(12).uppercase(), RadarTypes.color(r.type), 0xFFFFFFFF.toInt()))
        top.addView(tv(r.code ?: r.typeLabel, 17f, Palette.INK, true), lp(width = 0, weight = 1f, start = 10))
        top.addView(tv("×", 28f, Palette.MUTED).apply { setPadding(dp(14), 0, dp(4), 0); setOnClickListener { onClose() } })
        box.addView(top)
        box.addView(tv(r.typeLabel, 13f, Palette.MUTED), lp(top = 2, bottom = 6))
        infoRows(r).forEach { (label, value) ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            line.addView(tv(label, 12f, Palette.MUTED), LinearLayout.LayoutParams(dp(104), ViewGroup.LayoutParams.WRAP_CONTENT))
            line.addView(tv(value, 13f, Palette.INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            box.addView(line, lp(top = 4))
        }
        box.addView(secondaryButton("Abrir no app de mapas") { openInMaps(r) }, lp(top = 14))
    }

    private fun infoRows(r: Radar): List<Pair<String, String>> = listOfNotNull(
        r.roadLine.takeIf { it.isNotBlank() }?.let { "Via" to it + (r.highwayType?.let { t -> " ($t)" } ?: "") },
        r.cityDisplay?.let { "Município" to it },
        r.direction?.let { "Sentido" to directionWords(it) },
        r.lanes?.let { "Faixas" to it },
        r.speedLimit?.let { "Limite" to "$it km/h" },
        r.model?.let { "Equipamento" to it },
        r.operatorName?.let { "Operadora" to it },
        r.startDate?.let { "Em operação desde" to it },
        "Coordenadas" to String.format(Radar.PT_BR, "%.6f, %.6f", r.latitude, r.longitude)
    )

    private fun directionWords(raw: String): String = raw.split(',', ';').joinToString(", ") {
        when (it.trim().uppercase()) {
            "N" -> "Norte"; "S" -> "Sul"; "L", "E" -> "Leste"; "O", "W" -> "Oeste"
            "NE" -> "Nordeste"; "NO" -> "Noroeste"; "SE" -> "Sudeste"; "SO" -> "Sudoeste"
            else -> it.trim()
        }
    }

    private fun openInMaps(r: Radar) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${r.latitude},${r.longitude}?q=${r.latitude},${r.longitude}(${Uri.encode(r.title)})")))
        } catch (_: ActivityNotFoundException) {
            toast("Nenhum app de mapas encontrado")
        }
    }

    private fun showRadarOnMap(r: Radar) {
        mapFocus = r
        show(Tab.MAP)
    }

    /** Guarda a câmera e libera o mapa ao sair da aba. */
    private fun leaveMap() {
        val map = mapView ?: return
        try {
            val center = map.mapCenter
            savedLat = center.latitude
            savedLon = center.longitude
            savedZoom = map.zoomLevelDouble
        } catch (_: Exception) { }
        try { locationOverlay?.disableMyLocation() } catch (_: Exception) { }
        try { map.onPause(); map.onDetach() } catch (_: Exception) { }
        mapView = null
        locationOverlay = null
    }

    // ------------------------------------------------------------------ lista de radares

    private class RowHolder(val badge: TextView, val title: TextView, val sub: TextView, val meta: TextView)

    private inner class RadarAdapter : BaseAdapter() {
        var items: List<Radar> = emptyList()
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Radar = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view = convertView ?: buildRow()
            val holder = view.tag as RowHolder
            val r = items[position]
            val color = RadarTypes.color(r.type)
            holder.badge.text = badgeText(r.type)
            holder.badge.background = rounded(color, 12)
            holder.title.text = listOfNotNull(r.code, r.roadLine.ifBlank { null }).joinToString("  •  ").ifBlank { r.typeLabel }
            holder.sub.text = r.cityDisplay ?: "${String.format(Radar.PT_BR, "%.5f", r.latitude)}, ${String.format(Radar.PT_BR, "%.5f", r.longitude)}"
            holder.meta.text = listOfNotNull(r.direction?.let { "Sentido ${directionWords(it)}" }, r.model, r.speedLimit?.let { "$it km/h" }).joinToString(" • ")
            holder.meta.visibility = if (holder.meta.text.isNullOrBlank()) View.GONE else View.VISIBLE
            return view
        }

        private fun buildRow(): View {
            val wrap = FrameLayout(this@MainActivity).apply { setPadding(dp(16), dp(5), dp(16), dp(5)) }
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = pressable(Palette.SURFACE, 16, Palette.LINE)
            }
            val badge = tv("", 12f, 0xFFFFFFFF.toInt(), true).apply { gravity = Gravity.CENTER }
            row.addView(badge, LinearLayout.LayoutParams(dp(48), dp(48)))
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            val title = tv("", 15f, Palette.INK, true).apply { isSingleLine = true; ellipsize = android.text.TextUtils.TruncateAt.END }
            val sub = tv("", 13f, Palette.INK).apply { isSingleLine = true; ellipsize = android.text.TextUtils.TruncateAt.END }
            val meta = tv("", 12f, Palette.MUTED).apply { isSingleLine = true; ellipsize = android.text.TextUtils.TruncateAt.END }
            col.addView(title); col.addView(sub, lp(top = 1)); col.addView(meta, lp(top = 1))
            row.addView(col, lp(width = 0, weight = 1f, start = 12))
            row.addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_chevron); setColorFilter(Palette.MUTED) }, LinearLayout.LayoutParams(dp(20), dp(20)))
            wrap.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            wrap.tag = RowHolder(badge, title, sub, meta)
            return wrap
        }
    }

    private fun badgeText(type: String): String {
        val t = type.trim()
        if (t.length <= 4) return t.uppercase()
        return t.split(' ').filter { it.isNotEmpty() }.take(2).joinToString("") { it.take(1) }.uppercase()
    }

    private fun radarsScreen(): View {
        val all = RadarStore.all(this)
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val add = FrameLayout(this).apply {
            background = rounded(0x26FFFFFF, 22)
            isClickable = true
            setOnClickListener { showRadarEditor(null) }
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_add); setColorFilter(0xFFFFFFFF.toInt()) }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        }
        val countLabel = "${String.format(Radar.PT_BR, "%,d", all.size)} cadastrados"
        val head = header("Radares", countLabel, add)

        val search = EditText(this).apply {
            hint = "Buscar por código, rodovia ou município"
            textSize = 14f
            setTextColor(Palette.INK)
            setHintTextColor(Palette.MUTED)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            isSingleLine = true
            setText(listQuery)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            compoundDrawablePadding = dp(10)
            setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
            compoundDrawableTintList = ColorStateList.valueOf(Palette.MUTED)
            background = rounded(0xFFFFFFFF.toInt(), 14)
        }
        head.addView(search, lp(top = 14))
        column.addView(head)

        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(10), dp(12), dp(4)) }
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) }
        column.addView(chipScroll)
        column.addView(tv("Toque para ver no mapa • segure para editar ou excluir", 12f, Palette.MUTED).apply { setPadding(dp(18), dp(4), dp(18), dp(6)) })

        val rowsAdapter = RadarAdapter()
        val list = ListView(this).apply {
            divider = null
            dividerHeight = 0
            selector = ColorDrawable(0)
            overScrollMode = View.OVER_SCROLL_NEVER
            this.adapter = rowsAdapter
        }
        val empty = tv("", 14f, Palette.MUTED).apply { gravity = Gravity.CENTER; setPadding(dp(32), dp(48), dp(32), dp(32)) }
        column.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        column.addView(empty, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        list.emptyView = empty
        empty.text = if (all.isEmpty()) "Nenhum radar cadastrado.\nImporte uma planilha em Ajustes ou toque em + para adicionar." else "Nenhum radar encontrado para essa busca."

        // Índice de busca (sem acentos, minúsculo)
        val haystacks = all.map { r ->
            Text.normalize(listOfNotNull(r.code, r.highway, r.highway?.replace(" ", ""), r.city, r.model, r.operatorName, r.type, r.typeLabel, r.direction, r.highwayType).joinToString(" "))
        }
        fun applyFilter() {
            val tokens = Text.normalize(listQuery).split(' ').filter { it.isNotBlank() }
            rowsAdapter.items = all.indices.filter { i ->
                (listType == null || all[i].type == listType) && tokens.all { haystacks[i].contains(it) }
            }.map { all[it] }
            rowsAdapter.notifyDataSetChanged()
        }
        val counts = all.groupingBy { it.type }.eachCount().entries.sortedByDescending { it.value }
        fun renderChips() {
            chipRow.removeAllViews()
            chipRow.addView(chip("Todos", listType == null) { listType = null; renderChips(); applyFilter() }, lp(width = ViewGroup.LayoutParams.WRAP_CONTENT, end = 8))
            counts.forEach { (type, count) ->
                chipRow.addView(chip("$type ($count)", listType == type, RadarTypes.color(type)) { listType = type; renderChips(); applyFilter() }, lp(width = ViewGroup.LayoutParams.WRAP_CONTENT, end = 8))
            }
        }
        renderChips()
        applyFilter()
        search.doAfterTextChanged { listQuery = it?.toString() ?: ""; applyFilter() }
        list.setOnItemClickListener { _, _, position, _ -> showRadarOnMap(rowsAdapter.items[position]) }
        list.setOnItemLongClickListener { _, _, position, _ -> showRadarActions(rowsAdapter.items[position]); true }
        return column
    }

    private fun showRadarActions(r: Radar) {
        AlertDialog.Builder(this)
            .setTitle(r.code ?: r.typeLabel)
            .setItems(arrayOf("Ver no mapa", "Editar", "Excluir")) { _, which ->
                when (which) {
                    0 -> showRadarOnMap(r)
                    1 -> showRadarEditor(r)
                    else -> AlertDialog.Builder(this).setTitle("Excluir radar?").setMessage(listOfNotNull(r.code, r.roadLine.ifBlank { null }).joinToString(" • ").ifBlank { "${r.latitude}, ${r.longitude}" })
                        .setNegativeButton("Cancelar", null)
                        .setPositiveButton("Excluir") { _, _ -> RadarStore.remove(this, r); show(currentTab) }.show()
                }
            }.show()
    }

    private fun showRadarEditor(radar: Radar?) {
        val scroll = ScrollView(this)
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(8), dp(24), 0) }
        scroll.addView(form)
        fun field(hintText: String, value: String?, inputType: Int = InputType.TYPE_CLASS_TEXT): EditText {
            val edit = EditText(this).apply { hint = hintText; setText(value ?: ""); this.inputType = inputType }
            form.addView(edit)
            return edit
        }
        val decimal = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        val lat = field("Latitude (ex.: -23.5505)", radar?.latitude?.toString(), decimal)
        val lon = field("Longitude (ex.: -46.6333)", radar?.longitude?.toString(), decimal)
        val type = field("Tipo (ex.: CEV, REV ou Radar fixo)", radar?.type ?: "Radar fixo")
        val code = field("Código (opcional)", radar?.code)
        val highway = field("Rodovia (opcional)", radar?.highway)
        val km = field("Km (opcional)", radar?.km?.toString(), decimal)
        val city = field("Município (opcional)", radar?.city)
        val speed = field("Limite km/h (opcional)", radar?.speedLimit?.toString(), InputType.TYPE_CLASS_NUMBER)
        val direction = field("Sentido (ex.: N, S, L, O — opcional)", radar?.direction)
        val source = field("Origem dos dados", radar?.source ?: "Cadastro manual")
        AlertDialog.Builder(this).setTitle(if (radar == null) "Adicionar radar" else "Editar radar").setView(scroll)
            .setNegativeButton("Cancelar", null).setPositiveButton("Salvar", null).create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val latitude = lat.text.toString().trim().replace(',', '.').toDoubleOrNull()
                        val longitude = lon.text.toString().trim().replace(',', '.').toDoubleOrNull()
                        if (latitude == null || longitude == null || latitude !in -90.0..90.0 || longitude !in -180.0..180.0) { toast("Informe latitude e longitude válidas"); return@setOnClickListener }
                        val speedValue = speed.text.toString().toIntOrNull()
                        if (speed.text.isNotBlank() && (speedValue == null || speedValue !in 1..250)) { toast("O limite deve ser entre 1 e 250 km/h"); return@setOnClickListener }
                        if (type.text.toString().isBlank()) { toast("Informe o tipo do radar"); return@setOnClickListener }
                        fun txt(e: EditText): String? = e.text.toString().trim().ifBlank { null }
                        val updated = (radar ?: Radar(latitude, longitude)).copy(
                            latitude = latitude, longitude = longitude, type = type.text.toString().trim(),
                            code = txt(code), highway = txt(highway), km = txt(km)?.replace(',', '.')?.toDoubleOrNull(),
                            city = txt(city), speedLimit = speedValue, direction = txt(direction),
                            source = txt(source) ?: "Cadastro manual"
                        )
                        if (radar == null) RadarStore.upsert(this, updated) else RadarStore.replace(this, radar, updated)
                        dialog.dismiss()
                        show(currentTab)
                    }
                }
                dialog.show()
            }
    }

    // ------------------------------------------------------------------ ajustes

    private fun thinLine(): View = View(this).apply {
        setBackgroundColor(Palette.LINE)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
    }

    private fun switchRow(title: String, description: String, key: String, default: Boolean): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv(title, 15f, Palette.INK, true))
        col.addView(tv(description, 12f, Palette.MUTED), lp(top = 2))
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Switch(this).apply {
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                if (key == "overlay" && checked && !Settings.canDrawOverlays(this@MainActivity)) requestOverlayPermission()
            }
        })
        return row
    }

    private fun permissionRow(title: String, granted: Boolean, fix: () -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)) }
        row.addView(tv(title, 15f, Palette.INK, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(if (granted) pill("CONCEDIDA", 0xFFDDF4E7.toInt(), Palette.SUCCESS) else pill("AJUSTAR", 0xFFFDE7E5.toInt(), Palette.DANGER))
        if (!granted) { row.isClickable = true; row.setOnClickListener { fix() } }
        return row
    }

    private fun settingsScreen(): View {
        val s = screen("Ajustes", "Alertas, dados e permissões")
        val body = s.body

        body.addView(sectionTitle("Alertas"))
        body.addView(card(0).apply {
            addView(switchRow("Aviso por voz", "Fala o tipo de radar e a distância", "voice", true))
            addView(thinLine())
            addView(switchRow("Notificação sonora", "Notificação de alerta com som", "sound", true))
            addView(thinLine())
            addView(switchRow("Vibração", "Vibra ao se aproximar de um radar", "vibrate", false))
            addView(thinLine())
            addView(switchRow("Janela flutuante", "Mostra o aviso sobre outros apps", "overlay", true))
            addView(thinLine())
            addView(switchRow("Somente no sentido do radar", "Usa o sentido (N, S, L, O) da planilha quando existir", "direction", true))
        })

        body.addView(card().apply {
            addView(tv("Distância de aviso", 15f, Palette.INK, true))
            addView(tv("A que distância do radar o alerta é disparado", 12f, Palette.MUTED), lp(top = 2, bottom = 10))
            val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            val scroll = HorizontalScrollView(this@MainActivity).apply { isHorizontalScrollBarEnabled = false; addView(row) }
            fun render() {
                row.removeAllViews()
                val selected = prefs.getInt("distance", 2)
                DISTANCE_OPTIONS.forEachIndexed { index, label ->
                    row.addView(chip(label, index == selected) { prefs.edit().putInt("distance", index).apply(); render() }, lp(width = ViewGroup.LayoutParams.WRAP_CONTENT, end = 8))
                }
            }
            render()
            addView(scroll)
        }, lp(top = 12))

        val count = RadarStore.all(this).size
        body.addView(sectionTitle("Base de radares"))
        body.addView(card().apply {
            addView(tv("${String.format(Radar.PT_BR, "%,d", count)} radares", 18f, Palette.INK, true))
            addView(tv("Última atualização: ${RadarStore.updatedAt(this@MainActivity)}", 13f, Palette.MUTED), lp(top = 2, bottom = 14))
            addView(primaryButton("Importar planilha, CSV ou JSON") { openImportPicker() })
            addView(secondaryButton("Como obter radares") { showHowTo() }, lp(top = 8))
            addView(secondaryButton("Formatos aceitos") { showFormats() }, lp(top = 8))
            addView(secondaryButton("Exportar base (JSON)") { exportJson() }, lp(top = 8))
            addView(secondaryButton("Histórico de importações") { showHistory() }, lp(top = 8))
            addView(secondaryButton("Apagar toda a base", Palette.DANGER) {
                AlertDialog.Builder(this@MainActivity).setTitle("Apagar radares?").setMessage("Essa ação remove todos os dados locais e não pode ser desfeita.")
                    .setNegativeButton("Cancelar", null).setPositiveButton("Apagar") { _, _ -> RadarStore.save(this@MainActivity, emptyList()); show(Tab.SETTINGS) }.show()
            }, lp(top = 8))
        })

        body.addView(sectionTitle("Permissões"))
        body.addView(card(0).apply {
            addView(permissionRow("Localização precisa", hasLocationPermission()) {
                ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 12)
            })
            addView(thinLine())
            addView(permissionRow("Notificações", Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            })
            addView(thinLine())
            addView(permissionRow("Janela flutuante", Settings.canDrawOverlays(this@MainActivity)) { requestOverlayPermission() })
        })
        body.addView(secondaryButton("Abrir configurações do aplicativo") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, lp(top = 12))

        body.addView(sectionTitle("Sobre"))
        body.addView(card().apply {
            addView(tv("Radar Alerta ${versionName()}", 15f, Palette.INK, true))
            addView(tv("Mapa: © OpenStreetMap contributors. Os radares exibidos vêm da base importada por você; confira a origem, a data e a cobertura dos dados. Use como apoio e respeite sempre a sinalização.", 12f, Palette.MUTED), lp(top = 4))
        })
        return s.root
    }

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }

    private fun showFormats() {
        AlertDialog.Builder(this).setTitle("Formatos aceitos").setMessage(
            "Excel (.xlsx): primeira aba com cabeçalho. Reconhece o formato de lista de radares com as colunas Tipo, Código, Rodovia, Tipo da Rodovia, Km, Faixas, Município, Marca/Modelo, Operadora, Início Operação, Cancelamento e Coordenadas (\"latitude, longitude\" na mesma célula). Também aceita colunas separadas Latitude e Longitude.\n\n" +
                "• O sentido (N, S, L, O) é obtido da coluna Faixas.\n• Linhas com data de cancelamento já vencida são ignoradas.\n• Coordenadas fora do Brasil são tratadas como inválidas.\n• Radares com o mesmo código são atualizados ao mesclar.\n\n" +
                "GeoJSON (.geojson): exportado do Overpass Turbo ou de outros mapas. Lê pontos (e o centro de linhas/áreas) e as tags maxspeed, direction, name, ref e operator.\n\n" +
                "JSON do Overpass: arquivo com a lista \"elements\" (Exportar > dados brutos).\n\n" +
                "CSV: latitude/longitude (ou lat/lon, @lat/@lon do Overpass), tipo, velocidade (ou maxspeed) e direção; separador vírgula, ponto e vírgula ou tabulação.\n\n" +
                "JSON simples: lista de objetos com latitude/longitude, type/tipo, speedLimit/velocidade e direction/direcao.\n\n" +
                "O formato antigo .xls deve ser salvo como .xlsx ou CSV."
        ).setPositiveButton("OK", null).show()
    }

    private fun showHowTo() {
        val steps = "Você pode montar a base com dados do OpenStreetMap (gratuito; a cobertura varia por região e pode estar incompleta).\n\n" +
            "1. Toque em \"Copiar consulta\".\n" +
            "2. Abra o Overpass Turbo (botão abaixo), apague o texto do editor e cole a consulta.\n" +
            "3. Toque em Executar (Run) e aguarde. Se aparecer 0 elementos, nenhum radar foi encontrado: troque a região, por exemplo {{geocodeArea:Estado de São Paulo}} no lugar de {{geocodeArea:Brasil}}.\n" +
            "4. Toque em Exportar e baixe como GeoJSON (ou CSV).\n" +
            "5. Volte ao Radar Alerta, toque em \"Importar planilha, CSV ou JSON\" e escolha o arquivo baixado.\n\n" +
            "Antes de usar na via, confira a base: radares ausentes não geram alerta. Fontes oficiais, como a ANTT e os órgãos estaduais, costumam ser mais confiáveis."
        AlertDialog.Builder(this).setTitle("Como obter radares").setMessage(steps)
            .setPositiveButton("Abrir Overpass Turbo") { _, _ ->
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://overpass-turbo.eu"))) }
                catch (_: ActivityNotFoundException) { toast("Nenhum navegador encontrado") }
            }
            .setNeutralButton("Copiar consulta") { _, _ ->
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Consulta Overpass", OVERPASS_QUERY))
                toast("Consulta copiada")
            }
            .setNegativeButton("Fechar", null).show()
    }

    private fun showHistory() {
        val history = RadarStore.importHistory(this)
        AlertDialog.Builder(this).setTitle("Histórico de importações")
            .setMessage(if (history.isEmpty()) "Ainda não há importações registradas." else history.joinToString("\n\n"))
            .setPositiveButton("OK", null).show()
    }

    // ------------------------------------------------------------------ importação e exportação

    private fun openImportPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel", "text/csv", "text/comma-separated-values", "application/json", "application/geo+json", "application/vnd.geo+json", "text/plain", "application/octet-stream"))
        }
        startActivityForResult(intent, importPicker)
    }

    @Deprecated("Legacy activity result API used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == exportRequest) {
            try {
                val contents = pendingExport ?: RadarStore.exportJson(this)
                contentResolver.openOutputStream(uri)?.use { it.write(contents.toByteArray(Charsets.UTF_8)) }
                pendingExport = null
                toast("Base exportada")
            } catch (e: Exception) { toast("Falha ao exportar: ${e.message}") }
        }
        if (requestCode == importPicker) handleImport(uri)
    }

    private fun handleImport(uri: Uri) {
        val name = queryName(uri) ?: "radares.xlsx"
        val progress = AlertDialog.Builder(this).setTitle("Lendo arquivo").setMessage("Processando $name…").setCancelable(false).show()
        Thread {
            val result = runCatching {
                contentResolver.openInputStream(uri)?.use { RadarStore.preview(it, name) } ?: throw IllegalStateException("Não foi possível abrir o arquivo")
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                progress.dismiss()
                result.onSuccess { showImportPreview(name, it) }
                    .onFailure { AlertDialog.Builder(this).setTitle("Falha na importação").setMessage(it.message ?: "Arquivo inválido").setPositiveButton("OK", null).show() }
            }
        }.start()
    }

    private fun showImportPreview(name: String, preview: ImportPreview) {
        val types = preview.typeCounts.entries.sortedByDescending { it.value }.joinToString("\n") { "• ${it.key}: ${it.value}" }
        val message = buildString {
            append("Arquivo: $name\n")
            append("Radares válidos: ${preview.radars.size}\n")
            if (types.isNotEmpty()) append(types).append('\n')
            if (preview.cancelled > 0) append("Cancelados (ignorados): ${preview.cancelled}\n")
            if (preview.invalid > 0) append("Coordenadas inválidas (ignoradas): ${preview.invalid}\n")
            append("\nA mesclagem preserva os radares existentes e atualiza os de mesmo código; a substituição troca toda a base atual.")
        }
        AlertDialog.Builder(this).setTitle("Prévia da importação").setMessage(message)
            .setNegativeButton("Cancelar", null)
            .setNeutralButton("Substituir base") { _, _ -> confirmImport(preview, true) }
            .setPositiveButton("Mesclar base") { _, _ -> confirmImport(preview, false) }.show()
    }

    private fun confirmImport(preview: ImportPreview, replace: Boolean) {
        try {
            val r = RadarStore.commitImport(this, preview, replace)
            val message = "Modo: ${if (replace) "substituição" else "mesclagem"}\nRegistros lidos: ${r.read}\nNovos radares: ${r.added}\nAtualizados: ${r.updated}\nDuplicados ignorados: ${r.duplicates}\nCancelados ignorados: ${r.cancelled}\nInválidos: ${r.invalid}"
            AlertDialog.Builder(this).setTitle("Importação concluída").setMessage(message)
                .setPositiveButton("Ver no mapa") { _, _ -> show(Tab.MAP) }
                .setNegativeButton("OK") { _, _ -> show(currentTab) }.show()
            show(currentTab)
        } catch (e: Exception) { toast("Falha ao salvar a importação: ${e.message}") }
    }

    private fun queryName(uri: Uri): String? =
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    private fun exportJson() {
        pendingExport = RadarStore.exportJson(this)
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "radares-export.json") }
        startActivityForResult(intent, exportRequest)
    }

    // ------------------------------------------------------------------ monitoramento e permissões

    @Suppress("DEPRECATION")
    private fun isServiceRunning(): Boolean = try {
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getRunningServices(Int.MAX_VALUE).any { it.service.className == RadarMonitorService::class.java.name }
    } catch (_: Exception) { false }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun lastKnownLocation(): Location? {
        if (!hasLocationPermission()) return null
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        return try {
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
        } catch (_: Exception) { null }
    }

    private fun startMonitoring() {
        if (!hasLocationPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 12)
            return
        }
        if (RadarStore.all(this).isEmpty()) toast("A base está vazia: importe uma planilha para receber alertas.")
        if (prefs.getBoolean("overlay", true) && !Settings.canDrawOverlays(this)) requestOverlayPermission()
        ContextCompat.startForegroundService(this, Intent(this, RadarMonitorService::class.java))
        toast("Monitoramento iniciado. Confira a notificação permanente.")
        content.postDelayed({ if (currentTab == Tab.HOME && !isFinishing) show(Tab.HOME) }, 700)
    }

    private fun stopMonitoring() {
        stopService(Intent(this, RadarMonitorService::class.java))
        toast("Monitoramento parado")
        content.postDelayed({ if (currentTab == Tab.HOME && !isFinishing) show(Tab.HOME) }, 400)
    }

    private fun requestOverlayPermission() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun requestBasicPermissions() {
        val needed = mutableListOf<String>()
        if (!hasLocationPermission()) needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 11)
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    companion object {
        private val DISTANCE_OPTIONS = listOf("100 m", "200 m", "300 m", "500 m", "800 m", "1.000 m")

        private const val OVERPASS_QUERY = "[out:json][timeout:300];\n" +
            "{{geocodeArea:Brasil}}->.a;\n" +
            "(\n" +
            "  node[\"highway\"=\"speed_camera\"](area.a);\n" +
            "  node[\"enforcement\"=\"maxspeed\"](area.a);\n" +
            ");\n" +
            "out;"
    }
}
