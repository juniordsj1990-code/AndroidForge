@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pdfpro.app

import android.graphics.Bitmap
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val palette = listOf(0xFFFFEB3B, 0xFF8BC34A, 0xFFFF80AB, 0xFFE53935, 0xFF1E88E5, 0xFF000000).map { it.toInt() }

private val invertFilter = ColorFilter.colorMatrix(
    ColorMatrix(
        floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        )
    )
)

private enum class Dlg { NONE, GOTO, SEARCH, OUTLINE, FORMS, SPLIT, COMPRESS, PROTECT, SIGN, DISCARD }

@Composable
fun ViewerScreen(vm: MainViewModel) {
    val holder = vm.holder ?: return
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val density = LocalDensity.current
    var zoom by remember(vm.docId) { mutableFloatStateOf(1f) }
    var settled by remember(vm.docId) { mutableFloatStateOf(1f) }
    var menuOpen by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf(Dlg.NONE) }
    var textTap by remember { mutableStateOf<Triple<Int, Float, Float>?>(null) }

    val mergePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.appendPdfs(uris)
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.loadStamp(uri)
    }

    LaunchedEffect(zoom) {
        delay(300)
        settled = zoom
    }
    LaunchedEffect(vm.tool) {
        if (vm.tool != Tool.NONE) {
            zoom = 1f
            settled = 1f
        }
    }
    LaunchedEffect(vm.docId) {
        listState.scrollToItem(vm.startPage.coerceIn(0, max(0, holder.pageCount - 1)))
    }
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }.collect { vm.onPageChanged(it) }
    }

    fun jumpTo(p: Int) {
        scope.launch { listState.animateScrollToItem(p.coerceIn(0, holder.pageCount - 1)) }
    }

    fun goBack() {
        when {
            vm.tool != Tool.NONE -> vm.tool = Tool.NONE
            vm.hasChanges -> dlg = Dlg.DISCARD
            else -> vm.closeDoc()
        }
    }

    BackHandler { goBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(vm.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = { goBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                },
                actions = {
                    IconButton(onClick = { vm.undo() }, enabled = vm.annots.isNotEmpty() || vm.canUndoFile) {
                        Icon(Icons.AutoMirrored.Filled.Undo, "Desfazer")
                    }
                    IconButton(onClick = { dlg = Dlg.SEARCH }) { Icon(Icons.Default.Search, "Buscar") }
                    IconButton(onClick = { vm.toggleBookmark() }) {
                        Icon(
                            if (vm.bookmarks.contains(vm.currentPage)) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            "Marcador"
                        )
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Mais") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            MenuItem("Ir para página…") { menuOpen = false; dlg = Dlg.GOTO }
                            MenuItem("Índice e marcadores") { menuOpen = false; vm.loadOutline(); dlg = Dlg.OUTLINE }
                            MenuItem("Preencher formulário") { menuOpen = false; vm.loadFields(); dlg = Dlg.FORMS }
                            MenuItem(if (vm.darkReader) "Modo noturno: desligar" else "Modo noturno: ligar") {
                                menuOpen = false; vm.toggleDark()
                            }
                            HorizontalDivider()
                            MenuItem("Organizar páginas") { menuOpen = false; vm.goPages() }
                            MenuItem("Extrair / dividir") { menuOpen = false; dlg = Dlg.SPLIT }
                            MenuItem("Mesclar com outros PDFs") {
                                menuOpen = false; mergePicker.launch(arrayOf("application/pdf"))
                            }
                            MenuItem("Comprimir") { menuOpen = false; dlg = Dlg.COMPRESS }
                            MenuItem("Proteger com senha") { menuOpen = false; dlg = Dlg.PROTECT }
                            HorizontalDivider()
                            MenuItem("Salvar cópia (Downloads)") { menuOpen = false; vm.saveCopy() }
                            MenuItem("Sobrescrever original") { menuOpen = false; vm.overwriteOriginal() }
                            MenuItem("Compartilhar") { menuOpen = false; vm.share() }
                        }
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(Modifier.navigationBarsPadding()) {
                    if (vm.tool != Tool.NONE) {
                        ToolOptions(
                            vm = vm,
                            page = listState.firstVisibleItemIndex,
                            count = holder.pageCount,
                            onPrev = { jumpTo(listState.firstVisibleItemIndex - 1) },
                            onNext = { jumpTo(listState.firstVisibleItemIndex + 1) },
                            onRedraw = { dlg = Dlg.SIGN }
                        )
                    }
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        ToolBtn(Icons.Default.PanTool, "Ler", vm.tool == Tool.NONE) { vm.selectTool(Tool.NONE) }
                        ToolBtn(Icons.Default.Highlight, "Marcar", vm.tool == Tool.HIGHLIGHT) { vm.selectTool(Tool.HIGHLIGHT) }
                        ToolBtn(Icons.Default.FormatUnderlined, "Sublinhar", vm.tool == Tool.UNDERLINE) { vm.selectTool(Tool.UNDERLINE) }
                        ToolBtn(Icons.Default.Edit, "Caneta", vm.tool == Tool.PEN) { vm.selectTool(Tool.PEN) }
                        ToolBtn(Icons.Default.TextFields, "Texto", vm.tool == Tool.TEXT) { vm.selectTool(Tool.TEXT) }
                        ToolBtn(Icons.Default.Gesture, "Assinar", vm.tool == Tool.IMAGE) {
                            if (vm.hasSignature()) {
                                vm.useSignature()
                                vm.selectTool(Tool.IMAGE)
                            } else {
                                dlg = Dlg.SIGN
                            }
                        }
                        ToolBtn(Icons.Default.ImageIcon, "Imagem", false) { imagePicker.launch("image/*") }
                    }
                }
            }
        }
    ) { pad ->
        BoxWithConstraints(
            Modifier.padding(pad).fillMaxSize().background(Color(0xFF7A7A7A))
        ) {
            val baseW = maxWidth
            val pageW = baseW * zoom - 16.dp
            val renderPx = (with(density) { (baseW * settled - 16.dp).toPx() } / 64f).roundToInt().times(64).coerceIn(256, 2400)

            LaunchedEffect(vm.matchJump) {
                val m = vm.matches.getOrNull(vm.matchIndex) ?: return@LaunchedEffect
                if (m.page !in 0 until holder.pageCount) return@LaunchedEffect
                val (pw, ph) = holder.sizes[m.page]
                val pageHpx = with(density) { pageW.toPx() } * ph / pw
                val top = (m.rects.firstOrNull()?.top ?: 0f) * pageHpx
                val viewport = listState.layoutInfo.viewportSize.height
                listState.animateScrollToItem(m.page, (top - viewport / 3f).roundToInt().coerceAtLeast(0))
            }

            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(vm.tool) {
                        if (vm.tool == Tool.NONE) detectPinch { z -> zoom = (zoom * z).coerceIn(1f, 3f) }
                    }
                    .horizontalScroll(rememberScrollState())
            ) {
                LazyColumn(
                    state = listState,
                    userScrollEnabled = vm.tool == Tool.NONE,
                    modifier = Modifier.width(baseW * zoom).fillMaxHeight(),
                    contentPadding = PaddingValues(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(holder.pageCount, key = { it }) { i ->
                        PageView(
                            vm = vm,
                            holder = holder,
                            index = i,
                            width = pageW,
                            renderPx = renderPx,
                            dark = vm.darkReader,
                            onTextTap = { p, x, y -> textTap = Triple(p, x, y) }
                        )
                    }
                }
            }

            if (vm.matches.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    tonalElevation = 6.dp,
                    shadowElevation = 4.dp,
                    modifier = Modifier.align(Alignment.TopCenter).padding(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { vm.selectMatch(if (vm.matchIndex < 0) -1 else vm.matchIndex - 1) }) {
                            Icon(Icons.Default.KeyboardArrowUp, "Anterior")
                        }
                        Text("${vm.matchIndex + 1} / ${vm.matches.size}")
                        IconButton(onClick = { vm.selectMatch(vm.matchIndex + 1) }) {
                            Icon(Icons.Default.KeyboardArrowDown, "Próximo")
                        }
                        IconButton(onClick = { vm.clearSearch() }) { Icon(Icons.Default.Close, "Limpar busca") }
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.Black.copy(alpha = 0.6f),
                modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp)
            ) {
                Text(
                    "${listState.firstVisibleItemIndex + 1} / ${holder.pageCount}",
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }
        }
    }

    val close = { dlg = Dlg.NONE }
    when (dlg) {
        Dlg.GOTO -> GotoDialog(holder.pageCount, { jumpTo(it - 1) }, close)
        Dlg.SEARCH -> SearchDialog(vm, close)
        Dlg.OUTLINE -> OutlineDialog(vm, { jumpTo(it) }, close)
        Dlg.FORMS -> FormsDialog(vm, close)
        Dlg.SPLIT -> SplitDialog(vm, close)
        Dlg.COMPRESS -> CompressDialog(vm, close)
        Dlg.PROTECT -> ProtectDialog(vm, close)
        Dlg.SIGN -> SignatureDialog({ vm.saveSignature(it) }, close)
        Dlg.DISCARD -> DiscardDialog(
            onSave = { dlg = Dlg.NONE; vm.saveCopy { vm.closeDoc() } },
            onDiscard = { dlg = Dlg.NONE; vm.closeDoc() },
            onDismiss = close
        )
        Dlg.NONE -> {}
    }

    textTap?.let { (pg, nx, ny) ->
        TextInputDialog(
            onDismiss = { textTap = null },
            onOk = { t ->
                if (t.isNotBlank()) vm.annots.add(Annot.Text(pg, nx, ny, t, vm.textSize, vm.color))
                textTap = null
            }
        )
    }
}

@Composable
private fun MenuItem(text: String, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(text) }, onClick = onClick)
}

@Composable
private fun ToolBtn(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, label)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun ToolOptions(
    vm: MainViewModel,
    page: Int,
    count: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onRedraw: () -> Unit
) {
    Column(Modifier.padding(horizontal = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (vm.tool != Tool.IMAGE) {
                palette.forEach { c ->
                    Box(
                        Modifier
                            .padding(4.dp)
                            .size(if (vm.color == c) 30.dp else 24.dp)
                            .clip(CircleShape)
                            .background(Color(c))
                            .border(1.dp, Color.Gray, CircleShape)
                            .clickable { vm.color = c }
                    )
                }
            } else {
                TextButton(onClick = onRedraw) { Text("Nova assinatura") }
            }
            Box(Modifier.weight(1f))
            IconButton(onClick = onPrev) { Icon(Icons.Default.KeyboardArrowUp, "Página anterior") }
            Text("${page + 1}/$count")
            IconButton(onClick = onNext) { Icon(Icons.Default.KeyboardArrowDown, "Próxima página") }
        }
        when (vm.tool) {
            Tool.PEN -> LabeledSlider("Espessura", vm.penWidth, 0.002f..0.015f) { vm.penWidth = it }
            Tool.TEXT -> LabeledSlider("Tamanho", vm.textSize, 0.015f..0.08f) { vm.textSize = it }
            Tool.IMAGE -> LabeledSlider("Largura", vm.imageWidth, 0.1f..0.8f) { vm.imageWidth = it }
            else -> {}
        }
        Text(
            when (vm.tool) {
                Tool.HIGHLIGHT, Tool.UNDERLINE -> "Arraste sobre o texto para marcar"
                Tool.PEN -> "Desenhe com o dedo"
                Tool.TEXT -> "Toque onde quer escrever"
                Tool.IMAGE -> "Arraste na página e solte para posicionar"
                else -> ""
            },
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(80.dp))
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun PageView(
    vm: MainViewModel,
    holder: PdfHolder,
    index: Int,
    width: Dp,
    renderPx: Int,
    dark: Boolean,
    onTextTap: (Int, Float, Float) -> Unit
) {
    val (pw, ph) = holder.sizes[index]
    val height = width * (ph / pw)
    var bmp by remember(holder, index) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(holder, index, renderPx) {
        bmp = withContext(Dispatchers.IO) { holder.render(index, renderPx) }
    }
    val img = remember(bmp) { bmp?.asImageBitmap() }
    Box(Modifier.width(width).height(height).background(Color.White)) {
        if (img != null) {
            Image(
                bitmap = img,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds,
                colorFilter = if (dark) invertFilter else null
            )
        }
        AnnotLayer(vm, index, onTextTap)
    }
}

@Composable
private fun AnnotLayer(vm: MainViewModel, page: Int, onTextTap: (Int, Float, Float) -> Unit) {
    val tool = vm.tool
    val color = vm.color
    val stamp = vm.stampBitmap
    val stampImg = remember(stamp) { stamp?.asImageBitmap() }
    var pts by remember { mutableStateOf<List<Offset>>(emptyList()) }
    val mine = vm.annots.filter { it.page == page }

    Canvas(
        Modifier
            .fillMaxSize()
            .pointerInput(tool, color, vm.penWidth, vm.imageWidth, stamp) {
                if (tool == Tool.NONE) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val start = down.position
                    var last = start
                    var moved = false
                    pts = listOf(start)
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) break
                        last = ch.position
                        if ((last - start).getDistance() > 10f) moved = true
                        pts = if (tool == Tool.PEN) pts + last else listOf(start, last)
                        ch.consume()
                    }
                    fun nx(v: Float) = (v / w).coerceIn(0f, 1f)
                    fun ny(v: Float) = (v / h).coerceIn(0f, 1f)
                    when (tool) {
                        Tool.HIGHLIGHT, Tool.UNDERLINE -> if (moved) {
                            val l = nx(min(start.x, last.x))
                            val r = nx(max(start.x, last.x))
                            val t = ny(min(start.y, last.y))
                            val b = ny(max(start.y, last.y))
                            if (r - l > 0.005f && b - t > 0.002f) {
                                vm.annots.add(
                                    if (tool == Tool.HIGHLIGHT) Annot.Highlight(page, l, t, r, b, color)
                                    else Annot.Underline(page, l, t, r, b, color)
                                )
                            }
                        }
                        Tool.PEN -> vm.annots.add(Annot.Ink(page, pts.map { nx(it.x) to ny(it.y) }, color, vm.penWidth))
                        Tool.TEXT -> if (!moved) onTextTap(page, nx(start.x), ny(start.y))
                        Tool.IMAGE -> if (stamp != null) {
                            val wN = vm.imageWidth
                            val hN = (wN * w * stamp.height / stamp.width) / h
                            val l = (nx(last.x) - wN / 2f).coerceIn(0f, max(0f, 1f - wN))
                            val t = (ny(last.y) - hN / 2f).coerceIn(0f, max(0f, 1f - hN))
                            vm.annots.add(Annot.Picture(page, l, t, l + wN, t + hN, stamp))
                        }
                        else -> {}
                    }
                    pts = emptyList()
                }
            }
    ) {
        val w = size.width
        val h = size.height
        mine.forEach { drawAnnot(it, w, h) }
        vm.matchPages[page]?.forEach { idx ->
            val m = vm.matches.getOrNull(idx) ?: return@forEach
            val current = idx == vm.matchIndex
            m.rects.forEach { r ->
                val tl = Offset(r.left * w, r.top * h)
                val sz = Size((r.right - r.left) * w, (r.bottom - r.top) * h)
                drawRect(
                    if (current) Color(0xFFFF6D00).copy(alpha = 0.5f) else Color(0xFFFFC107).copy(alpha = 0.35f),
                    tl,
                    sz
                )
                if (current) drawRect(Color(0xFFE65100), tl, sz, style = Stroke(width = 3f))
            }
        }
        if (pts.isNotEmpty()) {
            val c = Color(color)
            val a = pts.first()
            val b = pts.last()
            when (tool) {
                Tool.HIGHLIGHT -> drawRect(
                    c.copy(alpha = 0.4f),
                    Offset(min(a.x, b.x), min(a.y, b.y)),
                    Size(abs(a.x - b.x), abs(a.y - b.y))
                )
                Tool.UNDERLINE -> drawLine(
                    c,
                    Offset(min(a.x, b.x), max(a.y, b.y)),
                    Offset(max(a.x, b.x), max(a.y, b.y)),
                    strokeWidth = max(2f, w * 0.0025f)
                )
                Tool.PEN -> {
                    val p = Path()
                    pts.forEachIndexed { i, o -> if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }
                    drawPath(p, c, style = Stroke(width = vm.penWidth * w, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                Tool.IMAGE -> if (stampImg != null && stamp != null) {
                    val gw = vm.imageWidth * w
                    val gh = gw * stamp.height / stamp.width
                    drawImage(
                        stampImg,
                        dstOffset = IntOffset((b.x - gw / 2f).roundToInt(), (b.y - gh / 2f).roundToInt()),
                        dstSize = IntSize(gw.roundToInt(), gh.roundToInt()),
                        alpha = 0.6f
                    )
                }
                else -> {}
            }
        }
    }
}

private fun DrawScope.drawAnnot(a: Annot, w: Float, h: Float) {
    when (a) {
        is Annot.Highlight -> drawRect(
            Color(a.color).copy(alpha = 0.4f),
            Offset(a.l * w, a.t * h),
            Size((a.r - a.l) * w, (a.b - a.t) * h)
        )
        is Annot.Underline -> drawLine(
            Color(a.color),
            Offset(a.l * w, a.b * h),
            Offset(a.r * w, a.b * h),
            strokeWidth = max(2f, w * 0.0025f)
        )
        is Annot.Ink -> {
            val p = Path()
            a.pts.forEachIndexed { i, o ->
                if (i == 0) p.moveTo(o.first * w, o.second * h) else p.lineTo(o.first * w, o.second * h)
            }
            if (a.pts.size == 1) p.lineTo(a.pts[0].first * w + 0.1f, a.pts[0].second * h)
            drawPath(p, Color(a.color), style = Stroke(width = a.width * w, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        is Annot.Text -> drawIntoCanvas { c ->
            val paint = android.graphics.Paint().apply {
                isAntiAlias = true
                color = a.color
                textSize = a.size * w
                typeface = Typeface.SANS_SERIF
            }
            a.text.split("\n").forEachIndexed { i, line ->
                c.nativeCanvas.drawText(line, a.x * w, a.y * h + a.size * w * (1f + 1.2f * i), paint)
            }
        }
        is Annot.Picture -> drawImage(
            a.image,
            dstOffset = IntOffset((a.l * w).roundToInt(), (a.t * h).roundToInt()),
            dstSize = IntSize(((a.r - a.l) * w).roundToInt(), ((a.b - a.t) * h).roundToInt())
        )
    }
}

/** Pinça com 2+ dedos; com 1 dedo deixa a lista rolar normalmente. */
private suspend fun PointerInputScope.detectPinch(onZoom: (Float) -> Unit) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        do {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            if (event.changes.count { it.pressed } >= 2) {
                val z = event.calculateZoom()
                if (z != 1f) {
                    onZoom(z)
                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                }
            }
        } while (event.changes.any { it.pressed })
    }
}
