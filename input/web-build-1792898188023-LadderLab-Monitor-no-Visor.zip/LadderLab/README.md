# Ladder Lab — projeto Android Studio

Simulador de CLP (Ladder / ST) empacotado em um WebView.

1. Android Studio: **File > Open** e escolha a pasta `LadderLab`.
2. Aguarde o *Gradle Sync* (o Studio baixa o Gradle 8.7 e as dependências).
3. Rode no emulador/celular (**Run ▶**) ou gere o APK em **Build > Build APK(s)**.

- minSdk 26 (Android 8.0+), targetSdk 34, Kotlin.
- O app é o arquivo `app/src/main/assets/index.html`. Para atualizar o simulador, substitua esse arquivo.
- Tela de carregamento: SplashScreen API (tema `Theme.LadderLab.Starting`), mantida até a página carregar.
- Ícone adaptativo: `res/mipmap-*/ic_launcher_foreground.png` (fundo `icon_bg`). Versão 512×512 para a loja: `ic_launcher-playstore.png`.
- O botão Voltar fecha primeiro a janela do Programador/Monitor.

- Programas salvos usam a extensão própria `.ladlab` (JSON legível, tipo `application/x-ladderlab`); tocar num arquivo `.ladlab` abre direto no app.
