package br.com.alertageografico

import kotlin.math.abs

/**
 * Sentido da viagem em relação à geometria de uma linha. Lógica pura, separada de
 * [StationNavigationStore.locate] para teste.
 */
object TravelDirection {
    /** Abaixo disso o rumo (do GPS ou derivado) é ruído e não atualiza o rumo de viagem guardado. */
    const val MIN_SPEED_FOR_BEARING_MPS = 2.0f

    /**
     * true = viajando contra a ordem da geometria; false = a favor; null = sem rumo.
     * Compara o rumo de viagem (absoluto) com o sentido do segmento mais próximo DESTA linha, por
     * isso continua correto se o app trocar para o traçado do sentido oposto: o rumo de viagem não
     * muda, só a orientação do traçado. A divisão é por hemisfério (90°): a favor ou contra.
     */
    fun isReverse(travelBearingDegrees: Double?, segmentBearingDegrees: Double): Boolean? {
        if (travelBearingDegrees == null || !travelBearingDegrees.isFinite()) return null
        val difference = abs((travelBearingDegrees - segmentBearingDegrees + 540.0) % 360.0 - 180.0)
        return difference > 90.0
    }
}
