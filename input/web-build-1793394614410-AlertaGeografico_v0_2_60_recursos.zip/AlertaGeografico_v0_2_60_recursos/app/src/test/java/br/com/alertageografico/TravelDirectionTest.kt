package br.com.alertageografico

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TravelDirectionTest {
    @Test fun sameBearingIsForward() = assertEquals(false, TravelDirection.isReverse(90.0, 95.0))

    @Test fun oppositeBearingIsReverse() = assertEquals(true, TravelDirection.isReverse(270.0, 90.0))

    @Test fun wrapsAroundNorth() {
        assertEquals(false, TravelDirection.isReverse(355.0, 5.0))
        assertEquals(true, TravelDirection.isReverse(5.0, 185.0))
    }

    @Test fun unknownBearingIsUnknownDirection() = assertNull(TravelDirection.isReverse(null, 90.0))

    // Regressão: o mesmo rumo de viagem, comparado com o traçado do sentido oposto (via orientada ao
    // contrário), tem de dar o resultado oposto. Antes, o flag guardado da linha anterior era reutilizado.
    @Test fun switchingToTheOppositeTrackFlipsTheRelativeFlagButNotTheTravel() {
        val travel = 80.0
        assertEquals(false, TravelDirection.isReverse(travel, 85.0))
        assertEquals(true, TravelDirection.isReverse(travel, 265.0))
    }
}
