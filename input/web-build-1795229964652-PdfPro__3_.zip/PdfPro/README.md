# PDF Pro (Android)

Leitor e editor de PDF em Kotlin + Jetpack Compose. 100% offline (sem permissão de internet).

## Como abrir
1. Android Studio (Ladybug ou mais novo) > File > Open > pasta `PdfPro`.
2. Aguarde o Gradle sincronizar (baixa dependências; precisa de internet na 1ª vez).
3. Run (▶) no celular, ou Build > Build APK(s).

Requisitos: Android 10+ (minSdk 29), JDK 17 (o Android Studio já traz).
Para usar `./gradlew` no terminal: rode `gradle wrapper` uma vez (o jar do wrapper não vem no zip).

## Estrutura
- `Ops.kt` – operações PdfBox-Android (mesclar, dividir, páginas, proteger, formulário, gravar anotações...)
- `PdfHolder.kt` – renderização com PdfRenderer nativo
- `MainViewModel.kt` – estado e fluxo (versões/desfazer, salvar, compartilhar)
- `ViewerScreen.kt` / `PagesScreen.kt` / `HomeScreen.kt` / `Dialogs.kt` – telas

## Foto -> PDF (scanner)
- "Foto -> PDF" abre o Document Scanner do Google ML Kit (detecta bordas, recorta, filtros, varias paginas, importa da galeria).
- As paginas viram um PDF e, com "PDF pesquisavel (OCR)" ligado, ganham camada de texto invisivel (ML Kit Text Recognition, offline).
- No visualizador: menu > "Reconhecer texto (OCR)" torna pesquisavel um PDF escaneado que ja existe.
- O scanner usa Google Play Services; sem ele o app cai para a camera simples.
