package com.pdfpro.app

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Screen { HOME, VIEWER, PAGES }

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    private val docsDir = File(app.cacheDir, "docs").apply { mkdirs() }
    private val sigFile = File(app.filesDir, "signature.png")

    var screen by mutableStateOf(Screen.HOME)
    var holder by mutableStateOf<PdfHolder?>(null)
    var title by mutableStateOf("")
    var docId by mutableIntStateOf(0)
    var startPage = 0
    var currentPage by mutableIntStateOf(0)

    val annots = mutableStateListOf<Annot>()
    var tool by mutableStateOf(Tool.NONE)
    var color by mutableIntStateOf(0xFFFFEB3B.toInt())
    var penWidth by mutableFloatStateOf(0.004f)
    var textSize by mutableFloatStateOf(0.035f)
    var imageWidth by mutableFloatStateOf(0.3f)
    var stampBitmap by mutableStateOf<Bitmap?>(null)

    var darkReader by mutableStateOf(store.darkReader)
    var ocrEnabled by mutableStateOf(store.ocr)
    var busy by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    var needPassword by mutableStateOf(false)
    var passwordError by mutableStateOf(false)
    var bookmarks by mutableStateOf<List<Int>>(emptyList())
    var recents by mutableStateOf(store.recents())
    var matches by mutableStateOf<List<SearchMatch>>(emptyList())
    var matchIndex by mutableIntStateOf(-1)
    var matchJump by mutableIntStateOf(0)
    var matchPages by mutableStateOf<Map<Int, List<Int>>>(emptyMap())
    var searching by mutableStateOf(false)
    var outline by mutableStateOf<List<OutlineItem>>(emptyList())
    var fields by mutableStateOf<List<FormField>>(emptyList())
    var canUndoFile by mutableStateOf(false)

    val hasChanges: Boolean get() = annots.isNotEmpty() || canUndoFile

    private var work: File? = null
    private var sourceUri: Uri? = null
    private val versions = ArrayDeque<File>()
    private var pendingFile: File? = null
    private var pendingTitle = ""
    private var pendingUri: Uri? = null

    init {
        docsDir.listFiles()?.forEach { it.delete() }
    }

    private fun newFile() = File(docsDir, "w_${System.nanoTime()}.pdf")

    fun nameOf(uri: Uri): String = try {
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: (uri.lastPathSegment ?: "documento.pdf")
    } catch (e: Exception) {
        uri.lastPathSegment ?: "documento.pdf"
    }

    private fun copyUri(uri: Uri): File {
        val f = newFile()
        app.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f
    }

    // ---------- abrir / fechar ----------

    fun open(uri: Uri) = viewModelScope.launch {
        busy = "Abrindo…"
        try {
            try {
                app.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
                try {
                    app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
            }
            val f = withContext(Dispatchers.IO) { copyUri(uri) }
            loadFile(f, nameOf(uri), uri)
        } catch (e: Exception) {
            message = "Não foi possível abrir o arquivo: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            busy = null
        }
    }

    private suspend fun loadFile(f: File, name: String, uri: Uri?) {
        val h = try {
            withContext(Dispatchers.IO) { PdfHolder(f) }
        } catch (e: SecurityException) {
            pendingFile = f
            pendingTitle = name
            pendingUri = uri
            passwordError = false
            needPassword = true
            return
        }
        val old = holder
        holder = h
        work = f
        sourceUri = uri
        title = name
        versions.clear()
        versions.addLast(f)
        canUndoFile = false
        annots.clear()
        clearSearch()
        tool = Tool.NONE
        startPage = uri?.let { store.lastPage(it.toString()) }?.coerceIn(0, h.pageCount - 1) ?: 0
        currentPage = startPage
        bookmarks = uri?.let { store.bookmarks(it.toString()) } ?: emptyList()
        docId++
        screen = Screen.VIEWER
        if (uri != null) {
            store.touch(uri.toString(), name, startPage)
            recents = store.recents()
        }
        withContext(Dispatchers.IO) { old?.close() }
    }

    fun unlock(pw: String) = viewModelScope.launch {
        val src = pendingFile ?: return@launch
        busy = "Desbloqueando…"
        try {
            val out = newFile()
            withContext(Dispatchers.IO) { Ops.unlock(src, pw, out) }
            needPassword = false
            loadFile(out, pendingTitle, pendingUri)
        } catch (e: Exception) {
            passwordError = true
        } finally {
            busy = null
        }
    }

    fun closeDoc() {
        val old = holder
        holder = null
        annots.clear()
        versions.clear()
        work = null
        sourceUri = null
        canUndoFile = false
        clearSearch()
        tool = Tool.NONE
        screen = Screen.HOME
        recents = store.recents()
        viewModelScope.launch(Dispatchers.IO) { old?.close() }
    }

    fun removeRecent(uri: String) {
        store.remove(uri)
        recents = store.recents()
    }

    // ---------- estado de leitura ----------

    fun onPageChanged(i: Int) {
        currentPage = i
        sourceUri?.let { store.updatePage(it.toString(), i) }
    }

    fun toggleBookmark() {
        bookmarks = if (bookmarks.contains(currentPage)) bookmarks - currentPage else (bookmarks + currentPage).sorted()
        sourceUri?.let { store.setBookmarks(it.toString(), bookmarks) }
    }

    fun removeBookmark(p: Int) {
        bookmarks = bookmarks - p
        sourceUri?.let { store.setBookmarks(it.toString(), bookmarks) }
    }

    fun setOcr(v: Boolean) {
        ocrEnabled = v
        store.ocr = v
    }

    fun toggleDark() {
        darkReader = !darkReader
        store.darkReader = darkReader
    }

    // ---------- ferramentas de anotação ----------

    fun selectTool(t: Tool) {
        tool = t
        when (t) {
            Tool.HIGHLIGHT -> color = 0xFFFFEB3B.toInt()
            Tool.UNDERLINE -> color = 0xFF1E88E5.toInt()
            Tool.PEN -> color = 0xFFE53935.toInt()
            Tool.TEXT -> color = 0xFF000000.toInt()
            else -> {}
        }
    }

    fun hasSignature() = sigFile.exists()

    fun useSignature() {
        stampBitmap = BitmapFactory.decodeFile(sigFile.absolutePath)
    }

    fun saveSignature(b: Bitmap) {
        sigFile.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        stampBitmap = b
        selectTool(Tool.IMAGE)
    }

    fun loadStamp(uri: Uri) = viewModelScope.launch {
        val b = withContext(Dispatchers.IO) { Ops.decode(app, uri, 1000, true) }
        if (b == null) {
            message = "Não foi possível abrir a imagem"
        } else {
            stampBitmap = b
            selectTool(Tool.IMAGE)
        }
    }

    fun undo() {
        if (annots.isNotEmpty()) {
            annots.removeAt(annots.lastIndex)
            return
        }
        if (versions.size > 1) {
            viewModelScope.launch {
                versions.removeLast()
                val prev = versions.last()
                try {
                    val nh = withContext(Dispatchers.IO) { PdfHolder(prev) }
                    val old = holder
                    holder = nh
                    work = prev
                    canUndoFile = versions.size > 1
                    withContext(Dispatchers.IO) { old?.close() }
                } catch (e: Exception) {
                    message = "Não foi possível desfazer"
                }
            }
        }
    }

    // ---------- núcleo: gravar anotações e aplicar operações ----------

    private suspend fun swap(newFile: File) {
        val nh = withContext(Dispatchers.IO) { PdfHolder(newFile) }
        val old = holder
        holder = nh
        work = newFile
        versions.addLast(newFile)
        canUndoFile = versions.size > 1
        withContext(Dispatchers.IO) { old?.close() }
    }

    private suspend fun commitInternal() {
        if (annots.isEmpty()) return
        val src = work ?: return
        val out = newFile()
        val list = annots.toList()
        withContext(Dispatchers.IO) { Ops.flatten(src, out, list) }
        annots.clear()
        swap(out)
    }

    private suspend fun runOp(label: String, block: (File, File) -> String?): Boolean {
        busy = label
        return try {
            commitInternal()
            val src = work ?: return false
            val out = newFile()
            val msg = withContext(Dispatchers.IO) { block(src, out) }
            swap(out)
            clearSearch()
            if (msg != null) message = msg
            true
        } catch (e: Exception) {
            message = "Erro: ${e.message ?: e.javaClass.simpleName}"
            false
        } finally {
            busy = null
        }
    }

    private fun op(label: String, block: (File, File) -> String?) = viewModelScope.launch { runOp(label, block) }

    private fun baseName() = title.removeSuffix(".pdf").removeSuffix(".PDF")

    // ---------- operações de página ----------

    fun goPages() = viewModelScope.launch {
        busy = "Preparando…"
        try {
            commitInternal()
            screen = Screen.PAGES
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    fun applyPages(order: List<Int>, rot: Map<Int, Int>) = viewModelScope.launch {
        if (runOp("Aplicando…") { s, o -> Ops.rebuild(s, o, order, rot); null }) screen = Screen.VIEWER
    }

    fun extractPages(order: List<Int>) = viewModelScope.launch {
        busy = "Extraindo…"
        try {
            commitInternal()
            val src = work ?: return@launch
            val tmp = newFile()
            val name = "${baseName()}_extraido.pdf"
            val uri = withContext(Dispatchers.IO) {
                Ops.rebuild(src, tmp, order, emptyMap())
                Ops.saveToDownloads(app, tmp, name)
            }
            message = if (uri != null) "Salvo em Downloads/PdfPro/$name" else "Falha ao salvar"
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    fun extractRange(text: String) {
        val n = holder?.pageCount ?: return
        val pages = Ops.parseRanges(text, n)
        if (pages.isEmpty()) message = "Intervalo inválido. Exemplo: 1-3,5" else extractPages(pages)
    }

    fun splitEvery(n: Int) = viewModelScope.launch {
        if (n < 1) {
            message = "Informe um número válido"
            return@launch
        }
        busy = "Dividindo…"
        try {
            commitInternal()
            val src = work ?: return@launch
            val dir = File(docsDir, "split_${System.nanoTime()}")
            val base = baseName()
            val count = withContext(Dispatchers.IO) {
                val files = Ops.splitEvery(src, n, dir)
                files.forEachIndexed { i, f -> Ops.saveToDownloads(app, f, "${base}_parte${i + 1}.pdf") }
                files.size
            }
            message = "$count arquivos salvos em Downloads/PdfPro"
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    fun appendPdfs(uris: List<Uri>) = op("Mesclando…") { s, o ->
        val extra = uris.map { copyUri(it) }
        Ops.merge(listOf(s) + extra, o)
        "PDFs adicionados ao final"
    }

    fun mergeUris(uris: List<Uri>) = viewModelScope.launch {
        busy = "Mesclando…"
        try {
            val out = newFile()
            withContext(Dispatchers.IO) { Ops.merge(uris.map { copyUri(it) }, out) }
            loadFile(out, "Mesclado.pdf", null)
        } catch (e: Exception) {
            message = "Erro ao mesclar: ${e.message}"
        } finally {
            busy = null
        }
    }

    fun imagesToPdf(uris: List<Uri>) = viewModelScope.launch {
        val ocr = ocrEnabled
        busy = if (ocr) "Criando PDF e reconhecendo texto…" else "Criando PDF…"
        try {
            val out = newFile()
            withContext(Dispatchers.IO) { Ops.imagesToPdf(app, uris, out, ocr) }
            val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.getDefault()).format(java.util.Date())
            loadFile(out, "Scan_$stamp.pdf", null)
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    /** OCR nas páginas sem texto (ex.: PDF escaneado) para que busca e seleção funcionem. */
    fun makeSearchable() = op("Reconhecendo texto…") { s, o ->
        val skip = Ops.pagesWithText(s)
        val tmp = PdfHolder(s)
        val map = HashMap<Int, List<OcrLine>>()
        try {
            for (i in 0 until tmp.pageCount) {
                if (i in skip) continue
                busy = "Reconhecendo texto… ${i + 1}/${tmp.pageCount}"
                map[i] = Ocr.lines(tmp.render(i, 1600))
            }
        } finally {
            tmp.close()
        }
        Ops.addOcrLayer(s, o, map)
        val n = map.values.count { it.isNotEmpty() }
        if (n == 0) "Nenhuma página nova com texto" else "Texto reconhecido em $n página(s). Salve uma cópia para manter."
    }

    fun compress(level: Int) {
        val (q, dim) = when (level) {
            0 -> 80 to 2000
            1 -> 60 to 1500
            else -> 40 to 1100
        }
        op("Comprimindo…") { s, o ->
            Ops.compress(s, o, q, dim)
            "Tamanho: ${s.length() / 1024} KB → ${o.length() / 1024} KB"
        }
    }

    fun protect(pw: String) = viewModelScope.launch {
        busy = "Protegendo…"
        try {
            commitInternal()
            val src = work ?: return@launch
            val tmp = newFile()
            val name = "${baseName()}_protegido.pdf"
            val uri = withContext(Dispatchers.IO) {
                Ops.protect(src, tmp, pw)
                Ops.saveToDownloads(app, tmp, name)
            }
            message = if (uri != null) "Protegido e salvo em Downloads/PdfPro/$name" else "Falha ao salvar"
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    // ---------- busca, índice, formulário ----------

    fun search(q: String) = viewModelScope.launch {
        val f = work ?: return@launch
        searching = true
        val res = try {
            withContext(Dispatchers.IO) { Ops.search(f, q) }
        } catch (e: Exception) {
            emptyList()
        }
        matches = res
        matchPages = res.withIndex().groupBy({ it.value.page }, { it.index })
        matchIndex = -1
        searching = false
        if (res.isEmpty()) message = "Nada encontrado (PDFs escaneados não têm texto pesquisável)"
    }

    /** Seleciona a ocorrência [i] (circular) e pede à tela para rolar até ela. */
    fun selectMatch(i: Int) {
        val n = matches.size
        if (n == 0) return
        matchIndex = ((i % n) + n) % n
        matchJump++
    }

    fun clearSearch() {
        matches = emptyList()
        matchPages = emptyMap()
        matchIndex = -1
    }

    fun loadOutline() = viewModelScope.launch {
        val f = work ?: return@launch
        outline = try {
            withContext(Dispatchers.IO) { Ops.outline(f) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun loadFields() = viewModelScope.launch {
        val f = work ?: return@launch
        fields = try {
            withContext(Dispatchers.IO) { Ops.formFields(f) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun fillForm(values: Map<String, String>) = op("Salvando formulário…") { s, o ->
        Ops.fillForm(s, o, values)
        "Formulário preenchido"
    }

    // ---------- salvar / compartilhar ----------

    fun saveCopy(onDone: (() -> Unit)? = null) = viewModelScope.launch {
        busy = "Salvando…"
        try {
            commitInternal()
            val f = work ?: return@launch
            val name = "${baseName()}_editado.pdf"
            val uri = withContext(Dispatchers.IO) { Ops.saveToDownloads(app, f, name) }
            message = if (uri != null) "Salvo em Downloads/PdfPro/$name" else "Falha ao salvar"
            if (uri != null) onDone?.invoke()
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }

    fun overwriteOriginal() = viewModelScope.launch {
        val u = sourceUri
        if (u == null) {
            message = "Este documento não tem arquivo original. Use Salvar cópia."
            return@launch
        }
        busy = "Salvando…"
        try {
            commitInternal()
            val f = work ?: return@launch
            withContext(Dispatchers.IO) {
                app.contentResolver.openOutputStream(u, "wt")!!.use { o -> f.inputStream().use { it.copyTo(o) } }
            }
            message = "Arquivo original atualizado"
        } catch (e: Exception) {
            message = "Sem permissão para sobrescrever. Use Salvar cópia."
        } finally {
            busy = null
        }
    }

    fun share() = viewModelScope.launch {
        busy = "Preparando…"
        try {
            commitInternal()
            val f = work ?: return@launch
            val dir = File(app.cacheDir, "share").apply { mkdirs() }
            var safe = title.replace(Regex("[^\\w .-]"), "_")
            if (!safe.endsWith(".pdf", ignoreCase = true)) safe += ".pdf"
            val out = File(dir, safe)
            withContext(Dispatchers.IO) { f.copyTo(out, overwrite = true) }
            val uri = FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", out)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            app.startActivity(Intent.createChooser(send, "Compartilhar PDF").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            message = "Erro: ${e.message}"
        } finally {
            busy = null
        }
    }
}
