@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pdfpro.app

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class PageItem(val src: Int, val rot: Int = 0, val sel: Boolean = false)

@Composable
fun PagesScreen(vm: MainViewModel) {
    val holder = vm.holder ?: return
    val items = remember(holder) {
        mutableStateListOf<PageItem>().apply { addAll((0 until holder.pageCount).map { PageItem(it) }) }
    }
    val selected = items.count { it.sel }

    BackHandler { vm.screen = Screen.VIEWER }

    fun rotate(d: Int) {
        for (i in items.indices) if (items[i].sel) items[i] = items[i].copy(rot = (items[i].rot + d + 360) % 360)
    }

    fun moveEarlier() {
        for (i in 1 until items.size) {
            if (items[i].sel && !items[i - 1].sel) {
                val x = items.removeAt(i)
                items.add(i - 1, x)
            }
        }
    }

    fun moveLater() {
        for (i in items.size - 2 downTo 0) {
            if (items[i].sel && !items[i + 1].sel) {
                val x = items.removeAt(i)
                items.add(i + 1, x)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (selected > 0) "$selected selecionada(s)" else "Organizar páginas") },
                navigationIcon = {
                    IconButton(onClick = { vm.screen = Screen.VIEWER }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                },
                actions = {
                    IconButton(onClick = {
                        val rot = items.filter { it.rot != 0 }.associate { it.src to it.rot }
                        vm.applyPages(items.map { it.src }, rot)
                    }) { Icon(Icons.Default.Check, "Aplicar") }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    IconButton(onClick = {
                        val all = items.all { it.sel }
                        for (i in items.indices) items[i] = items[i].copy(sel = !all)
                    }) { Icon(Icons.Default.SelectAll, "Selecionar tudo") }
                    IconButton(enabled = selected > 0, onClick = { rotate(-90) }) { Icon(Icons.Default.RotateLeft, "Girar à esquerda") }
                    IconButton(enabled = selected > 0, onClick = { rotate(90) }) { Icon(Icons.Default.RotateRight, "Girar à direita") }
                    IconButton(enabled = selected > 0, onClick = { moveEarlier() }) { Icon(Icons.Default.KeyboardArrowLeft, "Mover antes") }
                    IconButton(enabled = selected > 0, onClick = { moveLater() }) { Icon(Icons.Default.KeyboardArrowRight, "Mover depois") }
                    IconButton(enabled = selected > 0, onClick = {
                        vm.extractPages(items.filter { it.sel }.map { it.src })
                    }) { Icon(Icons.Default.ContentCut, "Extrair") }
                    IconButton(enabled = selected > 0, onClick = {
                        if (selected == items.size) vm.message = "O PDF precisa ter pelo menos uma página"
                        else items.removeAll { it.sel }
                    }) { Icon(Icons.Default.Delete, "Excluir") }
                }
            }
        }
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Adaptive(104.dp),
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(items, key = { _, it -> it.src }) { idx, it ->
                Thumb(holder, it, idx + 1) {
                    val i = items.indexOfFirst { p -> p.src == it.src }
                    if (i >= 0) items[i] = items[i].copy(sel = !items[i].sel)
                }
            }
        }
    }
}

@Composable
private fun Thumb(holder: PdfHolder, item: PageItem, number: Int, onClick: () -> Unit) {
    var bmp by remember(holder, item.src) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(holder, item.src) {
        bmp = withContext(Dispatchers.IO) { holder.render(item.src, 256) }
    }
    val img = remember(bmp) { bmp?.asImageBitmap() }
    Card(
        onClick = onClick,
        border = if (item.sel) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else null,
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE0E0E0))
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().aspectRatio(0.75f).padding(4.dp).clipToBounds(), contentAlignment = Alignment.Center) {
                if (img != null) {
                    Image(
                        bitmap = img,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().graphicsLayer(rotationZ = item.rot.toFloat())
                    )
                }
            }
            Text("$number", style = MaterialTheme.typography.labelMedium, color = Color.Black, modifier = Modifier.padding(bottom = 4.dp))
        }
    }
}
