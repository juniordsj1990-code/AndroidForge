package com.pdfpro.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("pdfpro", Context.MODE_PRIVATE)

    fun recents(): List<Recent> = try {
        val arr = JSONArray(sp.getString("recents", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Recent(o.getString("uri"), o.getString("name"), o.optInt("page"), o.optLong("time"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun saveRecents(list: List<Recent>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("uri", it.uri).put("name", it.name).put("page", it.page).put("time", it.time))
        }
        sp.edit().putString("recents", arr.toString()).apply()
    }

    fun touch(uri: String, name: String, page: Int) {
        val rest = recents().filter { it.uri != uri }
        saveRecents((listOf(Recent(uri, name, page, System.currentTimeMillis())) + rest).take(30))
    }

    fun updatePage(uri: String, page: Int) {
        val l = recents()
        if (l.none { it.uri == uri }) return
        saveRecents(l.map { if (it.uri == uri) it.copy(page = page) else it })
    }

    fun remove(uri: String) = saveRecents(recents().filter { it.uri != uri })

    fun lastPage(uri: String): Int = recents().firstOrNull { it.uri == uri }?.page ?: 0

    fun bookmarks(uri: String): List<Int> =
        (sp.getString("bm:$uri", "") ?: "").split(',').mapNotNull { it.toIntOrNull() }

    fun setBookmarks(uri: String, l: List<Int>) {
        sp.edit().putString("bm:$uri", l.joinToString(",")).apply()
    }

    var ocr: Boolean
        get() = sp.getBoolean("ocr", true)
        set(v) {
            sp.edit().putBoolean("ocr", v).apply()
        }

    var darkReader: Boolean
        get() = sp.getBoolean("dark", false)
        set(v) {
            sp.edit().putBoolean("dark", v).apply()
        }
}
