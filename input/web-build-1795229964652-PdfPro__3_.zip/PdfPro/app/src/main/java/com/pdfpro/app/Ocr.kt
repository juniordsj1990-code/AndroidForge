package com.pdfpro.app

import android.graphics.Bitmap
import android.graphics.RectF
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** OCR offline (ML Kit, modelo embutido no app). Bloqueante: chame em Dispatchers.IO. */
object Ocr {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    fun lines(bmp: Bitmap): List<OcrLine> {
        val res = Tasks.await(recognizer.process(InputImage.fromBitmap(bmp, 0)))
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        val out = ArrayList<OcrLine>()
        for (b in res.textBlocks) {
            for (l in b.lines) {
                val r = l.boundingBox ?: continue
                if (l.text.isBlank()) continue
                out.add(
                    OcrLine(
                        l.text,
                        RectF(
                            (r.left / w).coerceIn(0f, 1f), (r.top / h).coerceIn(0f, 1f),
                            (r.right / w).coerceIn(0f, 1f), (r.bottom / h).coerceIn(0f, 1f)
                        )
                    )
                )
            }
        }
        return out
    }
}
