package br.com.alertageografico

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log

/** Player único do alerta, com tom de emergência caso o toque configurado falhe. */
object RoutedAlertSound {
    private const val TAG = "RoutedAlertSound"
    private const val NORMAL_MAX_MS = 15_000L
    private const val ALARM_MAX_MS = 60_000L
    private val main = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var focusRequest: AudioFocusRequest? = null
    private var audioManager: AudioManager? = null
    private var stopRunnable: Runnable? = null
    private var fallbackTone: ToneGenerator? = null

    @Synchronized
    fun stop() {
        stopRunnable?.let { main.removeCallbacks(it) }
        stopRunnable = null
        fallbackTone?.let { runCatching { it.stopTone(); it.release() } }
        fallbackTone = null
        player?.let { p ->
            runCatching { if (p.isPlaying) p.stop() }
            runCatching { p.release() }
        }
        player = null
        if (Build.VERSION.SDK_INT >= 26) {
            focusRequest?.let { runCatching { audioManager?.abandonAudioFocusRequest(it) } }
        }
        focusRequest = null
    }

    @Synchronized
    fun play(context: Context, onStatus: ((String) -> Unit)? = null) {
        if (!DestinationStore.soundEnabled(context)) {
            onStatus?.invoke("Som desativado nas preferências")
            return
        }
        stop()
        val appContext = context.applicationContext
        val am = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager = am
        val output = DestinationStore.alertAudioOutput(appContext)
        val volume = DestinationStore.alertVolume(appContext)
        val alarm = DestinationStore.alarmMode(appContext)
        val audioMode = DestinationStore.alertAudioMode(appContext)
        val mixMode = DestinationStore.alertMixMode(appContext)
        val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        val target = if (output == "speaker") {
            devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
        } else {
            devices.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    (Build.VERSION.SDK_INT >= 31 && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET) ||
                    it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
        }
        if (output == "headphones" && target == null) {
            onStatus?.invoke("Nenhum fone detectado; o alerta tocará no alto-falante.")
        }

        val usage = when {
            alarm -> AudioAttributes.USAGE_ALARM
            audioMode == "notification" -> AudioAttributes.USAGE_NOTIFICATION
            else -> AudioAttributes.USAGE_MEDIA
        }
        val attributes = AudioAttributes.Builder()
            .setUsage(usage)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        fun requestDuckingFocus() {
            if (mixMode == "duck" && Build.VERSION.SDK_INT >= 26 && focusRequest == null) {
                val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attributes)
                    .setOnAudioFocusChangeListener { }
                    .build()
                focusRequest = request
                val result = runCatching { am.requestAudioFocus(request) }
                    .getOrDefault(AudioManager.AUDIOFOCUS_REQUEST_FAILED)
                Log.i(TAG, "Solicitação de foco de áudio: $result")
            }
        }

        fun fallbackBeep(reason: String) {
            Log.w(TAG, "$reason; usando tom de emergência")
            try {
                val stream = when {
                    alarm -> AudioManager.STREAM_ALARM
                    audioMode == "notification" -> AudioManager.STREAM_NOTIFICATION
                    else -> AudioManager.STREAM_MUSIC
                }
                val tone = ToneGenerator(stream, (volume * 100).toInt().coerceIn(1, 100))
                fallbackTone = tone
                requestDuckingFocus()
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, if (alarm) 1500 else 900)
                val timeout = Runnable { stop() }
                stopRunnable = timeout
                main.postDelayed(timeout, if (alarm) ALARM_MAX_MS else NORMAL_MAX_MS)
                onStatus?.invoke("Som de emergência reproduzido; verifique o toque configurado")
            } catch (e: Exception) {
                Log.e(TAG, "Falha também no tom de emergência", e)
                onStatus?.invoke("Falha no áudio. Verifique o volume e as configurações de som do Android.")
            }
        }

        val chosenUri = DestinationStore.alertSoundUri(appContext)?.let(Uri::parse)
        val uri = chosenUri ?: RingtoneManager.getDefaultUri(
            if (alarm) RingtoneManager.TYPE_ALARM else RingtoneManager.TYPE_NOTIFICATION
        ) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        if (uri == null) {
            fallbackBeep("Nenhum toque do sistema disponível")
            return
        }

        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(attributes)
            mp.setVolume(volume, volume)
            mp.isLooping = alarm
            mp.setDataSource(appContext, uri)
            if (target != null) mp.setPreferredDevice(target)
            mp.setOnCompletionListener { stopIfCurrent(mp) }
            mp.setOnErrorListener { _, what, extra ->
                Log.w(TAG, "Falha ao reproduzir alerta: what=$what extra=$extra")
                if (player === mp) {
                    runCatching { mp.release() }
                    player = null
                    fallbackBeep("Falha ao reproduzir o toque configurado")
                } else runCatching { mp.release() }
                true
            }
            mp.setOnPreparedListener { prepared ->
                try {
                    if (target != null) prepared.setPreferredDevice(target)
                    // Só reduz a música depois de o toque estar preparado para tocar.
                    requestDuckingFocus()
                    prepared.start()
                    val timeout = Runnable { stopIfCurrent(prepared) }
                    stopRunnable = timeout
                    main.postDelayed(timeout, if (alarm) ALARM_MAX_MS else NORMAL_MAX_MS)
                    val routed = if (Build.VERSION.SDK_INT >= 28) runCatching { prepared.routedDevice }.getOrNull() else null
                    val routedName = routed?.productName?.toString()?.takeIf { it.isNotBlank() }
                    val message = when {
                        routedName != null -> "Alerta reproduzido pela saída: $routedName"
                        target != null -> "Alerta iniciado; saída solicitada: ${target.productName}"
                        else -> "Alerta iniciado no alto-falante do celular"
                    }
                    Log.i(TAG, message)
                    onStatus?.invoke(message)
                } catch (e: Exception) {
                    Log.w(TAG, "Não foi possível iniciar o player", e)
                    if (player === prepared) {
                        runCatching { prepared.release() }
                        player = null
                        fallbackBeep("Não foi possível iniciar o player")
                    } else runCatching { prepared.release() }
                }
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            Log.w(TAG, "Erro ao preparar áudio", e)
            runCatching { mp.release() }
            if (player === mp) player = null
            fallbackBeep("Erro ao preparar o áudio")
        }
    }

    @Synchronized
    private fun stopIfCurrent(p: MediaPlayer) {
        if (player === p) stop() else runCatching { p.release() }
    }
}
