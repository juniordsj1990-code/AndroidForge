import { Camera } from '@capacitor/camera';
import { Geolocation } from '@capacitor/geolocation';
import { Filesystem , Directory } from '@capacitor/filesystem' ;

// pedir permissÃ£o
async function pedirPermissao() {
const perm = await Filesystem . requestPermissions ();
console . log (perm);
}

// escrever arquivo
await Filesystem.writeFile({
path: 'arquivo.txt',
data: 'ConteÃºdo do aplicativo',
directory: Directory.Documents
});

// ler arquivo
const file = await Filesystem.readFile({
path: 'arquivo.txt',
directory: Directory.Documents
});
console.log(file.data);



window.pedirPermissoes = async () => {
  try {
    // 📷 Permissão de câmera
    await Camera.requestPermissions();

    // 📍 Permissão de localização
    await Geolocation.requestPermissions();

    alert("Permissões concedidas ✅");
  } catch (erro) {
    alert("Permissões negadas ❌");
    console.error(erro);
  }
};