package com.docfotopro.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * Desenha o carimbo do DocFoto Pro (mesmo visual do carimbo das fotos no app web):
 * hora grande + barra de destaque + data/dia, endereço, cliente, OS/técnico, status
 * em pílula colorida e observação, sobre um degradê escuro no rodapé.
 * O fundo do bitmap é transparente: ele é usado como overlay sobre os quadros do vídeo.
 */
final class StampRenderer {

    static final class Info {
        String cliente = "", os = "", tecnico = "", status = "", obs = "", endereco = "";
        boolean showTime = true;
    }

    private static final String[] DIAS = {"Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"};

    private StampRenderer() {}

    /** Limpa o bitmap (transparente) e desenha o carimbo nele. */
    static void renderInto(Bitmap bmp, Info info, long timeMs, boolean withSeconds) {
        bmp.eraseColor(0x00000000);
        draw(new Canvas(bmp), bmp.getWidth(), bmp.getHeight(), info, timeMs, withSeconds);
    }

    static Bitmap render(int w, int h, Info info, long timeMs, boolean withSeconds) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        renderInto(bmp, info, timeMs, withSeconds);
        return bmp;
    }

    private static Paint paint(Typeface tf, float size, int color, float shadowBlur) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(tf);
        p.setTextSize(size);
        p.setColor(color);
        if (shadowBlur > 0f) p.setShadowLayer(shadowBlur, 0f, 1f, 0xBF000000);
        return p;
    }

    private static List<String> wrap(Paint p, String text, float maxW, int maxLines) {
        List<String> lines = new ArrayList<>();
        String[] words = text.trim().split("\\s+");
        StringBuilder cur = new StringBuilder();
        for (String wd : words) {
            if (wd.isEmpty()) continue;
            String t = cur.length() == 0 ? wd : cur.toString() + " " + wd;
            if (cur.length() == 0 || p.measureText(t) <= maxW) {
                cur.setLength(0);
                cur.append(t);
            } else {
                lines.add(cur.toString());
                cur.setLength(0);
                cur.append(wd);
            }
        }
        if (cur.length() > 0) lines.add(cur.toString());
        if (lines.size() > maxLines) {
            lines = new ArrayList<>(lines.subList(0, maxLines));
            String last = lines.get(maxLines - 1);
            while (last.length() > 1 && p.measureText(last + "…") > maxW) {
                last = last.substring(0, last.length() - 1);
            }
            last = last.replaceAll("[\\s,;.\\-]+$", "");
            lines.set(maxLines - 1, last + "…");
        }
        return lines;
    }

    private static String normStatus(String s) {
        String n = Normalizer.normalize(s == null ? "" : s.trim().toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        return n.replaceAll("\\p{M}", "");
    }

    private static int statusColor(String status) {
        String n = normStatus(status);
        if (n.equals("antes")) return 0xFFFF5A1F;
        if (n.equals("depois")) return 0xFF0E9F6E;
        return 0xFF1A56DB;
    }

    private static void drawPin(Canvas c, float cx, float top, float size, int color) {
        float r = size * 0.36f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        Path path = new Path();
        path.addArc(new RectF(cx - r, top, cx + r, top + 2 * r), 153f, 234f);
        path.lineTo(cx, top + size);
        path.close();
        c.drawPath(path, p);
        p.setColor(0x8C000000);
        c.drawCircle(cx, top + r, r * 0.4f, p);
    }

    private static void draw(Canvas c, int w, int h, Info info, long timeMs, boolean withSeconds) {
        final float u = Math.max(9f, w / 60f);
        final float pad = u * 1.7f;
        final float maxW = w - pad * 2f;

        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timeMs);
        String hhmm = withSeconds
                ? String.format(Locale.US, "%02d:%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND))
                : String.format(Locale.US, "%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));
        String data = String.format(Locale.US, "%02d/%02d/%d", cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR));
        String dia = DIAS[cal.get(Calendar.DAY_OF_WEEK) - 1];

        final float sizeLine = u * 2.1f;                  // hora, data e dia da semana: mesmo tamanho
        final float sizeTime = sizeLine, sizeDate = sizeLine, sizeWeek = sizeLine;
        final float sizeAddr = u * 1.15f, sizeCli = u * 1.4f, sizeInfo = u * 1.15f, sizeObs = u * 1.1f, sizePill = u * 1.0f;
        final float timeH = sizeTime * 0.72f;
        final float gap = u * 0.9f, barW = Math.max(3f, u * 0.22f);
        final float shadow = u * 0.4f;

        Typeface numBold = Typeface.create("sans-serif-condensed", Typeface.BOLD);
        Typeface numReg = Typeface.create("sans-serif-condensed", Typeface.NORMAL);
        Typeface textBold = Typeface.create("sans-serif", Typeface.BOLD);
        Typeface textMed = Typeface.create("sans-serif-medium", Typeface.NORMAL);
        Typeface textItalic = Typeface.create("sans-serif", Typeface.ITALIC);

        Paint pTime = paint(numBold, sizeTime, 0xFFFFFFFF, shadow);
        pTime.setFontFeatureSettings("tnum");        // dígitos de largura fixa (o relógio não "balança")
        Paint pDate = paint(numBold, sizeDate, 0xFFFFFFFF, shadow);
        Paint pWeek = paint(numReg, sizeWeek, 0xE0FFFFFF, shadow);
        Paint pAddr = paint(textMed, sizeAddr, 0xFFF3F4F6, shadow);
        Paint pCli = paint(textBold, sizeCli, 0xFFFFFFFF, shadow);
        Paint pInfo = paint(textMed, sizeInfo, 0xFFE5E7EB, shadow);
        Paint pObs = paint(textItalic, sizeObs, 0xFFE5E7EB, shadow);
        Paint pPill = paint(textBold, sizePill, 0xFFFFFFFF, 0f);

        // ── medidas ──
        float timeW = pTime.measureText(withSeconds ? "88:88:88" : "88:88");
        float dateW = pDate.measureText(data);
        float weekW = pWeek.measureText(dia);
        float xDate = pad + timeW + gap + barW + gap;
        float xWeek = xDate + dateW + u * 0.9f;          // dia da semana ao lado da data
        float rowRight = xWeek + weekW;

        boolean showTime = info.showTime;
        String status = info.status == null ? "" : info.status.trim();
        float pillW = 0f, pillH = 0f;
        boolean pillOnRow = false;
        String statusUp = status.toUpperCase(Locale.getDefault());
        if (!status.isEmpty()) {
            pillW = pPill.measureText(statusUp) + u * 1.8f;
            pillH = sizePill * 2f;
            pillOnRow = showTime && (rowRight + gap * 2f + pillW <= w - pad);
        }

        String endereco = info.endereco == null ? "" : info.endereco.trim();
        float pinW = sizeAddr * 1.3f;
        List<String> addrLines = endereco.isEmpty() ? new ArrayList<String>() : wrap(pAddr, endereco, maxW - pinW, 2);
        float addrLH = sizeAddr * 1.4f;

        String cliente = info.cliente == null ? "" : info.cliente.trim();
        List<String> cliLines = cliente.isEmpty() ? new ArrayList<String>() : wrap(pCli, cliente.toUpperCase(Locale.getDefault()), maxW, 1);
        StringBuilder parts = new StringBuilder();
        if (info.os != null && !info.os.trim().isEmpty()) parts.append("OS ").append(info.os.trim());
        if (info.tecnico != null && !info.tecnico.trim().isEmpty()) {
            if (parts.length() > 0) parts.append("  ·  ");
            parts.append("Téc. ").append(info.tecnico.trim());
        }
        List<String> infoLines = parts.length() == 0 ? new ArrayList<String>() : wrap(pInfo, parts.toString(), maxW, 1);
        float cliLH = sizeCli * 1.35f, infoLH = sizeInfo * 1.4f;

        String obs = info.obs == null ? "" : info.obs.trim();
        List<String> obsLines = obs.isEmpty() ? new ArrayList<String>() : wrap(pObs, obs, maxW, 2);
        float obsLH = sizeObs * 1.4f;

        // ── altura total do bloco ──
        boolean pillRow = !status.isEmpty() && !pillOnRow;
        float H = 0f;
        boolean started = false;
        if (pillRow)                { H += pillH; started = true; }
        if (showTime)               { if (started) H += u * 0.8f; H += timeH; started = true; }
        if (!addrLines.isEmpty())   { if (started) H += u * 1.0f; H += addrLines.size() * addrLH; started = true; }
        if (!cliLines.isEmpty())    { if (started) H += u * 0.9f; H += cliLH; started = true; }
        if (!infoLines.isEmpty())   { H += infoLH; started = true; }
        if (!obsLines.isEmpty())    { if (started) H += u * 0.5f; H += obsLines.size() * obsLH; started = true; }

        if (!started) return;   // nada para carimbar

        float y0 = h - pad - H;

        // ── degradê escuro de fundo ──
        float gy = Math.max(0f, y0 - u * 6f);
        Paint pg = new Paint();
        pg.setShader(new LinearGradient(0f, gy, 0f, h,
                new int[]{0x00000000, 0x61000000, 0xD9000000},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0f, gy, w, h, pg);

        float y = y0;
        boolean drawn = false;

        // pílula em linha própria
        if (pillRow) {
            drawPill(c, pPill, statusUp, status, pad, y, pillW, pillH, u);
            y += pillH;
            drawn = true;
        }

        // linha da hora
        if (showTime) {
            if (drawn) y += u * 0.8f;
            drawn = true;
            c.drawText(hhmm, pad, y + timeH, pTime);
            Paint pb = new Paint();
            pb.setColor(0xFFFFC21A);
            c.drawRect(pad + timeW + gap, y, pad + timeW + gap + barW, y + timeH, pb);
            c.drawText(data, xDate, y + timeH, pDate);
            c.drawText(dia, xWeek, y + timeH, pWeek);
            if (!status.isEmpty() && pillOnRow) {
                drawPill(c, pPill, statusUp, status, w - pad - pillW, y + timeH / 2f - pillH / 2f, pillW, pillH, u);
            }
            y += timeH;
        }

        // endereço
        if (!addrLines.isEmpty()) {
            if (drawn) y += u * 1.0f;
            drawn = true;
            drawPin(c, pad + sizeAddr * 0.4f, y + sizeAddr * 0.1f, sizeAddr * 1.05f, 0xFFFFC21A);
            for (int i = 0; i < addrLines.size(); i++) {
                c.drawText(addrLines.get(i), pad + pinW, y + sizeAddr + i * addrLH, pAddr);
            }
            y += addrLines.size() * addrLH;
        }

        // cliente
        if (!cliLines.isEmpty()) {
            if (drawn) y += u * 0.9f;
            drawn = true;
            c.drawText(cliLines.get(0), pad, y + sizeCli, pCli);
            y += cliLH;
        }

        // OS · técnico
        if (!infoLines.isEmpty()) {
            drawn = true;
            c.drawText(infoLines.get(0), pad, y + sizeInfo, pInfo);
            y += infoLH;
        }

        // observação
        if (!obsLines.isEmpty()) {
            if (drawn) y += u * 0.5f;
            for (int i = 0; i < obsLines.size(); i++) {
                c.drawText(obsLines.get(i), pad, y + sizeObs + i * obsLH, pObs);
            }
        }
    }

    private static void drawPill(Canvas c, Paint textPaint, String textUp, String status,
                                 float x, float y, float pw, float ph, float u) {
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(statusColor(status));
        c.drawRoundRect(new RectF(x, y, x + pw, y + ph), ph / 2f, ph / 2f, bg);
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float baseline = y + ph / 2f - (fm.ascent + fm.descent) / 2f;
        c.drawText(textUp, x + u * 0.9f, baseline, textPaint);
    }
}
