package com.docfotopro.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;

import androidx.activity.result.ActivityResult;
import androidx.core.content.FileProvider;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.effect.BitmapOverlay;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.Presentation;
import androidx.media3.effect.TextureOverlay;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Plugin nativo do DocFoto Pro:
 *  - saveImage:  JPEG direto na galeria (Pictures/DocFoto) via MediaStore
 *  - recordVideo / pickVideo: grava ou escolhe um vídeo
 *  - stampVideo: regrava o vídeo com o carimbo (Media3 Transformer + overlay), com relógio correndo
 *  - saveVideo:  vídeo direto na galeria (Movies/DocFoto)
 *  - shareVideo / deleteFile / cancelStamp: utilitários
 */
@CapacitorPlugin(
        name = "MediaSaver",
        permissions = {@Permission(strings = {Manifest.permission.CAMERA}, alias = "camera")}
)
public class MediaSaverPlugin extends Plugin {

    private static final String VIDEOS_DIR = "videos";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    // Estado da exportação em andamento (só uma por vez)
    private Transformer currentTransformer;
    private PluginCall currentCall;
    private File currentOut;
    private volatile boolean finished;

    // ─────────────────────────────────────────────────────────────
    // FOTO → galeria
    // ─────────────────────────────────────────────────────────────
    @PluginMethod
    public void saveImage(PluginCall call) {
        String data = call.getString("data");
        String filename = call.getString("filename");
        String folder = call.getString("folder", "DocFoto");

        if (data == null || filename == null) {
            call.reject("Parâmetros inválidos");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            call.reject("UNSUPPORTED");
            return;
        }

        try {
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            ContentResolver resolver = getContext().getContentResolver();

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + folder);
            values.put(MediaStore.Images.Media.IS_PENDING, 1);

            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) {
                call.reject("Não foi possível criar o arquivo na galeria");
                return;
            }

            try (OutputStream os = resolver.openOutputStream(uri)) {
                if (os == null) throw new IllegalStateException("Sem stream de saída");
                os.write(bytes);
            } catch (Exception e) {
                resolver.delete(uri, null, null);
                throw e;
            }

            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);

            JSObject ret = new JSObject();
            ret.put("uri", uri.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "Erro ao salvar na galeria");
        }
    }

    // ─────────────────────────────────────────────────────────────
    // VÍDEO: gravar / escolher
    // ─────────────────────────────────────────────────────────────
    @PluginMethod
    public void recordVideo(PluginCall call) {
        if (getPermissionState("camera") != PermissionState.GRANTED) {
            requestPermissionForAlias("camera", call, "cameraPermsCallback");
            return;
        }
        launchRecord(call);
    }

    @PermissionCallback
    private void cameraPermsCallback(PluginCall call) {
        if (getPermissionState("camera") == PermissionState.GRANTED) {
            launchRecord(call);
        } else {
            call.reject("Permissão da câmera negada");
        }
    }

    private void launchRecord(PluginCall call) {
        try {
            File dir = new File(getContext().getCacheDir(), VIDEOS_DIR);
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            File out = new File(dir, "rec_" + System.currentTimeMillis() + ".mp4");
            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", out);

            Intent i = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            i.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            i.setClipData(ClipData.newRawUri("", uri));

            call.getData().put("_out", out.getAbsolutePath());
            startActivityForResult(call, i, "recordResult");
        } catch (Exception e) {
            call.reject("Não foi possível abrir a câmera de vídeo: " + e.getMessage());
        }
    }

    @ActivityCallback
    private void recordResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK) {
            call.reject("CANCELLED");
            return;
        }
        String path = call.getString("_out");
        File f = path != null ? new File(path) : null;
        JSObject r = new JSObject();
        if (f != null && f.exists() && f.length() > 0) {
            r.put("uri", Uri.fromFile(f).toString());
            r.put("temp", true);
            call.resolve(r);
            return;
        }
        // Alguns apps de câmera ignoram EXTRA_OUTPUT e devolvem o vídeo em data
        Intent data = result.getData();
        if (data != null && data.getData() != null) {
            r.put("uri", data.getData().toString());
            r.put("temp", false);
            call.resolve(r);
            return;
        }
        call.reject("Vídeo não encontrado");
    }

    @PluginMethod
    public void pickVideo(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("video/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(call, Intent.createChooser(i, "Escolher vídeo"), "pickResult");
        } catch (Exception e) {
            call.reject("Não foi possível abrir o seletor de vídeos: " + e.getMessage());
        }
    }

    @ActivityCallback
    private void pickResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent data = result.getData();
        if (result.getResultCode() != Activity.RESULT_OK || data == null || data.getData() == null) {
            call.reject("CANCELLED");
            return;
        }
        JSObject r = new JSObject();
        r.put("uri", data.getData().toString());
        r.put("temp", false);
        call.resolve(r);
    }

    // ─────────────────────────────────────────────────────────────
    // VÍDEO: carimbo (Media3 Transformer)
    // ─────────────────────────────────────────────────────────────
    @PluginMethod
    public void stampVideo(final PluginCall call) {
        if (currentCall != null) {
            call.reject("Já existe um vídeo sendo processado");
            return;
        }
        final String input = call.getString("input");
        if (input == null || input.isEmpty()) {
            call.reject("Entrada inválida");
            return;
        }
        final StampRenderer.Info info = new StampRenderer.Info();
        info.cliente = nz(call.getString("cliente"));
        info.os = nz(call.getString("os"));
        info.tecnico = nz(call.getString("tecnico"));
        info.status = nz(call.getString("status"));
        info.obs = nz(call.getString("obs"));
        info.endereco = nz(call.getString("endereco"));
        info.showTime = call.getBoolean("hora", true);
        final boolean recorded = call.getBoolean("recorded", false);
        final boolean deleteInput = call.getBoolean("deleteInput", false);
        final boolean semAudio = call.getBoolean("semAudio", false);
        final long startParam = call.getData().optLong("startTs", 0L);

        currentCall = call;
        finished = false;
        io.execute(new Runnable() {
            @Override
            public void run() {
                prepareAndStart(call, input, info, recorded, deleteInput, startParam, semAudio);
            }
        });
    }

    private void prepareAndStart(PluginCall call, final String input, final StampRenderer.Info info,
                                 boolean recorded, final boolean deleteInput, long startParam, final boolean semAudio) {
        final Uri inUri = input.startsWith("/") ? Uri.fromFile(new File(input)) : Uri.parse(input);

        int dw, dh;
        final long durMs;
        long startTs;
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(getContext(), inUri);
            int vw = parseInt(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int vh = parseInt(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            int rot = parseInt(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
            durMs = parseLong(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            if (vw <= 0 || vh <= 0) throw new IllegalStateException("Vídeo sem dimensões");
            boolean swap = (rot % 180) != 0;
            dw = swap ? vh : vw;
            dh = swap ? vw : vh;

            startTs = System.currentTimeMillis() - durMs;
            if (!recorded) {
                Long d = parseMetaDate(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DATE));
                if (d != null) startTs = d;
            }
            if (startParam > 0) startTs = startParam;
        } catch (Exception e) {
            failCurrent("Não foi possível ler o vídeo: " + e.getMessage());
            return;
        } finally {
            releaseQuietly(mmr);
        }

        // Limita a 1080p (lado curto) para o carimbo não pesar demais
        int shortSide = Math.min(dw, dh);
        final boolean downscale = shortSide > 1080;
        final int ow, oh;
        if (downscale) {
            float k = 1080f / shortSide;
            ow = even(Math.round(dw * k));
            oh = even(Math.round(dh * k));
        } else {
            ow = dw;
            oh = dh;
        }
        final long startTsF = startTs;

        File dir = new File(getContext().getFilesDir(), VIDEOS_DIR);
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        final File out = new File(dir, "vid_" + System.currentTimeMillis() + ".mp4");
        currentOut = out;

        main.post(new Runnable() {
            @Override
            public void run() {
                startTransformer(inUri, out, info, ow, oh, downscale, startTsF, durMs, deleteInput, input, semAudio);
            }
        });
    }

    private void startTransformer(Uri inUri, final File out, final StampRenderer.Info info,
                                  final int ow, final int oh, boolean downscale,
                                  final long startTs, final long durMs,
                                  final boolean deleteInput, final String input, boolean semAudio) {
        try {
            // Overlay do mesmo tamanho do quadro: cobre o vídeo inteiro.
            // O bitmap é redesenhado a cada minuto (hora e minuto, sem segundos).
            final Bitmap overlayBmp = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888);
            BitmapOverlay overlay = new BitmapOverlay() {
                private long lastMinute = Long.MIN_VALUE;

                @Override
                public Bitmap getBitmap(long presentationTimeUs) {
                    long t = startTs + presentationTimeUs / 1000L;
                    long minute = t / 60000L;
                    if (lastMinute == Long.MIN_VALUE || (info.showTime && minute != lastMinute)) {
                        StampRenderer.renderInto(overlayBmp, info, t, false);
                        lastMinute = minute;
                    }
                    return overlayBmp;
                }
            };

            List<Effect> videoEffects = new ArrayList<>();
            if (downscale) {
                videoEffects.add(Presentation.createForWidthAndHeight(ow, oh, Presentation.LAYOUT_SCALE_TO_FIT));
            }
            List<TextureOverlay> overlays = new ArrayList<>();
            overlays.add(overlay);
            videoEffects.add(new OverlayEffect(overlays));

            EditedMediaItem item = new EditedMediaItem.Builder(MediaItem.fromUri(inUri))
                    .setRemoveAudio(semAudio)
                    .setEffects(new Effects(Collections.<AudioProcessor>emptyList(), videoEffects))
                    .build();

            Transformer transformer = new Transformer.Builder(getContext())
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .addListener(new Transformer.Listener() {
                        @Override
                        public void onCompleted(Composition composition, ExportResult exportResult) {
                            if (finished) return;
                            finished = true;
                            io.execute(new Runnable() {
                                @Override
                                public void run() {
                                    finishOk(out, ow, oh, startTs, durMs, deleteInput, input);
                                }
                            });
                        }

                        @Override
                        public void onError(Composition composition, ExportResult exportResult, ExportException exportException) {
                            if (finished) return;
                            finished = true;
                            //noinspection ResultOfMethodCallIgnored
                            out.delete();
                            failCurrent("Erro ao carimbar o vídeo: " + exportException.getMessage());
                        }
                    })
                    .build();

            currentTransformer = transformer;
            transformer.start(item, out.getAbsolutePath());
            pollProgress(transformer);
        } catch (Exception e) {
            finished = true;
            //noinspection ResultOfMethodCallIgnored
            out.delete();
            failCurrent("Erro ao iniciar o carimbo: " + e.getMessage());
        }
    }

    private void pollProgress(final Transformer transformer) {
        final ProgressHolder holder = new ProgressHolder();
        main.post(new Runnable() {
            @Override
            public void run() {
                if (finished || currentTransformer != transformer) return;
                if (transformer.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    JSObject o = new JSObject();
                    o.put("progress", holder.progress);
                    notifyListeners("videoProgress", o);
                }
                main.postDelayed(this, 400);
            }
        });
    }

    private void finishOk(File out, int ow, int oh, long startTs, long durMs, boolean deleteInput, String input) {
        try {
            String thumb = makeThumb(out);
            if (deleteInput && isInside(new File(input.startsWith("file:") ? Uri.parse(input).getPath() : input), getContext().getCacheDir())) {
                //noinspection ResultOfMethodCallIgnored
                new File(input.startsWith("file:") ? Uri.parse(input).getPath() : input).delete();
            }
            JSObject r = new JSObject();
            r.put("path", out.getAbsolutePath());
            r.put("thumb", thumb);
            r.put("duration", durMs);
            r.put("width", ow);
            r.put("height", oh);
            r.put("size", out.length());
            r.put("startTs", startTs);
            PluginCall c = currentCall;
            clearCurrent();
            if (c != null) c.resolve(r);
        } catch (Exception e) {
            failCurrent("Erro ao finalizar o vídeo: " + e.getMessage());
        }
    }

    /** Miniatura JPEG (data URL) tirada do próprio vídeo já carimbado. */
    private String makeThumb(File video) {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(video.getAbsolutePath());
            Bitmap frame = mmr.getFrameAtTime(500000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (frame == null) frame = mmr.getFrameAtTime(0L);
            if (frame == null) return "";
            int maxW = 640;
            if (frame.getWidth() > maxW) {
                int nh = Math.round(frame.getHeight() * (maxW / (float) frame.getWidth()));
                frame = Bitmap.createScaledBitmap(frame, maxW, nh, true);
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            frame.compress(Bitmap.CompressFormat.JPEG, 82, bos);
            return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        } finally {
            releaseQuietly(mmr);
        }
    }

    @PluginMethod
    public void cancelStamp(final PluginCall call) {
        main.post(new Runnable() {
            @Override
            public void run() {
                finished = true;
                try {
                    if (currentTransformer != null) currentTransformer.cancel();
                } catch (Exception ignored) {
                }
                if (currentOut != null) {
                    //noinspection ResultOfMethodCallIgnored
                    currentOut.delete();
                }
                failCurrent("CANCELLED");
                call.resolve();
            }
        });
    }

    private void failCurrent(String msg) {
        PluginCall c = currentCall;
        clearCurrent();
        if (c != null) c.reject(msg);
    }

    private void clearCurrent() {
        currentCall = null;
        currentTransformer = null;
        currentOut = null;
    }

    // ─────────────────────────────────────────────────────────────
    // VÍDEO → galeria / compartilhar / apagar
    // ─────────────────────────────────────────────────────────────
    @PluginMethod
    public void saveVideo(final PluginCall call) {
        final String path = call.getString("path");
        final String filename = call.getString("filename");
        final String folder = call.getString("folder", "DocFoto");
        final File src = safeFile(path);
        if (src == null || filename == null || !src.exists()) {
            call.reject("Vídeo não encontrado");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            call.reject("UNSUPPORTED");
            return;
        }
        io.execute(new Runnable() {
            @Override
            public void run() {
                ContentResolver resolver = getContext().getContentResolver();
                Uri uri = null;
                try {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/" + folder);
                    values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IOException("Não foi possível criar o arquivo na galeria");

                    try (InputStream in = new FileInputStream(src); OutputStream os = resolver.openOutputStream(uri)) {
                        if (os == null) throw new IOException("Sem stream de saída");
                        byte[] buf = new byte[256 * 1024];
                        int n;
                        while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                    }
                    values.clear();
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    resolver.update(uri, values, null, null);

                    JSObject r = new JSObject();
                    r.put("uri", uri.toString());
                    call.resolve(r);
                } catch (Exception e) {
                    if (uri != null) resolver.delete(uri, null, null);
                    call.reject(e.getMessage() != null ? e.getMessage() : "Erro ao salvar o vídeo");
                }
            }
        });
    }

    @PluginMethod
    public void shareVideo(final PluginCall call) {
        final File f = safeFile(call.getString("path"));
        if (f == null || !f.exists()) {
            call.reject("Vídeo não encontrado");
            return;
        }
        try {
            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("video/mp4");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            final Intent chooser = Intent.createChooser(send, "Compartilhar vídeo");
            main.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        getActivity().startActivity(chooser);
                        call.resolve();
                    } catch (Exception e) {
                        call.reject(e.getMessage());
                    }
                }
            });
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "Erro ao compartilhar");
        }
    }

    @PluginMethod
    public void deleteFile(PluginCall call) {
        File f = safeFile(call.getString("path"));
        JSObject r = new JSObject();
        r.put("deleted", f != null && f.exists() && f.delete());
        call.resolve(r);
    }

    // ─────────────────────────────────────────────────────────────
    // Utilitários
    // ─────────────────────────────────────────────────────────────
    // MediaMetadataRetriever.release() declara IOException nas versões novas do SDK
    private static void releaseQuietly(MediaMetadataRetriever mmr) {
        try {
            mmr.release();
        } catch (Exception ignored) {
        }
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static int parseInt(String s) {
        try {
            return s == null ? 0 : Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static long parseLong(String s) {
        try {
            return s == null ? 0L : Long.parseLong(s.trim());
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    private static int even(int n) {
        int v = n & ~1;
        return v < 2 ? 2 : v;
    }

    /** Data de criação do vídeo (ex.: 20260111T143000.000Z). Ignora datas inválidas/epoch. */
    private static Long parseMetaDate(String s) {
        if (s == null || s.length() < 15) return null;
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d = f.parse(s.substring(0, 15));
            if (d == null) return null;
            long t = d.getTime();
            return t > 1104537600000L ? t : null;   // > 2005-01-01
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean isInside(File f, File dir) {
        try {
            String fp = f.getCanonicalPath();
            String dp = dir.getCanonicalPath() + File.separator;
            return fp.startsWith(dp);
        } catch (IOException e) {
            return false;
        }
    }

    /** Só aceita arquivos dentro de files/videos ou cache/videos do próprio app. */
    private File safeFile(String path) {
        if (path == null || path.isEmpty()) return null;
        File f = new File(path);
        File a = new File(getContext().getFilesDir(), VIDEOS_DIR);
        File b = new File(getContext().getCacheDir(), VIDEOS_DIR);
        return (isInside(f, a) || isInside(f, b)) ? f : null;
    }
}
