@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Instale o Node.js LTS em https://nodejs.org e rode de novo. & pause & exit /b 1)
call npm install || (pause & exit /b 1)
call npm run dist || (pause & exit /b 1)
echo.
echo Pronto! Os executaveis estao na pasta dist\
start "" dist
pause
