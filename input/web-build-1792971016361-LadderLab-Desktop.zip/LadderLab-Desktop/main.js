const { app, BrowserWindow, Menu, shell } = require('electron');
const fs = require('fs');
const path = require('path');

let win = null;
let pendingFile = null;

// Arquivo .ladlab passado na linha de comando (duplo clique no Windows)
function fileFromArgs(argv) {
  return argv.slice(1).find(a => /\.ladlab$/i.test(a) && fs.existsSync(a)) || null;
}

function deliver(file) {
  if (!win || !file) return;
  try {
    const txt = fs.readFileSync(file, 'utf8');
    win.webContents.executeJavaScript('ldImportText(' + JSON.stringify(txt) + ')').catch(() => {});
  } catch (e) {}
}

function createWindow() {
  win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#000308',
    title: 'Ladder Lab',
    icon: path.join(__dirname, 'build', 'icon.png'),
    show: false,
    webPreferences: { contextIsolation: true, nodeIntegration: false }
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, 'src', 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.webContents.on('did-finish-load', () => {
    if (pendingFile) { deliver(pendingFile); pendingFile = null; }
  });
  // Links externos abrem no navegador padrão
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file://')) { e.preventDefault(); shell.openExternal(url); }
  });
  // Esc fecha o Programador/Monitor (equivalente ao botão Voltar no Android)
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'Escape') {
      win.webContents.executeJavaScript(
        "(function(){var o=document.getElementById('workspaceOverlay');if(o&&o.classList.contains('open'))closeWorkspace()})()"
      ).catch(() => {});
    }
    if (input.type === 'keyDown' && input.key === 'F12' && input.control) win.webContents.toggleDevTools();
  });
  win.on('closed', () => { win = null; });
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', (e, argv) => {
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); deliver(fileFromArgs(argv)); }
  });
  app.whenReady().then(() => {
    pendingFile = fileFromArgs(process.argv);
    createWindow();
  });
  app.on('window-all-closed', () => app.quit());
}
