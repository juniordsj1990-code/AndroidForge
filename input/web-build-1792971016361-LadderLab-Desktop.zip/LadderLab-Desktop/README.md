# Ladder Lab — versão Desktop (Windows / Electron)

Mesmo simulador do projeto Android (`index.html` idêntico), empacotado em Electron.

## Gerar o .exe
1. Instale o Node.js LTS (https://nodejs.org).
2. Dê duplo clique em `instalar-e-gerar-exe.bat` (ou: `npm install` e `npm run dist`).
3. Saída em `dist/`:
   - `LadderLab-1.0.0-nsis.exe` — instalador (associa arquivos `.ladlab`)
   - `LadderLab-1.0.0-portable.exe` — portátil, sem instalar

Testar sem gerar: `testar.bat` (ou `npm start`).

## Notas
- O app é `src/index.html`. Para atualizar, substitua o arquivo e gere de novo.
- Salvar/Abrir `.ladlab`, impressão e armazenamento local usam os recursos de navegador já previstos no HTML (sem as pontes Android).
- Duplo clique em `.ladlab` abre direto no app (versão instalada).
- `Esc` fecha o Programador/Monitor. `Ctrl+F12` abre o DevTools.
- Ícone: `build/icon.ico` (gerado de `ic_launcher-playstore.png`).

## Sem Windows? Gerar pelo GitHub
Suba esta pasta num repositório e rode **Actions > Build Windows EXE > Run workflow**. Os .exe ficam em *Artifacts*.
Este projeto é Electron (Node), não Gradle: não serve para AndroidForge/Android Studio.
