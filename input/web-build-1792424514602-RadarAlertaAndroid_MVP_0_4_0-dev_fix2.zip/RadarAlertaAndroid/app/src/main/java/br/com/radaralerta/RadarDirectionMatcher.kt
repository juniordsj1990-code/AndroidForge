package br.com.radaralerta

import android.location.Location
import kotlin.math.abs
import kotlin.math.sin

/** Conservative GPS-only filter. It reduces cross-street/opposite-direction alerts but cannot replace road geometry. */
object RadarDirectionMatcher {
    private const val MAX_HEADING_TO_RADAR_DEG = 58f
    private const val MAX_CROSS_TRACK_METERS = 45f
    private const val MAX_EXPLICIT_DIRECTION_DIFF_DEG = 55f
    private const val LOW_SPEED_MPS = 2.2f

    fun shouldAlert(radar: Radar, location: Location, distanceMeters: Float): Boolean {
        if (location.hasAccuracy() && location.accuracy > 65f) return false

        // At very low speed the phone's bearing is unstable. Permit only a very close alert,
        // and only when no explicit direction is supplied; otherwise wait for a stable heading.
        if (!location.hasBearing() || location.speed < LOW_SPEED_MPS) {
            return distanceMeters <= 70f && normalizeDirection(radar.direction) == null
        }

        val distanceAndBearings = FloatArray(3)
        Location.distanceBetween(
            location.latitude, location.longitude,
            radar.latitude, radar.longitude,
            distanceAndBearings
        )
        val heading = normalizeAngle(location.bearing)
        val targetBearing = normalizeAngle(distanceAndBearings[1])
        val angleToRadar = angleDifference(heading, targetBearing)

        // Radar should be roughly ahead, not on a parallel or perpendicular road.
        if (angleToRadar > MAX_HEADING_TO_RADAR_DEG) return false
        val crossTrack = distanceMeters * sin(Math.toRadians(angleToRadar.toDouble())).let { abs(it) }
        if (crossTrack > MAX_CROSS_TRACK_METERS) return false

        // If the imported file declares a compass direction, compare it with vehicle heading.
        // Unknown descriptions (e.g. "sentido bairro-centro") are not guessed.
        val declared = normalizeDirection(radar.direction)
        if (declared != null && angleDifference(heading, declared) > MAX_EXPLICIT_DIRECTION_DIFF_DEG) return false
        return true
    }

    private fun normalizeDirection(raw: String?): Float? {
        val value = raw?.trim()?.lowercase()?.replace('á', 'a')?.replace('ã', 'a')
            ?.replace('é', 'e')?.replace('í', 'i')?.replace('ó', 'o')?.replace('ú', 'u')
            ?.replace("º", "")?.replace("°", "") ?: return null
        return when {
            value in listOf("n", "norte", "north") || value.contains("sentido norte") -> 0f
            value in listOf("ne", "nordeste", "northeast") -> 45f
            value in listOf("l", "e", "leste", "este", "east") -> 90f
            value in listOf("se", "sudeste", "southeast") -> 135f
            value in listOf("s", "sul", "south") || value.contains("sentido sul") -> 180f
            value in listOf("so", "sudoeste", "southwest") -> 225f
            value in listOf("o", "w", "oeste", "west") -> 270f
            value in listOf("no", "noroeste", "northwest") -> 315f
            else -> null
        }
    }

    private fun normalizeAngle(value: Float): Float = ((value % 360f) + 360f) % 360f
    private fun angleDifference(a: Float, b: Float): Float {
        val diff = abs(normalizeAngle(a) - normalizeAngle(b))
        return minOf(diff, 360f - diff)
    }
}
