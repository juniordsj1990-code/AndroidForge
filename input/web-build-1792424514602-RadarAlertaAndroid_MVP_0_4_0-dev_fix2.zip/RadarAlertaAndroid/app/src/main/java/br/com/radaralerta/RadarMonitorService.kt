package br.com.radaralerta

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class RadarMonitorService : Service(), LocationListener, TextToSpeech.OnInitListener {
    private lateinit var locationManager: LocationManager
    private var tts: TextToSpeech? = null
    private var overlay: TextView? = null
    private var lastAlertAt = mutableMapOf<String, Long>()
    private var ttsReady = false
    private val channelId = "radar_monitor"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(42, notification("Monitoramento ativo • aguardando GPS"))
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return START_NOT_STICKY
        }
        try { locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500L, 5f, this) }
        catch (_: Exception) { updateNotification("GPS indisponível. Verifique as permissões e o sinal.") }
        return START_STICKY
    }

    override fun onLocationChanged(location: Location) {
        val radars = RadarStore.all(this)
        if (radars.isEmpty()) { updateNotification("Monitoramento ativo • base sem radares"); return }
        val distanceLimit = listOf(100, 200, 300, 500, 800, 1000).getOrElse(getSharedPreferences("radar_alerta", MODE_PRIVATE).getInt("distance", 2)) { 300 }
        var nearest: Pair<Radar, Float>? = null
        radars.forEach { radar ->
            val result = FloatArray(1)
            Location.distanceBetween(location.latitude, location.longitude, radar.latitude, radar.longitude, result)
            if (nearest == null || result[0] < nearest!!.second) nearest = radar to result[0]
            if (result[0] <= distanceLimit && RadarDirectionMatcher.shouldAlert(radar, location, result[0])) {
                maybeAlert(radar, result[0], location)
            }
        }
        nearest?.let { (radar, distance) -> updateNotification("Radar mais próximo: ${distance.toInt()} m • ${radar.speedLimit?.let { "$it km/h" } ?: radar.type}") }
    }

    private fun maybeAlert(radar: Radar, distance: Float, location: Location) {
        // Avoid using low-quality fixes to trigger warnings; the foreground service keeps running.
        if (location.hasAccuracy() && location.accuracy > 65f) return
        val key = "${radar.latitude},${radar.longitude}"
        val now = System.currentTimeMillis()
        if (now - (lastAlertAt[key] ?: 0L) < 45000L) return
        // A direction is only used when the file provides it; automatic road-direction inference is not implemented yet.
        lastAlertAt[key] = now
        val prefs = getSharedPreferences("radar_alerta", MODE_PRIVATE)
        val message = "Atenção, ${radar.type}. ${radar.speedLimit?.let { "Limite de $it quilômetros por hora. " } ?: ""}Aproximadamente ${distance.toInt()} metros."
        if (prefs.getBoolean("voice", true) && ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "radar_$now")
        if (prefs.getBoolean("vibrate", false)) {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(android.os.VibrationEffect.createOneShot(250, android.os.VibrationEffect.DEFAULT_AMPLITUDE)) else vibrator.vibrate(250)
        }
        if (prefs.getBoolean("sound", true)) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.notify((key.hashCode() and 0x7fffffff), NotificationCompat.Builder(this, channelId).setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("Radar próximo").setContentText(message).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build())
        }
        if (prefs.getBoolean("overlay", true) && Settings.canDrawOverlays(this)) showOverlay("RADAR • ${distance.toInt()} m\n${radar.speedLimit?.let { "$it km/h" } ?: radar.type}")
    }

    private fun showOverlay(text: String) {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            if (overlay == null) {
                overlay = TextView(this).apply { setPadding(28, 18, 28, 18); textSize = 18f; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xEEB3261E.toInt()); gravity = Gravity.CENTER; elevation = 12f; setOnClickListener { try { wm.removeView(this); this@RadarMonitorService.overlay = null } catch (_: Exception) {} } }
                val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
                val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
                params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; params.y = 100
                wm.addView(overlay, params)
            }
            overlay?.text = "$text\nToque para fechar"
        } catch (_: Exception) { }
    }

    private fun notification(content: String) = NotificationCompat.Builder(this, channelId).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Radar Alerta").setContentText(content).setOngoing(true).setPriority(NotificationCompat.PRIORITY_LOW).build()
    private fun updateNotification(text: String) { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(42, notification(text)) }
    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) { val channel = NotificationChannel(channelId, "Monitoramento de radares", NotificationManager.IMPORTANCE_HIGH).apply { description = "Serviço e alertas de radares próximos" }; (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel) } }
    override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS; if (ttsReady) tts?.language = Locale("pt", "BR") }
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) { updateNotification("GPS desligado") }
    @Deprecated("Deprecated by Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { try { locationManager.removeUpdates(this) } catch (_: Exception) {}; try { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Exception) {}; tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
