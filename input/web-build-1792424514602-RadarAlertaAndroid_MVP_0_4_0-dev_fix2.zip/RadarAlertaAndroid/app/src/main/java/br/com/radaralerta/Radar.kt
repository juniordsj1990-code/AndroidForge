package br.com.radaralerta

data class Radar(
    val latitude: Double,
    val longitude: Double,
    val type: String = "Radar fixo",
    val speedLimit: Int? = null,
    val direction: String? = null,
    val source: String = "Importado"
)
