package br.com.radaralerta

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("radar_alerta", MODE_PRIVATE) }
    private val importPicker = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderHome()
        requestBasicPermissions()
    }

    private fun base(title: String): LinearLayout {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 28); setBackgroundColor(0xFFF4F6F8.toInt()) }
        scroll.addView(root)
        setContentView(scroll)
        root.addView(TextView(this).apply { text = title; textSize = 27f; setTextColor(0xFF132238.toInt()); setPadding(0,0,0,18); setTypeface(null, 1) })
        return root
    }

    private fun cardTitle(text: String) = TextView(this).apply { this.text = text; textSize = 18f; setTextColor(0xFF132238.toInt()); setTypeface(null, 1); setPadding(0, 14, 0, 8) }
    private fun label(text: String) = TextView(this).apply { this.text = text; textSize = 15f; setTextColor(0xFF354052.toInt()); setPadding(0, 5, 0, 8) }
    private fun action(text: String, click: () -> Unit) = Button(this).apply { this.text = text; isAllCaps = false; setOnClickListener { click() }; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 } }
    private fun renderHome() {
        base("Radar Alerta")
        root.addView(label("Alertas independentes do Google Maps, Waze ou outro navegador."))
        root.addView(cardTitle("Monitoramento"))
        val count = RadarStore.all(this).size
        root.addView(label("Radares na base: $count\nÚltima atualização: ${RadarStore.updatedAt(this)}"))
        root.addView(action("▶  Iniciar monitoramento") { startMonitoring() })
        root.addView(action("■  Parar monitoramento") { stopService(Intent(this, RadarMonitorService::class.java)); toast("Monitoramento solicitado para parar") })
        root.addView(action("⚙  Configurações de alertas") { renderSettings() })
        root.addView(action("🗂  Gerenciar / importar radares") { renderDatabase() })
        root.addView(action("⌖  Radares próximos (lista local)") { renderNearby() })
        root.addView(action("Permissões e diagnóstico") { renderDiagnostics() })
        root.addView(label("Aviso: base vazia ou incompleta não gera alertas confiáveis. Importe dados verificados antes de usar na via."))
    }

    private fun renderSettings() {
        base("Configurações")
        root.addView(label("Personalize o comportamento dos alertas."))
        addSwitch("Aviso por voz", "voice", true)
        addSwitch("Notificação sonora", "sound", true)
        addSwitch("Vibração", "vibrate", false)
        addSwitch("Janela flutuante", "overlay", true)
        addSwitch("Avisar somente no sentido informado (quando disponível)", "direction", false)
        root.addView(cardTitle("Distância de aviso"))
        val spinner = Spinner(this)
        val options = listOf("100 m", "200 m", "300 m", "500 m", "800 m", "1.000 m")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        spinner.setSelection(prefs.getInt("distance", 2).coerceIn(0, options.lastIndex))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { prefs.edit().putInt("distance", position).apply() }
        }
        root.addView(spinner)
        root.addView(cardTitle("Aviso de velocidade"))
        val speed = EditText(this).apply { hint = "Limite adicional (km/h), opcional"; inputType = 2; setText(prefs.getInt("speed_extra", 0).takeIf { it > 0 }?.toString() ?: "") }
        root.addView(speed)
        root.addView(action("Salvar configurações") { prefs.edit().putInt("speed_extra", speed.text.toString().toIntOrNull() ?: 0).apply(); toast("Configurações salvas") })
        root.addView(action("Voltar") { renderHome() })
    }

    private fun addSwitch(text: String, key: String, default: Boolean) {
        root.addView(Switch(this).apply { this.text = text; isChecked = prefs.getBoolean(key, default); setTextColor(0xFF354052.toInt()); setPadding(0, 6, 0, 6); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply(); if (key == "overlay" && checked && !Settings.canDrawOverlays(this@MainActivity)) requestOverlayPermission() } })
    }

    private fun renderDatabase() {
        base("Base de radares")
        val list = RadarStore.all(this)
        root.addView(label("Registros cadastrados: ${list.size}\nÚltima atualização: ${RadarStore.updatedAt(this)}"))
        root.addView(action("Importar arquivo Excel, CSV ou JSON") { openImportPicker() })
        root.addView(action("＋ Adicionar radar manualmente") { showRadarEditor(null, null) })
        root.addView(action("Exportar base JSON") { exportJson() })
        root.addView(action("Histórico de importações") { renderImportHistory() })
        root.addView(action("Apagar toda a base") { AlertDialog.Builder(this).setTitle("Apagar radares?").setMessage("Essa ação remove os dados locais e não pode ser desfeita.").setNegativeButton("Cancelar", null).setPositiveButton("Apagar") { _, _ -> RadarStore.save(this, emptyList()); renderDatabase() }.show() })
        root.addView(cardTitle("Radares cadastrados"))
        if (list.isEmpty()) root.addView(label("Nenhum radar cadastrado. Importe uma base ou adicione um radar manualmente."))
        list.take(300).forEachIndexed { index, radar ->
            val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 10, 14, 10); setBackgroundColor(0xFFFFFFFF.toInt()) }
            panel.addView(TextView(this).apply { text = "${index + 1}. ${radar.type}"; textSize = 16f; setTextColor(0xFF132238.toInt()); setTypeface(null, 1) })
            panel.addView(label("${radar.latitude}, ${radar.longitude}\nLimite: ${radar.speedLimit?.let { "$it km/h" } ?: "não informado"} • Sentido: ${radar.direction ?: "não informado"}\nOrigem: ${radar.source}"))
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.addView(Button(this).apply { text = "Editar"; isAllCaps = false; setOnClickListener { showRadarEditor(radar, index) } }, LinearLayout.LayoutParams(0, -2, 1f))
            buttons.addView(Button(this).apply { text = "Excluir"; isAllCaps = false; setOnClickListener { AlertDialog.Builder(this@MainActivity).setTitle("Excluir radar?").setMessage("${radar.latitude}, ${radar.longitude}").setNegativeButton("Cancelar", null).setPositiveButton("Excluir") { _, _ -> RadarStore.delete(this@MainActivity, index); renderDatabase() }.show() } }, LinearLayout.LayoutParams(0, -2, 1f))
            panel.addView(buttons)
            root.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
        if (list.size > 300) root.addView(label("Exibindo os primeiros 300 registros. A base completa continua armazenada."))
        root.addView(cardTitle("Formatos aceitos"))
        root.addView(label("Excel (.xlsx): primeira aba com cabeçalhos latitude/longitude (ou lat/lon), opcionalmente tipo, velocidade, direção e origem.\nCSV: latitude/longitude (ou lat/lon), tipo, velocidade e direção; separador vírgula ou ponto e vírgula.\nJSON: lista de objetos com latitude/longitude (ou lat/lon), type/tipo, speedLimit/velocidade e direction/direcao. O formato antigo .xls deve ser salvo como .xlsx ou CSV."))
        root.addView(action("Voltar") { renderHome() })
    }

    private fun showRadarEditor(radar: Radar?, editIndex: Int?) {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        fun field(hintText: String, value: String = "", type: Int = android.text.InputType.TYPE_CLASS_TEXT): EditText {
            val edit = EditText(this).apply { hint = hintText; setText(value); inputType = type }
            form.addView(edit)
            return edit
        }
        val lat = field("Latitude (ex.: -23.5505)", radar?.latitude?.toString() ?: "", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED)
        val lon = field("Longitude (ex.: -46.6333)", radar?.longitude?.toString() ?: "", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED)
        val type = field("Tipo do radar", radar?.type ?: "Radar fixo")
        val speed = field("Limite km/h (opcional)", radar?.speedLimit?.toString() ?: "", android.text.InputType.TYPE_CLASS_NUMBER)
        val direction = field("Sentido (opcional)", radar?.direction ?: "")
        val source = field("Origem dos dados", radar?.source ?: "Cadastro manual")
        AlertDialog.Builder(this).setTitle(if (radar == null) "Adicionar radar" else "Editar radar").setView(form)
            .setNegativeButton("Cancelar", null).setPositiveButton("Salvar", null).create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val latitude = lat.text.toString().trim().replace(',', '.').toDoubleOrNull()
                        val longitude = lon.text.toString().trim().replace(',', '.').toDoubleOrNull()
                        if (latitude == null || longitude == null || latitude !in -90.0..90.0 || longitude !in -180.0..180.0) { toast("Informe latitude e longitude válidas"); return@setOnClickListener }
                        val speedValue = speed.text.toString().toIntOrNull()
                        if (speed.text.isNotBlank() && (speedValue == null || speedValue !in 1..250)) { toast("O limite deve ser entre 1 e 250 km/h"); return@setOnClickListener }
                        if (type.text.toString().isBlank()) { toast("Informe o tipo do radar"); return@setOnClickListener }
                        RadarStore.upsert(this, Radar(latitude, longitude, type.text.toString().trim(), speedValue, direction.text.toString().trim().ifBlank { null }, source.text.toString().trim().ifBlank { "Cadastro manual" }), editIndex)
                        dialog.dismiss(); renderDatabase()
                    }
                }
                dialog.show()
            }
    }

    private fun renderImportHistory() {
        base("Histórico de importações")
        val history = RadarStore.importHistory(this)
        if (history.isEmpty()) root.addView(label("Ainda não há importações registradas."))
        history.forEachIndexed { index, entry -> root.addView(label("${index + 1}. $entry")) }
        root.addView(action("Voltar à base de radares") { renderDatabase() })
    }

    private fun openImportPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel", "text/csv", "text/comma-separated-values", "application/json", "text/plain", "application/octet-stream")) }
        startActivityForResult(intent, importPicker)
    }

    @Deprecated("Legacy activity result API used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7002 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val contents = prefs.getString("pending_export", "[]") ?: "[]"
                contentResolver.openOutputStream(uri)?.use { it.write(contents.toByteArray(Charsets.UTF_8)) }
                toast("Base exportada")
            } catch (e: Exception) { toast("Falha ao exportar: ${e.message}") }
        }
        if (requestCode == importPicker && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val name = queryName(uri) ?: "radares.xlsx"
                val preview = contentResolver.openInputStream(uri)?.use { RadarStore.preview(it, name) } ?: throw IllegalStateException("Não foi possível abrir o arquivo")
                AlertDialog.Builder(this).setTitle("Prévia da importação").setMessage("Arquivo: $name\nRegistros válidos: ${preview.radars.size}\nRegistros inválidos estimados: ${preview.invalid}\n\nEscolha como aplicar os dados. A mesclagem preserva radares existentes; a substituição troca a base atual.")
                    .setNegativeButton("Cancelar", null)
                    .setNeutralButton("Substituir base") { _, _ -> confirmImport(preview, true) }
                    .setPositiveButton("Mesclar base") { _, _ -> confirmImport(preview, false) }.show()
            } catch (e: Exception) { AlertDialog.Builder(this).setTitle("Falha na importação").setMessage(e.message ?: "Arquivo inválido").setPositiveButton("OK", null).show() }
        }
    }

    private fun confirmImport(preview: ImportPreview, replace: Boolean) {
        try {
            val result = RadarStore.commitImport(this, preview, replace)
            AlertDialog.Builder(this).setTitle("Importação concluída").setMessage("Modo: ${if (replace) "substituição" else "mesclagem"}\nRegistros lidos: ${result.read}\nNovos radares: ${result.added}\nDuplicados ignorados: ${result.duplicates}\nRegistros inválidos: ${result.invalid}")
                .setPositiveButton("OK") { _, _ -> renderDatabase() }.show()
        } catch (e: Exception) { toast("Falha ao salvar a importação: ${e.message}") }
    }

    private fun queryName(uri: Uri): String? = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    private fun exportJson() {
        val arr = org.json.JSONArray()
        RadarStore.all(this).forEach { r -> arr.put(org.json.JSONObject().put("latitude", r.latitude).put("longitude", r.longitude).put("type", r.type).put("speedLimit", r.speedLimit ?: org.json.JSONObject.NULL).put("direction", r.direction ?: "").put("source", r.source)) }
        val filename = "radares-export.json"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, filename) }
        // Persist export text for the result callback.
        prefs.edit().putString("pending_export", arr.toString(2)).apply()
        startActivityForResult(intent, 7002)
    }

    private fun renderNearby() {
        base("Radares cadastrados")
        val list = RadarStore.all(this)
        if (list.isEmpty()) root.addView(label("A base está vazia. Importe um arquivo na seção Gerenciar radares."))
        list.take(100).forEachIndexed { i, r -> root.addView(label("${i+1}. ${r.type}\n${r.latitude}, ${r.longitude}\nLimite: ${r.speedLimit?.let { "$it km/h" } ?: "não informado"} • ${r.direction ?: "sentido não informado"}")) }
        root.addView(action("Voltar") { renderHome() })
    }

    private fun renderDiagnostics() {
        base("Permissões e diagnóstico")
        root.addView(label("Localização: ${if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) "concedida" else "não concedida"}\nSobreposição: ${if (Settings.canDrawOverlays(this)) "concedida" else "não concedida"}\nRadares locais: ${RadarStore.all(this).size}"))
        root.addView(action("Conceder permissão de janela flutuante") { requestOverlayPermission() })
        root.addView(action("Abrir configurações do aplicativo") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) })
        root.addView(action("Voltar") { renderHome() })
    }

    private fun startMonitoring() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 12); return
        }
        if (prefs.getBoolean("overlay", true) && !Settings.canDrawOverlays(this)) requestOverlayPermission()
        val intent = Intent(this, RadarMonitorService::class.java)
        ContextCompat.startForegroundService(this, intent)
        toast("Monitoramento iniciado. Confira a notificação permanente.")
    }

    private fun requestOverlayPermission() { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
    private fun requestBasicPermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 11)
    }
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
}
