package br.com.radaralerta

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipInputStream
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

object RadarStore {
    private const val PREFS = "radar_alerta"
    private const val KEY_DATA = "radars_json"
    private const val KEY_UPDATED = "updated_at"

    fun all(context: Context): List<Radar> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_DATA, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).mapNotNull { i ->
            runCatching {
                val o = arr.getJSONObject(i)
                Radar(o.getDouble("latitude"), o.getDouble("longitude"), o.optString("type", "Radar fixo"),
                    if (o.isNull("speedLimit")) null else o.optInt("speedLimit"), o.optString("direction").takeIf { it.isNotBlank() }, o.optString("source", "Importado"))
            }.getOrNull()
        }
    }

    fun save(context: Context, radars: List<Radar>) {
        val arr = JSONArray()
        radars.forEach { r -> arr.put(JSONObject().put("latitude", r.latitude).put("longitude", r.longitude).put("type", r.type)
            .put("speedLimit", r.speedLimit ?: JSONObject.NULL).put("direction", r.direction ?: "").put("source", r.source)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_DATA, arr.toString())
            .putString(KEY_UPDATED, SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())).apply()
    }

    fun updatedAt(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_UPDATED, "Nunca") ?: "Nunca"

    fun preview(input: java.io.InputStream, filename: String): ImportPreview {
        val lower = filename.lowercase(Locale.ROOT)
        if (lower.endsWith(".xlsx")) {
            val rows = parseXlsx(input)
            if (rows.isEmpty()) throw IllegalArgumentException("A planilha Excel está vazia ou não contém uma primeira aba legível.")
            val parsed = parseTabularRows(rows)
            val dataRows = (rows.size - 1).coerceAtLeast(0)
            return ImportPreview(dataRows, parsed, (dataRows - parsed.size).coerceAtLeast(0))
        }
        if (lower.endsWith(".xls")) throw IllegalArgumentException("O formato Excel antigo .xls não é suportado. Abra a planilha no Excel e salve como Pasta de Trabalho do Excel (*.xlsx), ou exporte como CSV.")
        val text = BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { it.readText() }.removePrefix("\uFEFF")
        val linesRead = text.lines().count { it.isNotBlank() }.let { if (lower.endsWith(".json")) JSONArray(text).length() else (it - 1).coerceAtLeast(0) }
        val parsed = if (lower.endsWith(".json")) parseJson(text) else parseCsv(text)
        return ImportPreview(linesRead, parsed, (linesRead - parsed.size).coerceAtLeast(0))
    }

    /** Reads the first worksheet of a standard .xlsx file without requiring network access. */
    private fun parseXlsx(input: java.io.InputStream): List<List<String>> {
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && (entry.name == "xl/sharedStrings.xml" || entry.name == "xl/worksheets/sheet1.xml")) {
                    entries[entry.name] = zip.readBytes()
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        val sheet = entries["xl/worksheets/sheet1.xml"] ?: throw IllegalArgumentException("Não encontrei a primeira planilha dentro do arquivo .xlsx.")
        val shared = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val parser = newXmlParser(sheet)
        val rows = mutableListOf<List<String>>()
        var row: MutableMap<Int, String>? = null
        var cellRef = ""
        var cellType = ""
        var cellValue = ""
        var inCell = false
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            when (parser.eventType) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> row = sortedMapOf<Int, String>()
                    "c" -> { inCell = true; cellRef = parser.getAttributeValue(null, "r") ?: "A1"; cellType = parser.getAttributeValue(null, "t") ?: ""; cellValue = "" }
                    "v", "t" -> if (inCell) cellValue += parser.nextText()
                }
                XmlPullParser.END_TAG -> when (parser.name) {
                    "c" -> {
                        val idx = columnIndex(cellRef)
                        val value = if (cellType == "s") shared.getOrNull(cellValue.toIntOrNull() ?: -1) ?: "" else cellValue
                        row?.put(idx, value)
                        inCell = false
                    }
                    "row" -> {
                        val current = row
                        if (current != null) {
                            val max = current.keys.maxOrNull() ?: -1
                            rows.add((0..max).map { current[it] ?: "" })
                        }
                        row = null
                    }
                }
            }
            parser.next()
        }
        return rows.filter { it.any(String::isNotBlank) }
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val parser = newXmlParser(bytes)
        val result = mutableListOf<String>()
        var current = StringBuilder()
        var inString = false
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            when (parser.eventType) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "si" -> { current = StringBuilder(); inString = true }
                    "t" -> if (inString) current.append(parser.nextText())
                }
                XmlPullParser.END_TAG -> if (parser.name == "si") { result.add(current.toString()); inString = false }
            }
            parser.next()
        }
        return result
    }

    private fun newXmlParser(bytes: ByteArray): XmlPullParser = XmlPullParserFactory.newInstance().newPullParser().apply {
        setInput(bytes.inputStream(), "UTF-8")
    }

    private fun columnIndex(ref: String): Int {
        var value = 0
        for (ch in ref.takeWhile { it.isLetter() }.uppercase(Locale.ROOT)) value = value * 26 + (ch - 'A' + 1)
        return (value - 1).coerceAtLeast(0)
    }

    private fun parseTabularRows(rows: List<List<String>>): List<Radar> {
        val headers = rows.first().map { normalize(it) }
        val latIndex = headers.indexOfFirst { it in listOf("latitude", "lat", "y") }
        val lonIndex = headers.indexOfFirst { it in listOf("longitude", "lon", "lng", "long", "x") }
        if (latIndex < 0 || lonIndex < 0) throw IllegalArgumentException("Não encontrei colunas de latitude e longitude na planilha Excel.")
        val typeIndex = headers.indexOfFirst { it in listOf("tipo", "type", "equipamento") }
        val speedIndex = headers.indexOfFirst { it in listOf("velocidade", "speed", "limite", "speedlimit") }
        val dirIndex = headers.indexOfFirst { it in listOf("direcao", "direction", "sentido") }
        val sourceIndex = headers.indexOfFirst { it in listOf("origem", "source", "fonte") }
        return rows.drop(1).mapNotNull { cols ->
            val lat = cols.getOrNull(latIndex)?.trim()?.replace(',', '.')?.toDoubleOrNull() ?: return@mapNotNull null
            val lon = cols.getOrNull(lonIndex)?.trim()?.replace(',', '.')?.toDoubleOrNull() ?: return@mapNotNull null
            val speedText = cols.getOrNull(speedIndex)?.trim()?.replace(Regex("\\.0+$"), "")
            makeRadar(lat, lon, cols.getOrNull(typeIndex) ?: "Radar fixo", speedText?.toDoubleOrNull()?.toInt() ?: -1, cols.getOrNull(dirIndex) ?: "", cols.getOrNull(sourceIndex) ?: "Importado")
        }
    }

    fun commitImport(context: Context, preview: ImportPreview, replace: Boolean): ImportResult {
        require(preview.radars.isNotEmpty()) { "O arquivo não contém radares válidos; a base não foi alterada." }
        val existing = if (replace) mutableListOf() else all(context).toMutableList()
        var added = 0
        var duplicates = 0
        preview.radars.forEach { r ->
            if (existing.any { distanceMeters(it, r) < 25.0 }) duplicates++
            else { existing.add(r); added++ }
        }
        save(context, existing)
        val history = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val oldHistory = JSONArray(history.getString("import_history", "[]") ?: "[]")
        oldHistory.put(0, JSONObject().put("date", updatedAt(context)).put("mode", if (replace) "Substituição" else "Mesclagem")
            .put("read", preview.read).put("added", added).put("duplicates", duplicates).put("invalid", preview.invalid))
        while (oldHistory.length() > 10) oldHistory.remove(oldHistory.length() - 1)
        history.edit().putString("import_history", oldHistory.toString()).apply()
        return ImportResult(preview.read, added, duplicates, preview.invalid)
    }

    fun importHistory(context: Context): List<String> {
        val arr = JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("import_history", "[]") ?: "[]")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            "${o.optString("date")} • ${o.optString("mode")}\nLidas: ${o.optInt("read")} | adicionadas: ${o.optInt("added")} | duplicadas: ${o.optInt("duplicates")} | inválidas: ${o.optInt("invalid")}"
        }
    }

    fun upsert(context: Context, radar: Radar, editIndex: Int? = null) {
        val list = all(context).toMutableList()
        if (editIndex != null && editIndex in list.indices) list[editIndex] = radar else list.add(radar)
        save(context, list)
    }

    fun delete(context: Context, index: Int) {
        val list = all(context).toMutableList()
        if (index in list.indices) { list.removeAt(index); save(context, list) }
    }

    private fun parseJson(text: String): List<Radar> {
        val arr = JSONArray(text)
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val lat = o.optDouble("latitude", o.optDouble("lat", Double.NaN))
            val lon = o.optDouble("longitude", o.optDouble("lon", o.optDouble("lng", Double.NaN)))
            makeRadar(lat, lon, o.optString("type", o.optString("tipo", "Radar fixo")), o.optInt("speedLimit", o.optInt("velocidade", -1)), o.optString("direction", o.optString("direcao", "")), o.optString("source", "Importado"))
        }
    }

    private fun parseCsv(text: String): List<Radar> {
        val lines = text.lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        val delimiter = if (lines.first().count { it == ';' } > lines.first().count { it == ',' }) ';' else ','
        val headers = lines.first().split(delimiter).map { normalize(it) }
        val latIndex = headers.indexOfFirst { it in listOf("latitude", "lat", "y") }
        val lonIndex = headers.indexOfFirst { it in listOf("longitude", "lon", "lng", "long", "x") }
        if (latIndex < 0 || lonIndex < 0) throw IllegalArgumentException("Não encontrei colunas de latitude e longitude no CSV.")
        return lines.drop(1).mapNotNull { line ->
            val cols = line.split(delimiter).map { it.trim().trim('"') }
            val lat = cols.getOrNull(latIndex)?.replace(',', '.')?.toDoubleOrNull() ?: return@mapNotNull null
            val lon = cols.getOrNull(lonIndex)?.replace(',', '.')?.toDoubleOrNull() ?: return@mapNotNull null
            val typeIndex = headers.indexOfFirst { it in listOf("tipo", "type", "equipamento") }
            val speedIndex = headers.indexOfFirst { it in listOf("velocidade", "speed", "limite", "speedlimit") }
            val dirIndex = headers.indexOfFirst { it in listOf("direcao", "direction", "sentido") }
            val sourceIndex = headers.indexOfFirst { it in listOf("origem", "source", "fonte") }
            makeRadar(lat, lon, cols.getOrNull(typeIndex) ?: "Radar fixo", cols.getOrNull(speedIndex)?.toIntOrNull() ?: -1, cols.getOrNull(dirIndex) ?: "", cols.getOrNull(sourceIndex) ?: "Importado")
        }
    }

    private fun makeRadar(lat: Double, lon: Double, type: String, speed: Int, direction: String, source: String = "Importado"): Radar? {
        if (!lat.isFinite() || !lon.isFinite() || lat !in -90.0..90.0 || lon !in -180.0..180.0) return null
        return Radar(lat, lon, type.ifBlank { "Radar fixo" }, speed.takeIf { it > 0 }, direction.takeIf { it.isNotBlank() }, source.ifBlank { "Importado" })
    }
    private fun normalize(s: String) = java.text.Normalizer.normalize(s.lowercase().trim().replace("\"", ""), java.text.Normalizer.Form.NFD).replace("\\p{Mn}+".toRegex(), "")
    private fun distanceMeters(a: Radar, b: Radar): Double {
        val r = 6371000.0; val dLat = Math.toRadians(b.latitude-a.latitude); val dLon = Math.toRadians(b.longitude-a.longitude)
        val x = kotlin.math.sin(dLat/2).let { it*it } + kotlin.math.cos(Math.toRadians(a.latitude))*kotlin.math.cos(Math.toRadians(b.latitude))*kotlin.math.sin(dLon/2).let { it*it }
        return 2*r*kotlin.math.asin(kotlin.math.sqrt(x.coerceIn(0.0, 1.0)))
    }
}
data class ImportPreview(val read: Int, val radars: List<Radar>, val invalid: Int)
data class ImportResult(val read: Int, val added: Int, val duplicates: Int, val invalid: Int)
