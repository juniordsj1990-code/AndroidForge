package br.com.alertageografico

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

/**
 * Monitora a posição e dispara alertas.
 *  - A decisão de alertar fica em [ProximityEngine] (testável).
 *  - O intervalo do GPS é definido pelo usuário e pode ser alterado durante o monitoramento.
 *  - O estado "ativo" é gravado em [DestinationStore] e o serviço é reiniciado pelo sistema (START_STICKY)
 *    caso seja encerrado para liberar memória.
 */
private fun formatEtaDuration(totalMinutes: Int): String {
    if (totalMinutes < 60) return "$totalMinutes min"
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return if (minutes == 0) "$hours h" else "$hours h $minutes min"
}

class LocationMonitorService : Service() {
    private lateinit var client: FusedLocationProviderClient
    private lateinit var callback: LocationCallback
    private val engine = ProximityEngine()
    private val etaEstimator = OfflineEtaEstimator()
    private var etaTargetId: String? = null
    // Trechos entre paradas do roteiro (distância pelos trilhos quando possível). Cada atualização
    // calcula no máximo um trecho novo por trilhos; os demais usam linha reta até estarem em cache.
    private val legCache = HashMap<String, Double>()
    private var legBudget = 0
    private fun legDistance(a: Destination, b: Destination): Double {
        val key = "${a.id}:${a.latitude},${a.longitude}>${b.id}:${b.latitude},${b.longitude}"
        legCache[key]?.let { return it }
        val straight = ProximityEngine.distanceMeters(a.latitude, a.longitude, b.latitude, b.longitude)
        if (legBudget <= 0) return straight
        legBudget--
        val rail = StationNavigationStore.distanceAlongRailMeters(this, a.latitude, a.longitude, b.latitude, b.longitude)?.toDouble()
        val value = rail?.takeIf { it <= straight * 2.5 + 2000.0 } ?: straight
        legCache[key] = value
        return value
    }
    private var destinations: List<Destination> = emptyList()
    private var updating = false
    private var currentRequestIntervalMs = -1L
    private var currentRequestPriority = -1
    private var lastLocationForPolicy: android.location.Location? = null
    private var stationaryUpdates = 0
    // Confirma o salto para uma parada posterior apenas após leituras GPS consecutivas coerentes.
    private var laterStopCandidateIndex: Int? = null
    private var laterStopCandidateReadings = 0
    private var laterStopCandidateFirstDistance: Double? = null
    private var laterStopCandidateLastDistance: Double? = null

    // Percurso concluído: o GPS é desligado na hora e o serviço se encerra poucos segundos depois.
    private var journeyFinished = false
    private var finishStartedAt = 0L
    private var foregroundRemoved = false
    private val finishHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val finishCheck = object : Runnable {
        override fun run() {
            val elapsed = System.currentTimeMillis() - finishStartedAt
            if (elapsed >= FINISH_FOREGROUND_MS && !foregroundRemoved) {
                foregroundRemoved = true
                stopForeground(STOP_FOREGROUND_REMOVE)
            }
            // Só espera mais enquanto o áudio final ainda toca (no máximo FINISH_AUDIO_MAX_MS).
            if (elapsed >= FINISH_FOREGROUND_MS && (!RoutedAlertSound.isBusy() || elapsed >= FINISH_AUDIO_MAX_MS)) {
                stopSelf()
            } else {
                finishHandler.postDelayed(this, 500L)
            }
        }
    }

    private val monitorChannelId = "geo_monitor"
    private val alertChannelId = "geo_alerts_routed"

    // Mantém referência forte: o SharedPreferences guarda o listener em WeakReference.
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            DestinationStore.KEY -> destinations = DestinationStore.load(this)
            DestinationStore.KEY_LOCATION_INTERVAL_SECONDS, DestinationStore.KEY_BATTERY_PROFILE -> {
                if (updating) {
                    try {
                        reconfigureLocationUpdates()
                    } catch (_: SecurityException) {
                        stopSelf()
                    }
                }
            }
        }
    }

    private fun dismissPendingIntent(notificationId: Int): PendingIntent {
        val intent = Intent(this, AlertDismissReceiver::class.java).putExtra("notification_id", notificationId)
        return PendingIntent.getBroadcast(
            this, notificationId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
        client = LocationServices.getFusedLocationProviderClient(this)
        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                if (journeyFinished || result.locations.isEmpty()) return
                onLocations(result.locations)
            }
        }
        try {
            startForeground(1001, buildStatusNotification())
        } catch (e: Exception) {
            // Ex.: início em segundo plano não permitido após reinício pelo sistema.
            Log.w(TAG, "Não foi possível entrar em primeiro plano", e)
            DestinationStore.setMonitoringActive(this, false)
            stopSelf()
            return
        }
        destinations = DestinationStore.load(this)
        getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
            .registerOnSharedPreferenceChangeListener(prefsListener)
        DestinationStore.setMonitoringActive(this, true)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (journeyFinished) {
            // Novo início enquanto o serviço ainda encerrava o percurso anterior: recomeça do zero.
            finishHandler.removeCallbacks(finishCheck)
            journeyFinished = false
            foregroundRemoved = false
            engine.reset()
            try {
                startForeground(1001, buildStatusNotification())
            } catch (e: Exception) {
                Log.w(TAG, "Não foi possível voltar ao primeiro plano", e)
                stopSelf()
                return START_NOT_STICKY
            }
            DestinationStore.setMonitoringActive(this, true)
        }
        if (!updating) {
            try {
                reconfigureLocationUpdates(force = true)
            } catch (_: SecurityException) {
                DestinationStore.setMonitoringActive(this, false)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun requestUpdates(intervalMs: Long, highAccuracy: Boolean, force: Boolean = false) {
        val priority = if (highAccuracy) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        if (!force && updating && currentRequestIntervalMs == intervalMs && currentRequestPriority == priority) return
        if (updating) client.removeLocationUpdates(callback)
        val request = LocationRequest.Builder(priority, intervalMs)
            .setMinUpdateIntervalMillis(intervalMs)
            .setWaitForAccurateLocation(false)
            .build()
        client.requestLocationUpdates(request, callback, mainLooper)
        currentRequestIntervalMs = intervalMs
        currentRequestPriority = priority
        updating = true
    }

    /** Escolhe a frequência e a precisão conforme o perfil, movimento e proximidade do destino. */
    private fun reconfigureLocationUpdates(force: Boolean = false) {
        val configuredMs = DestinationStore.locationIntervalSeconds(this) * 1_000L
        val profile = DestinationStore.batteryProfile(this)
        val location = lastLocationForPolicy
        val activeTargets = when (DestinationStore.monitorMode(this)) {
            "route" -> DestinationStore.orderedItineraryStops(this, destinations, DestinationStore.activeItinerary(this))
                .getOrNull(DestinationStore.itineraryIndex(this))?.let(::listOf).orEmpty()
            else -> destinations.filter { it.id == DestinationStore.selectedDestinationId(this) && it.enabled }
        }
        val nearTarget = location != null && activeTargets.any {
            ProximityEngine.distanceMeters(location.latitude, location.longitude, it.latitude, it.longitude) <= 1_000
        }
        val moving = location?.let { (it.hasSpeed() && it.speed >= 1.2f) || stationaryUpdates < 3 } ?: true

        val intervalMs: Long
        val highAccuracy: Boolean
        val railNavigationAvailable = StationNavigationStore.hasStations(this) && StationNavigationStore.hasRoutes(this)
        when (profile) {
            "precision" -> {
                // Durante navegação ferroviária, manter atualização responsiva mesmo se o
                // intervalo geral configurado for maior; fora disso, respeitar a preferência.
                intervalMs = if (railNavigationAvailable && moving) minOf(configuredMs, 5_000L) else configuredMs
                highAccuracy = true
            }
            "economy" -> {
                if (nearTarget) {
                    // Aumenta a responsividade ao se aproximar de uma parada.
                    intervalMs = minOf(configuredMs, 10_000L).coerceAtLeast(5_000L)
                    highAccuracy = true
                } else if (moving && railNavigationAvailable) {
                    intervalMs = minOf(configuredMs, 10_000L).coerceAtLeast(5_000L)
                    highAccuracy = true
                } else if (moving) {
                    intervalMs = maxOf(configuredMs, 20_000L)
                    highAccuracy = false
                } else {
                    intervalMs = maxOf(configuredMs, 120_000L)
                    highAccuracy = false
                }
            }
            else -> { // equilibrado
                if (nearTarget) {
                    intervalMs = minOf(configuredMs, 5_000L).coerceAtLeast(5_000L)
                    highAccuracy = true
                } else if (railNavigationAvailable && moving) {
                    intervalMs = minOf(configuredMs, 8_000L).coerceAtLeast(5_000L)
                    highAccuracy = true
                } else {
                    intervalMs = maxOf(configuredMs, 15_000L)
                    highAccuracy = false
                }
            }
        }
        requestUpdates(intervalMs, highAccuracy, force)
    }

    private fun onLocations(locations: List<android.location.Location>) {
        for (loc in locations) {
            var journeyCompleted = false
            val previousPolicyLocation = lastLocationForPolicy
            if (previousPolicyLocation != null && loc.accuracyOrDefault() <= 50f && previousPolicyLocation.accuracyOrDefault() <= 50f) {
                val movedMeters = ProximityEngine.distanceMeters(
                    previousPolicyLocation.latitude, previousPolicyLocation.longitude, loc.latitude, loc.longitude
                )
                if ((loc.hasSpeed() && loc.speed >= 1.2f) || movedMeters >= 30.0) stationaryUpdates = 0
                else if ((!loc.hasSpeed() || loc.speed < 0.8f) && movedMeters < 25.0) stationaryUpdates++
            }
            lastLocationForPolicy = loc
            DestinationStore.saveLastLocation(this, loc.latitude, loc.longitude)
            // A cada posição do monitoramento, reposiciona a sequência ferroviária a partir do GPS atual.
            // Assim, iniciar no meio do trajeto não depende de contar estações desde o início do serviço.
            val stationResult = runCatching { StationNavigationStore.locate(this, loc) }.getOrNull()
            DestinationStore.saveStationNavigation(this, stationResult)
            if (DestinationStore.snoozed(this)) engine.reset()
            val activeRoute = DestinationStore.activeItinerary(this)
            val routeMode = DestinationStore.monitorMode(this) == "route"
            if (routeMode) {
                val routePrefs = getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
                if (!routePrefs.getBoolean(DestinationStore.KEY_ROUTE_START_SET, false)) {
                    routePrefs.edit()
                        .putString(DestinationStore.KEY_ACTIVE_ITINERARY, activeRoute)
                        .putFloat(DestinationStore.KEY_ROUTE_START_LATITUDE, loc.latitude.toFloat())
                        .putFloat(DestinationStore.KEY_ROUTE_START_LONGITUDE, loc.longitude.toFloat())
                        .putBoolean(DestinationStore.KEY_ROUTE_START_SET, true)
                        .apply()
                }
            }
            if (routeMode && DestinationStore.autoSkipToLaterStopEnabled(this) && !activeRoute.isNullOrBlank()) {
                // Permite recuperar uma parada posterior quando o usuário ignora etapas,
                // mas exige leituras consistentes para evitar saltos causados por um único
                // ponto GPS ruim. A proximidade pode ser confirmada pelo raio da parada ou
                // por uma vantagem clara de distância em relação à parada atual.
                val stops = DestinationStore.orderedItineraryStops(this, destinations, activeRoute)
                val currentIndex = DestinationStore.itineraryIndex(this).coerceIn(0, stops.size)
                val currentStop = stops.getOrNull(currentIndex)
                val accuracy = loc.accuracyOrDefault()
                var candidateIndex: Int? = null
                var candidateDistance: Double? = null
                var candidateInsideRadius = false

                if (currentStop != null && currentIndex + 1 < stops.size && accuracy <= 75f) {
                    val currentDistance = ProximityEngine.distanceMeters(
                        loc.latitude, loc.longitude, currentStop.latitude, currentStop.longitude
                    )
                    // Não abandona a parada atual enquanto ainda estamos dentro do seu raio.
                    if (currentDistance > currentStop.radiusMeters) {
                        val candidates = (currentIndex + 1 until stops.size).mapNotNull { index ->
                            val stop = stops[index]
                            val distance = ProximityEngine.distanceMeters(
                                loc.latitude, loc.longitude, stop.latitude, stop.longitude
                            )
                            val gpsMargin = accuracy.coerceAtMost(75f)
                            val insideRadius = distance <= stop.radiusMeters + gpsMargin
                            // Detecta a aproximação a uma parada posterior antes de entrar no raio.
                            // A faixa é maior que o raio, mas o candidato precisa estar claramente
                            // mais perto do que a parada atual e ser confirmado por leituras coerentes.
                            val approachRange = maxOf(stop.radiusMeters * 2.0, 1_500.0)
                            val clearlyCloser = distance <= approachRange &&
                                distance + maxOf(75.0, gpsMargin.toDouble()) < currentDistance * 0.65
                            if (insideRadius || clearlyCloser) Triple(index, distance, insideRadius) else null
                        }
                        val bestCandidate = candidates.minWithOrNull(
                            compareBy<Triple<Int, Double, Boolean>> { it.second }.thenByDescending { it.first }
                        )
                        candidateIndex = bestCandidate?.first
                        candidateDistance = bestCandidate?.second
                        candidateInsideRadius = bestCandidate?.third == true
                    }
                }

                if (candidateIndex != null && candidateDistance != null) {
                    if (laterStopCandidateIndex == candidateIndex) {
                        val previousDistance = laterStopCandidateLastDistance
                        laterStopCandidateReadings++
                        // Tolera pequenas oscilações de GPS, mas não confirma se a distância
                        // piora continuamente; exige progresso real quando ainda fora do raio.
                        if (previousDistance != null && candidateDistance > previousDistance + maxOf(25.0, accuracy.toDouble())) {
                            laterStopCandidateReadings = 1
                            laterStopCandidateFirstDistance = candidateDistance
                        }
                        laterStopCandidateLastDistance = candidateDistance
                    } else {
                        laterStopCandidateIndex = candidateIndex
                        laterStopCandidateReadings = 1
                        laterStopCandidateFirstDistance = candidateDistance
                        laterStopCandidateLastDistance = candidateDistance
                    }
                    val firstDistance = laterStopCandidateFirstDistance ?: candidateDistance
                    val progressed = firstDistance - candidateDistance >= maxOf(20.0, accuracy.toDouble() * 0.5)
                    // Dentro do raio, a proximidade basta após duas leituras. Fora dele, exige
                    // três leituras consistentes e evidência de aproximação à parada posterior.
                    val confirmed = if (candidateInsideRadius) laterStopCandidateReadings >= 2
                        else laterStopCandidateReadings >= 3 && progressed
                    if (confirmed) {
                        DestinationStore.setItineraryIndex(this, candidateIndex)
                        engine.reset()
                        laterStopCandidateIndex = null
                        laterStopCandidateReadings = 0
                        laterStopCandidateFirstDistance = null
                        laterStopCandidateLastDistance = null
                    }
                } else {
                    laterStopCandidateIndex = null
                    laterStopCandidateReadings = 0
                    laterStopCandidateFirstDistance = null
                    laterStopCandidateLastDistance = null
                }
            } else {
                laterStopCandidateIndex = null
                laterStopCandidateReadings = 0
                laterStopCandidateFirstDistance = null
                laterStopCandidateLastDistance = null
            }
            val monitored = when (DestinationStore.monitorMode(this)) {
                "route" -> {
                    val stops = DestinationStore.orderedItineraryStops(this, destinations, activeRoute)
                    listOfNotNull(stops.getOrNull(DestinationStore.itineraryIndex(this)))
                }
                else -> destinations.filter { it.id == DestinationStore.selectedDestinationId(this) && it.enabled }
            }
            val result = engine.process(
                Fix(loc.latitude, loc.longitude, if (loc.hasAccuracy()) loc.accuracy else 9999f, loc.time),
                monitored
            )
            if (!DestinationStore.snoozed(this)) {
                result.distanceTriggered.forEach { destination ->
                    alert(
                        destination.copy(message = "Ônibus: faltam cerca de ${destination.distanceAlertMeters} m para ${destination.name}"),
                        AlertKind.BUS_DISTANCE
                    )
                }
                result.triggered.forEach { destination ->
                    // Parada final: a única do roteiro sem próxima parada, ou o destino individual.
                    val isFinal = if (routeMode) {
                        DestinationStore.orderedItineraryStops(this, destinations, activeRoute).lastOrNull()?.id == destination.id
                    } else true
                    if (isFinal) journeyCompleted = true
                    alert(destination, if (destination.isBus) AlertKind.BUS_RADIUS else AlertKind.TRAIN, arrival = true, isFinal = isFinal)
                    if (!activeRoute.isNullOrBlank() && destination.itineraryName == activeRoute) {
                        DestinationStore.setItineraryIndex(this, DestinationStore.itineraryIndex(this) + 1)
                        engine.reset()
                    }
                }
            }

            val target = monitored.firstOrNull()
            val railDistanceToTarget = target?.let {
                val rail = StationNavigationStore.distanceAlongRailMeters(this, loc.latitude, loc.longitude, it.latitude, it.longitude)
                val straight = ProximityEngine.distanceMeters(loc.latitude, loc.longitude, it.latitude, it.longitude)
                // Trajeto pelos trilhos muito maior que a linha reta indica falha na malha importada
                // (lacuna, desvio improvável); nesse caso a linha reta é mais confiável.
                rail?.takeIf { r -> r <= straight * 2.5 + 2000.0 }
            }
            val etaEstimate = if (target != null) {
                if (etaTargetId != target.id) {
                    etaEstimator.resetTarget()
                    etaTargetId = target.id
                }
                val straightDistance = ProximityEngine.distanceMeters(
                    loc.latitude, loc.longitude, target.latitude, target.longitude
                )
                val distanceForEta = railDistanceToTarget?.toDouble() ?: straightDistance
                // O raio é geográfico; não o subtraímos da distância medida ao longo dos trilhos.
                etaEstimator.update(loc, distanceForEta, if (railDistanceToTarget != null) 0 else target.radiusMeters)
            } else {
                etaEstimator.reset()
                etaTargetId = null
                null
            }

            // O alerta antecipado acompanha a ETA produzida pelo estimador, em vez de
            // recalcular distância/velocidade separadamente. Assim, a condição é avaliada
            // a cada posição e não depende de velocidade instantânea >= 1,5 m/s.
            // Uma pausa breve conserva a última ETA válida; baixa confiança/ETA indisponível
            // não gera um horário inventado.
            if (!DestinationStore.snoozed(this)) {
                val leadMinutes = DestinationStore.etaAlertMinutes(this)
                val estimate = etaEstimate?.takeIf {
                    (it.confidence == EtaConfidence.NORMAL || it.confidence == EtaConfidence.PAUSED) &&
                        it.minMinutes >= 0 && it.maxMinutes >= 0
                }
                if (leadMinutes > 0 && target != null && estimate != null) {
                    val d = target
                    val geographicDistance = ProximityEngine.distanceMeters(
                        loc.latitude, loc.longitude, d.latitude, d.longitude
                    )
                    val estimatedMinutes = (estimate.minMinutes + estimate.maxMinutes) / 2.0
                    val key = "eta_alerted_${d.id}"
                    val prefs = getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
                    val alreadyAlerted = prefs.getBoolean(key, false)
                    if (geographicDistance > d.radiusMeters && estimatedMinutes <= leadMinutes && !alreadyAlerted) {
                        prefs.edit().putBoolean(key, true).apply()
                        val shownMinutes = estimatedMinutes.toInt().coerceAtLeast(1)
                        alert(
                            d.copy(message = "Tempo estimado até ${d.name}: cerca de ${formatEtaDuration(shownMinutes)}"),
                            if (d.isBus) AlertKind.BUS_DISTANCE else AlertKind.TRAIN
                        )
                    } else if (estimate.confidence == EtaConfidence.NORMAL &&
                        geographicDistance > d.radiusMeters && estimatedMinutes > leadMinutes * 1.5) {
                        // Só rearma quando uma estimativa confiável indica que o destino
                        // voltou a estar claramente mais distante do que a antecedência.
                        prefs.edit().putBoolean(key, false).apply()
                    }
                }
            }

            val routeStops = if (routeMode) {
                DestinationStore.orderedItineraryStops(this, destinations, activeRoute)
            } else emptyList()
            val finalDestinationName = if (routeMode) {
                routeStops.lastOrNull()?.name ?: "Roteiro sem paradas ativas"
            } else target?.name ?: "Aguardando destino"
            // O índice aponta para a próxima parada ainda pendente. Não somar 1:
            // isso pulava a parada que o monitoramento está acompanhando no momento.
            val nextStopName = if (routeMode) {
                routeStops.getOrNull(DestinationStore.itineraryIndex(this))?.name
                    ?: if (routeStops.isNotEmpty()) "Roteiro concluído" else "Nenhuma parada disponível"
            } else "—"

            if (routeMode) {
                val routePrefs = getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
                val routeStartLat = routePrefs.getFloat(DestinationStore.KEY_ROUTE_START_LATITUDE, loc.latitude.toFloat()).toDouble()
                val routeStartLon = routePrefs.getFloat(DestinationStore.KEY_ROUTE_START_LONGITUDE, loc.longitude.toFloat()).toDouble()
                legBudget = 1
                val routeTotalMeters = if (routeStops.isEmpty()) 0.0 else {
                    ProximityEngine.distanceMeters(routeStartLat, routeStartLon, routeStops.first().latitude, routeStops.first().longitude) +
                        routeStops.zipWithNext().sumOf { (a, b) -> legDistance(a, b) }
                }
                val routeIndex = DestinationStore.itineraryIndex(this).coerceIn(0, routeStops.size)
                val routeRemainingMeters = if (routeIndex >= routeStops.size || routeStops.isEmpty()) 0.0 else {
                    val nextStop = routeStops[routeIndex]
                    val firstLeg = if (railDistanceToTarget != null && target?.id == nextStop.id) railDistanceToTarget.toDouble()
                        else ProximityEngine.distanceMeters(loc.latitude, loc.longitude, nextStop.latitude, nextStop.longitude)
                    firstLeg + routeStops.drop(routeIndex).zipWithNext().sumOf { (a, b) -> legDistance(a, b) }
                }
                // Tempo aproximado até a parada final: distância restante ÷ velocidade de cruzeiro estimada.
                // A faixa soma 25% no limite superior para cobrir o tempo parado nas estações.
                val totalSpeed = etaEstimate?.filteredSpeedMps
                if (routeRemainingMeters > 0.0 && totalSpeed != null && totalSpeed > 0.5 && etaEstimate?.confidence != EtaConfidence.UNAVAILABLE) {
                    val totalMinutes = routeRemainingMeters / totalSpeed / 60.0
                    val totalMin = Math.round(totalMinutes).toInt().coerceAtLeast(1)
                    val totalMax = Math.round(totalMinutes * 1.25).toInt().coerceAtLeast(totalMin)
                    DestinationStore.saveRouteTotals(this, routeRemainingMeters.toInt(), totalMin, totalMax)
                } else {
                    DestinationStore.saveRouteTotals(this, routeRemainingMeters.toInt(), -1, -1)
                }
                val routeProgress = when {
                    routeStops.isEmpty() -> 0f
                    routeIndex >= routeStops.size -> 1f
                    routeTotalMeters <= 0.0 -> 0f
                    else -> ((routeTotalMeters - routeRemainingMeters) / routeTotalMeters).toFloat().coerceIn(0f, 0.99f)
                }
                if (target != null && etaEstimate != null) {
                    val etaMin = etaEstimate.minMinutes
                    val etaMax = etaEstimate.maxMinutes
                    val etaMiddle = if (etaMin >= 0 && etaMax >= 0) (etaMin + etaMax) / 2 else -1
                    DestinationStore.saveDashboard(
                        this,
                        finalDestinationName,
                        nextStopName,
                        etaEstimate.distanceMeters,
                        etaMiddle,
                        etaMin,
                        etaMax,
                        etaEstimate.confidence.storageValue,
                        if (railDistanceToTarget != null) "rail" else "straight",
                        routeProgress
                    )
                } else {
                    // Continua mostrando o destino final mesmo quando todas as paradas foram concluídas.
                    DestinationStore.saveDashboard(
                        this, finalDestinationName, nextStopName, -1, -1, -1, -1, "unavailable", "straight", routeProgress
                    )
                }
            } else if (target != null && etaEstimate != null) {
                val etaMin = etaEstimate.minMinutes
                val etaMax = etaEstimate.maxMinutes
                val etaMiddle = if (etaMin >= 0 && etaMax >= 0) (etaMin + etaMax) / 2 else -1
                DestinationStore.saveDashboard(
                    this,
                    target.name,
                    nextStopName,
                    etaEstimate.distanceMeters,
                    etaMiddle,
                    etaMin,
                    etaMax,
                    etaEstimate.confidence.storageValue,
                    if (railDistanceToTarget != null) "rail" else "straight"
                )
            }
            refreshStatusNotification()
            if (journeyCompleted) {
                finishJourney()
                return
            }
            // Só altera a requisição quando o perfil realmente muda de faixa.
            try { reconfigureLocationUpdates() } catch (_: SecurityException) { stopSelf() }
        }
    }

    private fun android.location.Location.accuracyOrDefault(): Float = if (hasAccuracy()) accuracy else 9999f

    /** Encerra o monitoramento após a parada final: desliga o GPS já e finaliza o serviço em instantes. */
    private fun finishJourney() {
        if (journeyFinished) return
        journeyFinished = true
        finishStartedAt = System.currentTimeMillis()
        if (updating) {
            runCatching { client.removeLocationUpdates(callback) }
            updating = false
        }
        DestinationStore.setMonitoringActive(this, false)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(
            1001,
            buildStatusNotification("Percurso concluído", listOf("Monitoramento encerrado automaticamente"))
        )
        finishHandler.postDelayed(finishCheck, 500L)
    }

    private fun alert(destination: Destination, kind: AlertKind, arrival: Boolean = false, isFinal: Boolean = false) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationId = destination.id.hashCode()
        val dismiss = dismissPendingIntent(notificationId)
        val snoozeIntent = Intent(this, AlertDismissReceiver::class.java).setAction(AlertDismissReceiver.ACTION_SNOOZE)
            .putExtra("notification_id", notificationId).putExtra("minutes", 5)
        val snooze = PendingIntent.getBroadcast(this, notificationId + 100000, snoozeIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = NotificationCompat.Builder(this, alertChannelId)
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setColor(androidx.core.content.ContextCompat.getColor(this, R.color.ag_notification))
            .setContentTitle(destination.name)
            .setContentText(destination.message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(destination.message))
            .setWhen(System.currentTimeMillis())
            .setShowWhen(true)
            .setOnlyAlertOnce(false)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDeleteIntent(dismiss) // deslizar para dispensar também interrompe o som
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "OK", dismiss)
            .addAction(android.R.drawable.ic_lock_idle_alarm, "Soneca 5 min", snooze)

        // Modo pop-up: a notificação continua como apoio (e abre a janela sobre a tela bloqueada);
        // quando o app tem permissão de sobreposição, a janela também abre direto, em primeiro plano.
        if (DestinationStore.alertDisplayMode(this) == DestinationStore.DISPLAY_POPUP) {
            val popupIntent = Intent(this, AlertPopupActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(AlertPopupActivity.EXTRA_TITLE, destination.name)
                .putExtra(AlertPopupActivity.EXTRA_MESSAGE, destination.message)
                .putExtra(AlertPopupActivity.EXTRA_NOTIFICATION_ID, notificationId)
            builder.setFullScreenIntent(
                PendingIntent.getActivity(
                    this, notificationId + 200000, popupIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                ),
                true
            )
            if (android.provider.Settings.canDrawOverlays(this)) {
                try { startActivity(popupIntent) } catch (e: Exception) { Log.w(TAG, "Não foi possível abrir o pop-up", e) }
            }
        }
        manager.notify(notificationId, builder.build())

        // O toque é reproduzido separadamente para respeitar a saída escolhida pelo usuário.
        // Na parada final toca uma vez só e, ao terminar, vem o áudio de percurso concluído (se ligado).
        val completionAudio: (() -> Unit)? =
            if (isFinal && DestinationStore.completionAudioEnabled(this)) {
                { RoutedAlertSound.play(this, rawRes = R.raw.percurso_concluido) }
            } else null
        RoutedAlertSound.play(this, kind = kind, forceSingle = isFinal, then = completionAudio)

        if (DestinationStore.vibrationEnabled(this)) {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(500)
            }
        }

        // Só o alerta do raio (chegada) consome o "alertar só uma vez"; avisos por distância/ETA não.
        if (destination.oneShot && arrival) disableAfterAlert(destination.id)
    }

    /** Alerta único: desativa o destino. Relê a lista salva para não sobrescrever edições recentes. */
    private fun disableAfterAlert(id: String) {
        val latest = DestinationStore.load(this)
        val updated = latest.map { if (it.id == id) it.copy(enabled = false) else it }
        DestinationStore.save(this, updated)
        destinations = updated
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(monitorChannelId, "Monitoramento", NotificationManager.IMPORTANCE_LOW)
            )
            val alerts = NotificationChannel(alertChannelId, "Alertas de proximidade", NotificationManager.IMPORTANCE_HIGH)
            alerts.description = "Alertas sonoros direcionados conforme as preferências"
            // O som do canal fica desativado porque RoutedAlertSound reproduz o toque na saída escolhida.
            alerts.setSound(null, null)
            manager.createNotificationChannel(alerts)
        }
    }

    private var lastStatusKey: String? = null

    private fun formatNotificationMinutes(minutes: Int): String {
        if (minutes < 60) return "$minutes min"
        val h = minutes / 60
        val m = minutes % 60
        return if (m == 0) "$h h" else "$h h $m min"
    }

    private fun formatNotificationDistance(meters: Int): String =
        if (meters >= 1000) String.format(java.util.Locale.getDefault(), "%.1f km", meters / 1000.0)
        else "${(meters / 50) * 50} m"

    private fun formatNotificationEta(min: Int, max: Int): String? = when {
        min < 0 || max < 0 -> null
        min == 0 && max == 0 -> "no raio"
        max > min -> "≈ ${formatNotificationMinutes(min)}–${formatNotificationMinutes(max)}"
        else -> "≈ ${formatNotificationMinutes(min)}"
    }

    /** Atualiza a notificação fixa com próxima parada, estação atual e tempo previsto (só quando o texto muda). */
    private fun refreshStatusNotification() {
        val prefs = getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
        val routeMode = DestinationStore.monitorMode(this) == "route"
        val target = prefs.getString(DestinationStore.KEY_DASH_TARGET, null)
        val next = prefs.getString(DestinationStore.KEY_DASH_NEXT, null)
        val distance = prefs.getInt(DestinationStore.KEY_DASH_DISTANCE, -1)
        val etaMin = prefs.getInt(DestinationStore.KEY_DASH_ETA_MIN, -1)
        val etaMax = prefs.getInt(DestinationStore.KEY_DASH_ETA_MAX, -1)
        val station = prefs.getString(DestinationStore.KEY_STATION_CURRENT, null)?.takeIf { it.isNotBlank() }
        val totalDistance = prefs.getInt(DestinationStore.KEY_DASH_TOTAL_DISTANCE, -1)
        val totalMin = prefs.getInt(DestinationStore.KEY_DASH_TOTAL_ETA_MIN, -1)
        val totalMax = prefs.getInt(DestinationStore.KEY_DASH_TOTAL_ETA_MAX, -1)

        // Quando a próxima parada já é a final, "próxima" e "final" seriam a mesma informação:
        // mostra uma única vez, como "Última parada", sem a linha repetida de parada final.
        val nextIsFinal = routeMode && run {
            val stops = DestinationStore.orderedItineraryStops(this, destinations, DestinationStore.activeItinerary(this))
            stops.isNotEmpty() && DestinationStore.itineraryIndex(this) == stops.lastIndex
        }
        val title = when {
            routeMode && next == "Roteiro concluído" -> "Percurso concluído"
            nextIsFinal && !next.isNullOrBlank() -> "Última parada: $next"
            routeMode && !next.isNullOrBlank() && next != "—" -> "Próxima parada: $next"
            !target.isNullOrBlank() -> "Destino: $target"
            else -> "Alerta Geográfico ativo"
        }
        val lines = mutableListOf<String>()
        if (station != null) lines += "Estação atual: $station"
        if (distance >= 0) {
            val eta = formatNotificationEta(etaMin, etaMax)
            lines += "Faltam ${formatNotificationDistance(distance)}" + (eta?.let { " · $it" } ?: "")
        }
        if (routeMode && !nextIsFinal && next != "Roteiro concluído" && !target.isNullOrBlank() && totalDistance > 0) {
            val eta = formatNotificationEta(totalMin, totalMax)
            lines += "Parada final: $target · ${formatNotificationDistance(totalDistance)}" + (eta?.let { " · $it" } ?: "")
        }
        if (lines.isEmpty()) lines += "Monitorando destinos habilitados"

        val key = title + "|" + lines.joinToString("|")
        if (key == lastStatusKey) return
        lastStatusKey = key
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(1001, buildStatusNotification(title, lines))
    }

    private fun buildStatusNotification(
        title: String = "Alerta Geográfico ativo",
        lines: List<String> = listOf("Monitorando destinos habilitados")
    ): Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val reuse = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        val openApp = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(reuse), flags)
        // "Parar" abre o app pedindo confirmação, para evitar toques acidentais.
        val stop = PendingIntent.getActivity(
            this, 3,
            Intent(this, MainActivity::class.java).addFlags(reuse).putExtra(EXTRA_CONFIRM_STOP, true),
            flags
        )
        return NotificationCompat.Builder(this, monitorChannelId)
            .setSmallIcon(R.drawable.ic_stat_monitor)
            .setColor(androidx.core.content.ContextCompat.getColor(this, R.color.ag_notification))
            .setContentTitle(title)
            .setContentText(lines.joinToString(" • "))
            .setStyle(NotificationCompat.BigTextStyle().bigText(lines.joinToString("\n")))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(openApp)
            .addAction(R.drawable.ic_ui_stop, "Parar", stop)
            .build()
    }

    override fun onDestroy() {
        finishHandler.removeCallbacks(finishCheck)
        if (::client.isInitialized && ::callback.isInitialized) client.removeLocationUpdates(callback)
        getSharedPreferences(DestinationStore.PREFS, Context.MODE_PRIVATE)
            .unregisterOnSharedPreferenceChangeListener(prefsListener)
        // Parada normal (usuário ou stopSelf): marca como inativo. Se o processo for morto pelo sistema,
        // onDestroy não roda, o flag continua verdadeiro e o START_STICKY reinicia o serviço.
        DestinationStore.setMonitoringActive(this, false)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "LocationMonitor"
        // Após concluir o percurso, a notificação fixa some em até 5 s e o serviço encerra em seguida;
        // só o áudio final pode prolongar um pouco a vida do serviço (limite de segurança).
        private const val FINISH_FOREGROUND_MS = 5_000L
        private const val FINISH_AUDIO_MAX_MS = 30_000L
        const val ACTION_STOP = "br.com.alertageografico.action.STOP"
        const val EXTRA_CONFIRM_STOP = "br.com.alertageografico.extra.CONFIRM_STOP"
    }
}
