package br.com.alertageografico

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.alertageografico.ui.AgTheme

/**
 * Alerta em janela (alternativa à notificação): aparece em primeiro plano, inclusive sobre a tela
 * bloqueada, e oferece as mesmas ações da notificação: OK, Soneca 5 min e abrir o app.
 */
class AlertPopupActivity : ComponentActivity() {
    private var title by mutableStateOf("")
    private var message by mutableStateOf("")
    private var notificationId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        readIntent(intent)
        setContent {
            AgTheme {
                // Voltar equivale a OK: confirma o alerta e para o som.
                BackHandler { confirm() }
                Box(
                    Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)).padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(title, style = MaterialTheme.typography.headlineSmall)
                            Text(message, style = MaterialTheme.typography.bodyLarge)
                            Button(onClick = { confirm() }, modifier = Modifier.fillMaxWidth()) { Text("OK") }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(onClick = { snooze() }, modifier = Modifier.weight(1f)) { Text("Soneca 5 min") }
                                TextButton(onClick = { openApp() }, modifier = Modifier.weight(1f)) { Text("Abrir app") }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    private fun readIntent(intent: Intent?) {
        title = intent?.getStringExtra(EXTRA_TITLE).orEmpty()
        message = intent?.getStringExtra(EXTRA_MESSAGE).orEmpty()
        notificationId = intent?.getIntExtra(EXTRA_NOTIFICATION_ID, -1) ?: -1
    }

    // A confirmação passa pelo mesmo receptor da notificação (para o som e remove a notificação).
    private fun confirm() {
        sendBroadcast(Intent(this, AlertDismissReceiver::class.java).putExtra("notification_id", notificationId))
        finish()
    }

    private fun snooze() {
        sendBroadcast(
            Intent(this, AlertDismissReceiver::class.java).setAction(AlertDismissReceiver.ACTION_SNOOZE)
                .putExtra("notification_id", notificationId).putExtra("minutes", 5)
        )
        finish()
    }

    private fun openApp() {
        sendBroadcast(Intent(this, AlertDismissReceiver::class.java).putExtra("notification_id", notificationId))
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }

    companion object {
        const val EXTRA_TITLE = "br.com.alertageografico.extra.POPUP_TITLE"
        const val EXTRA_MESSAGE = "br.com.alertageografico.extra.POPUP_MESSAGE"
        const val EXTRA_NOTIFICATION_ID = "br.com.alertageografico.extra.POPUP_NOTIFICATION_ID"
    }
}
