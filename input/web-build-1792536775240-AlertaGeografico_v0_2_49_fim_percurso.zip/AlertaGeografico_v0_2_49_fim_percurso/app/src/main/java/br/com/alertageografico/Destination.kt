package br.com.alertageografico

import org.json.JSONObject
import java.util.UUID

/** Tipo de transporte do destino: define raio padrão e quais alertas sonoros existem. */
object TransportType {
    const val TRAIN = "train"
    const val BUS = "bus"
    const val DEFAULT_TRAIN_RADIUS = 300
    const val DEFAULT_BUS_RADIUS = 60
    const val DEFAULT_BUS_DISTANCE_ALERT = 300

    fun normalize(value: String?): String = if (value == BUS) BUS else TRAIN
    fun label(value: String?): String = if (value == BUS) "Ônibus" else "Trem/Metrô"
    fun defaultRadius(value: String?): Int = if (value == BUS) DEFAULT_BUS_RADIUS else DEFAULT_TRAIN_RADIUS
}

/** Qual som tocar: um por tipo de transporte; o ônibus tem dois (distância e raio). */
enum class AlertKind { TRAIN, BUS_RADIUS, BUS_DISTANCE }

data class Destination(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val radiusMeters: Int = 300,
    val message: String = "Você está chegando ao destino",
    val enabled: Boolean = true,
    val itineraryName: String? = null,
    /** Se verdadeiro, o destino é desativado automaticamente após o primeiro alerta. */
    val oneShot: Boolean = false,
    /** Nome legível do local/endereço informado pelo usuário. */
    val locationLabel: String? = null,
    /** Emoji escolhido pelo usuário para identificar visualmente o destino. */
    val icon: String = "📍",
    /** "train" (trem/metrô) ou "bus" (ônibus). Destinos antigos, sem o campo, contam como trem/metrô. */
    val transportType: String = TransportType.TRAIN,
    /** Só para ônibus: distância (m) do aviso antecipado, anterior à entrada no raio. */
    val distanceAlertMeters: Int = TransportType.DEFAULT_BUS_DISTANCE_ALERT,
    /** Comentário curto da parada. Aparece só em Roteiros e Destinos cadastrados; nunca no painel. */
    val comment: String = ""
) {
    val isBus: Boolean get() = transportType == TransportType.BUS

    /** O aviso por distância só existe para ônibus e só faz sentido se for maior que o raio. */
    val hasDistanceAlert: Boolean get() = isBus && distanceAlertMeters > radiusMeters

    fun toJson() = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("latitude", latitude)
        put("longitude", longitude)
        put("radiusMeters", radiusMeters)
        put("message", message)
        put("enabled", enabled)
        put("itineraryName", itineraryName)
        put("oneShot", oneShot)
        put("locationLabel", locationLabel)
        put("icon", icon)
        put("transportType", transportType)
        put("distanceAlertMeters", distanceAlertMeters)
        put("comment", comment)
    }

    companion object {
        const val COMMENT_MAX_LENGTH = 80
        fun fromJson(o: JSONObject) = Destination(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.getString("name"),
            latitude = o.getDouble("latitude"),
            longitude = o.getDouble("longitude"),
            radiusMeters = o.optInt("radiusMeters", 300),
            message = o.optString("message", "Você está chegando ao destino"),
            enabled = o.optBoolean("enabled", true),
            itineraryName = o.optString("itineraryName", "").takeIf { it.isNotBlank() && it != "null" },
            oneShot = o.optBoolean("oneShot", false),
            locationLabel = o.optString("locationLabel", "").takeIf { it.isNotBlank() && it != "null" },
            icon = o.optString("icon", "📍").ifBlank { "📍" },
            transportType = TransportType.normalize(o.optString("transportType", TransportType.TRAIN)),
            distanceAlertMeters = o.optInt("distanceAlertMeters", TransportType.DEFAULT_BUS_DISTANCE_ALERT),
            comment = o.optString("comment", "").take(Destination.COMMENT_MAX_LENGTH)
        )
    }
}
