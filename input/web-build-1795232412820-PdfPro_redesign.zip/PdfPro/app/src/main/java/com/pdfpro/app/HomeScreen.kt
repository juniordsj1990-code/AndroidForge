@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pdfpro.app

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var mergeList by remember { mutableStateOf<List<Uri>?>(null) }
    var camList by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var camPending by remember { mutableStateOf<Uri?>(null) }
    var camDialog by remember { mutableStateOf(false) }

    val openPdf = rememberLauncherForActivityResult(OpenPdfContract()) { uri ->
        if (uri != null) vm.open(uri)
    }
    val mergePick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l ->
        if (l.size >= 2) mergeList = l else if (l.isNotEmpty()) vm.message = "Escolha pelo menos 2 PDFs"
    }
    val imgPick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { l ->
        if (l.isNotEmpty()) vm.imagesToPdf(l)
    }
    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) camPending?.let { camList = camList + it }
        if (camList.isNotEmpty()) camDialog = true
    }

    fun shoot() {
        val dir = File(ctx.cacheDir, "cam").apply { mkdirs() }
        val f = File(dir, "foto_${System.nanoTime()}.jpg")
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        camPending = uri
        camLauncher.launch(uri)
    }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 32.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(
                                Brush.linearGradient(listOf(PdfColors.Brand, PdfColors.BrandDeep))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.PictureAsPdf, null, Modifier.size(26.dp), tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("PDF Pro", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            "Leitor e editor, 100% offline",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
            item {
                HeroCard {
                    openPdf.launch(arrayOf("application/pdf"))
                }
                Spacer(Modifier.height(12.dp))
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ToolTile(Icons.Default.Layers, "Mesclar", "PDFs", Modifier.weight(1f)) {
                        mergePick.launch(arrayOf("application/pdf"))
                    }
                    ToolTile(Icons.Default.Image, "Imagens", "para PDF", Modifier.weight(1f)) {
                        imgPick.launch("image/*")
                    }
                    ToolTile(Icons.Default.PhotoCamera, "Foto", "para PDF", Modifier.weight(1f)) {
                        camList = emptyList()
                        shoot()
                    }
                }
                Spacer(Modifier.height(28.dp))
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Recentes", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    if (vm.recents.isNotEmpty()) {
                        Text(
                            "${vm.recents.size}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            if (vm.recents.isEmpty()) {
                item { EmptyRecents() }
            } else {
                items(vm.recents, key = { it.uri }) { r ->
                    RecentRow(
                        name = r.name,
                        page = r.page,
                        onOpen = { vm.open(Uri.parse(r.uri)) },
                        onRemove = { vm.removeRecent(r.uri) }
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }

    mergeList?.let { MergeDialog(vm, it) { mergeList = null } }

    if (camDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { camDialog = false; camList = emptyList() },
            title = { Text("${camList.size} foto(s) adicionada(s)") },
            text = { Text("Quer fotografar mais páginas ou criar o PDF agora?") },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    camDialog = false
                    val l = camList
                    camList = emptyList()
                    vm.imagesToPdf(l)
                }) { Text("Criar PDF") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = {
                    camDialog = false
                    shoot()
                }) { Text("Outra foto") }
            }
        )
    }
}

@Composable
private fun HeroCard(onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(PdfColors.Brand, PdfColors.BrandDeep)))
            .clickable(onClick = onClick)
    ) {
        // detalhe gráfico: folha com dobra, ao fundo
        Canvas(Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            val p = Path().apply {
                moveTo(w * 0.70f, -h * 0.10f)
                lineTo(w * 1.02f, -h * 0.10f)
                lineTo(w * 1.02f, h * 1.10f)
                lineTo(w * 0.78f, h * 1.10f)
                close()
            }
            drawPath(p, Color.White.copy(alpha = 0.07f))
            drawCircle(Color.White.copy(alpha = 0.06f), radius = h * 0.55f, center = Offset(w * 0.92f, h * 0.15f))
        }
        Row(
            Modifier.padding(horizontal = 22.dp, vertical = 24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Abrir PDF",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Escolha um arquivo do aparelho",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.82f)
                )
            }
            Box(
                Modifier.size(52.dp).clip(CircleShape).background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.FolderOpen, null, Modifier.size(26.dp), tint = PdfColors.BrandDeep)
            }
        }
    }
}

@Composable
private fun ToolTile(icon: ImageVector, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 16.dp)) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(12.dp))
            Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1)
            Text(
                sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun PdfBadge() {
    Box(
        Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "PDF",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
private fun RecentRow(name: String, page: Int, onOpen: () -> Unit, onRemove: () -> Unit) {
    Surface(
        onClick = onOpen,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PdfBadge()
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    name.removeSuffix(".pdf").removeSuffix(".PDF"),
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "parou na página ${page + 1}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onRemove) {
                Icon(
                    Icons.Default.Close,
                    "Remover",
                    Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun EmptyRecents() {
    val line = MaterialTheme.colorScheme.outlineVariant
    val fill = MaterialTheme.colorScheme.surfaceContainerLowest
    val accent = MaterialTheme.colorScheme.primary
    Column(
        Modifier.fillMaxWidth().padding(vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(Modifier.size(width = 84.dp, height = 104.dp)) {
            val w = size.width
            val h = size.height
            val fold = w * 0.30f
            val page = Path().apply {
                moveTo(0f, 0f)
                lineTo(w - fold, 0f)
                lineTo(w, fold)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(page, fill)
            drawPath(page, line, style = Stroke(width = 3f, join = StrokeJoin.Round))
            val corner = Path().apply {
                moveTo(w - fold, 0f)
                lineTo(w - fold, fold)
                lineTo(w, fold)
                close()
            }
            drawPath(corner, line)
            val ys = listOf(0.52f, 0.64f, 0.76f)
            val ws = listOf(0.70f, 0.70f, 0.42f)
            ys.forEachIndexed { i, y ->
                drawLine(
                    if (i == 0) accent else line,
                    Offset(w * 0.15f, h * y),
                    Offset(w * (0.15f + ws[i] * 0.85f), h * y),
                    strokeWidth = 6f,
                    cap = StrokeCap.Round
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("Nada por aqui ainda", style = MaterialTheme.typography.titleSmall)
        Text(
            "Os PDFs que você abrir aparecem aqui.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
