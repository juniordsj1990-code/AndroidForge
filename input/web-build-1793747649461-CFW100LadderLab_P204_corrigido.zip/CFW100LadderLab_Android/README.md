# CFW100 + Ladder Lab — Android Studio

Projeto Android nativo (Java) que empacota o simulador HTML original em uma WebView.

## Abrir
1. Extraia o ZIP.
2. Abra a pasta `CFW100LadderLab_Android` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute em um dispositivo/emulador Android (minSdk 23).

## Recursos incluídos
- Simulador original CFW100 + Ladder Lab em `app/src/main/assets/index.html`.
- Ícone personalizado e tela de carregamento nativa.
- Seleção de arquivos `.ladlab` e `.invsim` pelo seletor Android.
- Salvamento `.invsim` pelo seletor de documentos do Android.
- Saída com dois toques em Voltar dentro de 2 segundos.
- Ajuste de parâmetros pela navegação e teclas ▲/▼ da HMI simulada.

## Observações técnicas
- O simulador continua sendo didático; não é conexão física com o inversor e não substitui o manual WEG.
- A lista de parâmetros continua sendo a seleção cadastrada no HTML de origem, não o conjunto completo de parâmetros do CFW100. A lista deve ser ampliada e conferida com a versão de firmware desejada.
- Para compilar, o Android Studio precisará baixar o Android Gradle Plugin e o SDK Platform 35.
