package br.com.alertageografico.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Identidade visual única do app, derivada do ícone: fundo azul-marinho,
 * pino vermelho (alerta), anéis verdes (raio) e azul para rotas.
 * Tema escuro de baixo brilho, como já era a intenção do app.
 */
object AG {
    val Navy900 = Color(0xFF0A1220)      // fundo
    val Navy800 = Color(0xFF101A2C)      // superfície
    val Navy700 = Color(0xFF16233A)      // cartões
    val Navy600 = Color(0xFF1D2D49)      // cartões elevados
    val Navy500 = Color(0xFF263A5C)      // realces
    val Line = Color(0xFF2A3C5C)         // bordas
    val Blue = Color(0xFF5B9DFF)         // primária / rotas
    val BlueDeep = Color(0xFF123A6B)
    val Green = Color(0xFF3DD6A0)        // monitoramento ativo / raio
    val GreenDeep = Color(0xFF0F3B33)
    val Red = Color(0xFFFF5A5F)          // alerta / parar
    val RedDeep = Color(0xFF4A1C24)
    val Amber = Color(0xFFFFC857)        // aviso
    val TextHigh = Color(0xFFE8EEF8)
    val TextMid = Color(0xFFA3B4CE)
    val TextLow = Color(0xFF6F819E)
}

private val AgColors = darkColorScheme(
    primary = AG.Blue,
    onPrimary = Color(0xFF05203F),
    primaryContainer = AG.BlueDeep,
    onPrimaryContainer = Color(0xFFD8E8FF),
    secondary = AG.Amber,
    onSecondary = Color(0xFF3A2A00),
    secondaryContainer = Color(0xFF4A3A10),
    onSecondaryContainer = Color(0xFFFFE3A3),
    tertiary = AG.Green,
    onTertiary = Color(0xFF04281F),
    tertiaryContainer = AG.GreenDeep,
    onTertiaryContainer = Color(0xFFB8F2DE),
    error = AG.Red,
    onError = Color(0xFF3F0A0D),
    errorContainer = AG.RedDeep,
    onErrorContainer = Color(0xFFFFD9DA),
    background = AG.Navy900,
    onBackground = AG.TextHigh,
    surface = AG.Navy800,
    onSurface = AG.TextHigh,
    surfaceVariant = AG.Navy600,
    onSurfaceVariant = AG.TextMid,
    outline = AG.Line,
    outlineVariant = Color(0xFF1F2F4B),
    surfaceContainerLowest = AG.Navy900,
    surfaceContainerLow = AG.Navy800,
    surfaceContainer = AG.Navy700,
    surfaceContainerHigh = Color(0xFF1A2942),
    surfaceContainerHighest = AG.Navy600,
    inverseSurface = AG.TextHigh,
    inverseOnSurface = AG.Navy900,
    scrim = Color(0xFF000000)
)

private val base = Typography()
private val Sans = FontFamily.SansSerif

private val AgTypography = Typography(
    displayLarge = base.displayLarge.copy(fontFamily = Sans, fontWeight = FontWeight.Bold),
    displayMedium = base.displayMedium.copy(fontFamily = Sans, fontWeight = FontWeight.Bold),
    displaySmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 36.sp, lineHeight = 40.sp, letterSpacing = (-0.5).sp),
    headlineLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.3).sp),
    headlineMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 32.sp, letterSpacing = (-0.2).sp),
    headlineSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = (-0.1).sp),
    titleLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp, letterSpacing = 0.1.sp),
    titleSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp),
    bodyLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp, letterSpacing = 0.2.sp),
    bodyMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.2.sp),
    bodySmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp, letterSpacing = 0.2.sp),
    labelLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.2.sp),
    labelMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.4.sp),
    labelSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, lineHeight = 16.sp, letterSpacing = 1.0.sp)
)

private val AgShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun AlertaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AgColors,
        typography = AgTypography,
        shapes = AgShapes,
        content = content
    )
}
