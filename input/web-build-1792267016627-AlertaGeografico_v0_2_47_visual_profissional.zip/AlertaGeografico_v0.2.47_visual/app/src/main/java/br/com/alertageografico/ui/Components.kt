package br.com.alertageografico.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Map as FilledMap
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.outlined.AddLocationAlt as OutAddLocationAlt
import androidx.compose.material.icons.outlined.AltRoute as OutAltRoute
import androidx.compose.material.icons.outlined.Help as OutHelp
import androidx.compose.material.icons.outlined.Home as OutHome
import androidx.compose.material.icons.outlined.Info as OutInfo
import androidx.compose.material.icons.outlined.Place as OutPlace
import androidx.compose.material.icons.outlined.Settings as OutSettings
import androidx.compose.material.icons.outlined.Train as OutTrain
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Desenha a marca (pino com sino + anéis de raio) num espaço de 108 x 108. */
private fun DrawScope.drawLogo(ringPhase: Float, withBackground: Boolean) {
    val s = size.minDimension / 108f
    scale(scale = s, pivot = Offset.Zero) {
        if (withBackground) {
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFF14233F), Color(0xFF0A1428))),
                size = Size(108f, 108f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(26f, 26f)
            )
        }
        // anéis do raio de alerta
        if (ringPhase > 0f) {
            val rx = 22f + 16f * ringPhase
            val ry = 9f + 6.5f * ringPhase
            drawOval(
                color = AG.Green.copy(alpha = (1f - ringPhase) * 0.55f),
                topLeft = Offset(54f - rx, 72f - ry),
                size = Size(rx * 2, ry * 2),
                style = Stroke(width = 1.6f)
            )
        }
        drawOval(
            color = AG.GreenDeep.copy(alpha = 0.85f),
            topLeft = Offset(32f, 63f), size = Size(44f, 18f)
        )
        drawOval(
            color = AG.Green, topLeft = Offset(32f, 63f), size = Size(44f, 18f),
            style = Stroke(width = 2.2f)
        )
        drawOval(
            color = AG.Green.copy(alpha = 0.9f), topLeft = Offset(40f, 66.2f), size = Size(28f, 11.6f),
            style = Stroke(width = 1.8f)
        )
        drawOval(color = AG.Green, topLeft = Offset(48f, 69.4f), size = Size(12f, 5.2f))

        // pino
        val pin = Path().apply {
            moveTo(54f, 74f)
            cubicTo(54f, 74f, 37f, 55f, 37f, 40f)
            arcTo(Rect(37f, 23f, 71f, 57f), 180f, 180f, false)
            cubicTo(71f, 55f, 54f, 74f, 54f, 74f)
            close()
        }
        drawPath(
            pin,
            brush = Brush.verticalGradient(
                listOf(Color(0xFFFF6A55), Color(0xFFE01428)), startY = 23f, endY = 74f
            )
        )
        // sino
        val bell = Path().apply {
            moveTo(54f, 31.5f)
            cubicTo(48.5f, 31.5f, 46.5f, 36f, 46.5f, 40f)
            cubicTo(46.5f, 43f, 45f, 44.5f, 43.5f, 46f)
            lineTo(64.5f, 46f)
            cubicTo(63f, 44.5f, 61.5f, 43f, 61.5f, 40f)
            cubicTo(61.5f, 36f, 59.5f, 31.5f, 54f, 31.5f)
            close()
        }
        drawPath(bell, color = Color.White)
        drawCircle(Color.White, radius = 1.6f, center = Offset(54f, 30.2f))
        drawCircle(Color.White, radius = 2.1f, center = Offset(54f, 48.6f))
        val left = Path().apply {
            moveTo(43f, 34.5f); cubicTo(41f, 36.5f, 41f, 41f, 43f, 43f)
        }
        val right = Path().apply {
            moveTo(65f, 34.5f); cubicTo(67f, 36.5f, 67f, 41f, 65f, 43f)
        }
        drawPath(left, Color.White, style = Stroke(width = 1.5f, cap = StrokeCap.Round))
        drawPath(right, Color.White, style = Stroke(width = 1.5f, cap = StrokeCap.Round))
    }
}

/** Marca estática do app. */
@Composable
fun AgLogo(size: Dp, modifier: Modifier = Modifier, withBackground: Boolean = false) {
    Canvas(modifier.size(size)) { drawLogo(0f, withBackground) }
}

/** Marca com onda de "radar" saindo do anel — usada na abertura. */
@Composable
fun AgLogoRadar(size: Dp, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "radar")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing)),
        label = "radarPhase"
    )
    Canvas(modifier.size(size)) { drawLogo(phase, false) }
}

/** Ponto de status com pulso suave quando [pulsing]. */
@Composable
fun StatusDot(color: Color, pulsing: Boolean, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "dot")
    val p by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing)),
        label = "dotPulse"
    )
    Canvas(modifier.size(14.dp)) {
        val c = center
        if (pulsing) {
            drawCircle(color.copy(alpha = (1f - p) * 0.45f), radius = size.minDimension / 2f * (0.5f + p * 0.5f), center = c)
        }
        drawCircle(color, radius = size.minDimension * 0.2f, center = c)
    }
}

/** Cartão padrão: fundo em camada, borda sutil, cantos generosos. */
@Composable
fun AgCard(
    modifier: Modifier = Modifier,
    container: Color = MaterialTheme.colorScheme.surfaceContainer,
    borderColor: Color = MaterialTheme.colorScheme.outlineVariant,
    padding: Dp = 18.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = container),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(padding),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

/** Rótulo de seção em caixa-alta, discreto. */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier = modifier,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

/** Selo de estado (ex.: ATIVO / EM ESPERA). */
@Composable
fun StatusPill(text: String, color: Color, pulsing: Boolean = false, modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(50))
            .padding(start = 6.dp, end = 12.dp, top = 3.dp, bottom = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StatusDot(color, pulsing)
        Spacer(Modifier.width(2.dp))
        Text(text, style = MaterialTheme.typography.labelSmall, color = color)
    }
}

/** Número grande com rótulo e legenda — usado para distância e tempo. */
@Composable
fun MetricBlock(label: String, value: String, caption: String?, modifier: Modifier = Modifier, highlight: Boolean = false) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        SectionLabel(label)
        Text(
            value,
            style = (if (value.length <= 11) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleMedium)
                .copy(fontFeatureSettings = "tnum"),
            color = if (highlight) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface,
            maxLines = 2
        )
        if (caption != null) Text(caption, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Seletor segmentado simples (substitui os RadioButtons). */
@Composable
fun AgSegmented(
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEach { option ->
            val isSel = option == selected
            Box(
                Modifier
                    .weight(1f)
                    .height(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                    .clickable(enabled = enabled) { onSelect(option) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    option,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isSel) MaterialTheme.colorScheme.onPrimaryContainer
                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (enabled) 1f else 0.5f)
                )
            }
        }
    }
}

/** Botão principal de iniciar/parar: verde para iniciar, vermelho contido para parar. */
@Composable
fun MonitorButton(running: Boolean, icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val colors = if (running) ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.errorContainer,
        contentColor = MaterialTheme.colorScheme.onErrorContainer
    ) else ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.tertiary,
        contentColor = MaterialTheme.colorScheme.onTertiary
    )
    Button(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(56.dp),
        shape = RoundedCornerShape(18.dp),
        colors = colors,
        border = if (running) BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f)) else null
    ) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(10.dp))
        Text(
            if (running) "Parar monitoramento" else "Iniciar monitoramento",
            style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp)
        )
    }
}

/** Estado vazio com ilustração leve e ação. */
@Composable
fun EmptyState(title: String, message: String, actionLabel: String?, onAction: () -> Unit, modifier: Modifier = Modifier) {
    AgCard(modifier) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AgLogo(64.dp)
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (actionLabel != null) Button(onClick = onAction, shape = RoundedCornerShape(14.dp)) { Text(actionLabel) }
        }
    }
}


/** Ícones usados fora deste arquivo (evita conflito de nomes, ex.: Map). */
object AgIcons {
    val Map: ImageVector get() = Icons.Filled.FilledMap
    val Play: ImageVector get() = Icons.Filled.PlayArrow
    val Stop: ImageVector get() = Icons.Filled.Stop
    val Train: ImageVector get() = Icons.Filled.Train
}

/** Ícone do menu lateral: contornado quando solto, preenchido quando selecionado. */
fun drawerIcon(section: String, selected: Boolean): ImageVector = when (section) {
    "Início" -> if (selected) Icons.Filled.Home else Icons.Outlined.OutHome
    "Adicionar destino" -> if (selected) Icons.Filled.AddLocationAlt else Icons.Outlined.OutAddLocationAlt
    "Destinos cadastrados" -> if (selected) Icons.Filled.Place else Icons.Outlined.OutPlace
    "Roteiros" -> if (selected) Icons.Filled.AltRoute else Icons.Outlined.OutAltRoute
    "Estações" -> if (selected) Icons.Filled.Train else Icons.Outlined.OutTrain
    "Preferências" -> if (selected) Icons.Filled.Settings else Icons.Outlined.OutSettings
    "Ajuda" -> if (selected) Icons.Filled.Help else Icons.Outlined.OutHelp
    else -> if (selected) Icons.Filled.Info else Icons.Outlined.OutInfo
}

/** Campo de seleção que abre um menu (aparência de campo, não de botão). */
@Composable
fun AgSelectField(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
    ) {
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, maxLines = 1)
        Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Número + rótulo em bloco compacto (resumo da tela inicial). */
@Composable
fun StatTile(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(value, style = MaterialTheme.typography.headlineMedium.copy(fontFeatureSettings = "tnum"), color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Linha do tempo vertical: anterior → atual → próxima estação. */
@Composable
fun StationTimeline(previous: String?, current: String, next: String?, modifier: Modifier = Modifier) {
    @Composable
    fun node(label: String, name: String, active: Boolean, last: Boolean) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(16.dp)) {
                Box(
                    Modifier
                        .padding(top = 4.dp)
                        .size(if (active) 14.dp else 10.dp)
                        .clip(CircleShape)
                        .background(if (active) AG.Green else AG.Navy500)
                        .border(2.dp, if (active) AG.GreenDeep else AG.Line, CircleShape)
                )
                if (!last) Box(Modifier.width(2.dp).height(26.dp).background(AG.Line))
            }
            Column(Modifier.padding(bottom = if (last) 0.dp else 8.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, color = if (active) AG.Green else MaterialTheme.colorScheme.onSurfaceVariant)
                Text(name, style = if (active) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge)
            }
        }
    }
    Column(modifier) {
        node("Anterior", previous ?: "Não identificada", false, false)
        node("Atual estimada", current, true, false)
        node("Próxima", next ?: "Não identificada", false, true)
    }
}
